# 我的群友难鱼 · 项目约定

用户于 2026-09-30 要求：记录本项目的发布方式，后续需要更新网站时继续按同一流程执行。发布前先读 [发布流程](tools/deploy/README.md)。这些指引仅适用于本项目；纯记录或文档维护不触发部署。

## 固定发布目标

- 私有源码：`HardFishDev/MyHardFish-web`，主分支 `main`。
- 公开产物：`HardFishDev/MyHardFish-web-public`，发布分支 `main`、根目录。
- 游戏地址：`https://hardfishdev.github.io/MyHardFish-web-public/`。
- 流水线：`.github/workflows/publish-pages.yml`；发布器：`tools/deploy/publish.mjs`。

## 后续更新遵循的流程

1. 完成代码修改及对应测试，检查暂存文件；只向私有仓库提交源码、配置、测试代码和运行素材。遵守 `.gitignore`，不提交测试运行产物、截图、报告、原始聊天导出、研究文件或凭据。
2. 优先推送私有仓库 `main`，让同一次 GitHub Actions 运行完成测试、构建、产物检查和公开仓库发布；PR 仅验证。
3. 发布凭据使用私有源码仓库的项目级 Secret `PAGES_DEPLOY_TOKEN`，仅提供给发布步骤。用户提供的 key 只用于本项目；不配置到全局 Git/GitHub、组织共享 Secret、公开仓库、提交、远程 URL 或日志中。文档不记录密钥值。
4. 自动发布受阻时，先确认实际原因与当前 Secret 状态。首次发布的 403 是带日期的历史记录，不能直接当成后续现状，也不能把构建成功当成发布成功。
5. 确需本地补发时，沿用现有发布器；从明确的源码提交重新构建，用对应的完整 SHA 作为 `SOURCE_COMMIT`。禁止将旧 `dist/` 配上新的提交 SHA。凭据只通过临时安全环境注入，使用后清理。
6. 公开仓库只接收经检查的运行产物、许可、`.nojekyll`、`deployment.json` 和已有有效 `CNAME`；正常推送，不强制覆盖历史。未取得完整自有域名及 DNS 配置前，保留默认 Pages 地址。
7. 确认公开仓库的 Pages 部署成功，再核对线上 `deployment.json` 的源码 SHA、运行文件哈希和实际页面。按改动范围验证桌面、手机及受影响的交互；本地结果留在仓库外或被忽略的目录。

当前 Actions 构建产物保留 3 天；产物过期后需重新运行构建，不能只重跑旧发布作业。历史测试项数、资源数量和提交 SHA 不作为后续版本的固定验收值；资源发生变更时同步维护产物校验器与相关测试。
