import { test, expect } from '@playwright/test';
import type { CDPSession, Locator, Page, TestInfo } from '@playwright/test';
import { writeFile } from 'node:fs/promises';
import { observeCyclingTouchControls, saveFailedCyclingTouchProbe } from './cycling-touch-probe';
import { newGame } from '../src/engine';
import { SAVE_KEY } from '../src/storage';
import { AUDIO_PREFERENCES_KEY } from '../src/audio-preferences';
import { CYCLING_CONTROL_PREFERENCES_KEY } from '../src/cycling-controls';
import type { CyclingControlPreferences } from '../src/cycling-controls';

const game = (page: Page) => page.getByTestId('cycling-game');
const scene = (page: Page) => page.getByTestId('cycling-scene');
const button = (page: Page, name: string) => page.getByRole('button', { name, exact: true });

async function ready(page: Page) {
  page.setDefaultTimeout(45000);
  await page.clock.install();
  const state = newGame();
  state.place = 'park'; state.energy = 100;
  state.settings.lowQuality = false; state.settings.voice = false;
  await page.addInitScript(({ state, saveKey, audioKey }) => {
    if (!localStorage.getItem(saveKey)) localStorage.setItem(saveKey, JSON.stringify(state));
    localStorage.setItem(audioKey, JSON.stringify({ music: false, effects: false, musicVolume: .3, effectsVolume: .6 }));
  }, { state, saveKey: SAVE_KEY, audioKey: AUDIO_PREFERENCES_KEY });
  await page.goto('./#cycling');
  await expect(game(page)).toHaveAttribute('data-phase', 'ready', { timeout: 210000 });
  await expect(button(page, '开始骑行 · 8 精力')).toBeEnabled();
  await expect(page.getByTestId('cycling-canvas')).toBeVisible();
}

async function press(page: Page, name: string, touch: boolean) {
  if (touch) await button(page, name).tap();
  else await button(page, name).click();
}

async function start(page: Page, touch: boolean) {
  await press(page, '开始骑行 · 8 精力', touch);
  await expect(game(page)).toHaveAttribute('data-phase', 'riding');
}

function observeErrors(page: Page) {
  const errors: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  return errors;
}

async function controlBounds(control: Locator, page: Page) {
  await expect(control).toBeVisible();
  const box = (await control.boundingBox())!;
  const viewport = page.viewportSize()!;
  expect(box.width).toBeGreaterThanOrEqual(44);
  expect(box.height).toBeGreaterThanOrEqual(44);
  expect(box.x).toBeGreaterThanOrEqual(0);
  expect(box.y).toBeGreaterThanOrEqual(0);
  expect(box.x + box.width).toBeLessThanOrEqual(viewport.width + .5);
  expect(box.y + box.height).toBeLessThanOrEqual(viewport.height + .5);
  expect(await control.evaluate(element => {
    const box = element.getBoundingClientRect();
    return element.contains(document.elementFromPoint(box.x + box.width / 2, box.y + box.height / 2));
  })).toBe(true);
  return box;
}

async function touchPoint(control: Locator, id: number) {
  const box = (await control.boundingBox())!;
  return { x: box.x + box.width / 2, y: box.y + box.height / 2, id, force: 1, radiusX: 4, radiusY: 4 };
}

async function touch(session: CDPSession, type: 'touchStart' | 'touchMove' | 'touchEnd' | 'touchCancel', points: Awaited<ReturnType<typeof touchPoint>>[]) {
  await session.send('Input.dispatchTouchEvent', { type, touchPoints: points });
}

async function screenshot(page: Page, info: TestInfo, name: string) {
  await page.screenshot({ path: info.outputPath(`${name}.png`) });
}

const settings = (page: Page) => page.getByRole('dialog', { name: '骑行操作设置', exact: true });
const preferences = (page: Page): Promise<CyclingControlPreferences | null> => page.evaluate(key => JSON.parse(localStorage.getItem(key) || 'null'), CYCLING_CONTROL_PREFERENCES_KEY);

test('keyboard remapping rejects conflicts, pauses safely and persists only saved changes', async ({ page }, info) => {
  test.skip(info.project.name !== 'desktop', 'Physical keyboard journey runs in the desktop project.');
  test.setTimeout(240000);
  const errors = observeErrors(page);
  await ready(page);
  await start(page, false);
  await game(page).focus();
  await page.keyboard.press('q');
  await expect(scene(page)).toHaveAttribute('data-camera-mode', 'orbit');
  await press(page, '操作设置', false);
  await expect(settings(page)).toBeVisible();
  await expect(game(page)).toHaveAttribute('data-paused', 'true');
  const distance = await game(page).getAttribute('data-distance');
  const camera = await scene(page).getAttribute('data-camera-orbit');
  await settings(page).getByRole('tab', { name: '键盘键位', exact: true }).click();
  const leftKey = settings(page).getByRole('button', { name: '修改向左变道主键', exact: true });
  await leftKey.click();
  await page.keyboard.press('r');
  await expect(settings(page).getByRole('alert')).toContainText('复位视角');
  await expect(scene(page)).toHaveAttribute('data-camera-mode', 'orbit');
  await expect(scene(page)).toHaveAttribute('data-camera-orbit', camera!);
  await expect(game(page)).toHaveAttribute('data-lane', '0');
  await leftKey.click();
  await page.keyboard.press('j');
  await expect(leftKey).toContainText('J');
  await settings(page).getByRole('button', { name: '保存设置', exact: true }).click();
  await expect(settings(page)).toBeHidden();
  await expect.poll(async () => (await preferences(page))?.bindings.steerLeft).toEqual(['KeyJ', 'KeyA']);
  await page.clock.fastForward(1000);
  await expect(game(page)).toHaveAttribute('data-paused', 'true');
  await expect(game(page)).toHaveAttribute('data-distance', distance!);

  await game(page).focus();
  await page.keyboard.press('p');
  await expect(game(page)).toHaveAttribute('data-paused', 'false');
  await page.keyboard.press('ArrowLeft');
  await expect(game(page)).toHaveAttribute('data-lane', '0');
  await page.keyboard.press('j');
  await expect(game(page)).toHaveAttribute('data-lane', '-1');
  await page.keyboard.press('d');
  await expect(game(page)).toHaveAttribute('data-lane', '0');
  await page.keyboard.down('s');
  await expect(game(page)).toHaveAttribute('data-braking', 'true');
  await page.keyboard.up('s');
  await expect(game(page)).toHaveAttribute('data-braking', 'false');
  await press(page, '操作设置', false);
  await screenshot(page, info, 'keyboard-custom-bindings');
  await page.reload();
  await expect(button(page, '开始骑行 · 8 精力')).toBeEnabled();
  await press(page, '操作设置', false);
  await settings(page).getByRole('tab', { name: '键盘键位', exact: true }).click();
  await expect(leftKey).toContainText('J');
  await leftKey.click();
  await page.keyboard.press('k');
  await settings(page).getByRole('button', { name: '取消', exact: true }).click();
  expect((await preferences(page))!.bindings.steerLeft).toEqual(['KeyJ', 'KeyA']);
  await press(page, '操作设置', false);
  await settings(page).getByRole('button', { name: '恢复默认', exact: true }).click();
  await settings(page).getByRole('button', { name: '保存设置', exact: true }).click();
  await expect.poll(async () => (await preferences(page))?.bindings.steerLeft).toEqual(['ArrowLeft', 'KeyA']);
  expect(errors).toEqual([]);
});

test('touch controls fit narrow and landscape screens, and layout edits survive reload', async ({ page }, info) => {
  test.skip(info.project.name !== 'mobile', 'Real touch layout journey runs in the mobile project.');
  test.setTimeout(240000);
  const errors = observeErrors(page);
  await ready(page);
  const originalPreferences = await preferences(page);
  await start(page, true);
  await press(page, '暂停骑行', true);
  await expect(game(page)).toHaveAttribute('data-paused', 'true');
  for (const viewport of [{ width: 320, height: 568 }, { width: 390, height: 844 }, { width: 844, height: 390 }]) {
    await page.setViewportSize(viewport);
    const left = await controlBounds(button(page, '向左变道'), page);
    const right = await controlBounds(button(page, '向右变道'), page);
    const brake = await controlBounds(button(page, '减速'), page);
    await controlBounds(button(page, '操作设置'), page);
    expect(left.x + left.width).toBeLessThanOrEqual(right.x + .5);
    expect(right.x + right.width).toBeLessThanOrEqual(brake.x + .5);
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(viewport.width);
    await screenshot(page, info, `touch-default-${viewport.width}x${viewport.height}`);
  }
  await page.setViewportSize({ width: 390, height: 844 });
  await press(page, '操作设置', true);
  await settings(page).getByRole('tab', { name: '触屏布局', exact: true }).tap();
  await settings(page).getByRole('radio', { name: '左手减速', exact: true }).check();
  await settings(page).getByRole('radio', { name: '大号按钮', exact: true }).check();
  const lift = settings(page).getByRole('slider', { name: '按钮上移', exact: true });
  await lift.focus();
  await page.keyboard.press('Home');
  for (let step = 0; step < 3; step++) await page.keyboard.press('ArrowRight');
  await settings(page).getByRole('button', { name: /^拖动调整位置/ }).tap();
  await expect(settings(page)).toBeHidden();
  const movable = page.getByRole('group', { name: '移动减速键位置', exact: true });
  const from = await touchPoint(movable, 1);
  const session = await page.context().newCDPSession(page);
  try {
    await touch(session, 'touchStart', [from]);
    await touch(session, 'touchMove', [{ ...from, y: from.y - 35 }]);
    await touch(session, 'touchEnd', []);
  } finally { await session.detach(); }
  await press(page, '完成布局', true);
  await expect(settings(page)).toBeVisible();
  expect(await preferences(page)).toEqual(originalPreferences);
  await settings(page).getByRole('button', { name: '保存设置', exact: true }).tap();
  await expect(settings(page)).toBeHidden();
  const persisted = (await preferences(page))!;
  expect(persisted.touch.handedness).toBe('left');
  expect(persisted.touch.size).toBe('large');
  expect(persisted.touch.verticalOffset).toBeGreaterThan(0);
  expect(persisted.touch.positions.portrait.brake.y).toBeLessThan(1);
  const customBrake = await controlBounds(button(page, '减速'), page);
  const customLeft = await controlBounds(button(page, '向左变道'), page);
  expect(customBrake.x + customBrake.width).toBeLessThanOrEqual(customLeft.x + .5);
  await screenshot(page, info, 'touch-custom-layout');
  for (const viewport of [{ width: 320, height: 568 }, { width: 844, height: 390 }]) {
    await page.setViewportSize(viewport);
    for (const name of ['向左变道', '向右变道', '减速', '操作设置']) await controlBounds(button(page, name), page);
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(viewport.width);
    await screenshot(page, info, `touch-custom-${viewport.width}x${viewport.height}`);
  }
  await page.setViewportSize({ width: 390, height: 844 });
  await page.reload();
  await expect(button(page, '开始骑行 · 8 精力')).toBeEnabled();
  await press(page, '操作设置', true);
  await settings(page).getByRole('tab', { name: '触屏布局', exact: true }).tap();
  await expect(settings(page).getByRole('radio', { name: '左手减速', exact: true })).toBeChecked();
  await expect(settings(page).getByRole('radio', { name: '大号按钮', exact: true })).toBeChecked();
  expect(await preferences(page)).toEqual(persisted);
  await settings(page).getByRole('button', { name: '恢复默认', exact: true }).tap();
  await settings(page).getByRole('button', { name: '保存设置', exact: true }).tap();
  expect((await preferences(page))!.touch.handedness).toBe('right');
  expect(errors).toEqual([]);
});

test('touch brake releases on end and cancel while simultaneous steering remains independent', async ({ page }, info) => {
  test.skip(info.project.name !== 'mobile', 'Multitouch requires the mobile project.');
  test.setTimeout(240000);
  const errors = observeErrors(page);
  await ready(page);
  await press(page, '简单难度', true);
  await expect(button(page, '开始骑行 · 8 精力')).toBeEnabled();
  await start(page, true);
  const session = await page.context().newCDPSession(page);
  try {
    const brake = await touchPoint(button(page, '减速'), 1);
    const right = await touchPoint(button(page, '向右变道'), 2);
    const cruisingSpeed = Number(await game(page).getAttribute('data-speed'));
    await touch(session, 'touchStart', [brake]);
    await expect(game(page)).toHaveAttribute('data-braking', 'true');
    await expect.poll(async () => Number(await game(page).getAttribute('data-speed'))).toBeLessThan(cruisingSpeed - .5);
    await touch(session, 'touchStart', [brake, right]);
    await expect(game(page)).toHaveAttribute('data-lane', '1');
    await expect(game(page)).toHaveAttribute('data-braking', 'true');
    // CDP touchEnd ends the complete gesture. A touchMove with the remaining
    // active points lifts only the omitted steering finger.
    await touch(session, 'touchMove', [brake]);
    await expect(game(page)).toHaveAttribute('data-braking', 'true');
    await expect(game(page)).toHaveAttribute('data-lane', '1');
    await touch(session, 'touchMove', [{ ...brake, x: 180, y: 320 }]);
    await expect(game(page)).toHaveAttribute('data-braking', 'true');
    await expect(scene(page)).toHaveAttribute('data-camera-mode', 'preset');
    const brakingSpeed = Number(await game(page).getAttribute('data-speed'));
    await touch(session, 'touchEnd', []);
    await expect(game(page)).toHaveAttribute('data-braking', 'false');
    await expect.poll(async () => Number(await game(page).getAttribute('data-speed'))).toBeGreaterThan(brakingSpeed + .1);
    await touch(session, 'touchStart', [brake]);
    await expect(game(page)).toHaveAttribute('data-braking', 'true');
    await touch(session, 'touchCancel', []);
    await expect(game(page)).toHaveAttribute('data-braking', 'false');
    await press(page, '操作设置', true);
    await expect(game(page)).toHaveAttribute('data-paused', 'true');
    await expect(game(page)).toHaveAttribute('data-braking', 'false');
    const distance = await game(page).getAttribute('data-distance');
    await page.clock.fastForward(1000);
    await expect(game(page)).toHaveAttribute('data-distance', distance!);
  } finally {
    await touch(session, 'touchCancel', []).catch(() => {});
    await session.detach();
  }
  expect(errors).toEqual([]);
});

test('each touch steering tap changes exactly one lane', async ({ page }, info) => {
  test.skip(info.project.name !== 'mobile', 'Single touch activation requires the mobile project.');
  test.setTimeout(240000);
  const errors = observeErrors(page);
  await ready(page);
  await observeCyclingTouchControls(page);
  await start(page, true);
  await press(page, '减速', true);
  await expect(game(page)).toHaveAttribute('data-braking', 'false');
  for (const [name, lane] of [['向左变道', '-1'], ['向右变道', '0'], ['向右变道', '1'], ['向左变道', '0'], ['向左变道', '-1'], ['向右变道', '0']]) {
    await press(page, name, true);
    await expect(game(page)).toHaveAttribute('data-lane', lane);
  }
  await button(page, '向右变道').press('Enter');
  await expect(game(page)).toHaveAttribute('data-lane', '1');
  await button(page, '向左变道').press('Space');
  await expect(game(page)).toHaveAttribute('data-lane', '0');
  // DOM click represents a virtual activation with no pointer source. It does
  // not stand in for testing an actual screen reader.
  await button(page, '向左变道').evaluate(element => (element as HTMLButtonElement).click());
  await expect(game(page)).toHaveAttribute('data-lane', '-1');
  await button(page, '减速').focus();
  await page.keyboard.down('Enter');
  await expect(game(page)).toHaveAttribute('data-braking', 'true');
  await page.keyboard.up('Enter');
  await expect(game(page)).toHaveAttribute('data-braking', 'false');
  await press(page, '暂停骑行', true);
  expect(errors).toEqual([]);
});

test.afterEach(async ({ page }, info) => {
  await saveFailedCyclingTouchProbe(page, info);
});

test('map switches paint busy feedback before construction and retain the rider and renderer', async ({ page }, info) => {
  test.setTimeout(240000);
  const errors = observeErrors(page);
  await page.addInitScript(() => {
    const frames: { indicator: boolean; initialLoader: boolean; canvas: boolean; stage: string; revision: string; difficulty: string }[] = [];
    (window as any).__cyclingTransitionFrames = frames;
    const sample = () => {
      const host = document.querySelector<HTMLElement>('[data-testid="cycling-scene"]');
      const indicator = document.querySelector<HTMLElement>('[data-testid="scene-transition-indicator"]');
      const initialLoader = Boolean(document.querySelector<HTMLElement>('.resource-loading')?.getClientRects().length);
      if (host && (indicator?.getClientRects().length || initialLoader) && frames.length < 500) frames.push({
        indicator: Boolean(indicator?.getClientRects().length), initialLoader,
        canvas: Boolean(host.querySelector('canvas')), stage: host.dataset.sceneTransition || '',
        revision: host.dataset.sceneRevision || '', difficulty: host.dataset.difficulty || '',
      });
      requestAnimationFrame(sample);
    };
    requestAnimationFrame(sample);
  });
  await ready(page);
  expect(await page.evaluate(() => (window as any).__cyclingTransitionFrames.some((frame: any) => (frame.initialLoader || frame.indicator) && !frame.canvas))).toBe(true);
  const canvas = await page.getByTestId('cycling-canvas').elementHandle();
  const renderer = await scene(page).getAttribute('data-renderer-instance');
  const rider = await scene(page).getAttribute('data-rider-instance');
  expect(renderer).toBeTruthy(); expect(rider).toBeTruthy();
  const revision = await scene(page).getAttribute('data-scene-revision');
  // Real button handlers issue two route choices within the frame window. The
  // second selection must win even if the first scene is still preparing.
  await page.getByRole('group', { name: '选择骑行难度', exact: true }).evaluate(async group => {
    (group.querySelector('[aria-label="简单难度"]') as HTMLButtonElement).click();
    await new Promise<void>(resolve => requestAnimationFrame(() => resolve()));
    (group.querySelector('[aria-label="困难难度"]') as HTMLButtonElement).click();
  });
  await expect(game(page)).toHaveAttribute('data-difficulty', 'hard');
  await expect(scene(page)).toHaveAttribute('data-difficulty', 'hard');
  await expect(scene(page)).toHaveAttribute('data-scene-loading', 'false');
  await expect(scene(page)).toHaveAttribute('data-scene-transition', 'ready');
  await expect(button(page, '开始骑行 · 8 精力')).toBeEnabled();
  expect(await page.evaluate(previous => (window as any).__cyclingTransitionFrames.some((frame: any) => frame.indicator && frame.canvas && frame.stage === 'loading' && frame.revision === previous), revision)).toBe(true);
  await expect(scene(page)).toHaveAttribute('data-renderer-instance', renderer!);
  await expect(scene(page)).toHaveAttribute('data-rider-instance', rider!);
  expect(await canvas!.evaluate(element => element === document.querySelector('[data-testid="cycling-canvas"]'))).toBe(true);
  await expect(page.getByTestId('cycling-canvas')).toHaveCount(1);
  await expect(page.getByTestId('scene-transition-indicator')).toHaveCount(0);
  await screenshot(page, info, 'map-latest-selection-ready');
  const framesPath = info.outputPath('transition-painted-frames.json');
  await writeFile(framesPath, JSON.stringify(await page.evaluate(() => (window as any).__cyclingTransitionFrames)));
  await info.attach('transition-painted-frames', { path: framesPath, contentType: 'application/json' });
  expect(errors).toEqual([]);
});
