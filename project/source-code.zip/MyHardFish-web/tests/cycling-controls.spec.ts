import { expect, test } from '@playwright/test';
import {
  CYCLING_CONTROL_PREFERENCES_KEY, createDefaultCyclingControls,
  cyclingKeyChord, cyclingKeyCode, cyclingKeyLabel, getCyclingTouchPositions,
  loadCyclingControlPreferences, matchCyclingControlAction,
  normalizeCyclingControlPreferences, normalizeCyclingTouchPreferences,
  resetCyclingControlPreferences, saveCyclingControlPreferences,
  updateCyclingBinding, validateCyclingBindings,
} from '../src/cycling-controls';
import type { CyclingControlAction } from '../src/cycling-controls';

function memoryStorage(initial: Record<string, string> = {}) {
  const entries = new Map(Object.entries(initial));
  return {
    entries,
    getItem: (key: string) => entries.get(key) ?? null,
    setItem: (key: string, value: string) => { entries.set(key, value); },
  };
}

test('defaults preserve existing steering, hold brake, pause and camera controls', () => {
  const { bindings } = createDefaultCyclingControls();
  const expected: [string, CyclingControlAction][] = [
    ['ArrowLeft', 'steerLeft'], ['KeyA', 'steerLeft'],
    ['ArrowRight', 'steerRight'], ['KeyD', 'steerRight'],
    ['ArrowDown', 'brake'], ['KeyS', 'brake'],
    ['KeyP', 'pause'], ['Space', 'pause'], ['KeyC', 'nextCamera'],
    ['KeyQ', 'orbitLeft'], ['KeyE', 'orbitRight'], ['KeyR', 'resetCamera'],
  ];
  for (const [code, action] of expected)
    expect(matchCyclingControlAction({ code }, bindings), code).toBe(action);
  expect(matchCyclingControlAction({ code: 'KeyQ', shiftKey: true }, bindings)).toBe('tiltUp');
  expect(matchCyclingControlAction({ code: 'KeyE', shiftKey: true }, bindings)).toBe('tiltDown');
  expect(matchCyclingControlAction({ code: 'KeyC', shiftKey: true }, bindings)).toBeNull();
  expect(matchCyclingControlAction({ code: 'KeyZ' }, bindings)).toBeNull();
});

test('key chords follow physical positions with exact Shift, while releases ignore modifier changes', () => {
  expect(cyclingKeyChord({ code: 'KeyA', key: 'q' })).toBe('KeyA');
  expect(cyclingKeyChord({ code: 'KeyQ', key: 'Q' })).toBe('KeyQ'); // Caps Lock is not Shift.
  expect(cyclingKeyChord({ code: 'KeyQ', key: 'Q', shiftKey: true })).toBe('Shift+KeyQ');
  expect(cyclingKeyCode({ code: 'KeyQ', shiftKey: true })).toBe('KeyQ');
  expect(cyclingKeyCode({ code: 'KeyQ', shiftKey: false })).toBe('KeyQ');
  expect(cyclingKeyChord({ key: 'a' })).toBe('KeyA');
  expect(cyclingKeyChord({ code: 'Unidentified', key: 'ArrowLeft' })).toBe('ArrowLeft');
  expect(cyclingKeyChord({ key: '?', shiftKey: true })).toBe('Shift+Slash');
  expect(cyclingKeyChord({ key: '!', shiftKey: true })).toBe('Shift+Digit1');
  expect(cyclingKeyChord({ code: 'Escape', key: 'a' })).toBeNull();
  expect(cyclingKeyLabel('Shift+KeyQ')).toBe('Shift + Q');
  expect(cyclingKeyLabel('Space')).toBe('空格');
  expect(cyclingKeyLabel('ArrowLeft')).toBe('←');
  expect(cyclingKeyLabel('Numpad1')).toBe('数字键盘 1');
  expect(cyclingKeyLabel(undefined)).toBe('未设置');
});

test('browser shortcuts, reserved keys and composition never trigger an action', () => {
  const { bindings } = createDefaultCyclingControls();
  for (const modifier of ['ctrlKey', 'altKey', 'metaKey', 'isComposing']) {
    const event = { code: 'KeyA', [modifier]: true };
    expect(cyclingKeyChord(event), modifier).toBeNull();
    expect(matchCyclingControlAction(event, bindings), modifier).toBeNull();
  }
  for (const key of ['Dead', 'Process', 'Compose'])
    expect(cyclingKeyChord({ code: 'KeyA', key })).toBeNull();
  const reserved = ['Escape', 'Tab', 'Enter', 'NumpadEnter', 'Backspace', 'Delete',
    'Home', 'End', 'PageUp', 'PageDown', 'ShiftLeft', 'ShiftRight', 'ControlLeft',
    'AltLeft', 'MetaLeft', 'CapsLock', 'NumLock', 'ScrollLock', 'PrintScreen',
    'Pause', 'ContextMenu', ...Array.from({ length: 12 }, (_, index) => `F${index + 1}`)];
  for (const code of reserved) {
    expect(cyclingKeyChord({ code }), code).toBeNull();
    expect(cyclingKeyChord({ code, shiftKey: true }), `Shift+${code}`).toBeNull();
    expect(updateCyclingBinding(bindings, 'steerLeft', 0, code).ok, code).toBe(false);
  }
});

test('remapping changes only the selected binding and reports named conflicts without mutation', () => {
  const { bindings } = createDefaultCyclingControls();
  const changed = updateCyclingBinding(bindings, 'steerLeft', 0, 'KeyJ');
  expect(changed.ok).toBe(true);
  if (!changed.ok) throw new Error(changed.error);
  expect(changed.bindings.steerLeft).toEqual(['KeyJ', 'KeyA']);
  expect(bindings.steerLeft).toEqual(['ArrowLeft', 'KeyA']);
  expect(matchCyclingControlAction({ code: 'KeyJ' }, changed.bindings)).toBe('steerLeft');
  expect(matchCyclingControlAction({ code: 'ArrowLeft' }, changed.bindings)).toBeNull();
  const conflict = updateCyclingBinding(changed.bindings, 'steerRight', 1, 'KeyJ');
  expect(conflict.ok).toBe(false);
  if (conflict.ok) throw new Error('Conflicting bindings were accepted');
  expect(conflict.error).toContain('J');
  expect(conflict.error).toContain('向左变道');
  expect(conflict.error).toContain('向右变道');
  expect(changed.bindings.steerRight).toEqual(['ArrowRight', 'KeyD']);
  expect(updateCyclingBinding(bindings, 'pause', 1, 'KeyP')).toMatchObject({ ok: false, error: expect.stringContaining('重复') });
});

test('primary and secondary bindings remain independent and at least one usable key is required', () => {
  const { bindings } = createDefaultCyclingControls();
  const removed = updateCyclingBinding(bindings, 'steerLeft', 0, null);
  expect(removed).toMatchObject({ ok: true, bindings: { steerLeft: ['KeyA'] } });
  expect(updateCyclingBinding(bindings, 'resetCamera', 0, null).ok).toBe(false);
  expect(updateCyclingBinding(bindings, 'resetCamera', 1, 'Shift+KeyR')).toMatchObject({
    ok: true, bindings: { resetCamera: ['KeyR', 'Shift+KeyR'] },
  });
  for (const invalid of [null, [], {}, { ...bindings, pause: [] },
    { ...bindings, pause: ['KeyP', 'Space', 'KeyZ'] }, { ...bindings, pause: ['Ctrl+KeyP'] },
    { ...bindings, pause: ['Shift+Shift+KeyP'] }, { ...bindings, pause: ['keyp'] },
    { ...bindings, pause: ['__proto__'] }, { ...bindings, pause: [true] }])
    expect(validateCyclingBindings(invalid).ok).toBe(false);
  expect(validateCyclingBindings(bindings).ok).toBe(true);
});

test('malformed or unavailable storage falls back safely without affecting save data', () => {
  const defaults = createDefaultCyclingControls();
  for (const serialized of ['', 'not-json', '{', 'null', '[]', '42', '"hello"', '{"version":9}']) {
    const storage = memoryStorage({ [CYCLING_CONTROL_PREFERENCES_KEY]: serialized, 'hardfish.save': 'untouched' });
    expect(loadCyclingControlPreferences(storage), serialized).toEqual(defaults);
    expect(storage.getItem('hardfish.save')).toBe('untouched');
    expect(storage.getItem(CYCLING_CONTROL_PREFERENCES_KEY)).toBe(serialized);
  }
  expect(loadCyclingControlPreferences({ getItem: () => { throw new Error('blocked'); } })).toEqual(defaults);
  const conflicted = { ...defaults, bindings: { ...defaults.bindings, steerLeft: ['KeyD'] },
    touch: { ...defaults.touch, handedness: 'left' } };
  const recovered = normalizeCyclingControlPreferences(conflicted);
  expect(recovered.bindings).toEqual(defaults.bindings);
  expect(recovered.touch.handedness).toBe('left');
});

test('saving and reset round-trip custom controls in their own key and surface write failures', () => {
  const storage = memoryStorage({ 'hardfish.save': 'village progress', 'hardfish.audio-preferences.v1': 'audio' });
  const custom = createDefaultCyclingControls();
  custom.bindings.steerLeft = ['KeyJ'];
  custom.touch.handedness = 'left';
  custom.touch.size = 'large';
  custom.touch.verticalOffset = 56;
  custom.touch.positions.landscape.brake = { x: .82, y: .66 };
  saveCyclingControlPreferences(custom, storage);
  expect(loadCyclingControlPreferences(storage)).toEqual(custom);
  expect(storage.entries.size).toBe(3);
  expect(storage.getItem('hardfish.save')).toBe('village progress');
  expect(storage.getItem('hardfish.audio-preferences.v1')).toBe('audio');
  expect(resetCyclingControlPreferences(storage)).toEqual(createDefaultCyclingControls());
  expect(loadCyclingControlPreferences(storage)).toEqual(createDefaultCyclingControls());
  const blocked = { setItem: () => { throw new Error('quota exceeded'); } };
  expect(() => saveCyclingControlPreferences(custom, blocked)).toThrow('quota exceeded');
  expect(() => resetCyclingControlPreferences(blocked)).toThrow('quota exceeded');
  const invalid = { ...custom, bindings: { ...custom.bindings, steerRight: ['KeyJ'] } };
  expect(() => saveCyclingControlPreferences(invalid, storage)).toThrow('向右变道');
  expect(loadCyclingControlPreferences(storage)).toEqual(createDefaultCyclingControls());
});

test('touch settings clamp finite coordinates and offsets, repairing malformed fields independently', () => {
  const defaults = createDefaultCyclingControls().touch;
  const normalized = normalizeCyclingTouchPreferences({
    handedness: 'left', size: 'large', verticalOffset: 500,
    positions: {
      portrait: { steering: { x: -5, y: 2 }, brake: { x: NaN, y: Infinity }, tools: null },
      landscape: { steering: { x: .8, y: .2 }, brake: { x: '0.1', y: undefined } },
    },
  });
  expect(normalized.handedness).toBe('left');
  expect(normalized.size).toBe('large');
  expect(normalized.verticalOffset).toBe(96);
  expect(normalized.positions.portrait.steering).toEqual({ x: 0, y: 1 });
  expect(normalized.positions.portrait.brake).toEqual(defaults.positions.portrait.brake);
  expect(normalized.positions.portrait.tools).toEqual(defaults.positions.portrait.tools);
  expect(normalized.positions.landscape.steering).toEqual({ x: .8, y: .2 });
  expect(normalized.positions.landscape.brake).toEqual(defaults.positions.landscape.brake);
  for (const verticalOffset of [-10, NaN, Infinity, '20', null])
    expect(normalizeCyclingTouchPreferences({ verticalOffset }).verticalOffset).toBe(0);
  expect(normalizeCyclingTouchPreferences({ handedness: 'both', size: 'huge' })).toEqual(defaults);
  expect(normalizeCyclingTouchPreferences(null)).toEqual(defaults);
});

test('left-handed views mirror controls without mixing orientations or modifying persisted positions', () => {
  const prefs = createDefaultCyclingControls();
  prefs.touch.handedness = 'left';
  prefs.touch.positions.portrait.steering = { x: .2, y: .7 };
  const portrait = getCyclingTouchPositions(prefs.touch, 'portrait');
  expect(portrait.steering).toEqual({ x: .8, y: .7 });
  expect(portrait.brake.x).toBeCloseTo(.03);
  expect(portrait.tools.y).toBe(0);
  expect(getCyclingTouchPositions(prefs.touch, 'landscape').tools).toEqual({ x: .5, y: 1 });
  expect(prefs.touch.positions.portrait.steering).toEqual({ x: .2, y: .7 });
  portrait.steering.x = 0;
  expect(prefs.touch.positions.portrait.steering.x).toBe(.2);
  const independent = createDefaultCyclingControls();
  prefs.bindings.steerLeft[0] = 'KeyJ';
  expect(independent.bindings.steerLeft[0]).toBe('ArrowLeft');
  expect(independent.touch.positions.portrait.steering).toEqual({ x: .03, y: 1 });
});
