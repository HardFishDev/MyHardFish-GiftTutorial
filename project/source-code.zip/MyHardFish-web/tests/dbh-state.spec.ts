import { test, expect } from '@playwright/test';
import { DBH_CLUES, DBH_GIFTS, DBH_TOPICS } from '../src/dbh-content';
import { applyDbhInteraction, createDbhState, dbhFriendship, normalizeDbhState, recordDbhVisit } from '../src/dbh-state';
import type { DbhAction } from '../src/dbh-content';

test('dbh repeats remain replayable without farming friendship or memories', () => {
  const empty = createDbhState();
  let state = applyDbhInteraction(empty, { type: 'greet' });
  for (let i = 0; i < 200; i++) {
    state = applyDbhInteraction(state, { type: 'greet' });
    state = applyDbhInteraction(state, { type: 'action', action: 'wave' });
    state = applyDbhInteraction(state, { type: 'craft', gift: 'paper_star' });
  }
  expect(dbhFriendship(state).points).toBe(2);
  expect(state.memories).toEqual(['first_meeting', 'paper_star']);
  expect(empty).toEqual(createDbhState());
  for (const topic of DBH_TOPICS) state = applyDbhInteraction(state, { type: 'talk', topic: topic.id });
  for (const action of ['dance', 'stretch', 'photo', 'cheer'] as const) state = applyDbhInteraction(state, { type: 'action', action });
  for (const gift of DBH_GIFTS) state = applyDbhInteraction(state, { type: 'craft', gift: gift.id });
  expect(dbhFriendship(state)).toEqual({ points: 11, label: '合拍的搭子', next: 14 });
  expect(state.memories).toHaveLength(5);
  const replay = applyDbhInteraction(state, { type: 'action', action: 'dance' });
  expect(replay).toEqual(state);
});

test('dbh observation quest requires accepted quest, real village visits, and all correct answers', () => {
  const fresh = createDbhState();
  expect(recordDbhVisit(fresh, 'village', 'village_board')).toEqual(fresh);
  let state = applyDbhInteraction(fresh, { type: 'startQuest' });
  expect(applyDbhInteraction(state, { type: 'finishQuest' }).quest.status).toBe('active');
  const before = structuredClone(state);
  expect(recordDbhVisit(state, 'river', 'village_board')).toEqual(before);
  expect(recordDbhVisit(state, 'village', 'dbh')).toEqual(before);
  expect(applyDbhInteraction(state, { type: 'answer', clue: 'board', answer: 'gather' })).toEqual(before);
  expect(state).toEqual(before);
  for (const clue of DBH_CLUES) {
    state = recordDbhVisit(state, 'village', clue.hotspot);
    const afterVisit = structuredClone(state);
    expect(recordDbhVisit(state, 'village', clue.hotspot)).toEqual(afterVisit);
    state = applyDbhInteraction(state, { type: 'answer', clue: clue.id, answer: clue.options.find(option => option.id !== clue.answer)!.id });
  }
  expect(state.quest.visited).toHaveLength(3);
  expect(applyDbhInteraction(state, { type: 'finishQuest' }).quest.status).toBe('active');
  expect(dbhFriendship(state).points).toBe(0);
  expect(state.memories).toEqual([]);
  for (const clue of DBH_CLUES) state = applyDbhInteraction(state, { type: 'answer', clue: clue.id, answer: clue.answer });
  const original = structuredClone(state);
  const complete = applyDbhInteraction(state, { type: 'finishQuest' });
  expect(state).toEqual(original);
  expect(complete.quest.status).toBe('completed');
  expect(complete.memories).toEqual(['village_walk']);
  expect(dbhFriendship(complete).points).toBe(3);
  expect(applyDbhInteraction(complete, { type: 'finishQuest' })).toEqual(complete);
  expect(applyDbhInteraction(complete, { type: 'startQuest' })).toEqual(complete);
  expect(applyDbhInteraction(complete, { type: 'answer', clue: 'board', answer: 'concert' })).toEqual(complete);
  expect(normalizeDbhState(JSON.parse(JSON.stringify(complete)))).toEqual(complete);
});

test('dbh normalization discards unknown ids, huge duplicate collections and inconsistent completion', () => {
  for (const input of [undefined, null, [], 'saved', { schema: 2, credited: ['greet'] }]) expect(normalizeDbhState(input)).toEqual(createDbhState());
  const restored = normalizeDbhState({ schema: 1, credited: ['greet', 'greet', 'action:photo', 'admin:1000', 42, ...Array(2000).fill('greet')], memories: ['village_walk', 'unknown'], quest: { status: 'completed', visited: ['village_board', 'village_board', 'river_dock'], answers: { board: 'gather', garden: 'berries', square: 'tables', unknown: 'yes' } } });
  expect(restored.credited).toEqual(['greet', 'action:photo']);
  expect(restored.quest).toEqual({ status: 'active', visited: ['village_board'], answers: { board: 'gather' } });
  expect(restored.memories).toEqual(['first_meeting', 'photo']);
  expect(dbhFriendship(restored).points).toBe(2);
  const untouched = createDbhState();
  expect(applyDbhInteraction(untouched, { type: 'talk', topic: 'nonexistent' })).toEqual(untouched);
  expect(applyDbhInteraction(untouched, { type: 'craft', gift: 'free-money' })).toEqual(untouched);
  expect(applyDbhInteraction(untouched, { type: 'action', action: 'invalid' as DbhAction })).toEqual(untouched);
  expect(normalizeDbhState({ schema: 1, quest: { status: 'available', visited: ['village_board'], answers: { board: 'gather' } } })).toEqual(untouched);
});
