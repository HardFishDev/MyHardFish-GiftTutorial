import { test, expect } from '@playwright/test';
import { foods, friends, outfits, places, stories } from '../src/content';
import { discoveries, quests } from '../src/adventure-content';
import { newGame, step, GAME_MAX_SCORE, getQuestView } from '../src/engine';
import type { Action, GameKind, GameState } from '../src/engine';
import type { QuestStage } from '../src/adventure-types';
import { EXPLORATION_SPOTS, WORLD_EXITS } from '../src/world-layout';
import { ACTIVITY_PRESETS, EXPLORATION_ACTIVITIES, activityForHotspot } from '../src/world-activities';
import {
  activityForAction, GAME_ACTIVITIES, QUEST_STAGE_ACTIVITIES, QUEST_CHOICE_ACTIVITIES,
  STORY_NODE_ACTIVITIES,
} from '../src/interaction-feedback';
import type { ActivityFeedback } from '../src/interaction-feedback';

const NOW = new Date(2026, 8, 30, 12).getTime();
const accepted = (previous: GameState, action: Action) => {
  const next = step(previous, action, previous.updatedAt);
  return { next, feedback: activityForAction(previous, next, action) };
};
const act = (state: GameState, action: Action) => accepted(state, action).next;
const validProps = ['none', 'book', 'food', 'cup', 'spatula', 'wateringCan', 'bag', 'ball', 'pencil', 'magnifier', 'lantern'];
function validActivity(activity: ActivityFeedback | null | undefined) {
  expect(activity).toBeTruthy();
  expect(Object.keys(ACTIVITY_PRESETS)).toContain(activity!.kind);
  if (activity!.prop) expect(validProps).toContain(activity!.prop);
  if (activity!.food) expect(foods.some(food => food.id === activity!.food)).toBe(true);
  if (activity!.duration !== undefined) {
    expect(Number.isFinite(activity!.duration)).toBe(true);
    expect(activity!.duration).toBeGreaterThan(0);
  }
}

function finish(state: GameState, kind: GameKind) {
  if (state.energy < 8) state = act(state, { type: 'interact', value: 'rest' });
  state = act(state, { type: 'startGame', value: kind });
  return act(state, { type: 'finishGame', value: kind, score: 0, sessionId: state.activeGame!.id });
}
function storyState(storyId: string) {
  const story = stories.find(item => item.id === storyId)!;
  let state = { ...newGame(NOW), bond: 100, place: story.place };
  state = act(state, { type: 'startStory', value: story.id });
  return state;
}
function satisfy(state: GameState, stage: QuestStage) {
  state = act(state, { type: 'place', value: stage.place });
  for (const requirement of stage.requirements || []) {
    if (requirement.kind === 'discovery') {
      const discovery = discoveries.find(item => item.id === requirement.discoveryId)!;
      state = act(state, { type: 'place', value: discovery.place });
      state = act(state, { type: 'discover', value: discovery.id, hotspot: discovery.hotspot });
    } else if (requirement.kind === 'game') {
      for (let n = 0; n < (requirement.count || 1); n++) state = finish(state, requirement.game);
    } else {
      const story = stories.find(item => item.id === requirement.storyId)!;
      state = { ...state, bond: Math.max(state.bond, story.minBond) };
      state = act(state, { type: 'place', value: story.place });
      state = act(state, { type: 'startStory', value: story.id });
      for (let guard = 0; state.story && guard < 20; guard++) {
        const node = story.nodes[state.story.node];
        state = act(state, { type: 'choice', value: node.choices![0].next });
      }
      expect(state.story).toBeNull();
    }
  }
  return act(state, { type: 'place', value: stage.place });
}

test('the activity catalog covers every exploration spot and ordinary world action, excluding travel', () => {
  expect(Object.keys(ACTIVITY_PRESETS).sort()).toEqual(['sit', 'read', 'cook', 'water', 'shop', 'play', 'write', 'inspect', 'talk', 'celebrate', 'eat'].sort());
  expect(Object.keys(EXPLORATION_ACTIVITIES).sort()).toEqual(EXPLORATION_SPOTS.map(spot => spot.id).sort());
  for (const spot of EXPLORATION_SPOTS) validActivity(activityForHotspot(spot.place, `adventure:${spot.id}`));
  for (const place of places) {
    for (const id of ['pet', 'rest', 'cook', 'shop', 'math', 'friends', 'closet', 'story', 'bottle', 'words', 'harvest'])
      validActivity(activityForHotspot(place.id, id));
    expect(activityForHotspot(place.id, 'not-a-hotspot')).toBeNull();
  }
  for (const place of places)
    for (const exit of WORLD_EXITS[place.id]) expect(activityForHotspot(place.id, `travel:${exit.to}`)).toBeNull();
  for (const story of stories) validActivity(activityForHotspot(story.place, `story:${story.id}`));
});

test('explicit stage, branch and story activity keys stay aligned with authored content', () => {
  expect(Object.keys(QUEST_STAGE_ACTIVITIES).sort()).toEqual(quests.map(quest => quest.id).sort());
  for (const quest of quests) {
    expect(Object.keys(QUEST_STAGE_ACTIVITIES[quest.id]).sort()).toEqual(quest.stages.map(stage => stage.id).sort());
    for (const stage of quest.stages) validActivity(QUEST_STAGE_ACTIVITIES[quest.id][stage.id]);
  }
  for (const [questId, stages] of Object.entries(QUEST_CHOICE_ACTIVITIES)) {
    const quest = quests.find(item => item.id === questId)!;
    expect(quest).toBeDefined();
    for (const [stageId, choices] of Object.entries(stages)) {
      const stage = quest.stages.find(item => item.id === stageId)!;
      expect(stage).toBeDefined();
      for (const [choiceId, activity] of Object.entries(choices)) {
        expect(stage.choices.some(choice => choice.id === choiceId)).toBe(true);
        validActivity(activity);
      }
    }
  }
  expect(Object.keys(STORY_NODE_ACTIVITIES).sort()).toEqual(stories.map(story => story.id).sort());
  for (const story of stories) {
    expect(Object.keys(STORY_NODE_ACTIVITIES[story.id]).sort()).toEqual(Object.keys(story.nodes).sort());
    for (const activity of Object.values(STORY_NODE_ACTIVITIES[story.id])) validActivity(activity);
  }
});

for (const food of foods) test(`successful ${food.id} feeding shows the consumed item, with cups for drinks`, () => {
  const state = newGame(NOW); state.hunger = 20; state.inventory[food.id] = 1;
  const { next, feedback } = accepted(state, { type: 'feed', value: food.id });
  expect(next.inventory[food.id]).toBe(0);
  expect(next.counts.feed).toBe(1);
  expect(feedback).toMatchObject({ kind: 'eat', food: food.id, prop: ['milk', 'coffee'].includes(food.id) ? 'cup' : 'food' });
});

test('empty food bags and full stomachs never play eating, including when an unrelated achievement pays', () => {
  const empty = newGame(NOW); empty.inventory.rice = 0;
  expect(accepted(empty, { type: 'feed', value: 'rice' }).feedback).toBeNull();
  const full = newGame(NOW); full.hunger = 100; full.counts.pet = 10;
  const result = accepted(full, { type: 'feed', value: 'milk' });
  expect(result.next.reaction.id).not.toBe(full.reaction.id);
  expect(result.next.shells).toBeGreaterThan(full.shells);
  expect(result.feedback).toBeNull();
});

test('shopping and changing outfits animate successful transactions, never rejection or re-equipping', () => {
  const state = newGame(NOW);
  expect(accepted(state, { type: 'buyFood', value: 'peach' }).feedback).toMatchObject({ kind: 'shop', prop: 'bag' });
  expect(accepted({ ...state, shells: 0 }, { type: 'buyFood', value: 'peach' }).feedback).toBeNull();
  expect(accepted({ ...state, inventory: { ...state.inventory, peach: 99 } }, { type: 'buyFood', value: 'peach' }).feedback).toBeNull();
  expect(accepted({ ...state, shells: 0 }, { type: 'outfit', value: 'mint' }).feedback).toBeNull();
  expect(accepted(state, { type: 'outfit', value: 'classic' }).feedback).toBeNull();
  for (const outfit of outfits.filter(item => item.id !== 'classic')) {
    const result = accepted({ ...state, shells: 9999 }, { type: 'outfit', value: outfit.id });
    validActivity(result.feedback);
    expect(result.next.outfit).toBe(outfit.id);
  }
});

test('chatting about each groupmate has a talking action while blank chat has none', () => {
  for (const friend of friends) expect(accepted(newGame(NOW), { type: 'chat', text: `聊聊${friend.name}` }).feedback?.kind).toBe('talk');
  expect(accepted(newGame(NOW), { type: 'chat', text: '   ' }).feedback).toBeNull();
});

for (const kind of Object.keys(GAME_MAX_SCORE) as GameKind[]) test(`${kind} uses its activity only after admission and celebrates one valid completion`, () => {
  const state = newGame(NOW);
  // App rejects admission before dispatch at energy < 8; no new session means no game gesture.
  const refused = { ...state, energy: 0 };
  expect(activityForAction(refused, refused, { type: 'startGame', value: kind })).toBeNull();
  const started = accepted(state, { type: 'startGame', value: kind });
  expect(started.feedback).toEqual(GAME_ACTIVITIES[kind]); validActivity(started.feedback);
  const sessionId = started.next.activeGame!.id;
  for (const score of [NaN, Infinity])
    expect(accepted(started.next, { type: 'finishGame', value: kind, sessionId, score }).feedback).toBeNull();
  expect(accepted(started.next, { type: 'finishGame', value: kind, sessionId: 'stale-session', score: 5 }).feedback).toBeNull();
  const mismatched = (Object.keys(GAME_MAX_SCORE) as GameKind[]).find(other => other !== kind)!;
  expect(accepted(started.next, { type: 'finishGame', value: mismatched, sessionId, score: 0 }).feedback).toBeNull();
  const completed = accepted(started.next, { type: 'finishGame', value: kind, sessionId, score: 0 });
  expect(completed.feedback?.kind).toBe('celebrate');
  expect(completed.next.counts.play).toBe(1);
  const duplicate = accepted(completed.next, { type: 'finishGame', value: kind, sessionId, score: 5 });
  expect(duplicate.feedback).toBeNull(); expect(duplicate.next.shells).toBe(completed.next.shells);
});

test('discovery and daily reward gestures occur only for the first accepted receipt', () => {
  for (const discovery of discoveries) {
    const state = { ...newGame(NOW), place: discovery.place };
    expect(accepted(state, { type: 'discover', value: discovery.id, hotspot: 'wrong' }).feedback).toBeNull();
    const wrongPlace = places.find(place => place.id !== discovery.place)!.id;
    expect(accepted({ ...state, place: wrongPlace }, { type: 'discover', value: discovery.id, hotspot: discovery.hotspot }).feedback).toBeNull();
    const first = accepted(state, { type: 'discover', value: discovery.id, hotspot: discovery.hotspot });
    validActivity(first.feedback);
    expect(accepted(first.next, { type: 'discover', value: discovery.id, hotspot: discovery.hotspot }).feedback).toBeNull();
  }
  const state = newGame(NOW);
  expect(accepted(state, { type: 'claim', value: 'chat' }).feedback).toBeNull();
  state.daily.counts.chat = 3;
  const first = accepted(state, { type: 'claim', value: 'chat' });
  expect(first.feedback?.kind).toBe('celebrate');
  expect(accepted(first.next, { type: 'claim', value: 'chat' }).feedback).toBeNull();
});

test('story admission and all reachable choices animate accepted transitions, not locked or invalid clicks', () => {
  for (const story of stories) {
    const ready = { ...newGame(NOW), place: story.place, bond: 100 };
    const otherPlace = places.find(place => place.id !== story.place)!.id;
    expect(accepted({ ...ready, place: otherPlace }, { type: 'startStory', value: story.id }).feedback).toBeNull();
    if (story.minBond) expect(accepted({ ...ready, bond: 0 }, { type: 'startStory', value: story.id }).feedback).toBeNull();
    const started = accepted(ready, { type: 'startStory', value: story.id }); validActivity(started.feedback);
    expect(accepted(started.next, { type: 'startStory', value: story.id }).feedback).toBeNull();
    expect(accepted(started.next, { type: 'choice', value: 'not-a-choice' }).feedback).toBeNull();
    const queue = [started.next]; const reached = new Set<string>();
    while (queue.length) {
      const state = queue.shift()!;
      if (!state.story || reached.has(state.story.node)) continue;
      reached.add(state.story.node);
      for (const choice of story.nodes[state.story.node].choices || []) {
        const result = accepted(state, { type: 'choice', value: choice.next });
        validActivity(result.feedback);
        if (result.next.story) queue.push(result.next);
      }
    }
  }
});

test('cake refusal and quiet story endings keep their semantic actions despite positive rewards', () => {
  const start = storyState('belated_cake');
  const card = act(start, { type: 'choice', value: 'card' });
  const wish = accepted(card, { type: 'choice', value: 'wish' });
  expect(wish.next.shells).toBeGreaterThan(card.shells);
  expect(wish.feedback).toMatchObject({ kind: 'write', prop: 'pencil' });
  const choose = act(start, { type: 'choice', value: 'choose' });
  expect(accepted(choose, { type: 'choice', value: 'later' }).feedback).toMatchObject({ kind: 'sit', prop: 'cup' });
  expect(accepted(choose, { type: 'choice', value: 'small' }).feedback).toMatchObject({ kind: 'eat', prop: 'food' });
  const slow = act(storyState('holiday'), { type: 'choice', value: 'slow' });
  expect(accepted(slow, { type: 'choice', value: 'today' }).feedback?.kind).toBe('sit');
  const window = act(storyState('quiet_revision'), { type: 'choice', value: 'window' });
  for (const value of ['enough', 'tomorrow']) expect(['eat', 'celebrate']).not.toContain(accepted(window, { type: 'choice', value }).feedback?.kind);
});

test('all authored quest choices animate only after location, objectives and item costs succeed', () => {
  let state = newGame(NOW);
  let stages = 0, choices = 0;
  for (const quest of quests) {
    if (!state.adventure.quests[quest.id]) state = act(state, { type: 'startQuest', value: quest.id });
    for (const stage of quest.stages) {
      state = act(state, { type: 'place', value: stage.place });
      const action: Extract<Action, { type: 'questAction' }> = { type: 'questAction', questId: quest.id, stageId: stage.id, choiceId: stage.choices[0].id, hotspot: stage.hotspot };
      if (getQuestView(state, quest.id)!.requirements.some(requirement => !requirement.met))
        expect(accepted(state, action).feedback).toBeNull();
      state = satisfy(state, stage);
      const wrongPlace = places.find(place => place.id !== stage.place)!.id;
      for (const invalid of [{ ...action, hotspot: 'wrong' }, { ...action, stageId: 'stale' }, { ...action, choiceId: 'missing' }])
        expect(accepted(state, invalid).feedback).toBeNull();
      expect(accepted({ ...state, place: wrongPlace }, action).feedback).toBeNull();
      for (const choice of stage.choices) {
        const selected = { ...action, choiceId: choice.id };
        const result = accepted(state, selected); validActivity(result.feedback);
        expect(result.next.adventure.quests[quest.id].choices[stage.id]).toBe(choice.id);
        for (const item of Object.keys(choice.costItems || {})) {
          const missing = structuredClone(state); missing.adventure.items[item] = 0;
          const rejected = accepted(missing, selected);
          expect(rejected.feedback).toBeNull();
          expect(rejected.next.adventure.quests[quest.id].stage).toBe(state.adventure.quests[quest.id].stage);
        }
        if (quest.id === 'shared_table' && stage.id === 'cake_offer')
          expect(result.feedback!.kind === 'eat').toBe(choice.id === 'fruit_bite');
        if (quest.id === 'opening_night' && stage.id === 'festival' && choice.id === 'quiet_seat')
          expect(result.feedback).toMatchObject({ kind: 'sit', prop: 'lantern' });
        expect(accepted(result.next, selected).feedback).toBeNull();
        choices++;
      }
      state = act(state, action); stages++;
    }
  }
  expect(stages).toBe(quests.reduce((n, quest) => n + quest.stages.length, 0));
  expect(choices).toBe(quests.reduce((n, quest) => n + quest.stages.reduce((m, stage) => m + stage.choices.length, 0), 0));
});

test('tick, settings, naming and route tracking do not invent physical rewards', () => {
  const state = newGame(NOW);
  const actions: Action[] = [{ type: 'tick' }, { type: 'settings', value: { voice: false } }, { type: 'name', value: '群友' }, { type: 'trackQuest', value: 'village_opening' }, { type: 'place', value: 'park' }];
  for (const action of actions) expect(accepted(state, action).feedback).toBeNull();
  expect(accepted(state, { type: 'interact', value: 'rest' }).feedback).toMatchObject({ kind: 'sit', seated: true });
});
