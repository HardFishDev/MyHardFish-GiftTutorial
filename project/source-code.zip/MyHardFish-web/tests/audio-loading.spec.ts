import { test, expect } from "@playwright/test";
import type { Page } from "@playwright/test";
import { newGame } from "../src/engine";
import { SAVE_KEY } from "../src/storage";
import { AUDIO_PREFERENCES_KEY } from "../src/audio-preferences";

const artifacts = process.env.QA_ARTIFACT_DIR || "../research/scene-music-v6";

async function setup(page: Page) {
  const state = newGame();
  state.settings.lowQuality = true;
  await page.addInitScript(({ state, key }) => {
    if (!localStorage.getItem(key)) localStorage.setItem(key, JSON.stringify(state));
    // Observe native media and audio nodes; playback and decoding remain real.
    const probe = { tracks: [] as HTMLAudioElement[], tones: [] as number[], gain: null as GainNode | null, context: null as AudioContext | null };
    (window as any).__audioProbe = probe;
    const fetches: { url: string; cache?: RequestCache }[] = [];
    (window as any).__resourceFetches = fetches;
    const originalFetch = window.fetch.bind(window);
    window.fetch = (input, init) => {
      fetches.push({ url: String(input), cache: init?.cache });
      return originalFetch(input, init);
    };
    const OriginalAudio = window.Audio;
    window.Audio = function(src?: string) {
      const track = new OriginalAudio(src);
      probe.tracks.push(track);
      return track;
    } as typeof Audio;
    window.Audio.prototype = OriginalAudio.prototype;
    const OriginalContext = window.AudioContext;
    const edges = new WeakMap<AudioNode, AudioNode>();
    window.AudioContext = class extends OriginalContext {
      constructor(options?: AudioContextOptions) { super(options); probe.context = this; }
      createGain() {
        const gain = super.createGain();
        const connect = gain.connect.bind(gain);
        gain.connect = ((node: AudioNode) => { edges.set(gain, node); return connect(node); }) as typeof gain.connect;
        return gain;
      }
      createMediaElementSource(track: HTMLMediaElement) {
        const source = super.createMediaElementSource(track);
        const connect = source.connect.bind(source);
        source.connect = ((node: AudioNode) => { probe.gain = (edges.get(node) || node) as GainNode; return connect(node); }) as typeof source.connect;
        return source;
      }
      createOscillator() {
        const tone = super.createOscillator();
        const start = tone.start.bind(tone);
        tone.start = (when?: number) => { probe.tones.push(tone.frequency.value); start(when); };
        return tone;
      }
    };
  }, { state, key: SAVE_KEY });
}
async function ready(page: Page) {
  await page.goto("./");
  await expect(page.locator(".resource-loading")).toHaveCount(0, { timeout: 60000 });
  await expect(page.getByTestId("scene")).toHaveAttribute("data-ready", "true");
}
async function settings(page: Page) {
  await page.getByRole("button", { name: "打开生活菜单", exact: true }).click();
  await page.getByRole("button", { name: "设置", exact: true }).click();
}
async function music(page: Page) {
  return page.evaluate(() => {
    const probe = (window as any).__audioProbe;
    const track = probe.tracks.find((a: HTMLAudioElement) => a.dataset.audioRole === "background-music");
    return track ? { paused: track.paused, time: track.currentTime, duration: track.duration, loop: track.loop, ready: track.readyState, gain: probe.gain?.gain.value, state: probe.context?.state } : null;
  });
}
async function phase(page: Page, milliseconds: number) {
  return page.locator(".resource-loading").evaluate((root, time) => {
    root.querySelectorAll(".resource-loading__burst *").forEach(node => {
      node.getAnimations().forEach(animation => { animation.pause(); animation.currentTime = time; });
    });
    return {
      horse: Number(getComputedStyle(root.querySelector(".resource-loading__horse")!).opacity),
      particles: [...root.querySelectorAll(".resource-loading__debris")].filter(node => Number(getComputedStyle(node).opacity) > .2).length,
    };
  }, milliseconds);
}

test("actual resource progress, horse explosion loop and loading input lock", async ({ page }, info) => {
  await setup(page);
  let release!: () => void;
  const gate = new Promise<void>(resolve => { release = resolve; });
  await page.route("**/audio/music-home.mp3", async route => { await gate; await route.continue(); });
  try {
    await page.goto("./");
    const loader = page.locator(".resource-loading");
    await expect(page.getByTestId("scene")).toHaveAttribute("data-ready", "true");
    const bar = page.getByRole("progressbar", { name: "游戏素材加载进度" });
    await expect.poll(async () => Number(await bar.getAttribute("aria-valuenow"))).toBeGreaterThan(0);
    expect(Number(await bar.getAttribute("aria-valuenow"))).toBeLessThan(100);
    await page.keyboard.press("m"); await page.keyboard.press("j"); await page.keyboard.press("Enter"); await page.keyboard.press("e");
    await expect(page.getByRole("dialog")).toHaveCount(0);
    expect((await phase(page, 0)).horse).toBe(1);
    await page.screenshot({ path: `${artifacts}/${info.project.name}-loading-horse.png` });
    const burst = await phase(page, 1800);
    expect(burst.horse).toBe(0); expect(burst.particles).toBeGreaterThan(8);
    await page.screenshot({ path: `${artifacts}/${info.project.name}-loading-burst.png` });
    expect((await phase(page, 2850)).horse).toBe(0);
    expect((await phase(page, 3500)).horse).toBe(1);
    const layout = await loader.evaluate(root => ({
      width: document.documentElement.scrollWidth, viewport: innerWidth,
      bar: root.querySelector('[role="progressbar"]')!.getBoundingClientRect().top,
      animation: root.querySelector(".resource-loading__performance")!.getBoundingClientRect().bottom,
    }));
    expect(layout.width).toBe(layout.viewport); expect(layout.bar).toBeGreaterThan(layout.animation);
  } finally { release(); }
  await expect(page.locator(".resource-loading")).toHaveCount(0, { timeout: 30000 });
  await expect(page.getByTestId("scene")).toHaveAttribute("data-loading", "false");
});

test("real BGM loops, ducks under voice, sound feedback and preferences survive reload", async ({ page }, info) => {
  await setup(page);
  const errors: string[] = [];
  page.on("pageerror", error => errors.push(error.message));
  await ready(page);
  expect(await music(page)).toBeNull(); // Never start before a real gesture.
  await settings(page);
  await expect.poll(async () => (await music(page))?.paused).toBe(false);
  await expect.poll(async () => (await music(page))?.time ?? 0).toBeGreaterThan(0);
  expect((await music(page))?.duration).toBeGreaterThan(80);
  expect((await music(page))?.loop).toBe(true);
  await expect.poll(async () => (await music(page))?.gain ?? 0).toBeCloseTo(.3, 2);
  await page.getByRole("button", { name: "试听难鱼的声音" }).click();
  await expect.poll(async () => (await music(page))?.gain ?? 1, { intervals: [25, 50, 100] }).toBeLessThan(.1);
  await expect.poll(async () => (await music(page))?.gain ?? 0).toBeCloseTo(.3, 2);
  await page.evaluate(() => {
    const track = (window as any).__audioProbe.tracks.find((a: HTMLAudioElement) => a.dataset.audioRole === "background-music");
    track.currentTime = track.duration - .05;
  });
  await expect.poll(async () => (await music(page))?.time ?? 999).toBeLessThan(5);
  await page.evaluate(() => { Object.defineProperty(document, "hidden", { configurable: true, value: true }); document.dispatchEvent(new Event("visibilitychange")); });
  await expect.poll(async () => (await music(page))?.paused).toBe(true);
  await page.evaluate(() => { Object.defineProperty(document, "hidden", { configurable: true, value: false }); document.dispatchEvent(new Event("visibilitychange")); });
  await expect.poll(async () => (await music(page))?.paused).toBe(false);
  await page.getByRole("slider", { name: "音乐音量" }).fill("0.45");
  await expect.poll(async () => (await music(page))?.gain ?? 0).toBeCloseTo(.45, 2);
  await page.getByRole("checkbox", { name: /^背景音乐/ }).uncheck();
  await expect.poll(async () => (await music(page))?.paused).toBe(true);
  await page.getByRole("button", { name: "关闭窗口", exact: true }).click();
  const before = await page.evaluate(() => (window as any).__audioProbe.tones.length);
  await page.getByRole("button", { name: "给她投喂", exact: true }).click();
  await page.getByRole("button", { name: "投喂热乎小包子", exact: true }).click();
  await expect(page.getByTestId("scene")).toHaveAttribute("data-motion", "eat");
  await expect.poll(() => page.evaluate(() => (window as any).__audioProbe.tones.length)).toBeGreaterThan(before + 1);
  await settings(page);
  await page.getByRole("checkbox", { name: /^互动音效/ }).uncheck();
  await page.screenshot({ path: `${artifacts}/${info.project.name}-sound-settings.png` });
  const quiet = await page.evaluate(() => (window as any).__audioProbe.tones.length);
  await page.getByRole("button", { name: "关闭窗口", exact: true }).click();
  await page.getByRole("button", { name: "打开生活菜单", exact: true }).click();
  expect(await page.evaluate(() => (window as any).__audioProbe.tones.length)).toBe(quiet);
  await page.reload();
  await expect(page.locator(".resource-loading")).toHaveCount(0, { timeout: 60000 });
  await settings(page);
  await expect(page.getByRole("checkbox", { name: /^背景音乐/ })).not.toBeChecked();
  await expect(page.getByRole("checkbox", { name: /^互动音效/ })).not.toBeChecked();
  await expect(page.getByRole("slider", { name: "音乐音量" })).toHaveValue("0.45");
  // Muted reload does not allocate a music deck; either absence or pause is silent.
  expect((await music(page))?.paused ?? true).toBe(true);
  await page.getByRole("checkbox", { name: /^背景音乐/ }).check();
  await expect.poll(async () => (await music(page))?.paused).toBe(false);
  expect(errors).toEqual([]);
});

test("one transport failure recovers automatically without settling the resource twice", async ({ page }) => {
  await setup(page);
  let requests = 0;
  await page.route("**/audio/music-home.mp3", async route => {
    requests++;
    if (requests === 1) await route.abort("failed");
    else await route.continue();
  });
  await ready(page);
  expect(requests).toBe(2);
  expect(await page.evaluate(() => (window as any).__resourceFetches
    .filter((entry: { url: string }) => entry.url.endsWith("/music-home.mp3"))
    .map((entry: { cache: RequestCache }) => entry.cache))).toEqual(["force-cache", "reload"]);
  await expect(page.getByTestId("scene")).toHaveAttribute("data-loading", "false");
  await expect(page.getByRole("button", { name: "给她投喂", exact: true })).toBeVisible();
});

test("failed resource has retry and continue; reduced motion retains the disappearing horse", async ({ page }) => {
  await setup(page);
  await page.emulateMedia({ reducedMotion: "reduce" });
  let broken = true;
  let requests = 0;
  await page.route("**/audio/music-home.mp3", async route => {
    requests++;
    if (broken) await route.fulfill({ status: 503, body: "temporarily absent", headers: { "cache-control": "max-age=600" } });
    else await route.continue();
  });
  await page.goto("./");
  await expect(page.getByRole("button", { name: "再试一次" })).toBeVisible({ timeout: 60000 });
  await expect(page.getByRole("progressbar")).toHaveAttribute("aria-valuenow", "100");
  expect((await phase(page, 1800)).horse).toBe(0);
  expect(await page.locator(".resource-loading__debris").first().evaluate(node => getComputedStyle(node).display)).toBe("none");
  broken = false;
  await page.getByRole("button", { name: "再试一次" }).click();
  await expect(page.locator(".resource-loading")).toHaveCount(0, { timeout: 60000 });
  expect(requests).toBeGreaterThanOrEqual(2);
  // Routing disables browser caching; inspect the actual native Fetch options
  // rather than a transport header that Playwright intercepts before generation.
  const caches = await page.evaluate(() => (window as any).__resourceFetches.filter((entry: { url: string }) => entry.url.endsWith("/music-home.mp3")).map((entry: { cache: RequestCache }) => entry.cache));
  expect(caches).toEqual(["force-cache", "reload"]);
  broken = true;
  await page.reload();
  await expect(page.getByRole("button", { name: "先进入小镇" })).toBeVisible({ timeout: 60000 });
  await page.getByRole("button", { name: "先进入小镇" }).click();
  await expect(page.locator(".resource-loading")).toHaveCount(0);
  await expect(page.getByRole("button", { name: "给她投喂", exact: true })).toBeVisible();
});

test("a blocked preferences write keeps the immediate toggle and reports persistence failure", async ({ page }) => {
  await setup(page);
  await page.addInitScript(key => {
    const original = Storage.prototype.setItem;
    Storage.prototype.setItem = function(name: string, value: string) {
      if (name === key) throw new DOMException("No room", "QuotaExceededError");
      original.call(this, name, value);
    };
  }, AUDIO_PREFERENCES_KEY);
  await ready(page);
  await page.getByRole("button", { name: "关闭背景音乐", exact: true }).click();
  await expect(page.getByRole("button", { name: "开启背景音乐", exact: true })).toBeVisible();
  await expect(page.locator(".toast")).toContainText("声音设置暂时无法保存");
  await expect.poll(async () => (await music(page))?.paused).toBe(true);
});
