import { test, expect } from "@playwright/test";
import type { Page } from "@playwright/test";
import { newGame } from "../src/engine";
import { SAVE_KEY } from "../src/storage";
import catalog from "../src/music-catalog.json" with { type: "json" };
const sceneNames = { home: "小窝", kitchen: "厨房", park: "公园", shop: "便利店", school: "教室", village: "村中心", workshop: "联机工坊", river: "瓶信河岸", market: "夜市" };
type Scene = keyof typeof sceneNames;

async function setup(page: Page) {
  const state = newGame(); state.settings.lowQuality = true; state.settings.voice = false;
  await page.addInitScript(({ state, key }) => {
    if (!localStorage.getItem(key)) localStorage.setItem(key, JSON.stringify(state));
    const probe = { tracks: [] as HTMLAudioElement[], peak: 0, context: null as AudioContext | null, freezeNextScene: "", routes: new WeakMap<HTMLAudioElement, { fade: GainNode; master: GainNode }>(), ramps: [] as { from: number; to: number; seconds: number }[] };
    (window as any).__sceneMusicProbe = probe;
    const OriginalAudio = window.Audio;
    window.Audio = function(src?: string) {
      const track = new OriginalAudio(src); probe.tracks.push(track);
      track.addEventListener("playing", () => {
        if (probe.freezeNextScene && track.dataset.musicScene === probe.freezeNextScene) {
          probe.freezeNextScene = "";
          void probe.context?.suspend();
        }
      });
      probe.peak = Math.max(probe.peak, probe.tracks.filter(a => a.getAttribute("src")?.includes("/music-")).length);
      return track;
    } as typeof Audio;
    window.Audio.prototype = OriginalAudio.prototype;
    const OriginalContext = window.AudioContext;
    const edges = new WeakMap<AudioNode, AudioNode>();
    window.AudioContext = class extends OriginalContext {
      constructor(options?: AudioContextOptions) { super(options); probe.context = this; }
      createGain() {
        const gain = super.createGain(); const connect = gain.connect.bind(gain);
        gain.connect = ((target: AudioNode) => { edges.set(gain, target); return connect(target); }) as typeof gain.connect;
        const ramp = gain.gain.linearRampToValueAtTime.bind(gain.gain);
        gain.gain.linearRampToValueAtTime = (value, end) => { probe.ramps.push({ from: gain.gain.value, to: value, seconds: end - this.currentTime }); return ramp(value, end); };
        return gain;
      }
      createMediaElementSource(track: HTMLMediaElement) {
        const source = super.createMediaElementSource(track); const connect = source.connect.bind(source);
        source.connect = ((target: AudioNode) => { probe.routes.set(track as HTMLAudioElement, { fade: target as GainNode, master: edges.get(target) as GainNode }); return connect(target); }) as typeof source.connect;
        return source;
      }
    };
  }, { state, key: SAVE_KEY });
}
async function ready(page: Page) {
  await page.goto("./"); await expect(page.locator(".resource-loading")).toHaveCount(0, { timeout: 60000 });
  await expect(page.getByTestId("scene")).toHaveAttribute("data-ready", "true");
}
async function stats(page: Page) {
  return page.evaluate(() => {
    const probe = (window as any).__sceneMusicProbe;
    const tracks = probe.tracks.filter((a: HTMLAudioElement) => a.dataset.audioRole === "background-music" && a.getAttribute("src")).map((a: HTMLAudioElement) => ({
      scene: a.dataset.musicScene, paused: a.paused, time: a.currentTime, duration: a.duration, src: a.src,
      fade: probe.routes.get(a)?.fade.gain.value, master: probe.routes.get(a)?.master.gain.value,
    }));
    return { tracks, peak: probe.peak, ramps: probe.ramps };
  });
}
async function settled(page: Page, scene: Scene) {
  await expect.poll(async () => {
    const { tracks } = await stats(page);
    return tracks.length === 1 && tracks[0].scene === scene && !tracks[0].paused && tracks[0].time > 0 && tracks[0].fade > .98;
  }, { timeout: 25000 }).toBe(true);
}
async function travel(page: Page, scene: Scene, quick = false) {
  const map = page.getByRole("button", { name: "打开地图", exact: true });
  if (quick) await map.evaluate(node => (node as HTMLButtonElement).click()); else await map.click();
  const button = page.getByRole("dialog").getByRole("button", { name: sceneNames[scene], exact: true });
  if (quick) await button.evaluate(node => (node as HTMLButtonElement).click()); else await button.click();
  await expect(page.getByTestId("scene")).toHaveAttribute("data-place", scene);
}

test("all nine scenes play distinct native instrumental tracks with bounded crossfade and visible attribution", async ({ page }, info) => {
  test.setTimeout(240000); await setup(page);
  const errors: string[] = []; page.on("pageerror", error => errors.push(error.message));
  await ready(page);
  await page.getByRole("button", { name: "打开生活菜单", exact: true }).click();
  await page.getByRole("button", { name: "设置", exact: true }).click();
  await settled(page, "home");
  await expect(page.getByTestId("current-music-title")).toHaveText(catalog.home.title);
  await page.locator(".music-credits summary").click();
  await expect(page.locator(".music-credits li")).toHaveCount(9);
  for (const track of Object.values(catalog)) await expect(page.locator(".music-credits").getByRole("link", { name: track.title, exact: true })).toHaveAttribute("href", track.source);
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(page.viewportSize()!.width);
  await page.screenshot({ path: `../research/scene-music-v6/${info.project.name}-music-credits.png` });
  await page.getByRole("button", { name: "关闭窗口", exact: true }).click();
  const played: string[] = [];
  for (const scene of Object.keys(sceneNames) as Scene[]) {
    if (scene !== "home") await travel(page, scene);
    await settled(page, scene);
    const metrics = await stats(page); const track = metrics.tracks[0];
    expect(track.src).toContain(`/audio/${catalog[scene].file}`);
    expect(Math.abs(track.duration - catalog[scene].duration)).toBeLessThan(.2);
    expect(track.master).toBeCloseTo(.3, 2); expect(metrics.peak).toBeLessThanOrEqual(2);
    played.push(scene);
  }
  const metrics = await stats(page);
  expect(metrics.ramps.filter((r: any) => r.to === 0 && r.seconds > 1).length).toBeGreaterThanOrEqual(8);
  expect(metrics.ramps.filter((r: any) => r.to === 1 && r.seconds > 1).length).toBeGreaterThanOrEqual(9);
  for (const ramp of metrics.ramps.filter((r: any) => r.seconds > 1)) expect(ramp.seconds).toBeCloseTo(1.2, 1);
  expect(errors).toEqual([]);
  await info.attach("played-scene-music", { body: JSON.stringify({ played, peak: metrics.peak, fadeSeconds: 1.2 }), contentType: "application/json" });
});

test("a suspended native audio clock preserves both crossfade decks until audio resumes", async ({ page }) => {
  test.setTimeout(90000); await setup(page); await ready(page);
  await page.getByRole("button", { name: "打开生活菜单", exact: true }).click();
  await settled(page, "home");
  await page.getByRole("button", { name: "关闭窗口", exact: true }).click();
  await page.evaluate(() => { (window as any).__sceneMusicProbe.freezeNextScene = "park"; });
  await travel(page, "park");
  await expect.poll(() => page.evaluate(() => (window as any).__sceneMusicProbe.context.state)).toBe("suspended");
  const clock = await page.evaluate(() => (window as any).__sceneMusicProbe.context.currentTime);
  // Intentionally let wall time exceed the fade while the real audio clock is stopped.
  await page.waitForTimeout(1600);
  expect(await page.evaluate(() => (window as any).__sceneMusicProbe.context.currentTime)).toBe(clock);
  expect((await stats(page)).tracks.map((track: any) => track.scene).sort()).toEqual(["home", "park"]);
  await page.evaluate(() => (window as any).__sceneMusicProbe.context.resume());
  await settled(page, "park");
  expect((await stats(page)).peak).toBeLessThanOrEqual(2);
});

test("failed replacement keeps old music, retries on gesture, rapid travel and muted reload keep final scene", async ({ page }) => {
  test.setTimeout(150000); await setup(page);
  let broken = true;
  const errors: string[] = []; page.on("pageerror", error => errors.push(error.message));
  await page.route("**/audio/music-workshop.mp3", async route => {
    if (broken && route.request().resourceType() === "media") await route.fulfill({ status: 503, body: "unavailable" });
    else await route.continue();
  });
  await ready(page);
  await page.getByRole("button", { name: "打开地图", exact: true }).click();
  await page.getByRole("button", { name: "关闭窗口", exact: true }).click();
  await settled(page, "home");
  await travel(page, "workshop");
  await settled(page, "home"); // Decode/request failure retains the known-good outgoing song.
  broken = false;
  await page.getByRole("button", { name: "打开生活菜单", exact: true }).click();
  await page.getByRole("button", { name: "关闭窗口", exact: true }).click();
  await settled(page, "workshop");
  for (const scene of ["kitchen", "park", "river"] as Scene[]) await travel(page, scene, true);
  await settled(page, "river"); expect((await stats(page)).peak).toBeLessThanOrEqual(2);
  let releaseLate!: () => void;
  const lateGate = new Promise<void>(resolve => { releaseLate = resolve; });
  let lateRequested = false;
  await page.route("**/audio/music-school.mp3", async route => {
    if (route.request().resourceType() === "media") { lateRequested = true; await lateGate; }
    await route.continue().catch(() => {}); // Returning to the old scene can abort this obsolete request.
  });
  try {
    await travel(page, "school");
    await expect.poll(() => lateRequested).toBe(true);
    expect((await stats(page)).tracks.some((track: any) => track.scene === "school")).toBe(true);
    await travel(page, "river", true);
  } finally { releaseLate(); }
  await settled(page, "river");
  await page.getByRole("button", { name: "关闭背景音乐", exact: true }).click();
  expect((await stats(page)).tracks.every((track: any) => track.paused)).toBe(true);
  await travel(page, "market");
  expect((await stats(page)).tracks).toHaveLength(0);
  await expect.poll(() => page.evaluate(key => JSON.parse(localStorage.getItem(key)!).place, SAVE_KEY)).toBe("market");
  await page.reload(); await expect(page.locator(".resource-loading")).toHaveCount(0, { timeout: 60000 });
  await expect(page.getByRole("button", { name: "开启背景音乐", exact: true })).toBeVisible();
  expect((await stats(page)).tracks).toHaveLength(0);
  await page.getByRole("button", { name: "开启背景音乐", exact: true }).click();
  await settled(page, "market");
  await page.getByRole("button", { name: "打开生活菜单", exact: true }).click();
  await page.getByRole("button", { name: "设置", exact: true }).click();
  await expect(page.getByTestId("current-music-title")).toHaveText(catalog.market.title);
  expect(errors).toEqual([]);
});
