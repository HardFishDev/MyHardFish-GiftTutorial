import { test, expect } from '@playwright/test';
import type { Page } from '@playwright/test';
import { newGame } from '../src/engine';
import { quests } from '../src/adventure-content';
import { SAVE_KEY } from '../src/storage';
import { EXPLORATION_SPOTS } from '../src/world-layout';

async function ready(page:Page) {
  const fixture=newGame(); fixture.settings.voice=false; fixture.settings.lowQuality=true;
  await page.addInitScript(({key,fixture})=>{if(!localStorage.getItem(key))localStorage.setItem(key,JSON.stringify(fixture));},{key:SAVE_KEY,fixture});
  await page.goto('./');
  await expect(page.getByTestId('scene')).toHaveAttribute('data-ready','true');
}
const close=(page:Page)=>page.getByRole('button',{name:'关闭窗口',exact:true}).click();
async function book(page:Page){await page.getByRole('button',{name:'打开村民手帐',exact:true}).click();}
async function games(page:Page){await page.getByRole('button',{name:'打开生活菜单',exact:true}).click();await page.getByRole('button',{name:'一起玩吧',exact:true}).click();}

test('an introductory commission follows real paths, records discoveries and survives a reload',async({page},info)=>{
  test.setTimeout(240000);
  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  await ready(page);
  const quest=quests.find(q=>q.autoStart&&!q.prerequisites.length)!;
  for(let i=0;i<quest.stages.length;i++){
    const stage=quest.stages[i];
    await book(page);
    const card=page.locator('.quest-card').filter({has:page.getByRole('heading',{name:quest.title,exact:true})});
    await expect(card).toBeVisible();
    await card.getByRole('button',{name:'去下一站',exact:true}).click();
    await expect(page.getByTestId('scene')).toHaveAttribute('data-place',stage.place);
    const spot=EXPLORATION_SPOTS.find(s=>s.id===stage.hotspot)!;
    await expect(page.getByRole('dialog')).toBeVisible({timeout:60000});
    await expect(page.getByRole('dialog')).toContainText(spot.label);
    await expect(page.getByTestId('scene')).toHaveAttribute('data-walking','false');
    const record=page.getByRole('button',{name:'记下这处发现',exact:true});
    if(await record.count())await record.click();
    // Introductory commissioning is deliberately playable without a score gate.
    expect((stage.requirements||[]).every(r=>r.kind==='discovery')).toBe(true);
    const choice=stage.choices.find(c=>!c.costShells&&!c.costFoods&&!c.costItems)||stage.choices[0];
    await page.getByRole('button',{name:choice.label,exact:true}).click();
    await expect(page.locator('.spot-feedback')).toContainText(choice.text);
    await close(page);
    if(i===0){await page.reload();await expect(page.getByTestId('scene')).toHaveAttribute('data-ready','true');}
  }
  await book(page);
  await page.getByRole('button',{name:/展开已完成的/}).click();
  await expect(page.locator('.completed-quest')).toContainText(quest.ending);
  await page.getByRole('tab',{name:'村中记事',exact:true}).click();
  await expect(page.locator('.village-log')).toContainText(`完成 · ${quest.title}`);
  await page.screenshot({path:`${process.env.QA_ARTIFACT_DIR || '../research/expansion-v3'}/${info.project.name}-quest-log.png`});
  expect(errors).toEqual([]);
});

test('word relay and berry orders accept corrections, finish once and keep rewards after reload',async({page},info)=>{
  test.setTimeout(180000);
  await ready(page);await games(page);
  await page.getByRole('button',{name:/词卡接力/}).click();
  const before=Number(await page.getByTestId('shells').textContent());
  await page.getByRole('button',{name:'和难鱼一起开始',exact:true}).click();
  const vocabulary:Record<string,string>={'浆果':'berry','桥':'bridge','瓶子':'bottle','花园':'garden','食谱':'recipe','灯笼':'lantern','分享':'share','修理':'repair','邀请':'invite','谢谢':'thanks'};
  for(let round=0;round<5;round++){
    const meaning=(await page.locator('.word-clue h4').textContent())!;
    const correct=vocabulary[meaning];expect(correct).toBeTruthy();
    if(round===0){const options=await page.locator('.word-options button').allTextContents();await page.getByRole('button',{name:options.find(word=>word!==correct)!,exact:true}).click();await expect(page.getByRole('status').filter({hasText:'先别急着交'})).toBeVisible();}
    await page.getByRole('button',{name:correct,exact:true}).click();
    await page.getByRole('button',{name:round===4?'收工，记下今天的成果':'下一张线索卡',exact:true}).click();
  }
  await expect(page.locator('.field-game .result-number')).toContainText('4');
  await expect(page.getByTestId('shells')).toHaveText(String(before+28));
  await close(page);await games(page);await page.getByRole('button',{name:/浆果回收/}).click();
  await page.getByRole('button',{name:'和难鱼一起开始',exact:true}).click();
  for(let round=0;round<5;round++){
    const requested=await page.locator('.harvest-order>div span').allTextContents();
    if(round===0){await page.getByRole('button',{name:'装入种子袋',exact:true}).click();await page.getByRole('button',{name:'核对并交付这一筐',exact:true}).click();await expect(page.getByRole('status').filter({hasText:'物料已退回'})).toBeVisible();}
    for(const line of requested){const match=line.match(/(熟浆果|酸浆果|种子袋)\s*×\s*(\d+)/)!;expect(match).toBeTruthy();for(let n=0;n<Number(match[2]);n++)await page.getByRole('button',{name:`装入${match[1]}`,exact:true}).click();}
    await page.getByRole('button',{name:'核对并交付这一筐',exact:true}).click();
    await page.getByRole('button',{name:round===4?'收工，记下今天的成果':'去装下一筐',exact:true}).click();
  }
  await expect(page.locator('.field-game .result-number')).toContainText('4');
  await expect(page.getByTestId('shells')).toHaveText(String(before+56));
  await page.screenshot({path:`${process.env.QA_ARTIFACT_DIR || '../research/expansion-v3'}/${info.project.name}-harvest.png`});
  await close(page);await page.reload();await expect(page.getByTestId('shells')).toHaveText(String(before+56));
  await games(page);await expect(page.getByRole('button',{name:/浆果回收/})).toContainText('最高 4 分');
});

test('arriving at a commission preserves an open notebook and nearby interaction remains available',async({page},info)=>{
  test.setTimeout(120000);
  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  await ready(page);await book(page);
  const quest=quests.find(q=>q.autoStart&&!q.prerequisites.length)!;
  const stage=quest.stages[0];
  const spot=EXPLORATION_SPOTS.find(s=>s.id===stage.hotspot)!;
  const scene=page.getByTestId('scene');
  const card=page.locator('.quest-card').filter({has:page.getByRole('heading',{name:quest.title,exact:true})});
  await card.getByRole('button',{name:'去下一站',exact:true}).click();
  await expect(scene).toHaveAttribute('data-walking','true');
  // The real keyboard shortcut opens the notebook during the existing route.
  // Keeping this quick leaves the character walking when the modal appears.
  await page.keyboard.press('j');
  await expect(page.getByRole('dialog',{name:'村民手帐',exact:true})).toBeVisible();
  await expect(scene).toHaveAttribute('data-walking','true');
  const before=await scene.getAttribute('data-position');
  await expect(scene).toHaveAttribute('data-walking','false',{timeout:60000});
  await expect(scene).not.toHaveAttribute('data-position',before!);
  await expect(page.getByRole('dialog',{name:'村民手帐',exact:true})).toBeVisible();
  await expect(page.getByRole('tab',{name:'委托',exact:true})).toBeVisible();
  await page.screenshot({path:`${process.env.QA_ARTIFACT_DIR || '../research/expansion-v3'}/${info.project.name}-arrival-notebook.png`});
  await close(page);
  // The HUD intentionally stops polling while a modal is open; check its final
  // arrival state after closing, then use the same interaction offered to players.
  await expect(page.locator('.navigation-status')).toContainText('到了，看看这里');
  await page.locator('.nearby-interaction').filter({hasText:spot.label}).click();
  await expect(page.getByRole('dialog')).toContainText(spot.label);
  await expect(page.getByRole('button',{name:stage.choices[0].label,exact:true})).toBeEnabled();
  expect(errors).toEqual([]);
});
