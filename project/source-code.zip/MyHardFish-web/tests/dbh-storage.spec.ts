import { test, expect } from '@playwright/test';
import { newGame, step } from '../src/engine';
import { makeArchive, readArchive, validateState } from '../src/storage';
import { applyDbhInteraction, createDbhState, recordDbhVisit } from '../src/dbh-state';
import { DBH_CLUES } from '../src/dbh-content';

test('existing saves gain an empty DBH record without changing player progress', () => {
  const original = newGame(); original.shells = 432; original.place = 'village';
  const legacy = JSON.parse(JSON.stringify(original)); delete legacy.dbh;
  const loaded = validateState(legacy);
  expect(loaded.dbh).toEqual(createDbhState());
  expect(loaded.shells).toBe(432); expect(loaded.place).toBe('village');
});

test('DBH quest, friendship and memories survive ZIP and manual slot round trips', () => {
  let dbh = applyDbhInteraction(createDbhState(), { type: 'greet' });
  dbh = applyDbhInteraction(dbh, { type: 'startQuest' });
  for (const clue of DBH_CLUES) {
    dbh = recordDbhVisit(dbh, 'village', clue.hotspot);
    dbh = applyDbhInteraction(dbh, { type: 'answer', clue: clue.id, answer: clue.answer });
  }
  dbh = applyDbhInteraction(dbh, { type: 'finishQuest' });
  const original = newGame();
  const next = step(original, { type: 'dbh', value: dbh }, original.updatedAt);
  expect(next.dbh.quest.status).toBe('completed');
  expect(next.shells).toBe(original.shells); expect(next.bond).toBe(original.bond);
  expect(original.dbh).toEqual(createDbhState());
  const result = readArchive(makeArchive(next, [{ label: '广场上的约定', savedAt: next.updatedAt, state: next }, null, null]));
  expect(result.state.dbh).toEqual(dbh);
  expect(result.slots[0]?.state.dbh).toEqual(dbh);
  expect(result.state.dbh.memories).toContain('village_walk');
});

test('malformed optional NPC data is bounded and does not destroy a valid main save', () => {
  const original = newGame();
  const loaded = validateState({ ...original, dbh: {schema: 1, credited: ['unknown'], quest: {status: 'completed',visited: [],answers: {untrusted: 'value'}}, memories: ['village_walk']} });
  expect(loaded.dbh.credited).toEqual([]);
  expect(loaded.dbh.quest.status).toBe('active');
  expect(loaded.dbh.memories).toEqual([]);
});
