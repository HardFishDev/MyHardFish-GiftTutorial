import { writeFile } from 'node:fs/promises';
import type { Page, TestInfo } from '@playwright/test';

/** Observe native input without preventing events or changing riding state. */
export async function observeCyclingTouchControls(page: Page) {
  await page.evaluate(() => {
    const host = document.querySelector<HTMLElement>('[data-testid="cycling-game"]')!;
    const events: unknown[] = [];
    (window as any).__cyclingTouchEvents = events;
    const read = () => ({ lane: host.dataset.lane, paused: host.dataset.paused, braking: host.dataset.braking });
    for (const type of ['pointerdown', 'pointerup', 'pointercancel', 'click', 'touchstart', 'touchend']) {
      document.addEventListener(type, event => {
        const target = event.target instanceof Element ? event.target.closest('button') : null;
        const name = target?.getAttribute('aria-label') || target?.textContent;
        if (!['向左变道', '向右变道', '减速'].includes(name || '')) return;
        const entry = { type, name, time: performance.now(), detail: (event as UIEvent).detail,
          pointerType: (event as PointerEvent).pointerType, pointerId: (event as PointerEvent).pointerId,
          firesTouchEvents: (event as any).sourceCapabilities?.firesTouchEvents,
          isTrusted: event.isTrusted, defaultPrevented: event.defaultPrevented, before: read(), after: {} };
        events.push(entry);
        setTimeout(() => { entry.after = read(); entry.defaultPrevented = event.defaultPrevented; }, 0);
      }, { capture: true, passive: true });
    }
    new MutationObserver(records => {
      for (const record of records) events.push({ type: 'lane', from: record.oldValue, to: host.dataset.lane, time: performance.now() });
    }).observe(host, { attributes: true, attributeOldValue: true, attributeFilter: ['data-lane'] });
  });
}

export async function saveFailedCyclingTouchProbe(page: Page, info: TestInfo) {
  if (info.status === info.expectedStatus) return;
  const events = await page.evaluate(() => (window as any).__cyclingTouchEvents).catch(() => null);
  if (!events) return;
  const path = info.outputPath('touch-events.json');
  await writeFile(path, JSON.stringify(events, null, 2));
  await info.attach('touch-events', { path, contentType: 'application/json' });
}
