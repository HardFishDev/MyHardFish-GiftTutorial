import { getEventListeners } from 'node:events';
import { expect, test as base } from '@playwright/test';
import { waitForScenePaint } from '../src/scene-transition';

type Frames = { paint: () => void; pending: () => number };
const test = base.extend<{ frames: Frames }>({
  frames: async ({}, use) => {
    const previousRequest = globalThis.requestAnimationFrame;
    const previousCancel = globalThis.cancelAnimationFrame;
    const pending = new Map<number, FrameRequestCallback>();
    let next = 0;
    globalThis.requestAnimationFrame = callback => { pending.set(++next, callback); return next; };
    globalThis.cancelAnimationFrame = id => { pending.delete(id); };
    try {
      await use({
        pending: () => pending.size,
        paint: () => {
          const current = [...pending];
          for (const [id, callback] of current) {
            if (!pending.delete(id)) continue;
            callback(next * 16);
          }
        },
      });
    } finally {
      globalThis.requestAnimationFrame = previousRequest;
      globalThis.cancelAnimationFrame = previousCancel;
    }
  },
});

test('scene preparation waits through a complete loading-message paint opportunity', async ({ frames }) => {
  const controller = new AbortController();
  let started = false;
  const preparation = waitForScenePaint(controller.signal).then(ready => { started = ready; return ready; });
  await Promise.resolve();
  expect(started).toBe(false);
  frames.paint();
  await Promise.resolve();
  expect(started).toBe(false);
  frames.paint();
  expect(await preparation).toBe(true);
  expect(started).toBe(true);
  expect(frames.pending()).toBe(0);
  expect(getEventListeners(controller.signal, 'abort')).toHaveLength(0);
});

for (const painted of [0, 1]) {
  test(`disposing after ${painted} frames cancels pending scene work and listeners`, async ({ frames }) => {
    const controller = new AbortController();
    const preparation = waitForScenePaint(controller.signal);
    if (painted) frames.paint();
    controller.abort();
    expect(await preparation).toBe(false);
    expect(frames.pending()).toBe(0);
    expect(getEventListeners(controller.signal, 'abort')).toHaveLength(0);
    frames.paint();
    expect(frames.pending()).toBe(0);
  });
}

test('a disposed view never schedules scene construction', async ({ frames }) => {
  const controller = new AbortController();
  controller.abort();
  expect(await waitForScenePaint(controller.signal)).toBe(false);
  expect(frames.pending()).toBe(0);
});

test('cancelling an older route leaves the latest route paint boundary intact', async ({ frames }) => {
  const old = new AbortController(), latest = new AbortController();
  const oldPreparation = waitForScenePaint(old.signal);
  frames.paint();
  const newPreparation = waitForScenePaint(latest.signal);
  old.abort();
  expect(await oldPreparation).toBe(false);
  expect(frames.pending()).toBe(1);
  frames.paint();
  frames.paint();
  expect(await newPreparation).toBe(true);
  expect(frames.pending()).toBe(0);
  expect(getEventListeners(latest.signal, 'abort')).toHaveLength(0);
});
