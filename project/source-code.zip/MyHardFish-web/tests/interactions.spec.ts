import { test, expect } from '@playwright/test';
import type { Page, TestInfo } from '@playwright/test';
import { newGame } from '../src/engine';
import { SAVE_KEY } from '../src/storage';
import { discoveries } from '../src/adventure-content';
import { EXPLORATION_SPOTS } from '../src/world-layout';
import { activityForHotspot } from '../src/world-activities';
import { AUDIO_PREFERENCES_KEY } from '../src/audio-preferences';

const evidence = process.env.QA_ARTIFACT_DIR || '../research/interaction-v7';
const discoveryMode = process.env.QA_DISCOVERY_MODE || 'full';
if (!['full', 'regional'].includes(discoveryMode)) throw new Error('Unknown QA_DISCOVERY_MODE');
async function ready(page: Page, lowQuality = true) {
  page.setDefaultTimeout(45000);
  const state = newGame(); state.settings.voice = false; state.settings.lowQuality = lowQuality;
  state.hunger = 12; state.energy = 100; state.inventory = { bun: 4, milk: 4, peach: 4, rice: 4, coffee: 4 };
  await page.addInitScript(({ state, key, audioKey }) => {
    if (!localStorage.getItem(key)) localStorage.setItem(key, JSON.stringify(state));
    localStorage.setItem(audioKey, JSON.stringify({ music: false, effects: false, musicVolume: .3, effectsVolume: .6 }));
  }, { state, key: SAVE_KEY, audioKey: AUDIO_PREFERENCES_KEY });
  await page.goto('./');
  await expect(page.locator('.resource-loading')).toHaveCount(0, { timeout: 210000 });
  await expect(page.getByTestId('scene')).toHaveAttribute('data-ready', 'true');
}
async function details(page: Page) {
  const raw = await page.getByTestId('scene').getAttribute('data-activity-details');
  return raw ? JSON.parse(raw) : null;
}
async function active(page: Page, kind: string) {
  await expect.poll(async () => {
    const d = await details(page); return d?.kind === kind && d.phase === 'active';
  }, { timeout: 70000 }).toBe(true);
  return details(page);
}
async function close(page: Page) { await page.getByRole('button', { name: '关闭窗口', exact: true }).click(); }
async function menu(page: Page) { await page.getByRole('button', { name: '打开生活菜单', exact: true }).click(); }
async function discover(page: Page, id: string) {
  const discovery = discoveries.find(d => d.hotspot === id)!;
  await page.getByRole('button', { name: '打开村民手帐', exact: true }).click();
  await page.getByRole('tab', { name: '探索册', exact: true }).click();
  await page.locator('.discovery-groups button').filter({ has: page.getByText(discovery.title, { exact: true }) }).click();
  const spot = EXPLORATION_SPOTS.find(s => s.id === id)!;
  await expect(page.getByRole('dialog')).toContainText(spot.label, { timeout: 70000 });
  return spot;
}
function seated(d: any) {
  expect(d.seatAnchor).toBeTruthy(); expect(d.seatContact).toBeTruthy();
  expect(d.seatContactError).toBeLessThan(.09);
  expect(Math.abs(d.seatContact.y - d.seatAnchor.y)).toBeLessThan(.07);
}
async function visibleBesidePanel(page: Page, d: any, info: TestInfo) {
  const panel = await page.getByRole('dialog').boundingBox(); expect(panel).toBeTruthy();
  expect(d.screen.bounds.width).toBeGreaterThan(18); expect(d.screen.bounds.height).toBeGreaterThan(50);
  const center = { x: (d.screen.bounds.left + d.screen.bounds.right) / 2, y: (d.screen.bounds.top + d.screen.bounds.bottom) / 2 };
  if (info.project.name === 'mobile') expect(center.y).toBeLessThan(panel!.y);
  else expect(center.x).toBeLessThan(panel!.x);
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(page.viewportSize()!.width);
}

test('sit on actual furniture, drink and eat visible props, and stand up when moving', async ({ page }, info) => {
  test.setTimeout(240000); const errors: string[] = []; page.on('pageerror', e => errors.push(e.message));
  await ready(page, false);
  await menu(page); await page.getByRole('button', { name: '歇一会儿', exact: true }).click();
  let d = await active(page, 'sit'); seated(d);
  await page.screenshot({ path: `${evidence}/${info.project.name}-sit-home.png` });
  await page.keyboard.press('w');
  await expect.poll(() => details(page)).toBeNull();
  await expect(page.getByTestId('scene')).toHaveAttribute('data-walking', 'false');
  for (const [name, prop, food] of [['温牛奶', 'cup', 'milk'], ['热乎小包子', 'food', 'bun']] as const) {
    const before = Number(await page.getByTestId('hunger').textContent());
    await page.getByRole('button', { name: '给她投喂', exact: true }).click();
    await page.getByRole('button', { name: `投喂${name}`, exact: true }).click();
    await expect(page.getByRole('dialog')).toHaveCount(0);
    d = await active(page, 'eat'); expect(d.prop).toBe(prop); expect(d.food).toBe(food);
    expect(d.visibleProps.length).toBeGreaterThan(0);
    await expect.poll(async () => Number(await page.getByTestId('hunger').textContent())).toBeGreaterThan(before);
    await page.screenshot({ path: `${evidence}/${info.project.name}-eat-${food}.png` });
    await expect.poll(async () => (await details(page))?.foodMouthDistance ?? 100, { timeout: 10000 }).toBeLessThan(.42);
    await expect.poll(() => details(page), { timeout: 13000 }).toBeNull();
  }
  expect(errors).toEqual([]);
});

test(discoveryMode === 'regional'
  ? 'regional scene actions and the workshop sequence keep character and props visible'
  : 'every discovery has a spatial action and panels leave the character visible', async ({ page }, info) => {
  test.setTimeout(720000); const errors: string[] = []; page.on('pageerror', e => errors.push(e.message));
  await ready(page);
  // The default remains the full desktop tour. Regional mode explicitly reports
  // 12 points in each viewport, including the desk and all three workshop objects.
  const regional = ['home_terrace', 'kitchen_table', 'park_pavilion', 'shop_fruit', 'school_desk', 'village_garden', 'workshop_server', 'river_observatory', 'market_table'];
  if (discoveryMode === 'regional') regional.push('home_record', 'workshop_recycle', 'workshop_project');
  const selected = info.project.name === 'desktop' && discoveryMode === 'full' ? EXPLORATION_SPOTS
    : EXPLORATION_SPOTS.filter(s => regional.includes(s.id));
  expect(new Set(selected.map(spot => spot.place)).size).toBe(9);
  expect(selected.length).toBe(discoveryMode === 'regional' ? 12 : info.project.name === 'desktop' ? 27 : 9);
  const checked: any[] = [];
  for (const spot of selected) {
    console.log(`Physical interaction ${info.project.name}: ${spot.id}`);
    await discover(page, spot.id);
    const preset = activityForHotspot(spot.place, `adventure:${spot.id}`)!;
    const d = await active(page, preset.kind);
    expect(d.hotspotId).toBe(`adventure:${spot.id}`); expect(d.prop).toBe(preset.prop);
    if (preset.prop !== 'none') expect(d.visibleProps.length).toBeGreaterThan(0);
    if (preset.seated) seated(d);
    await visibleBesidePanel(page, d, info);
    const sample = await page.evaluate(() => {
      const canvas = document.querySelector('[data-testid="scene"] canvas') as HTMLCanvasElement;
      const sampler = document.createElement('canvas'); sampler.width = sampler.height = 32;
      const ctx = sampler.getContext('2d')!; ctx.drawImage(canvas, 0, 0, 32, 32);
      const pixels = ctx.getImageData(0, 0, 32, 32).data, colors = new Set();
      for (let n = 0; n < pixels.length; n += 4) colors.add(`${pixels[n] >> 4},${pixels[n + 1] >> 4},${pixels[n + 2] >> 4}`);
      return colors.size;
    }); expect(sample).toBeGreaterThan(20);
    if (info.project.name === 'mobile' || preset.seated || preset.kind === 'water' || preset.prop === 'lantern')
      await page.screenshot({ path: `${evidence}/${info.project.name}-${spot.id}.png` });
    checked.push(d);
    await close(page);
    await expect.poll(() => details(page)).toBeNull();
  }
  expect(errors).toEqual([]);
  await info.attach('real-world-activity-geometry', { body: JSON.stringify({ discoveryMode, checked }), contentType: 'application/json' });
});

test('game steps use physical props and continuing a quiet story restores its gesture', async ({ page }, info) => {
  test.setTimeout(300000); const errors: string[] = []; page.on('pageerror', e => errors.push(e.message)); await ready(page);
  await menu(page); await page.getByRole('button', { name: '一起玩吧', exact: true }).click();
  await page.getByRole('button', { name: /火候刚刚好/ }).click();
  await active(page, 'inspect');
  await page.getByRole('button', { name: '和难鱼一起开始', exact: true }).click();
  let d = await active(page, 'cook');
  expect(d.visibleProps.some((p: any) => p.prop === 'spatula')).toBe(true);
  expect(d.visibleProps.some((p: any) => p.prop === 'pan')).toBe(true);
  await visibleBesidePanel(page, d, info);
  await page.screenshot({ path: `${evidence}/${info.project.name}-cooking.png` });
  for (let n = 0; n < 3; n++) await page.getByRole('button', { name: '出锅！', exact: true }).click();
  await expect(page.locator('.game-result')).toBeVisible();
  await expect.poll(async () => (await details(page))?.kind).toBe('celebrate');
  await close(page);
  await expect.poll(() => details(page), { timeout: 12000 }).toBeNull();

  // This original story explicitly allows declining dessert. Play its real choices.
  await page.getByRole('button', { name: /^聊聊天/ }).click();
  await page.getByRole('tab', { name: '小故事', exact: true }).click();
  const card = page.getByRole('button').filter({ has: page.getByRole('heading', { name: '谢谢，但蛋糕先不用', exact: true }) });
  await card.click();
  await expect(page.locator('.story-reader')).toBeVisible();
  await active(page, 'talk');
  await close(page);
  await page.getByRole('button', { name: /^聊聊天/ }).click();
  await page.getByRole('tab', { name: '小故事', exact: true }).click();
  await page.getByRole('button', { name: /继续上次的故事/ }).click();
  d = await active(page, 'talk'); expect(d.prop).toBe('none');
  expect(d.visibleProps).toEqual([]);
  await close(page); await expect.poll(() => details(page)).toBeNull();
  expect(errors).toEqual([]);
});

test('the other four games animate at their real locations and keep props after a step', async ({ page }, info) => {
  test.setTimeout(420000); const errors: string[] = []; page.on('pageerror', e => errors.push(e.message)); await ready(page);
  const games = [
    { title: '词卡接力', kind: 'read', prop: 'book', control: '.word-options button' },
    { title: '浆果回收', kind: 'shop', prop: 'bag', control: '.harvest-stock button' },
    { title: '漂流瓶记忆', kind: 'inspect', prop: 'magnifier', control: '.bottle-grid button' },
    { title: '五题就下课', kind: 'write', prop: 'pencil', control: '.math-options button' },
  ];
  for (const game of games) {
    console.log(`Game interaction ${info.project.name}: ${game.title}`);
    await menu(page); await page.getByRole('button', { name: '一起玩吧', exact: true }).click();
    await page.getByRole('button', { name: new RegExp(game.title) }).click();
    await active(page, game.kind);
    await page.getByRole('button', { name: '和难鱼一起开始', exact: true }).click();
    let d = await active(page, game.kind); expect(d.prop).toBe(game.prop); expect(d.visibleProps.length).toBeGreaterThan(0);
    await page.locator(game.control).first().click();
    d = await active(page, game.kind); expect(d.visibleProps.length).toBeGreaterThan(0);
    await visibleBesidePanel(page, d, info);
    await page.screenshot({ path: `${evidence}/${info.project.name}-game-${game.kind}-${game.prop}.png` });
    await close(page); await expect.poll(() => details(page), { timeout: 12000 }).toBeNull();
  }
  expect(errors).toEqual([]);
});

test('a story without a named world hotspot starts, changes gesture and resumes physically', async ({ page }, info) => {
  test.setTimeout(240000); const errors: string[] = []; page.on('pageerror', e => errors.push(e.message)); await ready(page);
  await page.getByRole('button', { name: /^聊聊天/ }).click();
  await page.getByRole('tab', { name: '小故事', exact: true }).click();
  await page.getByRole('button', { name: /应援会改名风波/ }).click();
  await active(page, 'talk');
  await page.getByRole('button', { name: '立刻改成「普通群友」', exact: true }).click();
  let d = await active(page, 'write'); expect(d.prop).toBe('pencil'); expect(d.visibleProps.length).toBeGreaterThan(0);
  await visibleBesidePanel(page, d, info);
  await close(page); await expect.poll(() => details(page), { timeout: 12000 }).toBeNull();
  await page.reload(); await expect(page.locator('.resource-loading')).toHaveCount(0, { timeout: 210000 });
  await expect(page.getByTestId('scene')).toHaveAttribute('data-ready', 'true');
  await page.getByRole('button', { name: /^聊聊天/ }).click();
  await page.getByRole('tab', { name: '小故事', exact: true }).click();
  await page.getByRole('button', { name: '继续上次的故事', exact: true }).click();
  d = await active(page, 'write'); expect(d.prop).toBe('pencil'); expect(d.visibleProps.length).toBeGreaterThan(0);
  await visibleBesidePanel(page, d, info);
  // The real side-front view previously put the desk divider and tall wardrobe over her face.
  await expect.poll(async () => {
    const raw = await page.getByTestId('scene').getAttribute('data-camera-occlusion');
    return raw ? JSON.parse(raw).hidden : [];
  }, { timeout: 7000 }).toEqual(expect.arrayContaining(['home-writing-screen', 'home-wardrobe-upper']));
  await page.screenshot({ path: `${evidence}/${info.project.name}-story-fanclub-resume.png` });
  await close(page); await expect.poll(() => details(page), { timeout: 12000 }).toBeNull();
  expect(errors).toEqual([]);
});
