import { test, expect } from '@playwright/test';
import type { Page, TestInfo } from '@playwright/test';
import { newGame } from '../src/engine';
import type { GameState } from '../src/engine';
import { SAVE_KEY } from '../src/storage';
import { AUDIO_PREFERENCES_KEY } from '../src/audio-preferences';
import { cyclingReward, getCyclingDifficulty } from '../src/cycling';
import type { CyclingItem } from '../src/cycling';
import audioCatalog from '../src/cycling-audio-catalog.json' with { type: 'json' };

const audioFiles = Object.values(audioCatalog).map(entry => entry.file).sort();
const game = (page: Page) => page.getByTestId('cycling-game');
const scene = (page: Page) => page.getByTestId('cycling-scene');
const value = async (page: Page, attribute: string) => Number(await game(page).getAttribute(attribute));
const saved = (page: Page): Promise<GameState> => page.evaluate(key => JSON.parse(localStorage.getItem(key)!), SAVE_KEY);
type AudioEvent = { file: string; started: number; ended: number | null; duration: number; contextState: string };
type AudioProbe = { decoded: string[]; events: AudioEvent[]; maxVoice: number; voiceActive: number; speechCalls: number };
type CyclingFrame = { integrity: number; speed: number; previousSpeed: number; slowdown: number;
  phase?: string; pickupAnimation?: string; hitAnimation?: string };
type CyclingFrames = { hits: CyclingFrame[]; pickups: (CyclingFrame & { kind: string })[]; frames: CyclingFrame[] };
const audioProbe = (page: Page): Promise<AudioProbe> => page.evaluate(() => (window as any).__cyclingAudioProbe);
const observedRecovery = (page: Page) => page.evaluate(() => {
  const probe = (window as any).__cyclingFrames as CyclingFrames;
  return probe.frames.some(frame => {
    const hit = probe.hits.find(hit => hit.integrity === frame.integrity);
    return hit && frame.integrity > 0 && frame.slowdown === 0 && frame.speed > hit.speed + 2;
  });
});

async function setup(page: Page, sound = false) {
  page.setDefaultTimeout(45000);
  await page.clock.install();
  const state = newGame();
  state.place = 'park'; state.energy = 100;
  state.settings.lowQuality = false; state.settings.voice = sound; state.settings.volume = .75;
  await page.addInitScript(({ state, key, preferencesKey, sound }) => {
    if (!localStorage.getItem(key)) localStorage.setItem(key, JSON.stringify(state));
    localStorage.setItem(preferencesKey, JSON.stringify({ music: false, effects: sound, musicVolume: .3 }));
    if (!sound) return;
    // Deterministic pickup-voice probability, retaining distinct random values
    // for Three.js object identifiers and other callers.
    let seed = 42;
    Math.random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296 * .3; };
    const probe = { decoded: [] as string[], events: [] as AudioEvent[], maxVoice: 0, voiceActive: 0, speechCalls: 0 };
    (window as any).__cyclingAudioProbe = probe;
    const fileForData = new WeakMap<ArrayBuffer, string>();
    const fileForBuffer = new WeakMap<AudioBuffer, string>();
    const nativeFetch = window.fetch.bind(window);
    window.fetch = async (input, init) => {
      const response = await nativeFetch(input, init);
      const read = response.arrayBuffer.bind(response);
      response.arrayBuffer = async () => {
        const data = await read();
        fileForData.set(data, new URL(response.url || String(input), location.href).pathname.split('/').pop()!);
        return data;
      };
      return response;
    };
    const NativeContext = window.AudioContext;
    window.AudioContext = class extends NativeContext {
      decodeAudioData(data: ArrayBuffer, success?: DecodeSuccessCallback | null, failure?: DecodeErrorCallback | null) {
        const result = super.decodeAudioData(data, success, failure);
        void result.then(buffer => {
          const file = fileForData.get(data) || '';
          fileForBuffer.set(buffer, file); probe.decoded.push(file);
        }).catch(() => {});
        return result;
      }
      createBufferSource() {
        const source = super.createBufferSource();
        const start = source.start.bind(source), stop = source.stop.bind(source);
        let entry: AudioEvent | undefined;
        const finish = () => {
          if (!entry || entry.ended !== null) return;
          entry.ended = performance.now();
          if (entry.file === 'cycling-voice-pickup.mp3') probe.voiceActive--;
        };
        source.start = (...args: Parameters<typeof source.start>) => {
          start(...args);
          entry = { file: fileForBuffer.get(source.buffer!) || '', started: performance.now(), ended: null, duration: source.buffer?.duration || 0, contextState: this.state };
          probe.events.push(entry);
          if (entry.file === 'cycling-voice-pickup.mp3') { probe.voiceActive++; probe.maxVoice = Math.max(probe.maxVoice, probe.voiceActive); }
        };
        source.stop = (...args: Parameters<typeof source.stop>) => { stop(...args); finish(); };
        source.addEventListener('ended', finish, { once: true });
        return source;
      }
    };
    if (window.speechSynthesis) {
      const speak = speechSynthesis.speak.bind(speechSynthesis);
      speechSynthesis.speak = utterance => { probe.speechCalls++; speak(utterance); };
    }
  }, { state, key: SAVE_KEY, preferencesKey: AUDIO_PREFERENCES_KEY, sound });
}

function observe(page: Page) {
  const requests: string[] = [], errors: string[] = [];
  page.on('request', request => requests.push(new URL(request.url()).pathname));
  page.on('pageerror', error => errors.push(error.message));
  return { requests, errors };
}

async function ready(page: Page, direct = true) {
  await page.goto(direct ? './#cycling' : './');
  await expect(page.locator('.resource-loading')).toHaveCount(0, { timeout: 210000 });
  if (direct) {
    await expect(page.getByTestId('cycling-standalone')).toBeVisible();
    await expect(game(page)).toHaveAttribute('data-phase', 'ready');
    await expect(page.getByRole('button', { name: '开始骑行 · 8 精力', exact: true })).toBeEnabled();
  } else await expect(page.getByTestId('scene')).toHaveAttribute('data-ready', 'true');
}

async function openFromTown(page: Page) {
  await page.getByRole('button', { name: '打开生活菜单', exact: true }).click();
  await page.getByRole('button', { name: '一起玩吧', exact: true }).click();
  await page.getByRole('button').filter({ has: page.getByRole('heading', { name: '难鱼骑自行车', exact: true }) }).click();
}

async function press(page: Page, name: string, touch: boolean) {
  const button = page.getByRole('button', { name, exact: true });
  if (touch) await button.tap(); else await button.click();
}

async function pressWhileRiding(page: Page, name: string, touch: boolean) {
  if (await game(page).getAttribute('data-phase') === 'finished') return;
  const button = page.getByRole('button', { name, exact: true });
  try {
    if (touch) await button.tap({ timeout: 5000 }); else await button.click({ timeout: 5000 });
  } catch (error) {
    // A real last collision may remove the riding controls during actionability.
    if (await game(page).getAttribute('data-phase') !== 'finished') throw error;
  }
}

async function pauseRide(page: Page, touch: boolean) {
  await pressWhileRiding(page, '暂停骑行', touch);
  await expect.poll(async () => await game(page).getAttribute('data-phase') === 'finished'
    || await game(page).getAttribute('data-paused') === 'true').toBe(true);
}

async function steer(page: Page, lane: number, touch: boolean) {
  for (let n = 0; n < 2; n++) {
    if (await game(page).getAttribute('data-phase') === 'finished') return;
    const current = await value(page, 'data-lane');
    if (current === lane) return;
    await pressWhileRiding(page, current < lane ? '向右变道' : '向左变道', touch);
    const target = current + (current < lane ? 1 : -1);
    await expect.poll(async () => await game(page).getAttribute('data-phase') === 'finished'
      || await value(page, 'data-lane') === target).toBe(true);
  }
}

async function canvasPalette(page: Page) {
  return page.getByTestId('cycling-canvas').evaluate(source => new Promise<{ colors: number; brightness: number }>(resolve => requestAnimationFrame(() => {
    const sample = document.createElement('canvas'); sample.width = sample.height = 64;
    const context = sample.getContext('2d')!;
    context.drawImage(source as HTMLCanvasElement, 0, 0, 64, 64);
    const pixels = context.getImageData(0, 0, 64, 64).data;
    const colors = new Set<string>(); let brightness = 0;
    for (let i = 0; i < pixels.length; i += 4) {
      colors.add(`${pixels[i] >> 4},${pixels[i + 1] >> 4},${pixels[i + 2] >> 4}`);
      brightness += .2126 * pixels[i] + .7152 * pixels[i + 1] + .0722 * pixels[i + 2];
    }
    resolve({ colors: colors.size, brightness: brightness / (pixels.length / 4) });
  })));
}

async function capture(page: Page, info: TestInfo, name: string) {
  await page.screenshot({ path: info.outputPath(`${name}.png`), style: '.cycling-intro,.cycling-paused,.cycling-share-status { visibility: hidden; }' });
}

test('cycling resources wait for entry and a cancelled loading screen leaves the town usable', async ({ page }, info) => {
  test.setTimeout(300000);
  await setup(page);
  const observed = observe(page);
  await ready(page, false);
  expect(observed.requests.filter(url => /\/cycling-[^/]+\.mp3$/.test(url))).toEqual([]);
  expect(observed.requests.some(url => /(?:CyclingGame|CyclingStandalone)[-.]/.test(url))).toBe(false);
  const initial = await saved(page);
  let release!: () => void;
  const gate = new Promise<void>(resolve => { release = resolve; });
  const blocked = '**/audio/cycling-pickup-metal.mp3';
  await page.route(blocked, async route => { await gate; await route.continue().catch(() => {}); });
  try {
    await openFromTown(page);
    const progress = page.getByRole('progressbar', { name: '游戏素材加载进度', exact: true });
    await expect(progress).toBeVisible();
    await expect.poll(async () => Number(await progress.getAttribute('aria-valuenow'))).toBeGreaterThan(0);
    expect(Number(await progress.getAttribute('aria-valuenow'))).toBeLessThan(100);
    await expect(page.getByTestId('cycling-canvas')).toHaveCount(0);
    await expect(page.getByTestId('scene')).toHaveAttribute('data-suspended', 'true');
    await page.keyboard.press('ArrowRight'); await page.keyboard.press('Enter');
    expect((await saved(page)).activeGame).toBeNull();
    await page.screenshot({ path: info.outputPath('cycling-entry-loading.png') });
    await press(page, '取消加载', info.project.name === 'mobile');
    await expect(page.getByTestId('cycling-entry')).toHaveCount(0);
    await expect(page.getByTestId('scene')).toHaveAttribute('data-suspended', 'false');
  } finally { release(); }
  await page.unroute(blocked);
  await openFromTown(page);
  await expect(page.getByRole('button', { name: '开始骑行 · 8 精力', exact: true })).toBeEnabled();
  expect([...new Set(observed.requests.filter(url => /\/cycling-[^/]+\.mp3$/.test(url)).map(url => url.split('/').pop()))].sort()).toEqual(audioFiles);
  await page.getByRole('button', { name: '关闭窗口', exact: true }).click();
  const ended = await saved(page);
  expect(ended.energy).toBe(initial.energy); expect(ended.shells).toBe(initial.shells);
  expect(ended.activeGame).toBeNull();
  await test.step('a same-task feed and direct-route change keeps the latest save', async () => {
    await page.getByRole('button', { name: '给她投喂', exact: true }).click();
    const feed = page.getByRole('button', { name: '投喂热乎小包子', exact: true });
    await expect(feed).toBeEnabled();
    // Exercise the real UI handler, then navigate in the same task before the
    // normal 250 ms autosave can flush. No simulation state is injected.
    await feed.evaluate(button => { (button as HTMLButtonElement).click(); location.hash = 'cycling'; });
    await expect(page.getByTestId('cycling-standalone')).toBeVisible();
    await expect(page.getByRole('button', { name: '开始骑行 · 8 精力', exact: true })).toBeEnabled();
    await press(page, '开始骑行 · 8 精力', info.project.name === 'mobile');
    await press(page, '暂停骑行', info.project.name === 'mobile');
    // Starting writes the independently loaded state back to storage; checking
    // after this write catches an incoming route that loaded stale inventory.
    const routed = await saved(page);
    expect(routed.counts.feed).toBe(ended.counts.feed + 1);
    expect(routed.inventory.bun).toBe(ended.inventory.bun - 1);
    await page.getByRole('link', { name: '回到小镇', exact: true }).click();
    await expect(page.getByTestId('scene')).toHaveAttribute('data-ready', 'true');
    await expect.poll(async () => (await saved(page)).activeGame).toBeNull();
    expect((await saved(page)).counts.feed).toBe(routed.counts.feed);
    expect((await saved(page)).inventory.bun).toBe(routed.inventory.bun);
  });
  expect(observed.errors).toEqual([]);
});

test('standalone cycling loads only its assets, shares its direct URL and renders three distinct maps', async ({ page }, info) => {
  test.setTimeout(240000);
  await setup(page);
  await page.context().grantPermissions(['clipboard-read', 'clipboard-write']);
  const observed = observe(page);
  await ready(page);
  await expect(page.getByTestId('scene')).toHaveCount(0);
  const favicon = await page.locator('link[rel="icon"]').evaluate(link => new URL((link as HTMLLinkElement).href).pathname);
  const resources = observed.requests.filter(url => url !== favicon);
  expect(resources.filter(url => /\/(?:App[-.]|world-|avatar|reference)/.test(url))).toEqual([]);
  expect([...new Set(resources.filter(url => /\.(?:mp3|png|webp|jpe?g)$/.test(url)).map(url => url.split('/').pop()))].sort()).toEqual(audioFiles);
  const direct = new URL(page.url()); direct.search = ''; direct.hash = 'cycling';
  await press(page, '分享骑行直链', info.project.name === 'mobile');
  await expect(page.getByRole('status')).toContainText('直链已复制');
  expect(await page.evaluate(() => navigator.clipboard.readText())).toBe(direct.href);
  await page.evaluate(() => { navigator.clipboard.writeText = () => Promise.reject(new DOMException('Clipboard denied', 'NotAllowedError')); });
  await press(page, '分享骑行直链', info.project.name === 'mobile');
  await expect(page.getByRole('textbox', { name: '骑行直链', exact: true })).toHaveValue(direct.href);
  await expect(page.getByRole('textbox', { name: '骑行直链', exact: true })).toHaveAttribute('readonly', '');
  await page.screenshot({ path: info.outputPath('cycling-direct-layout.png') });
  const palettes: Record<string, { colors: number; brightness: number }> = {};
  const rows: Record<string, number> = {};
  for (const [label, difficulty, map] of [['简单', 'easy', 'riverside'], ['普通', 'normal', 'village'], ['困难', 'hard', 'nightHarbor']]) {
    await press(page, `${label}难度`, info.project.name === 'mobile');
    await expect(game(page)).toHaveAttribute('data-difficulty', difficulty);
    await expect(scene(page)).toHaveAttribute('data-map', map);
    await expect(page.getByRole('button', { name: '开始骑行 · 8 精力', exact: true })).toBeEnabled();
    await expect.poll(async () => (await canvasPalette(page)).colors).toBeGreaterThan(20);
    palettes[difficulty] = await canvasPalette(page);
    const course: CyclingItem[] = JSON.parse((await game(page).getAttribute('data-course'))!);
    rows[difficulty] = course.filter(item => item.kind === 'hole' || item.kind === 'barrier').length;
    await capture(page, info, `cycling-map-${difficulty}`);
    for (const name of ['俯视视角', '侧后视角', '跟随视角']) {
      await press(page, name, info.project.name === 'mobile');
      await expect(page.getByRole('button', { name, exact: true })).toHaveAttribute('aria-pressed', 'true');
    }
  }
  expect(palettes.hard.brightness).toBeLessThan(palettes.easy.brightness * .9);
  expect(rows.easy).toBeLessThan(rows.normal); expect(rows.normal).toBeLessThan(rows.hard);
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(page.viewportSize()!.width);
  expect(observed.errors).toEqual([]);
});

test('real pickups and collisions animate, play decoded files and save one hard difficulty reward', async ({ page }, info) => {
  test.setTimeout(300000);
  const touch = info.project.name === 'mobile';
  await setup(page, true);
  const observed = observe(page);
  await ready(page);
  const initial = await saved(page);
  await expect.poll(async () => [...new Set((await audioProbe(page)).decoded)].sort()).toEqual(audioFiles);
  expect((await audioProbe(page)).events).toEqual([]);
  await press(page, '困难难度', touch);
  await expect(scene(page)).toHaveAttribute('data-map', 'nightHarbor');
  const course: CyclingItem[] = JSON.parse((await game(page).getAttribute('data-course'))!);
  await game(page).evaluate(root => {
    const element = root as HTMLElement;
    let previous = Number(element.dataset.integrity);
    let lastEvent = 0;
    const probe: CyclingFrames = { hits: [], pickups: [], frames: [] };
    (window as any).__cyclingFrames = probe;
    // Sample the real event publication. A touch pause can arrive after a later
    // obstacle, so current paused state cannot describe an earlier pickup.
    new MutationObserver(() => {
      const integrity = Number(element.dataset.integrity);
      const host = element.querySelector<HTMLElement>('[data-testid="cycling-scene"]')!;
      const frame = { integrity, speed: Number(element.dataset.speed), previousSpeed: probe.frames.at(-1)?.speed || 0,
        slowdown: Number(element.dataset.slowdownRemaining),
        phase: element.dataset.phase, pickupAnimation: host.dataset.pickupAnimation, hitAnimation: host.dataset.hitAnimation };
      probe.frames.push(frame);
      if (integrity < previous) probe.hits.push(frame);
      for (const event of JSON.parse(element.dataset.events || '[]')) {
        if (event.id <= lastEvent) continue;
        if (event.type === 'pickup') probe.pickups.push({ ...frame, kind: event.kind });
        lastEvent = event.id;
      }
      previous = integrity;
    }).observe(element, { attributes: true, attributeFilter: ['data-integrity', 'data-speed', 'data-events'] });
  });
  await press(page, '开始骑行 · 8 精力', touch);
  await expect.poll(async () => (await saved(page)).activeGame?.difficulty).toBe('hard');
  const sessionId = (await saved(page)).activeGame!.id;
  await page.evaluate(() => { location.hash = 'CYCLING'; });
  await expect(page).toHaveURL(/#CYCLING$/);
  const cruising = getCyclingDifficulty('hard').startSpeed;
  await expect.poll(() => page.evaluate(() => ((window as any).__cyclingFrames as CyclingFrames).frames
    .some(frame => frame.phase === 'riding' && frame.integrity === 3 && frame.speed >= 16))).toBe(true);
  await expect.poll(() => value(page, 'data-score'), { intervals: [25, 50, 100] }).toBeGreaterThanOrEqual(40);
  await pauseRide(page, touch);
  expect((await saved(page)).activeGame?.id).toBe(sessionId);
  const pickupFrame = await page.evaluate(() => (window as any).__cyclingFrames.pickups[0]);
  expect(pickupFrame.kind).toBe('cover'); expect(pickupFrame.integrity).toBe(3);
  expect(pickupFrame.pickupAnimation).toBe('active');
  expect(pickupFrame.speed).toBeGreaterThanOrEqual(pickupFrame.previousSpeed);
  expect(pickupFrame.speed).toBeGreaterThanOrEqual(cruising);
  expect(pickupFrame.slowdown).toBe(0);
  const pickupAudio = await audioProbe(page);
  expect(pickupAudio.events.some(event => event.file === 'cycling-pickup-metal.mp3' && event.duration > .3 && event.contextState === 'running')).toBe(true);
  expect(pickupAudio.events.some(event => event.file === 'cycling-voice-pickup.mp3' && event.duration > 1)).toBe(true);
  await capture(page, info, 'cycling-real-pickup');
  const pickupProgress = await scene(page).getAttribute('data-pickup-progress');
  await page.clock.fastForward(500);
  await expect(scene(page)).toHaveAttribute('data-pickup-progress', pickupProgress!);
  expect((await audioProbe(page)).voiceActive).toBe(0);

  const hazards = course.filter(item => item.kind === 'hole' || item.kind === 'barrier');
  let recoveryChecked = false;
  for (let encounter = 0; encounter < 3 && await game(page).getAttribute('data-phase') !== 'finished'; encounter++) {
    const beforeIntegrity = await value(page, 'data-integrity');
    await pressWhileRiding(page, '继续骑行', touch);
    const distance = await value(page, 'data-distance');
    const target = hazards.find(item => item.distance > distance + 8);
    expect(target).toBeTruthy();
    await steer(page, target!.lane, touch);
    await expect.poll(() => value(page, 'data-integrity'), { timeout: 45000, intervals: [25, 50, 100] }).toBeLessThan(beforeIntegrity);
    if (await game(page).getAttribute('data-phase') === 'finished') break;
    await pauseRide(page, touch);
    if (await game(page).getAttribute('data-phase') === 'finished') break;
    const hitFrame = await page.evaluate(() => (window as any).__cyclingFrames.hits.at(-1));
    expect(hitFrame.speed).toBeLessThan(cruising * .8);
    expect(hitFrame.slowdown).toBeGreaterThan(0);
    expect(hitFrame.hitAnimation).toBe('active');
    expect((await audioProbe(page)).events.some(event => event.file === 'cycling-hit.mp3' && event.duration > .3)).toBe(true);
    if (!recoveryChecked) {
      await capture(page, info, 'cycling-real-hit');
      const distance = await game(page).getAttribute('data-distance');
      const hitProgress = await scene(page).getAttribute('data-hit-progress');
      await page.clock.fastForward(500);
      await expect(scene(page)).toHaveAttribute('data-hit-progress', hitProgress!);
      await expect(game(page)).toHaveAttribute('data-distance', distance!);
      await pressWhileRiding(page, '继续骑行', touch);
      // Recover in the next clear lane, so another deliberate obstacle does
      // not restart the slowdown while this assertion measures its lifetime.
      const nextObstacle = hazards.find(item => item.distance > Number(distance) + 2)!;
      const safePickup = course.find(item => item.distance === nextObstacle.distance && item.kind !== 'hole' && item.kind !== 'barrier')!;
      await steer(page, safePickup.lane, touch);
      await expect.poll(() => observedRecovery(page), { intervals: [50, 100] }).toBe(true);
      recoveryChecked = true;
      if (await game(page).getAttribute('data-phase') !== 'finished') await pauseRide(page, touch);
    }
  }
  await expect(game(page)).toHaveAttribute('data-phase', 'finished');
  const hits = await page.evaluate(() => (window as any).__cyclingFrames.hits as { integrity: number; speed: number; slowdown: number; hitAnimation: string }[]);
  expect(hits.map(hit => hit.integrity)).toEqual([2, 1, 0]);
  for (const hit of hits) {
    expect(hit.speed).toBeLessThan(cruising * .8); expect(hit.slowdown).toBeGreaterThan(0);
    expect(hit.hitAnimation).toBe('active');
  }
  expect(await observedRecovery(page)).toBe(true);
  const score = await value(page, 'data-score');
  const reward = cyclingReward(score, 'hard');
  expect(reward.shells).toBeGreaterThan(cyclingReward(score, 'normal').shells);
  await expect.poll(async () => (await saved(page)).counts.play).toBe(initial.counts.play + 1);
  const result = await saved(page);
  expect(result.shells).toBe(initial.shells + reward.shells);
  expect(result.records.cycling).toBe(score); expect(result.activeGame).toBeNull();
  const audio = await audioProbe(page);
  expect(audio.maxVoice).toBe(1); expect(audio.speechCalls).toBe(0);
  expect(audio.events.every(event => audioFiles.includes(event.file))).toBe(true);
  await page.clock.fastForward(5000);
  expect((await saved(page)).shells).toBe(result.shells);
  await page.reload();
  await expect(page.getByRole('button', { name: '开始骑行 · 8 精力', exact: true })).toBeEnabled({ timeout: 60000 });
  expect((await saved(page)).shells).toBe(result.shells);
  expect((await saved(page)).records.cycling).toBe(score);
  await expect(page.getByTestId('scene')).toHaveCount(0);
  expect(observed.errors).toEqual([]);
});

test('standalone loading keeps the horse animation and retries a missing cycling file before starting', async ({ page }, info) => {
  test.skip(info.project.name === 'mobile', 'Phone entry loading/cancellation and direct resources are covered above.');
  test.setTimeout(180000);
  await setup(page);
  let broken = true, requests = 0;
  await page.route('**/audio/cycling-hit.mp3', async route => {
    requests++;
    if (broken) await route.fulfill({ status: 503, body: 'Temporarily unavailable' });
    else await route.continue();
  });
  await page.goto('./#cycling');
  await expect(page.getByRole('button', { name: '再试一次', exact: true })).toBeVisible();
  await expect(page.getByTestId('cycling-canvas')).toHaveCount(0);
  await expect(page.getByTestId('scene')).toHaveCount(0);
  const opacity = await page.locator('.resource-loading__horse').evaluate(horse => {
    const root = horse.closest('.resource-loading')!;
    root.querySelectorAll('.resource-loading__burst *').forEach(node => node.getAnimations().forEach(animation => { animation.pause(); animation.currentTime = 1800; }));
    return Number(getComputedStyle(horse).opacity);
  });
  expect(opacity).toBe(0);
  await page.screenshot({ path: info.outputPath('cycling-loading-retry.png') });
  expect((await saved(page)).activeGame).toBeNull();
  broken = false;
  await page.getByRole('button', { name: '再试一次', exact: true }).click();
  await expect(page.locator('.resource-loading')).toHaveCount(0);
  await expect(page.getByRole('button', { name: '开始骑行 · 8 精力', exact: true })).toBeEnabled();
  expect(requests).toBeGreaterThanOrEqual(2);
});

test('a pending town route unmounts the active ride and a quick return opens a fresh intro', async ({ page }, info) => {
  test.skip(info.project.name === 'mobile', 'The shared lazy-route boundary is exercised once; touch navigation and save are covered above.');
  test.setTimeout(240000);
  await setup(page);
  const observed = observe(page);
  await ready(page);
  await press(page, '开始骑行 · 8 精力', false);
  await expect.poll(() => value(page, 'data-distance')).toBeGreaterThan(1);
  await expect.poll(async () => (await saved(page)).activeGame?.kind).toBe('cycling');
  let release!: () => void;
  let requested = false;
  const gate = new Promise<void>(resolve => { release = resolve; });
  // Cover both the production chunk and Vite's direct source request.
  const appChunk = /\/(?:assets\/App-[^/]+\.js|src\/App\.tsx)(?:\?.*)?$/;
  await page.route(appChunk, async route => { requested = true; await gate; await route.continue().catch(() => {}); });
  try {
    await page.getByRole('link', { name: '回到小镇', exact: true }).click();
    await expect.poll(() => requested).toBe(true);
    await expect(page.locator('.resource-loading')).toBeVisible();
    await expect(game(page)).toHaveCount(0);
    await expect(page.getByTestId('cycling-standalone')).toHaveCount(0);
    await expect.poll(async () => (await saved(page)).activeGame).toBeNull();
    await page.evaluate(() => { location.hash = 'cycling'; });
    await expect(page.getByTestId('cycling-standalone')).toBeVisible();
    await expect(game(page)).toHaveAttribute('data-phase', 'ready');
    await expect(game(page)).toHaveAttribute('data-distance', '0.00');
    await expect(page.getByRole('button', { name: '开始骑行 · 8 精力', exact: true })).toBeEnabled();
    expect((await saved(page)).activeGame).toBeNull();
    await expect(page.getByTestId('scene')).toHaveCount(0);
  } finally { release(); }
  await page.unroute(appChunk);
  await page.getByRole('link', { name: '回到小镇', exact: true }).click();
  await expect(page.locator('.resource-loading')).toHaveCount(0, { timeout: 210000 });
  await expect(page.getByTestId('scene')).toHaveAttribute('data-ready', 'true');
  await expect(game(page)).toHaveCount(0);
  expect((await saved(page)).activeGame).toBeNull();
  expect(observed.errors).toEqual([]);
});
