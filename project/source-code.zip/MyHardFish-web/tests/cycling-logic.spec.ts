import { expect, test } from '@playwright/test';
import {
  CYCLING_LENGTH, CYCLING_MAX_SCORE, CYCLING_LANE_WIDTH, CYCLING_DIFFICULTIES, CYCLING_HIT_RECOVERY_SECONDS,
  createCyclingState, cyclingReward, getCyclingDifficulty, startCycling, steerCycling, stepCycling,
} from '../src/cycling';
import type { CyclingDifficulty, CyclingItem, CyclingState } from '../src/cycling';
import { newGame, step } from '../src/engine';
import { makeArchive, readArchive, validateState } from '../src/storage';

const NOW = new Date(2026, 9, 3, 12).getTime();
const item = (id: string, kind: CyclingItem['kind'], lane: number, distance: number): CyclingItem =>
  ({ id, kind, lane, distance, collected: false, passed: false });
const riding = (items: CyclingItem[] = []): CyclingState => ({ ...startCycling(createCyclingState(42)), items });
function advance(state: CyclingState, seconds: number, brake = false) {
  for (let elapsed = 0; elapsed < seconds && state.phase === 'riding'; elapsed += 0.05)
    state = stepCycling(state, Math.min(0.05, seconds - elapsed), brake);
  return state;
}

test('seeded courses have unique items, a forgiving start and a clear lane at every obstacle row', () => {
  expect(createCyclingState(42)).toEqual(createCyclingState(42));
  expect(createCyclingState(42).items).not.toEqual(createCyclingState(43).items);
  for (let seed = 0; seed < 60; seed++) {
    const state = createCyclingState(seed);
    expect(state.phase).toBe('ready');
    expect(new Set(state.items.map(entry => entry.id)).size).toBe(state.items.length);
    const obstacles = state.items.filter(entry => entry.kind === 'hole' || entry.kind === 'barrier');
    expect(Math.min(...obstacles.map(entry => entry.distance))).toBeGreaterThanOrEqual(50);
    for (const distance of new Set(obstacles.map(entry => entry.distance))) {
      const lanes = obstacles.filter(entry => entry.distance === distance).map(entry => entry.lane);
      expect(new Set(lanes).size).toBeLessThan(3);
      const pickup = state.items.find(entry => entry.distance === distance && (entry.kind === 'cover' || entry.kind === 'parcel'));
      expect(pickup).toBeDefined();
      expect(lanes).not.toContain(pickup!.lane);
    }
    for (const entry of state.items) {
      expect([-1, 0, 1]).toContain(entry.lane);
      expect(entry.distance).toBeGreaterThan(0);
      expect(entry.distance).toBeLessThan(CYCLING_LENGTH);
    }
  }
});

test('ready and finished rounds do not advance; steering stays inside the three lanes', () => {
  const ready = createCyclingState();
  expect(stepCycling(ready, 1)).toBe(ready);
  const start = startCycling(ready);
  expect(start.phase).toBe('riding');
  expect(start.speed).toBe(11);
  expect(startCycling(start)).toBe(start);
  let left = steerCycling(steerCycling(start, -1), -1);
  expect(left.lane).toBe(-1);
  left = advance(left, 0.5);
  expect(left.x).toBeCloseTo(-CYCLING_LANE_WIDTH, 1);
  let right = steerCycling(steerCycling(steerCycling(left, 1), 1), 1);
  expect(right.lane).toBe(1);
  right = advance(right, 1);
  expect(right.x).toBeCloseTo(CYCLING_LANE_WIDTH, 1);
  const finished = { ...right, phase: 'finished' as const };
  expect(steerCycling(finished, -1)).toBe(finished);
  expect(stepCycling(finished, 0.1)).toBe(finished);
});

test('braking slows the ride without stopping progress', () => {
  const normal = advance(riding(), 2);
  const braking = advance(riding(), 2, true);
  expect(braking.distance).toBeGreaterThan(10);
  expect(braking.distance).toBeLessThan(normal.distance);
  expect(braking.speed).toBeCloseTo(6, 1);
  const released = advance(braking, 2);
  expect(released.speed).toBeGreaterThan(10);
});

test('pickups score once without mutating the original course or collecting other lanes', () => {
  const original = riding([
    item('cover', 'cover', 0, 0.2), item('bottle', 'bottle', 0, 0.6),
    item('parcel', 'parcel', 0, 1), item('miss', 'cover', -1, 1),
  ]);
  const next = stepCycling(original, 0.25);
  expect(next.score).toBe(80);
  expect(next.collected).toBe(3);
  expect(next.items.find(entry => entry.id === 'miss')?.collected).toBe(false);
  expect(advance(next, 1).score).toBe(80);
  expect(original.score).toBe(0);
  expect(original.distance).toBe(0);
  expect(original.items.every(entry => !entry.collected && !entry.passed)).toBe(true);
});

test('swept collision catches a hazard crossed during a lane change and ignores a clear lane', () => {
  const crossing = { ...riding([item('crossing', 'hole', 0, 1.5)]), x: -CYCLING_LANE_WIDTH, lane: 1 };
  const hit = stepCycling(crossing, 0.25);
  expect(hit.hits).toBe(1);
  expect(hit.integrity).toBe(2);
  const clear = stepCycling(riding([item('off-road', 'hole', 1, 1.5)]), 0.25);
  expect(clear.hits).toBe(0);
  expect(clear.integrity).toBe(3);
});

test('collision immunity blocks a cluster, then later hazards end the ride on the third hit', () => {
  const state = riding([
    item('first', 'hole', 0, 1), item('cluster', 'barrier', 0, 1.4),
    item('second', 'barrier', 0, 28), item('third', 'hole', 0, 55),
    item('too-late', 'cover', 0, 58),
  ]);
  const first = advance(state, 0.5);
  expect(first.hits).toBe(1);
  expect(first.integrity).toBe(2);
  expect(first.invulnerable).toBeGreaterThan(0);
  const finished = advance(first, 8);
  expect(finished.phase).toBe('finished');
  expect(finished.integrity).toBe(0);
  expect(finished.hits).toBe(3);
  expect(finished.distance).toBeLessThan(55);
  expect(finished.speed).toBe(0);
  expect(finished.score).toBe(0);
  expect(finished.items.find(entry => entry.id === 'too-late')?.collected).toBe(false);
});

test('finish bonuses and pickups respect the score cap and cannot apply twice', () => {
  const cappedPickup = stepCycling({ ...riding([item('cover', 'cover', 0, 0.2)]), score: 990 }, 0.1);
  expect(cappedPickup.score).toBe(CYCLING_MAX_SCORE);
  const nearFinish = { ...riding(), distance: 599, score: 970, integrity: 2 };
  const finished = stepCycling(nearFinish, 0.25);
  expect(finished.distance).toBe(CYCLING_LENGTH);
  expect(finished.phase).toBe('finished');
  expect(finished.score).toBe(CYCLING_MAX_SCORE);
  expect(finished.speed).toBe(0);
  expect(stepCycling(finished, 0.25)).toBe(finished);
  const modest = stepCycling({ ...nearFinish, score: 100 }, 0.25);
  expect(modest.score).toBe(200);
});

test('a rider following the safe pickups can complete the course unharmed with full score', () => {
  let state = startCycling(createCyclingState(20261003));
  for (let frames = 0; frames < 2000 && state.phase === 'riding'; frames++) {
    const target = state.items.find(entry => !entry.passed && !entry.collected
      && entry.kind !== 'hole' && entry.kind !== 'barrier');
    // Finish passing the current hazard row before turning toward the next pickup.
    const besideHazard = state.items.some(entry => (entry.kind === 'hole' || entry.kind === 'barrier')
      && Math.abs(entry.distance - state.distance) < 1.4);
    if (target && target.lane !== state.lane && !besideHazard)
      state = steerCycling(state, target.lane < state.lane ? -1 : 1);
    state = stepCycling(state, 0.05);
  }
  expect(state.phase).toBe('finished');
  expect(state.distance).toBe(CYCLING_LENGTH);
  expect(state.integrity).toBe(3);
  expect(state.score).toBe(CYCLING_MAX_SCORE);
  expect(state.elapsed).toBeGreaterThan(40);
  expect(state.elapsed).toBeLessThan(60);
});

test('invalid frame times cannot poison the simulation and background gaps cannot skip the course', () => {
  const state = riding();
  for (const time of [NaN, Infinity, -Infinity, -1, 0]) expect(stepCycling(state, time)).toBe(state);
  expect(stepCycling(state, 500)).toEqual(stepCycling(state, 0.25));
  const repaired = stepCycling({ ...state, distance: NaN, x: Infinity, speed: NaN, score: Infinity }, 0.1);
  for (const value of [repaired.distance, repaired.x, repaired.speed, repaired.score, repaired.elapsed])
    expect(Number.isFinite(value)).toBe(true);
  expect(createCyclingState(NaN)).toEqual(createCyclingState());
});

test('cycling rewards use their own bounded scale', () => {
  expect(cyclingReward(0)).toEqual({ shells: 8, bond: 3 });
  expect(cyclingReward(399)).toEqual({ shells: 27, bond: 4 });
  expect(cyclingReward(1000)).toEqual({ shells: 58, bond: 8 });
  expect(cyclingReward(100000)).toEqual({ shells: 58, bond: 8 });
  for (const score of [NaN, Infinity, -Infinity, -100])
    expect(cyclingReward(score)).toEqual({ shells: 8, bond: 3 });
});

test('the engine settles cycling once, caps rewards, saves best scores and counts play', () => {
  const initial = newGame(NOW);
  const started = step(initial, { type: 'startGame', value: 'cycling' }, NOW);
  const claim = { type: 'finishGame' as const, value: 'cycling' as const, score: 50000, sessionId: started.activeGame!.id };
  const finished = step(started, claim, NOW);
  expect(finished.shells).toBe(initial.shells + 58);
  expect(finished.bond).toBe(initial.bond + 8);
  expect(finished.records.cycling).toBe(1000);
  expect(finished.counts.play).toBe(1);
  expect(finished.daily.counts.play).toBe(1);
  expect(finished.activeGame).toBeNull();
  expect(step(finished, claim, NOW).shells).toBe(finished.shells);
  const again = step(finished, { type: 'startGame', value: 'cycling' }, NOW);
  const lower = step(again, { ...claim, score: 100, sessionId: again.activeGame!.id }, NOW);
  expect(lower.records.cycling).toBe(1000);
  expect(lower.shells).toBe(finished.shells + 13);
  expect(readArchive(makeArchive(lower, [null, null, null])).state.records.cycling).toBe(1000);
});

test('cancelling only the matching session blocks reward claims without changing earned records', () => {
  const initial = newGame(NOW);
  const started = step(initial, { type: 'startGame', value: 'cycling' }, NOW);
  const token = started.activeGame!.id;
  expect(step(started, { type: 'cancelGame', sessionId: 'stale' }, NOW).activeGame).toEqual(started.activeGame);
  const cancelled = step(started, { type: 'cancelGame', sessionId: token }, NOW);
  expect(cancelled.activeGame).toBeNull();
  expect(cancelled.energy).toBe(initial.energy - 8);
  expect(cancelled.counts.play).toBe(0);
  const lateClaim = step(cancelled, { type: 'finishGame', value: 'cycling', score: 900, sessionId: token }, NOW);
  expect(lateClaim.shells).toBe(initial.shells);
  expect(lateClaim.records.cycling).toBe(0);
  const restarted = step(started, { type: 'startGame', value: 'cycling' }, NOW);
  expect(step(restarted, { type: 'cancelGame', sessionId: token }, NOW).activeGame).toEqual(restarted.activeGame);
});

test('older archives migrate cycling records while invalid new records are rejected', () => {
  const legacy = JSON.parse(JSON.stringify(newGame(NOW)));
  delete legacy.records.cycling;
  expect(validateState(legacy).records.cycling).toBe(0);
  for (const score of [-1, 1001, 0.5, NaN, Infinity, '100'])
    expect(() => validateState({ ...legacy, records: { ...legacy.records, cycling: score } })).toThrow();
});

test('difficulty selects a distinct map, pace, braking speed and score reward without changing the normal default', () => {
  expect(createCyclingState(42)).toEqual(createCyclingState(42, 'normal'));
  expect(getCyclingDifficulty('invalid').id).toBe('normal');
  expect(getCyclingDifficulty(undefined).id).toBe('normal');
  expect(new Set(CYCLING_DIFFICULTIES.map(config => config.theme)).size).toBe(3);
  expect(new Set(CYCLING_DIFFICULTIES.map(config => config.mapName)).size).toBe(3);
  const distances: number[] = [];
  const payouts: number[] = [];
  for (const config of CYCLING_DIFFICULTIES) {
    const state = { ...startCycling(createCyclingState(42, config.id)), items: [] };
    expect(state.difficulty).toBe(config.id);
    expect(state.speed).toBe(config.startSpeed);
    expect(config.length).toBe(CYCLING_LENGTH);
    const normal = advance(state, 2);
    const braking = advance(state, 2, true);
    distances.push(normal.distance);
    expect(braking.speed).toBeCloseTo(config.brakeSpeed, 1);
    payouts.push(cyclingReward(1000, config.id).shells);
  }
  expect(distances[0]).toBeLessThan(distances[1]);
  expect(distances[1]).toBeLessThan(distances[2]);
  expect(payouts).toEqual([48, 58, 88]);
  expect(cyclingReward(1000, 'hard')).toEqual({ shells: 88, bond: 11 });
  expect(cyclingReward(1000, 'easy')).toEqual({ shells: 48, bond: 7 });
});

test('hard routes have dense alternating safe lanes while all difficulties remain reachable at full speed', () => {
  const hazard = (entry: CyclingItem) => entry.kind === 'hole' || entry.kind === 'barrier';
  const counts = CYCLING_DIFFICULTIES.map(config => createCyclingState(42, config.id).items.filter(hazard).length);
  expect(counts[0]).toBeLessThan(counts[1]);
  expect(counts[2]).toBeGreaterThan(counts[1] * 2);
  for (const difficulty of ['easy', 'normal', 'hard'] as CyclingDifficulty[]) {
    for (const seed of [0, 1, 42, 20261003, 0xffffffff]) {
      let state = startCycling(createCyclingState(seed, difficulty));
      const rows = [...new Set(state.items.filter(hazard).map(entry => entry.distance))];
      let previousLane = 0;
      for (const distance of rows) {
        const hazards = state.items.filter(entry => hazard(entry) && entry.distance === distance);
        const reward = state.items.find(entry => !hazard(entry) && entry.distance === distance)!;
        expect(hazards.some(entry => entry.lane === reward.lane)).toBe(false);
        if (difficulty === 'hard') {
          expect(hazards.length).toBe(2);
          expect(Math.abs(previousLane - reward.lane)).toBe(1);
        }
        previousLane = reward.lane;
      }
      for (let frames = 0; frames < 2200 && state.phase === 'riding'; frames++) {
        const target = state.items.find(entry => !entry.passed && !entry.collected && !hazard(entry));
        const besideHazard = state.items.some(entry => hazard(entry) && Math.abs(entry.distance - state.distance) < 1.4);
        if (target && target.lane !== state.lane && !besideHazard)
          state = steerCycling(state, target.lane < state.lane ? -1 : 1);
        state = stepCycling(state, .05);
      }
      expect(state.distance, `${difficulty}, seed ${seed}`).toBe(CYCLING_LENGTH);
      expect(state.integrity, `${difficulty}, seed ${seed}`).toBe(3);
      expect(state.score).toBe(CYCLING_MAX_SCORE);
    }
  }
});

test('a collision creates one timed hit event and a sustained recovery; pickups never change speed', () => {
  const hit = stepCycling(riding([item('hole', 'hole', 0, 1)]), .1);
  expect(hit.events).toHaveLength(1);
  expect(hit.events[0]).toMatchObject({ id: 1, type: 'hit', itemId: 'hole', kind: 'hole', lane: 0, distance: 1, points: 0 });
  expect(hit.events[0].at).toBeGreaterThanOrEqual(0);
  expect(hit.events[0].at).toBeLessThanOrEqual(hit.elapsed);
  expect(hit.slowdownRemaining).toBeGreaterThan(CYCLING_HIT_RECOVERY_SECONDS - .11);
  expect(hit.speed).toBeLessThan(5);
  const recovering = advance(hit, .6);
  expect(recovering.slowdownRemaining).toBeGreaterThan(0);
  expect(recovering.speed).toBeLessThan(9);
  expect(recovering.events.filter(event => event.type === 'hit')).toHaveLength(1);
  const recovered = advance(recovering, 1.8);
  expect(recovered.slowdownRemaining).toBe(0);
  expect(recovered.speed).toBeGreaterThan(10);
  const pickup = stepCycling(riding([item('cover', 'cover', 0, 1)]), .1);
  const empty = stepCycling(riding(), .1);
  expect(pickup.speed).toBe(empty.speed);
  expect(pickup.distance).toBe(empty.distance);
  expect(pickup.slowdownRemaining).toBe(0);
  expect(pickup.events[0]).toMatchObject({ id: 1, type: 'pickup', itemId: 'cover', kind: 'cover', points: 40 });
  expect(advance(pickup, .5).events).toHaveLength(1);
});

test('feedback events keep bounded immutable history and IDs remain monotonic after expiry', () => {
  const source = riding(Array.from({ length: 30 }, (_, index) => item(`pickup-${index}`, 'bottle', 0, .1 + index * .04)));
  const burst = stepCycling(source, .25);
  expect(source.events).toEqual([]);
  expect(source.eventId).toBe(0);
  expect(burst.events).toHaveLength(12);
  expect(burst.eventId).toBe(30);
  expect(burst.events.map(event => event.id)).toEqual(Array.from({ length: 12 }, (_, index) => index + 19));
  const expired = advance(burst, 3.2);
  expect(expired.events).toEqual([]);
  expect(expired.eventId).toBe(30);
  const next = stepCycling({ ...expired, items: [...expired.items, item('new', 'parcel', 0, expired.distance + 1)] }, .1);
  expect(next.eventId).toBe(31);
  expect(next.events[0].id).toBe(31);
  expect(next.events[0].points).toBe(25);
});

test('difficulty is bound to the admitted engine session and cannot be changed by a completion payload', () => {
  for (const difficulty of ['easy', 'normal', 'hard'] as CyclingDifficulty[]) {
    const initial = newGame(NOW);
    const started = step(initial, { type: 'startGame', value: 'cycling', difficulty }, NOW);
    expect(started.activeGame?.difficulty).toBe(difficulty);
    const claim = { type: 'finishGame' as const, value: 'cycling' as const, score: 1000, sessionId: started.activeGame!.id, difficulty: difficulty === 'hard' ? 'easy' : 'hard' };
    const completed = step(started, claim, NOW);
    const reward = cyclingReward(1000, difficulty);
    expect(completed.shells).toBe(initial.shells + reward.shells);
    expect(completed.bond).toBe(initial.bond + reward.bond);
    expect(completed.records.cycling).toBe(1000);
    expect(step(completed, claim, NOW).shells).toBe(completed.shells);
    expect(validateState(started).activeGame).toBeNull();
    const legacySession = { ...started, activeGame: { ...started.activeGame!, difficulty: undefined } };
    expect(step(legacySession, claim, NOW).shells).toBe(initial.shells + 58);
  }
});
