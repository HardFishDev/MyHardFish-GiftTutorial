import { test, expect } from "@playwright/test";
import type { Page } from "@playwright/test";
import { readFile } from "node:fs/promises";
import { newGame } from "../src/engine";
import { makeArchive, SAVE_KEY } from "../src/storage";
const close = (page: Page) =>
  page.getByRole("button", { name: "关闭窗口", exact: true }).click();
async function ready(page: Page, defaultQuality = false) {
  if (!defaultQuality) {
    // Functional flows exercise the real supported low-power setting. Initial
    // seeding never replaces a player's save, including after reload/import.
    const fixture = newGame();
    fixture.settings.lowQuality = true;
    await page.addInitScript(({ key, state }) => {
      if (!localStorage.getItem(key)) localStorage.setItem(key, JSON.stringify(state));
    }, { key: SAVE_KEY, state: fixture });
  }
  await page.goto("./");
  await expect(page.getByTestId("scene")).toHaveAttribute("data-ready", "true");
}
async function mute(page: Page) {
  // The compact mobile HUD intentionally omits the top-level voice toggle.
  const shortcut = page.getByRole("button", { name: "关闭语音", exact: true });
  if (await shortcut.isVisible()) {
    await shortcut.click();
    return;
  }
  await menu(page, "设置");
  await page.getByRole("checkbox", { name: /难鱼开麦/ }).uncheck();
  await close(page);
}
async function menu(page: Page, name: string) {
  await page.getByRole("button", { name: "打开生活菜单", exact: true }).click();
  await page.getByRole("dialog").getByRole("button", { name, exact: true }).click();
}
async function chat(page: Page) {
  await page.getByRole("button", { name: /^聊聊天/ }).click();
}
async function stories(page: Page) {
  await chat(page);
  await page.getByRole("tab", { name: "小故事", exact: true }).click();
}
async function fullscreenWorld(page: Page) {
  const viewport = page.viewportSize()!;
  await expect(async () => {
    const canvas = await page.getByTestId("scene").locator("canvas").boundingBox();
    expect(canvas).not.toBeNull();
    expect(canvas!.width * canvas!.height / (viewport.width * viewport.height)).toBeGreaterThanOrEqual(0.98);
    expect(Math.abs(canvas!.x)).toBeLessThanOrEqual(1);
    expect(Math.abs(canvas!.y)).toBeLessThanOrEqual(1);
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  }).toPass();
}

test("3D, mobile layout, movement, scenes and outfit stay functional without console errors", async ({
  page,
}, info) => {
  test.setTimeout(240000);
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await ready(page, true);
  await mute(page);
  await expect(
    page.getByRole("heading", { name: /我的群友\s*难鱼/ }),
  ).toBeVisible();
  await fullscreenWorld(page);
  // Sample the actual framebuffer: a mounted but blank WebGL canvas is not ready.
  await expect.poll(() => page.getByTestId("scene").locator("canvas").evaluate((source) => {
    const sample = document.createElement("canvas");
    sample.width = sample.height = 32;
    const context = sample.getContext("2d")!;
    context.drawImage(source as HTMLCanvasElement, 0, 0, 32, 32);
    const pixels = context.getImageData(0, 0, 32, 32).data;
    const colors = new Set<string>();
    for (let i = 0; i < pixels.length; i += 4)
      colors.add(`${pixels[i] >> 4},${pixels[i + 1] >> 4},${pixels[i + 2] >> 4}`);
    return colors.size;
  })).toBeGreaterThan(16);
  await page.getByTestId("scene").locator("canvas").focus();
  const before = await page.getByTestId("scene").getAttribute("data-position");
  await page.keyboard.down("ArrowRight");
  try {
    await expect(page.getByTestId("scene")).not.toHaveAttribute("data-position", before!);
  } finally {
    await page.keyboard.up("ArrowRight");
  }
  for (const [name, id] of [
    ["厨房", "kitchen"],
    ["公园", "park"],
    ["便利店", "shop"],
    ["教室", "school"],
    ["村中心", "village"],
    ["联机工坊", "workshop"],
    ["瓶信河岸", "river"],
    ["夜市", "market"],
    ["小窝", "home"],
  ]) {
    await page.getByRole("button", { name: "打开地图", exact: true }).click();
    await page.getByRole("dialog").getByRole("button", { name, exact: true }).click();
    await expect(page.getByTestId("scene")).toHaveAttribute("data-place", id);
  }
  await menu(page, "衣柜");
  const mint = page
    .locator(".outfit-card")
    .filter({
      has: page.getByRole("heading", { name: "薄荷围巾", exact: true }),
    });
  await mint.getByRole("button", { name: /买下并换上/ }).click();
  await expect(page.getByTestId("scene")).toHaveAttribute(
    "data-outfit",
    "mint",
  );
  await close(page);
  await page.screenshot({
    path: `../research/expansion-v3/${info.project.name}-verified.png`,
    fullPage: true,
  });
  await page.reload();
  await expect(page.getByTestId("scene")).toHaveAttribute(
    "data-outfit",
    "mint",
  );
  expect(errors).toEqual([]);
});
test("chat follows context, feeding changes needs, shop consumes shells and saves on reload", async ({
  page,
}) => {
  await ready(page);
  await mute(page);
  await chat(page);
  await page
    .getByRole("textbox", { name: "给难鱼发消息" })
    .fill("今天想玩什么");
  await page.getByRole("button", { name: "发送消息", exact: true }).click();
  await page.getByRole("textbox", { name: "给难鱼发消息" }).fill("好");
  await page.getByRole("textbox", { name: "给难鱼发消息" }).press("Enter");
  await expect(page.getByRole("log")).toContainText("输了别赖我");
  await page.getByRole("tab", { name: "零食袋" }).click();
  // Native dialogs make the HUD inert; mobile activity panels also hide the card. Read its stable text, which still updates.
  const hunger = Number(await page.getByTestId("hunger").textContent());
  await page
    .getByRole("button", { name: "投喂热乎小包子", exact: true })
    .click();
  await expect(page.getByTestId("hunger")).toHaveText(String(Math.min(100, hunger + 22)));
  await expect(page.getByRole("dialog")).toHaveCount(0);
  await page.getByRole("button", { name: "给她投喂", exact: true }).click();
  await expect(
    page.locator(".food-row").filter({ hasText: "热乎小包子" }),
  ).toContainText("×2");
  await page.getByRole("button", { name: /去便利店补货/ }).click();
  const balance = Number(await page.getByTestId("shells").textContent());
  await page
    .getByRole("button", { name: "购买温牛奶 10贝壳", exact: true })
    .click();
  await expect(page.getByTestId("shells")).toHaveText(String(balance - 10));
  await close(page);
  await page.reload();
  await expect(page.getByTestId("shells")).toHaveText(String(balance - 10));
  await page.getByRole("button", { name: "给她投喂", exact: true }).click();
  await expect(
    page.locator(".food-row").filter({ hasText: "温牛奶" }),
  ).toContainText("×3");
});
test("story choices resume after reload and produce an ending in the journal", async ({
  page,
}) => {
  await ready(page);
  await mute(page);
  await stories(page);
  await page.getByRole("dialog").getByRole("button", { name: /应援会改名风波/ }).click();
  await page.getByRole("button", { name: "立刻改成「普通群友」" }).click();
  await close(page);
  await page.reload();
  await stories(page);
  await page.getByRole("button", { name: "继续上次的故事" }).click();
  await expect(page.getByRole("dialog")).toContainText("你把应援会招牌收起来");
  await page.getByRole("button", { name: "递个桃子，和好吧" }).click();
  await expect(page.getByRole("heading", { name: "停战协议" })).toBeVisible();
  await page.getByRole("button", { name: "继续一起过日子" }).click();
  await close(page);
  await menu(page, "收藏");
  await page.getByRole("button", { name: "一起的日记", exact: true }).click();
  await expect(page.getByRole("dialog")).toContainText("停战协议");
});
test("math mini-game pays one reward and daily task can be claimed once", async ({
  page,
}) => {
  await ready(page);
  await mute(page);
  await menu(page, "一起玩吧");
  await page.getByRole("button", { name: /五题就下课/ }).click();
  await page.getByRole("button", { name: "和难鱼一起开始" }).click();
  const balance = Number(await page.getByTestId("shells").textContent());
  for (let i = 0; i < 5; i++) {
    const expression = (await page.locator(".math-board").innerText())
      .replace(" = ?", "")
      .split(" ");
    const a = Number(expression[0]),
      b = Number(expression[2]);
    const answer =
      expression[1] === "+" ? a + b : expression[1] === "×" ? a * b : a - b;
    await page
      .getByRole("dialog")
      .getByRole("button", { name: String(answer), exact: true })
      .click();
    await page
      .getByRole("button", { name: i === 4 ? "交卷，下课！" : "下一题" })
      .click();
  }
  await expect(page.getByRole("dialog")).toContainText("+33 贝壳");
  await expect(page.getByTestId("shells")).toHaveText(
    String(balance + 33 + 35),
  );
  await close(page);
  await menu(page, "今日小事");
  const task = page.locator(".task").filter({ hasText: "一起玩一局" });
  await task.getByRole("button", { name: "领取", exact: true }).click();
  await expect(task.getByRole("button", { name: "已领取" })).toBeDisabled();
});
test("ZIP export/import round trip, manual slot and invalid archive preserve progress", async ({
  page,
}) => {
  await ready(page);
  await mute(page);
  await menu(page, "存档");
  await page
    .locator(".save-slot")
    .first()
    .getByRole("button", { name: "保存", exact: true })
    .click();
  const downloadPromise = page.waitForEvent("download");
  await page.getByRole("button", { name: "导出 ZIP", exact: true }).click();
  const downloaded = await downloadPromise,
    path = await downloaded.path();
  const bytes = await readFile(path!);
  const original = Number(await page.getByTestId("shells").textContent());
  await close(page);
  await page.getByRole("button", { name: /贝壳余额/ }).click();
  await page.getByRole("button", { name: "购买脆甜桃子 12贝壳" }).click();
  await close(page);
  await menu(page, "存档");
  await page
    .getByLabel("选择存档 ZIP")
    .setInputFiles({
      name: "broken.zip",
      mimeType: "application/zip",
      buffer: Buffer.from("bad"),
    });
  await expect(page.getByRole("alert")).toBeVisible();
  await expect(page.getByTestId("shells")).toHaveText(String(original - 12));
  await page
    .getByLabel("选择存档 ZIP")
    .setInputFiles({
      name: "save.zip",
      mimeType: "application/zip",
      buffer: bytes,
    });
  await expect(
    page.getByRole("heading", { name: "已检查这份存档" }),
  ).toBeVisible();
  await expect(page.getByTestId("shells")).toHaveText(String(original - 12));
  await page.getByRole("button", { name: "确认导入并替换" }).click();
  await expect(page.getByTestId("shells")).toHaveText(String(original));
  await page.getByRole("button", { name: "回到上次恢复之前" }).click();
  await page.getByRole("button", { name: "确认读取", exact: true }).click();
  await expect(page.getByTestId("shells")).toHaveText(String(original - 12));
  await page
    .locator(".save-slot")
    .first()
    .getByRole("button", { name: "读取", exact: true })
    .click();
  await page.getByRole("button", { name: "确认读取", exact: true }).click();
  await expect(page.getByTestId("shells")).toHaveText(String(original));
});
test("voice asset really loads, journal quote is readable, keyboard dialog closes", async ({
  page,
}) => {
  await page.addInitScript(() => {
    const original = HTMLMediaElement.prototype.play;
    HTMLMediaElement.prototype.play = function () {
      this.addEventListener(
        "playing",
        () => {
          document.documentElement.dataset.audioPlaying = "true";
        },
        { once: true },
      );
      return original.call(this);
    };
  });
  await ready(page);
  const response = await page.request.get("./audio/greeting.mp3");
  expect(response.ok()).toBe(true);
  expect((await response.body()).length).toBeGreaterThan(5000);
  const playing = page.waitForResponse(
    (r) =>
      r.url().includes("/audio/") && (r.status() === 200 || r.status() === 206),
  );
  await page.getByRole("button", { name: "重播这句语音", exact: true }).click();
  await playing;
  await expect(page.locator("html")).toHaveAttribute(
    "data-audio-playing",
    "true",
  );
  await menu(page, "收藏");
  await page.getByRole("dialog").getByRole("button", { name: /我心情好先不骂你/ }).click();
  await expect(page.getByRole("dialog")).toContainText("2023-06-21");
  const download = page.waitForEvent("download");
  await page.getByRole("button", { name: "保存语录贴纸" }).click();
  expect((await download).suggestedFilename()).toBe("难鱼_greeting.png");
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog")).not.toBeVisible();
});
test("import validation rejects bad state and honors a complete valid state on reload", async ({
  page,
}) => {
  await ready(page);
  await mute(page);
  await menu(page, "存档");
  const s = newGame();
  s.name = "测试群友";
  s.settings.voice = false;
  s.settings.lowQuality = true;
  const original = await page.getByTestId("shells").textContent();
  s.shells = -1;
  await page.getByLabel("选择存档 ZIP").setInputFiles({
    name: "invalid-state.zip",
    mimeType: "application/zip",
    buffer: Buffer.from(makeArchive(s, [null, null, null])),
  });
  await expect(page.getByRole("alert")).toContainText("数值超出范围");
  await expect(page.getByTestId("shells")).toHaveText(original);
  await expect(page.getByRole("button", { name: "确认导入并替换", exact: true })).toHaveCount(0);
  s.shells = 333;
  await page
    .getByLabel("选择存档 ZIP")
    .setInputFiles({
      name: "portable.zip",
      mimeType: "application/zip",
      buffer: Buffer.from(makeArchive(s, [null, null, null])),
    });
  await page.getByRole("button", { name: "确认导入并替换" }).click();
  await close(page);
  await page.reload();
  await expect(page.getByTestId("shells")).toHaveText("333");
  await menu(page, "设置");
  await expect(page.getByLabel("难鱼怎么称呼你")).toHaveValue("测试群友");
});

test("bottle pairs can be solved using revealed clues and cooking gives real inventory", async ({
  page,
}) => {
  // This combines every revealed pair and a full cooking round; software WebGL
  // runners need a larger total budget without relaxing individual assertions.
  test.setTimeout(240000);
  await ready(page);
  await mute(page);
  await menu(page, "一起玩吧");
  await page.getByRole("button", { name: /漂流瓶记忆/ }).click();
  await page.getByRole("button", { name: "和难鱼一起开始" }).click();
  const seen = new Map<number, string>(),
    matched = new Set<number>();
  // Remember only clues that the UI actually reveals. A winning pair replaces
  // the grid after 360 ms, before a slow software-GPU round trip can read it.
  await page.exposeFunction("recordVisibleBottleClue", (index: number, value: string) => {
    seen.set(index, value);
  });
  await page.locator(".bottle-grid").evaluate((grid) => {
    const recorded = new Map<number, string>();
    const collect = () => {
      for (const card of grid.querySelectorAll<HTMLButtonElement>('button[aria-pressed="true"]')) {
        const index = Array.from(grid.children).indexOf(card);
        const value = card.textContent?.trim() || "";
        if (value && recorded.get(index) !== value) {
          recorded.set(index, value);
          void (window as unknown as {
            recordVisibleBottleClue: (index: number, value: string) => Promise<void>;
          }).recordVisibleBottleClue(index, value);
        }
      }
    };
    new MutationObserver(collect).observe(grid, {
      subtree: true, childList: true, attributes: true, attributeFilter: ["aria-pressed"],
    });
    collect();
  });
  for (let turn = 0; turn < 12 && matched.size < 12; turn++) {
    const available = Array.from({ length: 12 }, (_, i) => i).filter(
      (i) => !matched.has(i),
    );
    const knownPair = available.flatMap((a, at) =>
      available
        .slice(at + 1)
        .filter((b) => seen.has(a) && seen.get(a) === seen.get(b))
        .map((b) => [a, b]),
    )[0];
    const first =
      knownPair?.[0] ?? available.find((i) => !seen.has(i)) ?? available[0];
    await page
      .getByRole("button", { name: `漂流瓶 ${first + 1}`, exact: true })
      .click();
    await expect.poll(() => seen.get(first)).toBeTruthy();
    const value = seen.get(first)!;
    const second =
      knownPair?.[1] ??
      available.find((i) => i !== first && seen.get(i) === value) ??
      available.find((i) => i !== first && !seen.has(i)) ??
      available.find((i) => i !== first)!;
    await page
      .getByRole("button", { name: `漂流瓶 ${second + 1}`, exact: true })
      .click();
    await expect.poll(() => seen.get(second)).toBeTruthy();
    const secondValue = seen.get(second)!;
    if (value === secondValue) {
      matched.add(first);
      matched.add(second);
    }
    await expect(page.locator(".bottle.flipped")).toHaveCount(0);
  }
  await expect(page.getByRole("dialog")).toContainText("奖励已放进背包");
  await expect(page.getByRole("dialog")).toContainText("+38 贝壳");
  await close(page);
  await menu(page, "一起玩吧");
  await page.getByRole("button", { name: /火候刚刚好/ }).click();
  await page.getByRole("button", { name: "和难鱼一起开始" }).click();
  for (let i = 0; i < 3; i++)
    await page.getByRole("button", { name: "出锅！", exact: true }).click();
  await expect(page.getByRole("dialog")).toContainText(/蛋炒饭 ×[12]/);
  await close(page);
  await page.getByRole("button", { name: "给她投喂", exact: true }).click();
  await expect(
    page.locator(".food-row").filter({ hasText: "蛋炒饭" }),
  ).toContainText(/×[12]/);
});

test("group friends use familiar names, contextual chat and a persistent shared story", async ({ page }) => {
  await ready(page);
  await mute(page);
  await page.getByRole("button", { name: "群友圈", exact: true }).click();
  const circle = page.getByRole("dialog");
  for (const name of ["猴", "狐狸", "酒窝", "胡辣汤", "雨夜", "jin佬"])
    await expect(circle.getByRole("heading", { name, exact: true })).toBeVisible();
  const monkey = circle.getByRole("article").filter({ has: page.getByRole("heading", { name: "猴", exact: true }) });
  await monkey.getByText("称呼与互动来历", { exact: true }).click();
  await expect(monkey).toContainText("正文中的反复称呼");
  await monkey.getByRole("button", { name: "公告栏不许再叫应援会", exact: true }).click();
  await expect(page.getByRole("dialog")).toContainText("猴留了一支笔");
  await page.getByRole("button", { name: "先把永久会址划掉", exact: true }).click();
  await close(page);
  await page.reload();
  await stories(page);
  await page.getByRole("button", { name: "继续上次的故事", exact: true }).click();
  await expect(page.getByRole("dialog")).toContainText("猴发来一串问号");
  await page.getByRole("button", { name: "让全村写下想一起做的事", exact: true }).click();
  await expect(page.getByRole("heading", { name: "当事人拥有命名权", exact: true })).toBeVisible();
  await close(page);
  await page.getByRole("button", { name: "群友圈", exact: true }).click();
  await expect(monkey).toContainText("1 段共同回忆");
  await circle.getByRole("button", { name: "跟难鱼聊聊狐狸", exact: true }).click();
  await expect(page.getByRole("log")).toContainText("狐狸的建议先听半句");
  await page.getByRole("textbox", { name: "给难鱼发消息", exact: true }).fill("好");
  await page.getByRole("button", { name: "发送消息", exact: true }).click();
  await expect(page.getByRole("log")).toContainText("有用的建议就留着");
});

test("cinematic view preserves the full-screen world and narrow-screen menus remain usable", async ({ page }, info) => {
  await ready(page);
  await fullscreenWorld(page);
  await page.getByRole("button", { name: "隐藏界面欣赏风景", exact: true }).click();
  await expect(page.getByRole("navigation", { name: "陪伴操作", exact: true })).toBeHidden();
  await expect(page.getByRole("button", { name: "返回游戏", exact: true })).toBeVisible();
  await fullscreenWorld(page);
  await page.screenshot({ path: `../research/expansion-v3/${info.project.name}-cinematic-verified.png` });
  await page.getByRole("button", { name: "返回游戏", exact: true }).click();
  await expect(page.getByRole("navigation", { name: "陪伴操作", exact: true })).toBeVisible();

  await page.setViewportSize({ width: 320, height: 740 });
  await fullscreenWorld(page);
  for (const name of [/^聊聊天/, /^摸摸脑袋$/, /^给她投喂$/, /^群友圈$/])
    await expect(page.getByRole("button", { name })).toBeInViewport();
  await page.getByRole("button", { name: "打开生活菜单", exact: true }).click();
  await expect(page.getByRole("dialog")).toBeVisible();
  const box = await page.getByRole("dialog").boundingBox();
  expect(box!.x).toBeGreaterThanOrEqual(0);
  expect(box!.x + box!.width).toBeLessThanOrEqual(320);
  await page.getByRole("dialog").getByRole("button", { name: "衣柜", exact: true }).click();
  await expect(page.getByRole("heading", { name: "薄荷围巾", exact: true })).toBeVisible();
  await close(page);
  await page.getByRole("button", { name: "打开地图", exact: true }).click();
  await page.getByRole("dialog").getByRole("button", { name: "公园", exact: true }).click();
  await expect(page.getByTestId("scene")).toHaveAttribute("data-place", "park");
  await fullscreenWorld(page);
  await page.screenshot({ path: `../research/expansion-v3/${info.project.name}-320px-verified.png` });
});
