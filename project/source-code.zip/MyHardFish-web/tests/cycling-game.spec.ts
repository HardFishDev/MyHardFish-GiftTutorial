import { test, expect } from '@playwright/test';
import type { CDPSession, Locator, Page } from '@playwright/test';
import { observeCyclingTouchControls, saveFailedCyclingTouchProbe } from './cycling-touch-probe';
import { newGame } from '../src/engine';
import type { GameState } from '../src/engine';
import { SAVE_KEY } from '../src/storage';
import { AUDIO_PREFERENCES_KEY } from '../src/audio-preferences';
import { CYCLING_LENGTH, cyclingReward } from '../src/cycling';
import type { CyclingItem } from '../src/cycling';

const game = (page: Page) => page.getByTestId('cycling-game');
const scene = (page: Page) => page.getByTestId('scene');
const number = async (locator: Locator, attribute: string) => Number(await locator.getAttribute(attribute));
const saved = (page: Page): Promise<GameState> => page.evaluate(key => JSON.parse(localStorage.getItem(key)!), SAVE_KEY);
const observeErrors = (page: Page) => {
  const errors: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  return errors;
};

test.afterEach(async ({ page }, info) => {
  await saveFailedCyclingTouchProbe(page, info);
});

async function ready(page: Page) {
  page.setDefaultTimeout(45000);
  // Installing before startup keeps the game's elapsed time and timer origins aligned.
  // Only paused intervals are skipped; course traversal runs through real animation frames.
  await page.clock.install();
  const state = newGame();
  state.place = 'park'; state.energy = 100; state.settings.voice = false;
  state.settings.lowQuality = false;
  await page.addInitScript(({ state, saveKey, audioKey }) => {
    if (!localStorage.getItem(saveKey)) localStorage.setItem(saveKey, JSON.stringify(state));
    localStorage.setItem(audioKey, JSON.stringify({ music: false, effects: false, musicVolume: .3, effectsVolume: .6 }));
  }, { state, saveKey: SAVE_KEY, audioKey: AUDIO_PREFERENCES_KEY });
  await page.goto('./');
  await expect(page.locator('.resource-loading')).toHaveCount(0, { timeout: 210000 });
  await expect(scene(page)).toHaveAttribute('data-ready', 'true');
  await expect(scene(page)).toHaveAttribute('data-place', 'park');
}

async function openCycling(page: Page) {
  await page.getByRole('button', { name: '打开生活菜单', exact: true }).click();
  await page.getByRole('button', { name: '一起玩吧', exact: true }).click();
  await page.getByRole('button').filter({ has: page.getByRole('heading', { name: '难鱼骑自行车', exact: true }) }).click();
  await expect(page.getByRole('dialog', { name: '难鱼骑自行车', exact: true })).toBeVisible();
  await expect(game(page)).toHaveAttribute('data-phase', 'ready');
  await expect(scene(page)).toHaveAttribute('data-suspended', 'true');
  await expect(page.getByTestId('cycling-scene').locator('canvas')).toBeVisible();
}

async function start(page: Page) {
  await page.getByRole('button', { name: '开始骑行 · 8 精力', exact: true }).click();
  await expect(game(page)).toHaveAttribute('data-phase', 'riding');
  await expect.poll(async () => (await saved(page)).activeGame?.kind).toBe('cycling');
}

async function tapOrClick(_page: Page, button: Locator, touch: boolean) {
  if (touch) await button.tap(); else await button.click();
}

async function canvasColors(page: Page) {
  // Sample in the same animation frame as rendering; a normal WebGL canvas may
  // discard its drawing buffer after compositing without becoming visually blank.
  return page.getByTestId('cycling-scene').locator('canvas').evaluate(source => new Promise<number>(resolve => requestAnimationFrame(() => {
    const sample = document.createElement('canvas'); sample.width = sample.height = 48;
    const ctx = sample.getContext('2d')!;
    ctx.drawImage(source as HTMLCanvasElement, 0, 0, 48, 48);
    const pixels = ctx.getImageData(0, 0, 48, 48).data;
    const colors = new Set<string>();
    for (let i = 0; i < pixels.length; i += 4) colors.add(`${pixels[i] >> 4},${pixels[i + 1] >> 4},${pixels[i + 2] >> 4}`);
    resolve(colors.size);
  })));
}

async function course(page: Page): Promise<CyclingItem[]> {
  return JSON.parse(await game(page).getAttribute('data-course') || '[]');
}

async function steerTo(page: Page, lane: number, touch: boolean) {
  for (let n = 0; n < 2; n++) {
    const current = await number(game(page), 'data-lane');
    if (current === lane) return;
    const direction = current < lane ? 1 : -1;
    await tapOrClick(page, page.getByRole('button', { name: direction === 1 ? '向右变道' : '向左变道', exact: true }), touch);
    await expect(game(page)).toHaveAttribute('data-lane', String(current + direction));
  }
}

type CameraOrbit = { azimuth: number; polar: number; distance: number };
const cameraOrbit = async (page: Page): Promise<CameraOrbit> => JSON.parse((await page.getByTestId('cycling-scene').getAttribute('data-camera-orbit'))!);
const cameraVector = async (page: Page, attribute: string): Promise<number[]> => JSON.parse((await page.getByTestId('cycling-scene').getAttribute(attribute))!);

async function rotateCanvas(page: Page, touch: CDPSession | null, dx: number, dy = 0) {
  const canvas = page.getByTestId('cycling-canvas');
  const box = (await canvas.boundingBox())!;
  // The exposed strip between the HUD and pause card receives actual browser
  // input. Hit-testing catches an overlay swallowing gestures on small screens.
  const start = { x: box.x + box.width * .22, y: box.y + box.height * .28 };
  expect(await canvas.evaluate((element, point) => document.elementFromPoint(point.x, point.y) === element, start)).toBe(true);
  const end = { x: start.x + box.width * dx, y: start.y + box.height * dy };
  if (touch) {
    const point = (x: number, y: number) => ({ x, y, id: 1, force: 1, radiusX: 3, radiusY: 3 });
    await touch.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [point(start.x, start.y)] });
    for (let step = 1; step <= 3; step++) {
      await touch.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [point(start.x + (end.x - start.x) * step / 3, start.y + (end.y - start.y) * step / 3)] });
    }
    await touch.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  } else {
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();
    await page.mouse.move(end.x, end.y, { steps: 3 });
    await page.mouse.up();
  }
  await expect(page.getByTestId('cycling-scene')).toHaveAttribute('data-camera-mode', 'orbit');
}

test('cycling camera rotates freely by mouse or touch without steering, and presets reset the view', async ({ page }, info) => {
  test.setTimeout(300000);
  const errors = observeErrors(page);
  const touch = info.project.name === 'mobile';
  const touchSession = touch ? await page.context().newCDPSession(page) : null;
  await ready(page);
  const origin = await scene(page).getAttribute('data-position');
  await openCycling(page); await start(page);
  await tapOrClick(page, page.getByRole('button', { name: '暂停骑行', exact: true }), touch);
  await expect(game(page)).toHaveAttribute('data-paused', 'true');
  const distance = await game(page).getAttribute('data-distance');
  const lane = await game(page).getAttribute('data-lane');
  const integrity = await game(page).getAttribute('data-integrity');
  const host = page.getByTestId('cycling-scene');
  const reset = page.getByRole('button', { name: '复位视角', exact: true });

  await test.step('each camera preset can be rotated and its active button restores it', async () => {
    for (const [name, id] of [['俯视视角', 'overhead'], ['侧后视角', 'side'], ['跟随视角', 'follow']]) {
      const button = page.getByRole('button', { name, exact: true });
      await tapOrClick(page, button, touch);
      await expect(host).toHaveAttribute('data-camera', id);
      await expect(host).toHaveAttribute('data-camera-mode', 'preset');
      const preset = await host.getAttribute('data-camera-position');
      await rotateCanvas(page, touchSession, .16);
      await expect(host).not.toHaveAttribute('data-camera-position', preset!);
      await tapOrClick(page, button, touch);
      await expect(host).toHaveAttribute('data-camera-mode', 'preset');
      await expect(host).toHaveAttribute('data-camera-position', preset!);
      await expect(button).toHaveAttribute('aria-pressed', 'true');
    }
  });

  await test.step('horizontal gestures pass the front of the rider and complete a full circle', async () => {
    let angle = (await cameraOrbit(page)).azimuth;
    let traveled = 0;
    let sawFront = false;
    for (let turn = 0; turn < 5; turn++) {
      await rotateCanvas(page, touchSession, .27);
      const next = (await cameraOrbit(page)).azimuth;
      traveled += Math.abs(Math.atan2(Math.sin(next - angle), Math.cos(next - angle)));
      angle = next;
      const position = await cameraVector(page, 'data-camera-position');
      const target = await cameraVector(page, 'data-camera-target');
      if (position[2] < target[2] - 1 && !sawFront) {
        sawFront = true;
        await expect.poll(() => canvasColors(page)).toBeGreaterThan(20);
        // Keep the ride paused while recording the rider unobscured by its card.
        await page.screenshot({ path: info.outputPath('cycling-orbit-front.png'), style: '.cycling-paused { visibility: hidden; }' });
      }
    }
    expect(sawFront).toBe(true);
    expect(traveled).toBeGreaterThan(Math.PI * 2);
    await tapOrClick(page, reset, touch);
    await expect(host).toHaveAttribute('data-camera-mode', 'preset');
  });

  await test.step('vertical gestures stop above ground and below the overhead pole', async () => {
    await rotateCanvas(page, touchSession, 0, .60);
    await rotateCanvas(page, touchSession, 0, .60);
    const firstLimit = (await cameraOrbit(page)).polar;
    await rotateCanvas(page, touchSession, 0, .60);
    expect((await cameraOrbit(page)).polar).toBeCloseTo(firstLimit, 3);
    const position = await cameraVector(page, 'data-camera-position');
    expect(position[1]).toBeGreaterThan(.5);
    expect(firstLimit).toBeGreaterThan(0);
    expect(firstLimit).toBeLessThan(Math.PI / 2);
    await page.screenshot({ path: info.outputPath('cycling-orbit-vertical-limit.png'), style: '.cycling-paused { visibility: hidden; }' });
    for (let swipe = 0; swipe < 3; swipe++) await rotateCanvas(page, touchSession, 0, -.25);
    const oppositeLimit = (await cameraOrbit(page)).polar;
    await rotateCanvas(page, touchSession, 0, -.25);
    expect((await cameraOrbit(page)).polar).toBeCloseTo(oppositeLimit, 3);
    expect(Math.abs(firstLimit - oppositeLimit)).toBeGreaterThan(.5);
    expect(oppositeLimit).toBeGreaterThan(0);
    expect(oppositeLimit).toBeLessThan(Math.PI / 2);
    expect((await cameraVector(page, 'data-camera-position'))[1]).toBeGreaterThan(.5);
    await tapOrClick(page, reset, touch);
  });

  await test.step('zoom and keyboard controls keep riding controls independent', async () => {
    await rotateCanvas(page, touchSession, .08);
    const beforeZoom = (await cameraOrbit(page)).distance;
    const canvas = page.getByTestId('cycling-canvas');
    const box = (await canvas.boundingBox())!;
    const y = box.y + box.height * .28;
    if (touchSession) {
      const center = box.x + box.width * .5;
      const scale = await page.evaluate(() => window.visualViewport!.scale);
      const points = (radius: number) => [
        { x: center - radius, y, id: 1, force: 1 },
        { x: center + radius, y, id: 2, force: 1 },
      ];
      await touchSession.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: points(30) });
      await touchSession.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: points(50) });
      await touchSession.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: points(75) });
      await touchSession.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
      await expect.poll(() => page.evaluate(() => window.visualViewport!.scale)).toBe(scale);
    } else {
      await page.mouse.move(box.x + box.width * .5, y);
      await page.mouse.wheel(0, -350);
    }
    await expect.poll(async () => (await cameraOrbit(page)).distance).toBeLessThan(beforeZoom);
    await tapOrClick(page, reset, touch);
    await expect(host).toHaveAttribute('data-camera-mode', 'preset');
    if (!touch) {
      await game(page).focus();
      await page.keyboard.press('q');
      await expect(host).toHaveAttribute('data-camera-mode', 'orbit');
      const left = (await cameraOrbit(page)).azimuth;
      await page.keyboard.press('e');
      await expect.poll(async () => (await cameraOrbit(page)).azimuth).not.toBe(left);
      await page.keyboard.press('r');
      await expect(host).toHaveAttribute('data-camera-mode', 'preset');
      await page.keyboard.press('c');
      await expect(host).toHaveAttribute('data-camera', 'overhead');
      await expect(host).toHaveAttribute('data-camera-mode', 'preset');
    }
  });

  await page.clock.fastForward(1000);
  await expect(game(page)).toHaveAttribute('data-distance', distance!);
  await expect(game(page)).toHaveAttribute('data-lane', lane!);
  await expect(game(page)).toHaveAttribute('data-integrity', integrity!);
  await expect(game(page)).toHaveAttribute('data-paused', 'true');
  await expect(scene(page)).toHaveAttribute('data-position', origin!);
  await expect(scene(page)).toHaveAttribute('data-suspended', 'true');
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(page.viewportSize()!.width);
  await test.step('the chosen angle stays with the rider after resuming and changing lane', async () => {
    await rotateCanvas(page, touchSession, .08);
    const angle = (await cameraOrbit(page)).azimuth;
    const target = await cameraVector(page, 'data-camera-target');
    await tapOrClick(page, page.getByRole('button', { name: '继续骑行', exact: true }), touch);
    await steerTo(page, -1, touch);
    await expect.poll(() => number(game(page), 'data-distance')).toBeGreaterThan(Number(distance));
    await expect.poll(async () => (await cameraVector(page, 'data-camera-target'))[0]).toBeLessThan(target[0] - .5);
    await expect(host).toHaveAttribute('data-camera-mode', 'orbit');
    expect((await cameraOrbit(page)).azimuth).toBeCloseTo(angle, 3);
    await tapOrClick(page, page.getByRole('button', { name: '暂停骑行', exact: true }), touch);
    await expect(game(page)).toHaveAttribute('data-paused', 'true');
  });
  await page.getByRole('button', { name: '关闭窗口', exact: true }).click();
  await expect(scene(page)).toHaveAttribute('data-suspended', 'false');
  await openCycling(page);
  await expect(host).toHaveAttribute('data-camera', 'follow');
  await expect(host).toHaveAttribute('data-camera-mode', 'preset');
  await expect(game(page)).toHaveAttribute('data-distance', '0.00');
  await expect(game(page)).toHaveAttribute('data-lane', '0');
  await page.getByRole('button', { name: '关闭窗口', exact: true }).click();
  await touchSession?.detach();
  expect(errors).toEqual([]);
});

test('independent cycling world animates, supports cameras and controls, pauses and cancels without rewards', async ({ page }, info) => {
  test.setTimeout(300000);
  const errors = observeErrors(page);
  await ready(page);
  const initial = await saved(page);
  const origin = await scene(page).getAttribute('data-position');
  await openCycling(page);
  const touch = info.project.name === 'mobile';
  if (touch) await observeCyclingTouchControls(page);
  const viewport = page.viewportSize()!;
  const dialog = await page.getByRole('dialog').boundingBox();
  expect(dialog).toBeTruthy();
  expect(dialog!.width).toBeGreaterThanOrEqual(viewport.width - 2);
  expect(dialog!.height).toBeGreaterThanOrEqual(viewport.height - 2);
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(viewport.width);
  await expect.poll(() => canvasColors(page)).toBeGreaterThan(20);
  await page.screenshot({ path: info.outputPath('cycling-intro.png') });

  for (const name of ['俯视视角', '侧后视角', '跟随视角']) {
    const button = page.getByRole('button', { name, exact: true });
    await tapOrClick(page, button, touch);
    await expect(button).toHaveAttribute('aria-pressed', 'true');
  }
  await start(page);
  await expect(page.getByTestId('cycling-scene')).toHaveAttribute('data-pedal-phase', /^-?\d+(?:\.\d+)?$/);
  const pedal = await page.getByTestId('cycling-scene').getAttribute('data-pedal-phase');
  await expect(page.getByTestId('cycling-scene')).not.toHaveAttribute('data-pedal-phase', pedal || '');
  await expect.poll(() => number(game(page), 'data-distance')).toBeGreaterThan(2);
  await steerTo(page, -1, touch);
  await steerTo(page, 1, touch);
  await steerTo(page, 0, touch);
  if (!touch) {
    await page.keyboard.press('a'); await expect(game(page)).toHaveAttribute('data-lane', '-1');
    await page.keyboard.press('ArrowRight'); await expect(game(page)).toHaveAttribute('data-lane', '0');
    const before = await page.getByRole('button', { name: '跟随视角', exact: true }).getAttribute('aria-pressed');
    expect(before).toBe('true');
    await page.keyboard.press('c');
    await expect(page.getByRole('button', { name: '俯视视角', exact: true })).toHaveAttribute('aria-pressed', 'true');
  }
  const brake = page.getByRole('button', { name: '减速', exact: true });
  if (touch) {
    await brake.tap();
    await expect(brake).toHaveAttribute('aria-pressed', 'false');
    await expect(game(page)).toHaveAttribute('data-braking', 'false');
  }
  const brakeBox = (await brake.boundingBox())!;
  const brakePoint = { x: brakeBox.x + brakeBox.width / 2, y: brakeBox.y + brakeBox.height / 2, id: 1, force: 1 };
  const brakeTouch = touch ? await page.context().newCDPSession(page) : null;
  try {
    if (brakeTouch) await brakeTouch.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [brakePoint] });
    else { await page.mouse.move(brakePoint.x, brakePoint.y); await page.mouse.down(); }
    await expect(brake).toHaveAttribute('aria-pressed', 'true');
    await expect(game(page)).toHaveAttribute('data-braking', 'true');
  } finally {
    if (brakeTouch) {
      await brakeTouch.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
      await brakeTouch.detach();
    } else await page.mouse.up();
  }
  await expect(brake).toHaveAttribute('aria-pressed', 'false');
  await expect(game(page)).toHaveAttribute('data-braking', 'false');
  await tapOrClick(page, page.getByRole('button', { name: '暂停骑行', exact: true }), touch);
  await expect(game(page)).toHaveAttribute('data-paused', 'true');
  const distance = await game(page).getAttribute('data-distance');
  await page.clock.fastForward(5000);
  await expect(game(page)).toHaveAttribute('data-distance', distance!);
  // A visibility callback must not resume the independent main-world suspension.
  await page.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
  await expect(scene(page)).toHaveAttribute('data-suspended', 'true');
  await expect(scene(page)).toHaveAttribute('data-place', 'park');
  await expect(scene(page)).toHaveAttribute('data-position', origin!);
  await expect(scene(page)).toHaveAttribute('data-walking', 'false');
  // Screenshots can be slow under software WebGL. Keep simulation paused while
  // reviewing cameras so visual evidence does not consume the control-test run.
  for (const [name, filename] of [['侧后视角', 'side'], ['俯视视角', 'overhead'], ['跟随视角', 'follow']]) {
    await tapOrClick(page, page.getByRole('button', { name, exact: true }), touch);
    await expect(page.getByTestId('cycling-scene')).toHaveAttribute('data-camera', filename);
    await page.screenshot({ path: info.outputPath(`cycling-paused-${filename}.png`) });
  }
  await page.screenshot({ path: info.outputPath('cycling-paused.png') });
  await tapOrClick(page, page.getByRole('button', { name: '继续骑行', exact: true }), touch);
  await expect.poll(() => number(game(page), 'data-distance')).toBeGreaterThan(Number(distance));
  await page.getByRole('button', { name: '关闭窗口', exact: true }).click();
  await expect(game(page)).toHaveCount(0);
  await expect(scene(page)).toHaveAttribute('data-suspended', 'false');
  await expect(scene(page)).toHaveAttribute('data-place', 'park');
  await expect(scene(page)).toHaveAttribute('data-position', origin!);
  await expect.poll(async () => (await saved(page)).activeGame).toBeNull();
  const ended = await saved(page);
  expect(ended.shells).toBe(initial.shells); expect(ended.counts.play).toBe(initial.counts.play);
  expect(ended.energy).toBeLessThanOrEqual(initial.energy - 8);
  await openCycling(page);
  expect(await number(game(page), 'data-distance')).toBe(0);
  await page.keyboard.press('Escape'); await expect(game(page)).toHaveCount(0);
  expect(errors).toEqual([]);
});

test('a lost cycling WebGL context stays stopped until the player returns to the map', async ({ page }, info) => {
  test.setTimeout(240000);
  const errors = observeErrors(page);
  await ready(page); const initial = await saved(page);
  await openCycling(page); await start(page);
  await expect.poll(() => number(game(page), 'data-distance')).toBeGreaterThan(2);
  await page.getByTestId('cycling-scene').locator('canvas').evaluate(canvas => {
    const gl = (canvas as HTMLCanvasElement).getContext('webgl2');
    const extension = gl?.getExtension('WEBGL_lose_context');
    if (!extension) throw new Error('This browser cannot exercise WebGL context loss.');
    extension.loseContext();
  });
  await expect(page.getByRole('alert')).toContainText('3D 画面已中断');
  await expect(game(page)).toHaveAttribute('data-paused', 'true');
  const distance = await game(page).getAttribute('data-distance');
  const score = await game(page).getAttribute('data-score');
  await page.keyboard.press('p'); await page.keyboard.press('Space');
  await page.clock.fastForward(30000);
  await expect(game(page)).toHaveAttribute('data-paused', 'true');
  await expect(game(page)).toHaveAttribute('data-distance', distance!);
  await expect(game(page)).toHaveAttribute('data-score', score!);
  await expect(page.getByRole('button', { name: '继续骑行', exact: true })).toHaveCount(0);
  expect((await saved(page)).shells).toBe(initial.shells);
  await page.screenshot({ path: info.outputPath('cycling-context-lost.png') });
  await page.getByRole('button', { name: '关闭窗口', exact: true }).click();
  await expect(scene(page)).toHaveAttribute('data-suspended', 'false');
  await expect.poll(async () => (await saved(page)).activeGame).toBeNull();
  await openCycling(page);
  await expect.poll(() => canvasColors(page)).toBeGreaterThan(20);
  expect(errors).toEqual([]);
});

test('collecting and three real collisions settle a single reward and preserve it after reload', async ({ page }, info) => {
  test.setTimeout(360000);
  const errors = observeErrors(page);
  await ready(page); const initial = await saved(page);
  await openCycling(page); const items = await course(page);
  expect(items.some(item => item.kind === 'cover')).toBe(true);
  expect(items.some(item => item.kind === 'hole')).toBe(true);
  await start(page);
  await expect.poll(() => number(game(page), 'data-score'), { timeout: 30000 }).toBeGreaterThanOrEqual(40);
  const hazards = items.filter(item => item.kind === 'hole' || item.kind === 'barrier');
  let previousDistance = 24;
  for (let hit = 1; hit <= 3; hit++) {
    const currentDistance = await number(game(page), 'data-distance');
    const target = hazards.find(item => item.distance > Math.max(previousDistance + 16, currentDistance + 8));
    expect(target).toBeTruthy(); previousDistance = target!.distance;
    await steerTo(page, target!.lane, info.project.name === 'mobile');
    await expect.poll(() => number(game(page), 'data-integrity'), { timeout: 45000 }).toBeLessThanOrEqual(3 - hit);
  }
  await expect(game(page)).toHaveAttribute('data-phase', 'finished');
  await expect(game(page)).toHaveAttribute('data-integrity', '0');
  const score = await number(game(page), 'data-score');
  const payout = cyclingReward(score);
  await expect.poll(async () => (await saved(page)).counts.play).toBe(initial.counts.play + 1);
  const finished = await saved(page);
  expect(finished.activeGame).toBeNull();
  expect(finished.shells).toBe(initial.shells + payout.shells);
  expect(finished.records.cycling).toBe(score);
  await page.clock.fastForward(5000);
  expect((await saved(page)).shells).toBe(finished.shells);
  await page.screenshot({ path: info.outputPath('cycling-result.png') });
  await page.getByRole('button', { name: '关闭窗口', exact: true }).click();
  await page.reload();
  await expect(page.locator('.resource-loading')).toHaveCount(0, { timeout: 210000 });
  await expect(scene(page)).toHaveAttribute('data-ready', 'true');
  const restored = await saved(page);
  expect(restored.shells).toBe(finished.shells); expect(restored.records.cycling).toBe(score);
  expect(restored.counts.play).toBe(initial.counts.play + 1); expect(restored.place).toBe('park');
  await openCycling(page); await start(page);
  await page.getByRole('button', { name: '关闭窗口', exact: true }).click();
  await expect.poll(async () => (await saved(page)).activeGame).toBeNull();
  expect((await saved(page)).shells).toBe(finished.shells);
  expect(errors).toEqual([]);
});

test('the complete cycling road can be finished by choosing safe pickup lanes', async ({ page }, info) => {
  test.skip(info.project.name === 'mobile', 'Full course uses desktop; touch collision, controls, rewards and save are covered separately.');
  test.setTimeout(360000);
  const errors = observeErrors(page);
  await ready(page); await openCycling(page);
  const items = await course(page);
  const rows = [...new Set(items.filter(item => item.kind === 'hole' || item.kind === 'barrier').map(item => item.distance))];
  await start(page);
  for (const distance of rows) {
    // Default polling backs off to 1 s, nearly a whole row at riding speed.
    await expect.poll(() => number(game(page), 'data-distance'), { timeout: 45000, intervals: [50, 100] }).toBeGreaterThan(distance - 15);
    const hazards = items.filter(item => item.distance === distance && (item.kind === 'hole' || item.kind === 'barrier'));
    const reward = items.find(item => item.distance === distance && item.kind !== 'hole' && item.kind !== 'barrier');
    expect(reward).toBeTruthy(); expect(hazards.some(item => item.lane === reward!.lane)).toBe(false);
    await steerTo(page, reward!.lane, false);
  }
  await expect(game(page)).toHaveAttribute('data-phase', 'finished', { timeout: 45000 });
  expect(await number(game(page), 'data-distance')).toBe(CYCLING_LENGTH);
  expect(await number(game(page), 'data-integrity')).toBe(3);
  expect(await number(game(page), 'data-score')).toBeGreaterThan(500);
  await page.screenshot({ path: info.outputPath('cycling-complete.png') });
  expect(errors).toEqual([]);
});
