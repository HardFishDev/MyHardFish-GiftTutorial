import { test, expect } from "@playwright/test";
import { mkdir, writeFile } from "node:fs/promises";
import { adventureItems, discoveries, quests } from "../src/adventure-content";
import { foods, friends, outfits, places, stories } from "../src/content";
import { GAME_MAX_SCORE, getAdventureView, getQuestView, newGame, quoteMap, step } from "../src/engine";
import type { Action, GameState } from "../src/engine";
import type { AdventureReward, GameKind, QuestStage } from "../src/adventure-types";
import { makeArchive, readArchive, validateState } from "../src/storage";
import { EXPLORATION_SPOTS } from "../src/world-layout";

const NOW = new Date(2026, 8, 29, 12).getTime();
const act = (s: GameState, action: Action) => step(s, action, Math.max(NOW, s.updatedAt + 6000));
function play(input: GameState, game: GameKind, score = 0) {
  let s = input.energy < 8 ? act(input, { type: "interact", value: "rest" }) : input;
  s = act(s, { type: "startGame", value: game });
  expect(s.activeGame?.kind).toBe(game);
  return act(s, { type: "finishGame", value: game, score, sessionId: s.activeGame!.id });
}
function satisfy(input: GameState, stage: QuestStage) {
  let s = act(input, { type: "place", value: stage.place });
  for (const requirement of stage.requirements || []) {
    if (requirement.kind === "game") {
      for (let count = 0; count < (requirement.count || 1); count++)
        s = play(s, requirement.game, requirement.minScore || 0);
    } else if (requirement.kind === "discovery") {
      const d = discoveries.find(item => item.id === requirement.discoveryId)!;
      s = act(s, { type: "place", value: d.place });
      s = act(s, { type: "discover", value: d.id, hotspot: d.hotspot });
    } else {
      const story = stories.find(item => item.id === requirement.storyId)!;
      while (s.bond < story.minBond) s = act(s, { type: "interact", value: "praise" });
      s = act(s, { type: "place", value: story.place });
      s = act(s, { type: "startStory", value: story.id });
      for (let guard = 0; s.story && guard < 12; guard++) {
        const current = story.nodes[s.story.node];
        s = act(s, { type: "choice", value: current.choices![0].next });
      }
      expect(s.story).toBeNull();
    }
  }
  return act(s, { type: "place", value: stage.place });
}

type Checkpoint = { questId: string; stage: QuestStage; entered: GameState; ready: GameState };
function completeCampaign(emptyPockets = false, preferLast = false) {
  let s = newGame(NOW);
  if (emptyPockets) {
    s.shells = 0;
    for (const food of foods) s.inventory[food.id] = 0;
    s.energy = 0;
  }
  const checkpoints: Checkpoint[] = [];
  for (let guard = 0; guard < quests.length; guard++) {
    const view = getAdventureView(s).quests.find(q => q.status === "active" || q.status === "available");
    expect(view, "the remaining quest graph must have an accessible next quest").toBeTruthy();
    if (!view) break;
    if (view.status === "available") s = act(s, { type: "startQuest", value: view.quest.id });
    for (const stage of view.quest.stages) {
      const entered = structuredClone(s);
      s = satisfy(s, stage);
      const ready = structuredClone(s);
      const options = getQuestView(s, view.quest.id)!.choices.filter(choice => choice.enabled);
      expect(options.length, `${view.quest.id}/${stage.id} has no reachable option`).toBeGreaterThan(0);
      const free = options.filter(({ choice }) => !(choice.costShells || 0) && !Object.values(choice.costFoods || {}).some(Boolean));
      const choices = free.length ? free : options;
      const chosen = preferLast ? choices[choices.length - 1] : choices[0];
      s = act(s, { type: "questAction", questId: view.quest.id, stageId: stage.id, choiceId: chosen.choice.id, hotspot: stage.hotspot });
      expect(s.adventure.quests[view.quest.id].choices[stage.id]).toBe(chosen.choice.id);
      checkpoints.push({ questId: view.quest.id, stage, entered, ready });
      const restored = readArchive(makeArchive(s, [null, null, null])).state;
      expect(restored.adventure).toEqual(s.adventure);
      expect(restored.inventory).toEqual(s.inventory);
      s = restored;
    }
    expect(s.adventure.quests[view.quest.id].status).toBe("completed");
  }
  expect(getAdventureView(s).completedCount).toBe(quests.length);
  return { state: s, checkpoints };
}

let cachedCampaign: ReturnType<typeof completeCampaign> | undefined;
const getCampaign = () => cachedCampaign ??= completeCampaign();

test("authored quest graph, outcomes and references have no missing dependencies or impossible goals", () => {
  expect(quests.length).toBeGreaterThanOrEqual(8);
  expect(new Set(quests.map(q => q.id)).size).toBe(quests.length);
  expect(new Set(adventureItems.map(item => item.id)).size).toBe(adventureItems.length);
  expect(new Set(discoveries.map(item => item.id)).size).toBe(discoveries.length);
  expect(discoveries.length).toBe(EXPLORATION_SPOTS.length);
  expect(new Set(discoveries.map(item => item.hotspot)).size).toBe(discoveries.length);
  const reward = (r: AdventureReward | undefined) => {
    if (!r) return;
    for (const n of [r.shells || 0, r.bond || 0, ...Object.values(r.items || {}), ...Object.values(r.foods || {})]) {
      expect(Number.isInteger(n)).toBe(true); expect(n).toBeGreaterThanOrEqual(0);
    }
    for (const id of Object.keys(r.items || {})) expect(adventureItems.some(item => item.id === id)).toBe(true);
    for (const id of Object.keys(r.foods || {})) expect(foods.some(item => item.id === id)).toBe(true);
    for (const id of Object.keys(r.relations || {})) expect(friends.some(friend => friend.id === id)).toBe(true);
    for (const points of Object.values(r.relations || {})) { expect(Number.isInteger(points)).toBe(true); expect(Math.abs(points)).toBeLessThanOrEqual(100); }
    for (const id of r.outfits || []) expect(outfits.some(outfit => outfit.id === id)).toBe(true);
  };
  const visit = (id: string, seen: string[]) => {
    expect(seen).not.toContain(id);
    const quest = quests.find(q => q.id === id);
    expect(quest).toBeDefined();
    for (const parent of quest!.prerequisites) visit(parent, [...seen, id]);
  };
  for (const quest of quests) {
    visit(quest.id, []); reward(quest.reward);
    expect(quest.source).toMatch(/改编|原型|原创/);
    expect(quest.stages.length).toBeGreaterThanOrEqual(3);
    expect(quest.stages.length).toBeLessThanOrEqual(5);
    expect(new Set(quest.stages.map(stage => stage.id)).size).toBe(quest.stages.length);
    for (const friendId of quest.friendIds) expect(friends.some(friend => friend.id === friendId)).toBe(true);
    for (const stage of quest.stages) {
      expect(places.some(place => place.id === stage.place)).toBe(true);
      expect(stage.hotspot.length).toBeGreaterThan(0);
      expect(EXPLORATION_SPOTS.some(spot => spot.id === stage.hotspot && spot.place === stage.place)).toBe(true);
      expect(stage.choices.length).toBeGreaterThan(0);
      expect(stage.choices.some(choice => !(choice.costShells || 0)
        && !Object.values(choice.costFoods || {}).some(Boolean)), `${quest.id}/${stage.id} needs an option without money or snack costs`).toBe(true);
      expect(new Set(stage.choices.map(choice => choice.id)).size).toBe(stage.choices.length);
      if (stage.quoteId) expect(quoteMap[stage.quoteId]).toBeDefined();
      expect(new Set((stage.requirements || []).map(r => r.id)).size).toBe((stage.requirements || []).length);
      for (const r of stage.requirements || []) {
        if (r.kind === "game") { expect(GAME_MAX_SCORE[r.game]).toBeDefined(); expect(Number.isInteger(r.minScore || 0)).toBe(true); expect(r.minScore || 0).toBeGreaterThanOrEqual(0); expect(r.minScore || 0).toBeLessThanOrEqual(2); expect(r.count || 1).toBe(1); }
        if (r.kind === "story") expect(stories.some(story => story.id === r.storyId)).toBe(true);
        if (r.kind === "discovery") expect(discoveries.some(d => d.id === r.discoveryId)).toBe(true);
      }
      for (const choice of stage.choices) {
        reward(choice.reward);
        if (choice.quoteId) expect(quoteMap[choice.quoteId]).toBeDefined();
        for (const id of Object.keys(choice.costItems || {})) expect(adventureItems.some(item => item.id === id)).toBe(true);
        for (const id of Object.keys(choice.costFoods || {})) expect(foods.some(item => item.id === id)).toBe(true);
        for (const n of [choice.costShells || 0, ...Object.values(choice.costItems || {}), ...Object.values(choice.costFoods || {})]) {
          expect(Number.isInteger(n)).toBe(true); expect(n).toBeGreaterThanOrEqual(0);
        }
      }
    }
  }
  for (const d of discoveries) { reward(d.reward); expect(EXPLORATION_SPOTS.some(spot => spot.id === d.hotspot && spot.place === d.place)).toBe(true); if (d.quoteId) expect(quoteMap[d.quoteId]).toBeDefined(); }
});

test("a new player completes every quest with ZIP checkpoints and without wiping old progress", async () => {
  const campaign = getCampaign();
  expect(campaign.checkpoints.length).toBeGreaterThanOrEqual(24);
  expect(campaign.state.adventure.log.some(log => log.kind === "stage")).toBe(true);
  expect(Object.values(campaign.state.adventure.relations).some(points => points > 0)).toBe(true);
  expect(campaign.state.adventure.flags.length).toBeGreaterThan(0);
  expect(campaign.state.version).toBe(1);
  const replay = validateState(JSON.parse(JSON.stringify(campaign.state)));
  expect(replay.adventure).toEqual(campaign.state.adventure);
  const fixture = step(replay, { type: "settings", value: { voice: false, lowQuality: false } }, replay.updatedAt);
  const directory = new URL("../../research/expansion-v3/", import.meta.url);
  await mkdir(directory, { recursive: true });
  await writeFile(new URL("completed-campaign-fixture.json", directory), JSON.stringify(validateState(fixture), null, 2) + "\n");
  await writeFile(new URL("completed-campaign-fixture.provenance.json", directory), JSON.stringify({
    generatedAt: new Date().toISOString(), generator: "tests/adventure.spec.ts / completeCampaign()",
    reproduce: "npx playwright test --project=logic tests/adventure.spec.ts --grep 'a new player completes'",
    method: "newGame() followed by real engine actions, legitimate minigame sessions and a ZIP round trip after every stage",
    completedQuests: quests.length, completedStages: campaign.checkpoints.length,
    settings: { voice: false, lowQuality: false },
    purpose: "Late-game visual inspection fixture. This is engine-generated progression, not a claim of browser or human campaign completion.",
  }, null, 2) + "\n");
});

test("groupmate chat remembers the most recent shared quest after a ZIP restore", () => {
  const campaign = getCampaign();
  const last = campaign.checkpoints[campaign.checkpoints.length - 1];
  const quest = quests.find(q => q.id === last.questId)!;
  const friend = friends.find(friend => friend.id === quest.friendIds[0])!;
  const restored = readArchive(makeArchive(campaign.state, [null, null, null])).state;
  const chat = act(restored, { type: "chat", text: `聊聊${friend.name}` });
  expect(chat.reaction.text).toContain(quest.title);
  expect(chat.reaction.text).toContain(quest.ending.slice(0, 100));
  expect(chat.topic).toBe(`friend:${friend.id}`);
});

test("explicit guidance follows the tracked stage, respects emotions and offers post-campaign exploration", () => {
  const fresh = newGame(NOW);
  const first = getAdventureView(fresh).tracked!;
  const answer = act(fresh, { type: "chat", text: "下一步去哪？" });
  expect(answer.topic).toBe("adventure");
  expect(answer.reaction.text).toContain(first.stage!.title);
  expect(answer.reaction.text).toContain(places.find(place => place.id === first.stage!.place)!.name);
  expect(answer.reaction.text).toContain("手帐");
  const campaign = getCampaign();
  const pending = campaign.checkpoints.find(item => (item.stage.requirements || []).some(r => r.kind === "game"))!;
  const tracked = act(pending.entered, { type: "trackQuest", value: pending.questId });
  const reminder = act(tracked, { type: "chat", text: "现在做什么任务" });
  expect(reminder.reaction.text).toContain(pending.stage.title);
  expect(reminder.reaction.text).toContain(pending.stage.requirements![0].label);
  const comfort = act(tracked, { type: "chat", text: "任务好多，我有点焦虑" });
  expect(comfort.topic).toBe("sad");
  expect(comfort.reaction.text).toContain("我听着");
  for (const text of ["花", "鱼"]) expect(act(tracked, { type: "chat", text }).topic).not.toBe("adventure");
  const epilogue = act(campaign.state, { type: "chat", text: "开村日以后去哪？" });
  expect(epilogue.reaction.text).toContain("发现册");
  expect(epilogue.reaction.text).toContain("回忆");
});

test("empty pockets, empty food bag, zero energy and alternative choices never soft-lock the campaign", () => {
  const result = completeCampaign(true, true);
  expect(getAdventureView(result.state).completedCount).toBe(quests.length);
  expect(result.state.shells).toBeGreaterThanOrEqual(0);
  expect(Object.values(result.state.inventory).every(count => count >= 0)).toBe(true);
});

test("legacy v1 saves preserve stories, possessions and old achievements while adding safe defaults", () => {
  let s = act(newGame(NOW), { type: "startStory", value: "fanclub" });
  s = act(s, { type: "choice", value: "rename" });
  s.achievements = ["explore"];
  const legacy = JSON.parse(JSON.stringify(s));
  delete legacy.adventure; delete legacy.activeGame; delete legacy.records.words; delete legacy.records.harvest;
  const restored = validateState(legacy);
  expect(restored.version).toBe(1);
  expect(restored.story).toEqual(s.story);
  expect(restored.inventory).toEqual(s.inventory);
  expect(restored.shells).toBe(s.shells);
  expect(restored.achievements).toContain("explore");
  expect(restored.records.words).toBe(0); expect(restored.records.harvest).toBe(0);
  expect(restored.activeGame).toBeNull();
  expect(getAdventureView(restored).activeCount).toBeGreaterThan(0);
  expect(validateState(restored).adventure).toEqual(restored.adventure);
});

test("all games require matching live sessions and settle only once", () => {
  for (const kind of Object.keys(GAME_MAX_SCORE) as GameKind[]) {
    const initial = newGame(NOW);
    const missing = step(initial, { type: "finishGame", value: kind, score: 1, sessionId: "missing" }, NOW);
    expect(missing.shells).toBe(initial.shells);
    expect(missing.counts.play).toBe(0);
    const started = step(initial, { type: "startGame", value: kind }, NOW);
    expect(started.energy).toBe(initial.energy - 8);
    const action: Action = { type: "finishGame", value: kind, score: 1, sessionId: started.activeGame!.id };
    const finished = step(started, action, NOW);
    expect(finished.shells).toBe(initial.shells + (kind === "cycling" ? 8 : 13));
    expect(finished.records[kind]).toBe(1);
    expect(finished.counts.play).toBe(1);
    expect(finished.activeGame).toBeNull();
    const duplicate = step(finished, action, NOW);
    expect(duplicate.shells).toBe(finished.shells);
    expect(duplicate.inventory).toEqual(finished.inventory);
    expect(duplicate.counts).toEqual(finished.counts);
  }
});

test("stale, mismatched, non-finite and restored session claims cannot award progress", () => {
  const first = step(newGame(NOW), { type: "startGame", value: "words" }, NOW);
  const newer = step(first, { type: "startGame", value: "words" }, NOW);
  const stale = step(newer, { type: "finishGame", value: "words", score: 5, sessionId: first.activeGame!.id }, NOW);
  expect(stale.shells).toBe(newer.shells); expect(stale.activeGame).toEqual(newer.activeGame);
  const wrong = step(newer, { type: "finishGame", value: "harvest", score: 5, sessionId: newer.activeGame!.id }, NOW);
  expect(wrong.shells).toBe(newer.shells);
  for (const score of [NaN, Infinity, -Infinity]) {
    const invalid = step(newer, { type: "finishGame", value: "words", score, sessionId: newer.activeGame!.id }, NOW);
    expect(invalid.shells).toBe(newer.shells); expect(invalid.activeGame).toEqual(newer.activeGame);
  }
  const restored = readArchive(makeArchive(newer, [null, null, null])).state;
  expect(restored.activeGame).toBeNull();
  expect(step(restored, { type: "finishGame", value: "words", score: 5, sessionId: newer.activeGame!.id }, NOW).shells).toBe(restored.shells);
});

test("unfinished stories cannot be overwritten or restarted by another entry point", () => {
  let s = step(newGame(NOW), { type: "startStory", value: "fanclub" }, NOW);
  s = step(s, { type: "choice", value: "rename" }, NOW);
  expect(step(s, { type: "startStory", value: "fanclub" }, NOW).story).toEqual(s.story);
  expect(step(s, { type: "startStory", value: "movie" }, NOW).story).toEqual(s.story);
});

test("quest actions require the current step, valid choice, correct place and correct hotspot", () => {
  const campaign = getCampaign();
  const { ready, stage, questId } = campaign.checkpoints[0];
  const choice = getQuestView(ready, questId)!.choices.find(option => option.enabled)!.choice;
  const valid: Action = { type: "questAction", questId, stageId: stage.id, choiceId: choice.id, hotspot: stage.hotspot };
  const actions: Action[] = [
    { ...valid, hotspot: "missing-hotspot" }, { ...valid, stageId: "missing-stage" },
    { ...valid, choiceId: "missing-choice" }, { ...valid, questId: "missing-quest" },
    { type: "startQuest", value: "missing-quest" }, { type: "trackQuest", value: "missing-quest" },
  ];
  for (const action of actions) {
    const rejected = step(ready, action, ready.updatedAt);
    expect(rejected.adventure).toEqual(ready.adventure); expect(rejected.shells).toBe(ready.shells);
  }
  const away = { ...ready, place: places.find(place => place.id !== stage.place)!.id };
  expect(getQuestView(away, questId)!.choices.every(option => !option.enabled)).toBe(true);
  expect(step(away, valid, away.updatedAt).adventure).toEqual(away.adventure);
  const done = step(ready, valid, ready.updatedAt);
  const repeated = step(done, valid, done.updatedAt);
  expect(repeated.adventure).toEqual(done.adventure); expect(repeated.shells).toBe(done.shells);
});

test("missing quest materials reject all costs atomically", () => {
  const campaign = getCampaign();
  const checkpoint = campaign.checkpoints.find(c => c.stage.choices.some(choice => Object.values(choice.costItems || {}).some(Boolean)));
  expect(checkpoint).toBeDefined();
  const { ready, stage, questId } = checkpoint!;
  const choice = stage.choices.find(choice => Object.values(choice.costItems || {}).some(Boolean))!;
  const empty = structuredClone(ready); empty.adventure.items = {};
  const rejected = step(empty, { type: "questAction", questId, stageId: stage.id, choiceId: choice.id, hotspot: stage.hotspot }, empty.updatedAt);
  expect(rejected.adventure).toEqual(empty.adventure); expect(rejected.inventory).toEqual(empty.inventory); expect(rejected.shells).toBe(empty.shells);
  expect(rejected.notice).toContain("还需要");
});

test("historical records do not satisfy a newly entered game stage", () => {
  const campaign = getCampaign();
  const checkpoint = campaign.checkpoints.find(c => c.stage.requirements?.some(r => r.kind === "game"))!;
  const s = structuredClone(checkpoint.entered); s.place = checkpoint.stage.place;
  s.records = { ...GAME_MAX_SCORE };
  const view = getQuestView(s, checkpoint.questId)!;
  expect(view.requirements.filter(r => r.requirement.kind === "game").every(r => !r.met && r.current === 0)).toBe(true);
  const after = satisfy(s, checkpoint.stage);
  expect(getQuestView(after, checkpoint.questId)!.requirements.every(r => r.met)).toBe(true);
});

test("a round begun before entering the next stage cannot satisfy that stage even at the same timestamp", () => {
  const campaign = getCampaign();
  const checkpoint = campaign.checkpoints.find(c => {
    const quest = quests.find(q => q.id === c.questId)!;
    const index = quest.stages.findIndex(stage => stage.id === c.stage.id);
    return quest.stages[index + 1]?.requirements?.some(r => r.kind === "game");
  })!;
  expect(checkpoint).toBeDefined();
  const quest = quests.find(q => q.id === checkpoint.questId)!;
  const nextStage = quest.stages[checkpoint.ready.adventure.quests[quest.id].stage + 1];
  const requirement = nextStage.requirements!.find(r => r.kind === "game")!;
  if (requirement.kind !== "game") throw Error("expected a game objective");
  let s = structuredClone(checkpoint.ready);
  s.energy = 100; s.place = nextStage.place;
  const now = s.updatedAt;
  s = step(s, { type: "startGame", value: requirement.game }, now);
  const token = s.activeGame!.id;
  s.place = checkpoint.stage.place;
  const choice = getQuestView(s, quest.id)!.choices.find(c => c.enabled)!.choice;
  s = step(s, { type: "questAction", questId: quest.id, stageId: checkpoint.stage.id, choiceId: choice.id, hotspot: checkpoint.stage.hotspot }, now);
  s = step(s, { type: "finishGame", value: requirement.game, score: GAME_MAX_SCORE[requirement.game], sessionId: token }, now);
  expect(getQuestView(s, quest.id)!.requirements.find(r => r.requirement.id === requirement.id)?.met).toBe(false);
  s.place = nextStage.place;
  s = play(s, requirement.game, requirement.minScore || 0);
  expect(getQuestView(s, quest.id)!.requirements.find(r => r.requirement.id === requirement.id)?.met).toBe(true);
});

test("discoveries are local, durable and reward once even across a ZIP restore", () => {
  const discovery = discoveries[0];
  expect(discovery).toBeDefined();
  const initial = newGame(NOW);
  initial.place = places.find(place => place.id !== discovery.place)!.id;
  const action: Action = { type: "discover", value: discovery.id, hotspot: discovery.hotspot };
  expect(step(initial, action, NOW).adventure.discoveries).toEqual([]);
  initial.place = discovery.place;
  const found = step(initial, action, NOW);
  expect(found.adventure.discoveries).toContain(discovery.id);
  const restored = readArchive(makeArchive(found, [null, null, null])).state;
  const repeated = step(restored, action, NOW);
  expect(repeated.shells).toBe(restored.shells); expect(repeated.adventure).toEqual(restored.adventure);
});

test("invalid partial adventure saves and unknown IDs are rejected while valid completed progress stays settled", () => {
  const campaign = getCampaign();
  const initial = newGame(NOW);
  expect(() => validateState({ ...initial, adventure: {} })).toThrow();
  expect(() => validateState({ ...initial, records: { ...initial.records, words: 6 } })).toThrow();
  expect(() => validateState({ ...initial, adventure: { ...initial.adventure, items: { unknown: 1 } } })).toThrow();
  expect(() => validateState({ ...initial, adventure: { ...initial.adventure, flags: ["unknown"] } })).toThrow();
  const malformed = structuredClone(campaign.state);
  const id = quests[0].id;
  malformed.adventure.quests[id].status = "active";
  expect(() => validateState(malformed)).toThrow(/阶段|完成/);
  const restored = validateState(campaign.state);
  const restart = step(restored, { type: "startQuest", value: id }, restored.updatedAt);
  expect(restart.adventure).toEqual(restored.adventure); expect(restart.shells).toBe(restored.shells);
});

test("the expanded exploration achievement requires every current place and preserves legacy awards", () => {
  let s = newGame(NOW);
  for (const place of places.slice(0, 5)) s = step(s, { type: "place", value: place.id }, NOW);
  expect(places.length).toBeGreaterThan(5);
  expect(s.achievements).not.toContain("explore");
  for (const place of places.slice(5)) s = step(s, { type: "place", value: place.id }, NOW);
  expect(s.achievements).toContain("explore");
  const shells = s.shells;
  expect(step(s, { type: "tick" }, NOW).shells).toBe(shells);
});
