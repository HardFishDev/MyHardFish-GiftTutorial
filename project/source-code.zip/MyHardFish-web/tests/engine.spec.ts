import { test, expect } from "@playwright/test";
import { zipSync, strToU8 } from "fflate";
import { localDate, newGame, quoteMap, quotes, step } from "../src/engine";
import { stories } from "../src/content";
import { makeArchive, readArchive, validateState } from "../src/storage";
const NOW = new Date(2026, 8, 28, 12).getTime();

test("waving replies with voiced greeting without spending or blocking affection rewards", () => {
  const start = newGame(NOW);
  const waved = step(start, { type: "interact", value: "wave" }, NOW);
  expect(waved.reaction.motion).toBe("happy");
  expect(waved.reaction.quoteId).toBe("greeting");
  expect(waved.shells).toBe(start.shells);
  expect(waved.energy).toBe(start.energy);
  expect(waved.bond).toBe(start.bond);
  expect(waved.lastReward).toBe(start.lastReward);
  expect(waved.counts).toEqual(start.counts);
  const pet = step(waved, { type: "interact", value: "pet" }, NOW);
  expect(pet.bond).toBe(start.bond + 2);
  expect(validateState(JSON.parse(JSON.stringify(waved))).outfit).toBe("classic");
});

test("feeding consumes one item; full stomach and empty bag do not consume", () => {
  const start = newGame(NOW);
  const fed = step(start, { type: "feed", value: "bun" }, NOW);
  expect(fed.hunger).toBe(94);
  expect(fed.inventory.bun).toBe(2);
  expect(fed.counts.feed).toBe(1);
  const full = step(
    { ...fed, hunger: 100 },
    { type: "feed", value: "milk" },
    NOW,
  );
  expect(full.inventory.milk).toBe(2);
  expect(full.counts.feed).toBe(1);
  const empty = step(start, { type: "feed", value: "rice" }, NOW);
  expect(empty.inventory.rice).toBe(0);
  expect(empty.hunger).toBe(start.hunger);
  expect(start.inventory.bun).toBe(3);
});
test("purchases and re-equipping conserve money and inventory", () => {
  const bought = step(newGame(NOW), { type: "outfit", value: "mint" }, NOW);
  expect(bought.shells).toBe(60);
  expect(bought.owned).toEqual(["classic", "mint"]);
  expect(step(bought, { type: "outfit", value: "mint" }, NOW).shells).toBe(60);
  expect(
    step({ ...bought, shells: 0 }, { type: "buyFood", value: "coffee" }, NOW)
      .inventory.coffee,
  ).toBe(0);
  expect(step(bought, { type: "outfit", value: "night" }, NOW).outfit).toBe(
    "mint",
  );
});
test("absence decay caps at eight hours and daily tasks reset without losing bond", () => {
  const s = newGame(NOW);
  s.daily.claimed = ["chat"];
  s.daily.counts.chat = 4;
  const next = step(s, { type: "tick" }, NOW + 30 * 86400000);
  expect(next.hunger).toBe(48);
  expect(next.energy).toBe(62);
  expect(next.bond).toBe(12);
  expect(next.daily.claimed).toEqual([]);
  expect(next.daily.counts.chat).toBe(0);
  expect(next.daily.date).toBe(localDate(NOW + 30 * 86400000));
});
test("daily and achievement rewards cannot be claimed twice", () => {
  let s = newGame(NOW);
  s.daily.counts.chat = 3;
  s = step(s, { type: "claim", value: "chat" }, NOW);
  expect(s.shells).toBe(135);
  s = step(s, { type: "claim", value: "chat" }, NOW);
  expect(s.shells).toBe(135);
  s.counts.pet = 10;
  s = step(s, { type: "tick" }, NOW);
  const earned = s.shells;
  expect(s.achievements).toContain("hello");
  expect(step(s, { type: "tick" }, NOW).shells).toBe(earned);
});
test("contextual follow-ups remember a topic; wellbeing does not trigger insults", () => {
  let s = step(newGame(NOW), { type: "chat", text: "今天想玩什么" }, NOW);
  expect(s.topic).toBe("game");
  s = step(s, { type: "chat", text: "好" }, NOW);
  expect(s.reaction.text).toContain("漂流瓶");
  s = step(s, { type: "chat", text: "然后呢" }, NOW);
  expect(s.reaction.text).toContain("再来一把");
  s = step(s, { type: "chat", text: "最近压力很大，很难过" }, NOW);
  expect(s.reaction.text).toContain("我听着");
  expect(s.topic).toBe("sad");
});
test("all story branches terminate, survive saves and only award a discovered ending once", () => {
  for (const story of stories) {
    const walk = (node: string, path: string[]) => {
      expect(path.length).toBeLessThan(12);
      for (const c of story.nodes[node].choices || [])
        walk(c.next, [...path, c.next]);
      if (!story.nodes[node].ending) return;
      let s = newGame(NOW);
      s.bond = 100;
      s.place = story.place;
      s = step(s, { type: "startStory", value: story.id }, NOW);
      for (const value of path)
        s = step(
          validateState(JSON.parse(JSON.stringify(s))),
          { type: "choice", value },
          NOW,
        );
      expect(s.endings).toContain(`${story.id}:${node}`);
      expect(s.story).toBeNull();
      const balance = s.shells;
      s = step(s, { type: "startStory", value: story.id }, NOW);
      for (const value of path) s = step(s, { type: "choice", value }, NOW);
      expect(s.shells).toBe(balance);
    };
    walk("start", []);
  }
});
test("locked stories and invalid jumps never change progress", () => {
  const s = newGame(NOW);
  expect(
    step(s, { type: "startStory", value: "holiday" }, NOW).story,
  ).toBeNull();
  const opened = step(s, { type: "startStory", value: "fanclub" }, NOW);
  expect(
    step(opened, { type: "choice", value: "chair" }, NOW).story?.node,
  ).toBe("start");
});
test("each curated quote is reachable and has provenance and context", () => {
  expect(new Set(quotes.map((q) => q.id)).size).toBe(quotes.length);
  expect(quoteMap.thanksmaster.context).toContain("反讽");
  let s = newGame(NOW);
  for (const q of quotes) {
    expect(q.messageId).toMatch(/^\d+$/);
    expect(q.context.length).toBeGreaterThan(10);
    s = step(s, { type: "recall" }, NOW);
  }
  expect(s.collected.length).toBe(quotes.length);
});
test("ZIP round trip keeps Chinese chat, inventory, branches and manual slots", () => {
  let s = step(newGame(NOW), { type: "chat", text: "喵，存下来！" }, NOW);
  s = step(s, { type: "startStory", value: "fanclub" }, NOW);
  s = step(s, { type: "choice", value: "rename" }, NOW);
  const out = readArchive(
    makeArchive(s, [{ label: "带你回家", savedAt: NOW, state: s }, null, null]),
  );
  expect(out.state.messages).toEqual(s.messages);
  expect(out.state.inventory).toEqual(s.inventory);
  expect(out.state.story).toEqual({ id: "fanclub", node: "rename" });
  expect(out.slots[0]?.label).toBe("带你回家");
});
test("malformed, oversized and unknown archives are rejected without permissive defaults", () => {
  expect(() => readArchive(new Uint8Array([1, 2, 3]))).toThrow();
  expect(() => readArchive(new Uint8Array(3 * 1024 * 1024))).toThrow(/2 MB/);
  expect(() => validateState({ ...newGame(NOW), shells: -10 })).toThrow();
  expect(() =>
    validateState({ ...newGame(NOW), inventory: { bun: 10000000 } }),
  ).toThrow();
  expect(() =>
    validateState({
      ...newGame(NOW),
      messages: [{ who: "fish", text: "x".repeat(100000), at: NOW }],
    }),
  ).toThrow();
  expect(() =>
    readArchive(
      zipSync({
        "manifest.json": strToU8('{"game":"wrong"}'),
        "save.json": strToU8("{}"),
        "slots.json": strToU8("[]"),
      }),
    ),
  ).toThrow(/不支持|不是/);
  const big = zipSync({ "manifest.json": new Uint8Array(2 * 1024 * 1024) });
  expect(() => readArchive(big)).toThrow(/过大/);
});

test("groupmates use stable names and remember contextual follow-ups across saves", async () => {
  const { friends } = await import("../src/content");
  for (const friend of friends) {
    const state = step(newGame(NOW), { type: "chat", text: `聊聊${friend.name}` }, NOW);
    expect(state.topic).toBe(`friend:${friend.id}`);
    expect(state.reaction.quoteId).toBe(friend.quoteId);
    expect(quoteMap[friend.quoteId]?.text).toBe(friend.quote);
    expect(state.reaction.text).toContain(friend.topic);
    const restored = validateState(JSON.parse(JSON.stringify(state)));
    const next = step(restored, { type: "chat", text: "后来呢" }, NOW);
    expect(next.topic).toBe(`friend:${friend.id}`);
    expect(next.reaction.text).toContain(friend.followup);
    for (const id of friend.storyIds) expect(stories.some((story) => story.id === id)).toBeTruthy();
  }
  expect(step(newGame(NOW), { type: "chat", text: "dbh又来了吗" }, NOW).topic).toBe("friend:monkey");
  expect(step(newGame(NOW), { type: "chat", text: "聊聊jin佬" }, NOW).topic).toBe("friend:jin");
  const sad = step(newGame(NOW), { type: "chat", text: "聊聊狐狸，我今天很难过" }, NOW);
  expect(sad.topic).toBe("sad");
  expect(sad.reaction.motion).toBe("happy");
  const talking = step(newGame(NOW), { type: "chat", text: "聊聊猴" }, NOW);
  expect(step(talking, { type: "chat", text: "好难过" }, NOW).topic).toBe("sad");
});

test("relationship memories derive from existing ending keys and count each story once", async () => {
  const { friendProgress } = await import("../src/content");
  let s = newGame(NOW);
  s.place = "kitchen";
  s = step(s, { type: "startStory", value: "belated_cake" }, NOW);
  s = step(s, { type: "choice", value: "card" }, NOW);
  s = step(s, { type: "choice", value: "later" }, NOW);
  expect(s.endings).toContain("belated_cake:later");
  const legacyShape = validateState(JSON.parse(JSON.stringify(s)));
  expect(friendProgress("rainnight", legacyShape.endings).completed).toBe(1);
  expect(friendProgress("rainnight", [...legacyShape.endings, "belated_cake:wish"]).completed).toBe(1);
  const recalled = step(legacyShape, { type: "chat", text: "聊聊雨夜" }, NOW);
  expect(recalled.reaction.text).toContain("不用也能说谢谢");
  expect(recalled.inventory).toEqual(s.inventory);
  expect(recalled.version).toBe(1);
});

test("adapted group stories have valid cast, quote assets and equally valid cake choices", async () => {
  expect(new Set(stories.map((story) => story.id)).size).toBe(stories.length);
  const { friends } = await import("../src/content");
  for (const story of stories.filter((s) => s.friendIds?.length)) {
    expect(story.source).toContain("改编");
    for (const friendId of story.friendIds!) expect(friends.some((f) => f.id === friendId)).toBeTruthy();
    for (const node of Object.values(story.nodes)) {
      if (node.quote) expect(quoteMap[node.quote]).toBeDefined();
    }
  }
  const cake = stories.find((s) => s.id === "belated_cake")!;
  const endings = Object.values(cake.nodes).filter((n) => n.ending);
  expect(endings).toHaveLength(3);
  expect(new Set(endings.map((n) => n.bond)).size).toBe(1);
  expect(new Set(endings.map((n) => n.shells)).size).toBe(1);
});
