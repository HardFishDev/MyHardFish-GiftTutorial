import { expect, test } from '@playwright/test';
import { newGame } from '../src/engine';
import { SAVE_KEY } from '../src/storage';
import { AUDIO_PREFERENCES_KEY } from '../src/audio-preferences';
import { discoveries } from '../src/adventure-content';
import { EXPLORATION_SPOTS } from '../src/world-layout';

type TransitionFrame = {
  place: string;
  stage: string;
  revision: string;
  indicator: boolean;
  inert: boolean;
  walking: string;
};
type TransitionProbe = { frames: TransitionFrame[]; stop: () => void };
type ProbeWindow = Window & { __worldTransitionProbe?: TransitionProbe };

test('world switches paint feedback, honor a quick return, and resume cross-region navigation', async ({ page }, info) => {
  test.skip(info.project.name !== 'desktop', 'The focused transition case runs on desktop; scene interaction tours cover both viewports.');
  test.setTimeout(240000);
  const errors: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  const state = newGame();
  state.settings.voice = false;
  state.settings.lowQuality = true;
  await page.addInitScript(({ state, saveKey, audioKey }) => {
    if (!localStorage.getItem(saveKey)) localStorage.setItem(saveKey, JSON.stringify(state));
    localStorage.setItem(audioKey, JSON.stringify({ music: false, effects: false, musicVolume: .3, effectsVolume: .6 }));
  }, { state, saveKey: SAVE_KEY, audioKey: AUDIO_PREFERENCES_KEY });
  await page.goto('./');
  await expect(page.locator('.resource-loading')).toHaveCount(0, { timeout: 210000 });
  const scene = page.getByTestId('scene');
  await expect(scene).toHaveAttribute('data-ready', 'true');
  await expect(scene).toHaveAttribute('data-place', 'home');
  await expect(scene).toHaveAttribute('data-scene-loading', 'false');
  const canvas = await scene.locator('canvas').elementHandle();
  const initialRevision = await scene.getAttribute('data-scene-revision');

  // This probe observes DOM diagnostics at real animation frames. It never
  // changes the simulation, rendering schedule, or any application state.
  await page.evaluate(() => {
    const frames: TransitionFrame[] = [];
    let frame = 0;
    const sample = () => {
      const host = document.querySelector<HTMLElement>('[data-testid="scene"]');
      if (host?.dataset.sceneLoading === 'true' && frames.length < 200) {
        const indicator = document.querySelector<HTMLElement>('.world-scene-transition');
        frames.push({
          place: host.dataset.place || '', stage: host.dataset.sceneTransition || '', revision: host.dataset.sceneRevision || '',
          indicator: Boolean(indicator?.getClientRects().length) && !document.querySelector('dialog[open]'),
          inert: host.inert, walking: host.dataset.walking || '',
        });
      }
      frame = requestAnimationFrame(sample);
    };
    (window as ProbeWindow).__worldTransitionProbe = { frames, stop: () => cancelAnimationFrame(frame) };
    frame = requestAnimationFrame(sample);
  });

  await test.step('the old scene remains visible while its loading indicator gets a frame', async () => {
    await page.getByRole('button', { name: '打开地图', exact: true }).click();
    await page.getByRole('dialog').getByRole('button', { name: '公园', exact: true }).click();
    await expect(scene).toHaveAttribute('data-place', 'park');
    await expect(scene).toHaveAttribute('data-scene-loading', 'false');
    await expect(page.getByTestId('scene-transition-indicator')).toHaveCount(0);
    const samples = await page.evaluate(() => (window as ProbeWindow).__worldTransitionProbe!.frames);
    expect(samples.some(frame => frame.place === 'home' && frame.stage === 'loading' &&
      frame.revision === initialRevision && frame.indicator && frame.inert && frame.walking === 'false')).toBe(true);
  });

  await test.step('park to home to park replaces a pending map change through real map buttons', async () => {
    await page.getByRole('button', { name: '打开地图', exact: true }).click();
    const beforeRevision = Number(await scene.getAttribute('data-scene-revision'));
    // Observe the loading boundary and reopen the actual map immediately. Using
    // its ordinary buttons avoids protocol round trips consuming the two-frame
    // cancellation window; no private React or world methods are invoked.
    const overlap = await page.getByRole('dialog').getByRole('button', { name: '小窝', exact: true }).evaluate(button =>
      new Promise<{ place: string; stage: string; busy: string }>((resolve, reject) => {
        let reopened = false;
        const observer = new MutationObserver(() => {
          const host = document.querySelector<HTMLElement>('[data-testid="scene"]')!;
          if (!reopened && host.dataset.sceneLoading === 'true' && !document.querySelector('dialog[open]')) {
            reopened = true;
            document.querySelector<HTMLButtonElement>('button[aria-label="打开地图"]')!.click();
            return;
          }
          if (!reopened) return;
          const park = document.querySelector<HTMLButtonElement>('dialog[open] .atlas-pin[aria-label="公园"]');
          if (!park) return;
          const result = { place: host.dataset.place || '', stage: host.dataset.sceneTransition || '', busy: host.dataset.sceneLoading || '' };
          observer.disconnect(); clearTimeout(timeout);
          park.click(); resolve(result);
        });
        const timeout = setTimeout(() => { observer.disconnect(); reject(new Error('The map could not be reopened during scene preparation.')); }, 10000);
        observer.observe(document.body, { childList: true, subtree: true, attributes: true });
        (button as HTMLButtonElement).click();
      }));
    expect(overlap).toEqual({ place: 'park', stage: 'loading', busy: 'true' });
    await expect(page.getByRole('dialog')).toHaveCount(0);
    await expect(scene).toHaveAttribute('data-place', 'park');
    await expect(scene).toHaveAttribute('data-scene-loading', 'false');
    await expect(scene).toHaveAttribute('data-scene-transition', 'ready');
    await expect.poll(async () => Number(await scene.getAttribute('data-scene-revision'))).toBe(beforeRevision + 1);
    expect(await canvas!.evaluate(element => element === document.querySelector('[data-testid="scene"] canvas'))).toBe(true);
    await expect(page.getByRole('button', { name: '打开地图', exact: true })).toContainText('公园');
  });

  await test.step('notebook navigation waits for the destination, walks to it, and permits interaction', async () => {
    const discovery = discoveries.find(value => value.id === 'home_notice')!;
    const spot = EXPLORATION_SPOTS.find(value => value.id === discovery.hotspot)!;
    await page.getByRole('button', { name: '打开村民手帐', exact: true }).click();
    await page.getByRole('tab', { name: '探索册', exact: true }).click();
    await page.locator('.discovery-groups button').filter({ has: page.getByText(discovery.title, { exact: true }) }).click();
    await expect(scene).toHaveAttribute('data-place', discovery.place);
    await expect(scene).toHaveAttribute('data-scene-loading', 'false');
    await expect(scene).toHaveAttribute('data-walking', 'true');
    const departure = await scene.getAttribute('data-position');
    await expect(scene).not.toHaveAttribute('data-position', departure!);
    await expect(page.getByRole('dialog')).toContainText(spot.label, { timeout: 70000 });
    await expect(scene).toHaveAttribute('data-walking', 'false');
    await page.getByRole('button', { name: '记下这处发现', exact: true }).click();
    await expect(page.getByRole('dialog')).toContainText('已记入探索册');
    await page.getByRole('button', { name: '关闭窗口', exact: true }).click();
    await scene.locator('canvas').focus();
    await page.keyboard.press('e');
    await expect(page.getByRole('dialog')).toContainText(spot.label);
    await expect(page.locator('.world-scene-error')).toHaveCount(0);
    await expect(page.getByTestId('scene-transition-indicator')).toHaveCount(0);
  });

  const samples = await page.evaluate(() => {
    const probe = (window as ProbeWindow).__worldTransitionProbe!;
    probe.stop(); return probe.frames;
  });
  await info.attach('world-transition-frames', { body: JSON.stringify(samples), contentType: 'application/json' });
  expect(errors).toEqual([]);
});
