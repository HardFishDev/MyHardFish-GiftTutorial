import { expect, test } from '@playwright/test';
import type { Page, TestInfo } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { newGame } from '../src/engine';
import { SAVE_KEY } from '../src/storage';
import { AUDIO_PREFERENCES_KEY } from '../src/audio-preferences';
import { DBH_CLUES } from '../src/dbh-content';
import type { DbhState } from '../src/dbh-state';

const output = process.env.QA_ARTIFACT_DIR || '../research/dbh-npc/browser';
const panel = (page: Page) => page.getByRole('dialog', { name: '与 dbh 聊天', exact: true });
async function ready(page: Page) {
  const state = newGame();
  state.place = 'village'; state.settings.voice = false; state.settings.lowQuality = true;
  await page.addInitScript(({ state, saveKey, audioKey }) => {
    if (!localStorage.getItem(saveKey)) localStorage.setItem(saveKey, JSON.stringify(state));
    localStorage.setItem(audioKey, JSON.stringify({ music: false, effects: false, musicVolume: .3, effectsVolume: .6 }));
  }, { state, saveKey: SAVE_KEY, audioKey: AUDIO_PREFERENCES_KEY });
  await page.goto('./');
  await expect(page.locator('.resource-loading')).toHaveCount(0, { timeout: 210000 });
  await expect(page.getByTestId('scene')).toHaveAttribute('data-ready', 'true');
  await expect(page.getByTestId('scene')).toHaveAttribute('data-place', 'village');
}
async function npc(page: Page) {
  const raw = await page.getByTestId('scene').getAttribute('data-dbh-details');
  return raw ? JSON.parse(raw) as { id: string; action: string; conversation: boolean; position: { x: number; y: number; z: number }; screen: { x: number; y: number } } | null : null;
}
async function saved(page: Page): Promise<DbhState> {
  return page.evaluate(key => JSON.parse(localStorage.getItem(key) || '{}').dbh, SAVE_KEY);
}
async function meet(page: Page) {
  await page.getByRole('button', { name: /去找 dbh/ }).click();
  await expect(panel(page)).toBeVisible({ timeout: 70000 });
  await expect(page.getByTestId('scene')).toHaveAttribute('data-walking', 'false');
  await expect.poll(async () => (await npc(page))?.conversation).toBe(true);
  const data = await npc(page); expect(data?.id).toBe('dbh');
  const position = (await page.getByTestId('scene').getAttribute('data-position'))!.split(',').map(Number);
  expect(Math.hypot(position[0] - data!.position.x, position[1] - data!.position.z)).toBeLessThan(4.6);
}
async function checkLayout(page: Page, info: TestInfo) {
  const viewport = page.viewportSize()!;
  await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth)).toBe(viewport.width);
  const bounds = await panel(page).boundingBox(); expect(bounds).not.toBeNull();
  expect(bounds!.x).toBeGreaterThanOrEqual(0); expect(bounds!.y).toBeGreaterThanOrEqual(0);
  expect(bounds!.x + bounds!.width).toBeLessThanOrEqual(viewport.width + 1);
  expect(bounds!.y + bounds!.height).toBeLessThanOrEqual(viewport.height + 1);
  await expect.poll(async () => {
    const point = (await npc(page))?.screen;
    return Boolean(point && point.x > 0 && point.x < viewport.width && point.y > 0 && point.y < viewport.height &&
      (info.project.name === 'mobile' ? point.y < bounds!.y : point.x < bounds!.x));
  }, { timeout: 20000 }).toBe(true);
}

test('dbh can be reached, responds with visible actions, saves memories and survives travel', async ({ page }, info) => {
  test.setTimeout(360000);
  const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  await ready(page); await meet(page);
  await expect(panel(page)).toContainText('QQ 80117801');
  await checkLayout(page, info);
  // A conversation must hold the player in place while keyboard controls are used.
  const position = await page.getByTestId('scene').getAttribute('data-position');
  await page.keyboard.press('w');
  await expect(page.getByTestId('scene')).toHaveAttribute('data-position', position!);
  await panel(page).getByRole('button', { name: '挥手打招呼', exact: true }).click();
  await expect(page.getByTestId('scene')).toHaveAttribute('data-dbh-action', 'wave');
  await panel(page).getByRole('button', { name: '聊聊这件 DBH T 恤', exact: true }).click();
  await expect(panel(page)).toContainText('灰色宽松 T 恤');
  await panel(page).getByRole('button', { name: '有树荫、有微风的那种', exact: true }).click();
  await expect(page.getByTestId('scene')).toHaveAttribute('data-dbh-action', 'stretch');
  await panel(page).getByRole('button', { name: '一起做点事', exact: true }).click();
  for (const [name, action] of [['一起跳一小段', 'dance'], ['伸个懒腰', 'stretch'], ['一起折纸星', 'gift']] as const) {
    await panel(page).getByRole('button', { name: new RegExp(name) }).click();
    await expect(page.getByTestId('scene')).toHaveAttribute('data-dbh-action', action);
    if (action === 'dance') {
      await page.screenshot({ path: `${output}/${info.project.name}-dance.png` });
      await panel(page).getByRole('button', { name: '跟上下一拍', exact: true }).click();
      await panel(page).getByRole('button', { name: '跟上下一拍', exact: true }).click();
      await panel(page).getByRole('button', { name: '一起完成收尾', exact: true }).click();
      await expect(page.getByTestId('scene')).toHaveAttribute('data-dbh-action', 'cheer');
    }
  }
  // A failed browser capture must restore the conversation camera and allow retry.
  await page.getByTestId('scene').locator('canvas').evaluate(element => {
    const canvas = element as HTMLCanvasElement;
    const original = canvas.toDataURL;
    canvas.toDataURL = () => {
      canvas.toDataURL = original;
      throw new Error('Controlled capture failure');
    };
  });
  await panel(page).getByRole('button', { name: /拍张合影/ }).click();
  await expect(panel(page)).toContainText('刚才的照片没有保存好');
  await expect(panel(page).getByRole('button', { name: /拍张合影/ })).toBeEnabled();
  expect((await saved(page)).credited).not.toContain('action:photo');
  await checkLayout(page, info);
  const downloading = page.waitForEvent('download');
  await panel(page).getByRole('button', { name: /拍张合影/ }).click();
  const download = await downloading;
  expect(download.suggestedFilename()).toMatch(/dbh.*\.png$/);
  const photograph = `${output}/${info.project.name}-download.png`;
  await download.saveAs(photograph);
  expect((await readFile(photograph)).subarray(0, 8)).toEqual(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
  await expect.poll(async () => (await saved(page)).memories).toEqual(expect.arrayContaining(['first_meeting', 'dance', 'paper_star', 'photo']));
  const before = await saved(page);
  await panel(page).getByRole('button', { name: /一起跳一小段/ }).click();
  await panel(page).getByRole('button', { name: '跟上下一拍', exact: true }).click();
  await panel(page).getByRole('button', { name: '跟上下一拍', exact: true }).click();
  await panel(page).getByRole('button', { name: '一起完成收尾', exact: true }).click();
  await panel(page).getByRole('button', { name: /^村中手记/ }).click();
  await expect(panel(page)).toContainText('不用踩准的节拍');
  await page.screenshot({ path: `${output}/${info.project.name}-memories.png` });
  await page.keyboard.press('Escape');
  await expect(panel(page)).toHaveCount(0);
  await expect.poll(async () => (await npc(page))?.conversation).toBe(false);
  await page.getByRole('button', { name: '打开地图', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: '公园', exact: true }).click();
  await expect(page.getByTestId('scene')).toHaveAttribute('data-place', 'park');
  await expect.poll(() => npc(page)).toBeNull();
  await page.getByRole('button', { name: '打开地图', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: '村中心', exact: true }).click();
  await expect(page.getByTestId('scene')).toHaveAttribute('data-place', 'village');
  await expect.poll(() => saved(page)).toEqual(before);
  await page.reload();
  await expect(page.locator('.resource-loading')).toHaveCount(0, { timeout: 210000 });
  await expect(page.getByTestId('scene')).toHaveAttribute('data-ready', 'true');
  await meet(page);
  await panel(page).getByRole('button', { name: /^村中手记/ }).click();
  await expect(panel(page)).toContainText('纸星约定');
  expect(await saved(page)).toEqual(before);
  await panel(page).getByRole('button', { name: '结束与 dbh 的交谈', exact: true }).click();
  await expect(panel(page)).toHaveCount(0);
  await page.getByTestId('scene').locator('canvas').focus();
  await page.keyboard.press('e');
  await expect(panel(page)).toBeVisible();
  await expect.poll(async () => (await npc(page))?.conversation).toBe(true);
  expect(errors).toEqual([]);
});

test('dbh village notes require actual visits and retain the completed shared memory', async ({ page }, info) => {
  test.setTimeout(600000);
  const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  await ready(page); await meet(page);
  await panel(page).getByRole('button', { name: /^村中手记/ }).click();
  await panel(page).getByRole('button', { name: '接下散步小约定', exact: true }).click();
  await expect.poll(async () => (await saved(page)).quest.status).toBe('active');
  for (const clue of DBH_CLUES) {
    await expect(panel(page).getByLabel(clue.question, { exact: true })).toHaveCount(0);
  }
  await expect(panel(page).getByRole('button', { name: '交上这页手记', exact: true })).toBeDisabled();
  for (const clue of DBH_CLUES) {
    await panel(page).locator('.dbh-clue').filter({ has: page.getByText(clue.label, { exact: true }) }).getByRole('button', { name: '带我过去', exact: true }).click();
    await expect(panel(page)).toHaveCount(0);
    await expect.poll(async () => (await saved(page)).quest.visited, { timeout: 100000 }).toContain(clue.hotspot);
    await page.getByRole('button', { name: '关闭窗口', exact: true }).click();
    await meet(page);
    await panel(page).getByRole('button', { name: /^村中手记/ }).click();
    await panel(page).getByLabel(clue.question, { exact: true }).selectOption(clue.answer);
  }
  await panel(page).getByRole('button', { name: '交上这页手记', exact: true }).click();
  await expect.poll(async () => (await saved(page)).quest.status).toBe('completed');
  await expect(panel(page)).toContainText('和 dbh 的村中散步手记');
  const before = await saved(page);
  expect(before.memories.filter(id => id === 'village_walk')).toHaveLength(1);
  await checkLayout(page, info);
  await page.screenshot({ path: `${output}/${info.project.name}-quest-complete.png` });
  await page.keyboard.press('Escape'); await meet(page);
  await panel(page).getByRole('button', { name: /^村中手记/ }).click();
  await expect(panel(page).getByRole('button', { name: '交上这页手记', exact: true })).toHaveCount(0);
  expect(await saved(page)).toEqual(before);
  expect(errors).toEqual([]);
});
