import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({
  plugins: [react()],
  base: "./",
  // WSL /mnt drives do not consistently deliver filesystem change notifications.
  server: { watch: { usePolling: true, interval: 500 } },
  build: {
    chunkSizeWarningLimit: 700,
    rollupOptions: {
      output: {
        manualChunks: {
          three: ["three"],
          react: ["react", "react-dom"],
          icons: ["@phosphor-icons/react"],
        },
      },
    },
  },
});
