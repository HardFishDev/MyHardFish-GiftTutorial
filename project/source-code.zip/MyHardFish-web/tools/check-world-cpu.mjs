import {build} from 'esbuild';
import {mkdtempSync,copyFileSync,readFileSync,writeFileSync,rmSync,mkdirSync,readdirSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const codeRoot=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const target=resolve(codeRoot,process.env.QA_OUTPUT_DIR||'../research/town-expansion','world-navigation.json');
const temporary=mkdtempSync(join(tmpdir(),'hardfish-world-qa-'));
try {
 await build({entryPoints:['environment','world-navigation','world-layout','scene'].map(name=>resolve(codeRoot,`src/${name}.ts`)),bundle:true,format:'esm',platform:'node',outdir:temporary,splitting:true,logLevel:'silent'});
 for(const name of ['check','movement','markers']) {
  copyFileSync(resolve(codeRoot,`tools/world-qa/${name}.mjs`),join(temporary,`${name}.mjs`));
  execFileSync(process.execPath,[join(temporary,`${name}.mjs`)],{env:{...process.env,HARDFISH_CODE_ROOT:codeRoot,HARDFISH_QA_DIR:temporary},stdio:'pipe'});
 }
 const report=JSON.parse(readFileSync(join(temporary,'navigation.json'),'utf8'));
 report.movement=JSON.parse(readFileSync(join(temporary,'movement.json'),'utf8'));
 report.markerPicking=JSON.parse(readFileSync(join(temporary,'markers.json'),'utf8'));
 const sources=[...readdirSync(resolve(codeRoot,'src')).filter(name=>/^environment.*\.ts$/.test(name)), 'scene.ts','world-navigation.ts','world-layout.ts','world-town-props.ts','world-atmosphere.ts'];
 report.sourceSHA256=Object.fromEntries(sources.map(name=>[`src/${name}`,createHash('sha256').update(readFileSync(resolve(codeRoot,'src',name))).digest('hex')]));
 report.checkedAt=new Date().toISOString();
 report.fixtureSHA256=Object.fromEntries(['tools/check-world-cpu.mjs',...['check','movement','markers'].map(name=>`tools/world-qa/${name}.mjs`)].map(name=>[name,createHash('sha256').update(readFileSync(resolve(codeRoot,name))).digest('hex')]));
 report.summary={regions:report.result.length,fixedRoutes:report.result.reduce((n,r)=>n+r.checks,0),sampledTargets:report.result.reduce((n,r)=>n+r.sampled,0),errors:report.result.reduce((n,r)=>n+r.errors.length,0),fpsSimulation:[60,10,4],markerTargets:report.markerPicking.length,markerFailures:report.markerPicking.filter(r=>!r.ok||!r.containsMarker).length};
 report.limitations=['Only Canvas 2D drawing was stubbed; geometry, collision, A* and pick handler are real.','No GPU memory, pixels or hardware FPS were measured.','Collision is configured AABBs plus a 0.6 metre actor radius, not per-triangle mesh collision.','60/10/4 FPS is simulated through real movement substeps, not a throttled live browser.','The bridge movement fixture uses a navigation-only synthetic goal and a position/rotation actor; it does not test character geometry or semantic activities.','Marker ray tests do not assess occlusion by environmental meshes.'];
 mkdirSync(dirname(target),{recursive:true});writeFileSync(target,JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify(report.summary,null,2));console.log(target);
 const movementFailure=report.movement.some(r=>r.blocked||r.events.length!==1||r.routeRemaining||!r.accepted);
 if(report.summary.errors||report.summary.markerFailures||movementFailure)process.exitCode=1;
} finally {rmSync(temporary,{recursive:true,force:true});}
