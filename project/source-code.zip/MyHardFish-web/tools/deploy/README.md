# GitHub Pages 发布

私有源码仓库为 [HardFishDev/MyHardFish-web](https://github.com/HardFishDev/MyHardFish-web)，公开产物仓库为 [HardFishDev/MyHardFish-web-public](https://github.com/HardFishDev/MyHardFish-web-public)。公开网站使用 `https://hardfishdev.github.io/MyHardFish-web-public/`。

本文件是本项目后续更新的发布操作依据，项目入口见 [AGENTS.md](../../AGENTS.md)。涉及网站更新时沿用下述流程；纯记录或文档维护不触发部署。

## 首次发布记录（2026-09-30）

首次验收时，源码已推送，首批公开产物已上线，包括 91 个运行文件，以及发布器生成的 `.nojekyll` 和 `deployment.json`。公开提交为 `7e9bc0fce2992b4ef8d8035eed6be2977e29de50`；[首次 Pages 发布](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/36660674534) 已成功，站点返回 HTTP 200，HTTPS 已启用，Pages 来源为 `main` 根目录。当时私有仓库 Secret 的 API 写入返回 403，`PAGES_DEPLOY_TOKEN` 尚待配置；首批本地发布与 Pages 上线不代表源码仓库的自动更新已经成功。

2026-09-30 的[首次源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/36661007632)已经实际运行：30 项逻辑测试、8 项产物检查、生产构建和构建产物上传均通过，发布作业下载产物后因缺少 `PAGES_DEPLOY_TOKEN` 明确失败。补齐 Secret 后可在该运行页选择 **Re-run failed jobs**，或在 Actions 中手动运行主分支；随后核对公开仓库的 Pages 部署状态。线上首批文件另经 91 个资源的 HTTP/SHA 校验，以及桌面 1440×1000、手机 390×844 的真实 WebGL、挥手和投喂检查，均通过。生成的截图与 JSON 留在 Git 根目录外，没有上传。

这些是首次发布的历史事实，后续发布应重新确认 Secret 和流水线状态。构建产物仅保留 3 天；只有未过期时才可单独重跑旧发布作业，过期后应对需要发布的提交重新构建。

## 1.3 声音与加载发布（2026-09-30）

网页 1.3.0 已上线，源码提交为 `c94f810c727a088f0839e35f02c2cdd97ef2ff55`，公开产物提交为 `59c76eb6a106482d9927d0ac491ef17b0744a38f`，[Pages 部署](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/36674469944)成功。包含用户提供的 BGM、8 类原创合成音效、独立持久声音偏好以及真实素材进度/马的爆破循环。

本次重新查询确认项目 Secret 仍不存在，API 写入仍返回 403；[源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/36674248030)的 30 项逻辑、15 项产物检查与构建均通过，发布因缺少 `PAGES_DEPLOY_TOKEN` 失败。随后从上述已提交源码的干净 worktree 安装锁定依赖、重新验证构建，93 个成品文件逐项匹配本地浏览器验收哈希，按现有发布器完成本地补发。凭据只通过临时项目目录与发布环境使用，没有配置为全局或组织共享认证。

线上 `deployment.json` 对应同一源码提交，93 个运行文件均完成 HTTP/字节数/SHA-256 核对；桌面 1440×1000 与手机 390×844 的真实 WebGL、BGM 播放/循环/关闭后刷新记忆、挥手与投喂均通过，没有页面/控制台错误、失败资源或外域请求。HTTP 扫描第一次因瞬时 TLS EOF 中断，保持 TLS 校验、采用复用连接及有限重试后完整核对通过。结果与截图在仓库外 `../research/audio-v5/`，没有上传。本轮未更新历史 1.2 离线 ZIP。

## 1.4.1 场景音乐发布（2026-09-30）

本轮将全局 `audio/bgm.mp3` 替换为 9 首本地场景纯音乐，曲目均由 Kevin MacLeod 创作，采用 CC BY 4.0；许可与修改说明见 [音乐名单](../../docs/MUSIC.md) 和成品 `THIRD_PARTY_NOTICES.txt`。游戏内设置保留可见的逐曲署名入口。新曲就绪后进行约 1.2 秒交叉淡变，声音开关和音量继续保存在当前浏览器。

当前预加载清单为 93 项：85 个音频（76 条语音 + 9 首场景曲）与 8 张图片。静态构建包含 101 个运行文件，发布器再生成 `.nojekyll` 和 `deployment.json`。所有音频随本站部署，不使用外域音频请求。当前产物测试集为 23 项，覆盖精确台词/曲目清单、旧 BGM 残留、缺失、改名、多余音频、错误目录和原有分发边界。

1.4.0 初次源码提交为 `93b9d1d81b1498eaa2bc3018f488b8cc2d1e2a95`，公开提交 `52420b4d84f48303638c63a2000c66a9444756e0`；[源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/36681323345)构建成功、发布因缺项目 Secret 失败，本地补发后的 [Pages](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/36681618005)成功。但两个实际浏览器冷加载仍因原资源超时预算不足停在失败提示，不能仅凭 Pages 成功与 101 个 HTTP/SHA 通过宣称游戏验收成功。该轮证据单独保留于 `first-release-1.4.0/`。

1.4.1 保留曲目音质，改用 30 秒无进展续期、90 秒单文件硬限和 180 秒整体硬限。已发布源码提交 `5dc6299953e1e47004e72c96908c1163916409dd`，公开提交 `4df9d49b22204fa583573a2e675110139c19fdee`，[Pages 部署](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/36685092230)成功。

本轮项目 Secret 查询仍为 404，尝试写入为 403，现有项目 PAT 无 Secrets 写权限；[本次源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/36684583847)的 30 项逻辑、23 项产物检查与构建成功，发布作业日志明确因缺少 `PAGES_DEPLOY_TOKEN` 失败。随后按既有发布器，从上述源码提交的干净 worktree 安装锁定依赖、重新测试及构建，101 个文件逐项匹配浏览器验收字节与哈希后本地补发。令牌只用于临时项目目录、Git 请求和发布环境，没有配置全局认证或组织共享 Secret；任务结束清理临时目录。

线上 `deployment.json` 的版本为 1.4.1、源码 SHA 正确，101 个 HTTPS 运行文件逐项核对通过。桌面 1440×1000 与手机 390×844 的独立浏览器均正常完成冷加载、播放小窝/公园/夜市音乐、核对署名、关闭及刷新记忆、从当前夜市存档重开正确音乐，并验证挥手/投喂和全屏 WebGL，零页面/控制台错误、失败资源、HTTP 错误或外域请求。原始证据存放于仓库外 `../research/scene-music-v6/`，实际验证摘要由 [VALIDATION.md](../../docs/VALIDATION.md) 维护；没有上传截图、报告、原始素材研究或凭据。本轮不更新历史 1.2 离线 ZIP，旧报告不能用于签发 1.4 离线包。

## 1.5.1 场景动作发布（2026-10-01）

九区新增 11 类活动，覆盖普通物件、27 个探索点、37 个委托阶段的 76 个选项、21 篇故事的 108 个节点，以及五种小游戏。动作包含实际家具坐姿、五种食物／饮料、读写、平底锅与锅铲、浇水、抛球、购物袋、小灯等；成功与拒绝使用对应反馈，移动／关窗／换区收起道具。桌面侧边和手机下方窗口保留角色可见空间，必要时临时隐藏挡住角色的上部家具或屋檐。设计与验证见 [INTERACTIONS.md](../../docs/INTERACTIONS.md)、[VALIDATION.md](../../docs/VALIDATION.md)。

1.5.0 首次源码 `7869b08c37e3027379b9deb0087fdcd127160bbb` 已推送，公开提交 `99bcbba35283e87c98fcfa26df1269af4595ffa8`，[Pages](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/36753315291)成功、101 文件 HTTPS 哈希通过；但实际浏览器冷加载出现 `ERR_ABORTED` 并停在失败提示。该轮声音巡检两端未进入，随后动作巡检桌面未进入、手机通过，均保持原记录，不把部署成功等同于全部验收成功。

最终 **1.5.1** 源码 `74e0656c5d747bb20fc438594cd9d8c490c49485`，公开产物 `afac5af32c0f9f6ac67248a52c5633d5530ec230`，[Pages 部署](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/36760161829)成功。只对传输／流异常／停滞加入一次自动重试；两次请求共享 90 秒资源预算，保留 30 秒无进展、180 秒整体和六并发，失败请求显式取消。资源计数保持 93 项，成品 101 个运行文件。

本次项目 Secret 查询仍为 404，加密写入仍为 403；[源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/36759701607)的 20 + 22 项加载／报告 CPU、50 项游戏逻辑、23 项产物测试和构建全部成功，发布日志明确因缺 `PAGES_DEPLOY_TOKEN` 失败。随后在上述源码提交的干净 worktree 重装锁定依赖、重新检查构建，101 文件逐项匹配实际浏览器验收字节和哈希，使用既有发布器完成本地补发。凭据仅进入临时项目目录与安全环境，不写入全局认证、组织共享 Secret、公开仓库或日志，结束后清理。

最终线上 `deployment.json` 的版本／源码 SHA 正确，101 个 HTTPS 文件字节及 SHA-256 通过。动作与音乐两个 runner 各检查桌面／手机：实际冷加载、真实座位、喝牛奶、凉亭／厨房餐位、道具转换及取消、BGM 三场景播放／署名／关闭刷新记忆／夜市重开、挥手和投喂全部通过；音乐 runner 的刷新同样核对完整源码 SHA 和实际 HTML 哈希。四个视口运行均为 `clean`，93 项预加载完整自动进入，页面／控制台／HTTP／失败资源／外域／越出子目录错误全为零。主代理实际复核六张动作截图；视口模拟不代替真机 FPS 或全剧情人工通关。

原始证据与截图位于 Git 外 `../research/interaction-v7/`，不上传。1.5.0 的角色／世界／动作回归与 1.5.1 的加载、流水线及线上验证各自保留 SHA 和版本边界；后续更新重新按当前源码执行，不套用历史通过数量。dbh 的未完成工作区改动保留，本轮不纳入发布；历史 1.2 离线 ZIP 未更新。

## 1.6.0 dbh 村中心 NPC 首轮发布（2026-10-01，本地补发）

网页 **1.6.0** 已上线精修版 dbh，包括连续头部曲面、表情形变、分层长发、蒙皮四肢与衣物，以及聊天、协作动作、合影、纪念物和散步委托。源码提交为 `67fcd00c47a5628f8c44f987926c9941821ae2da`，公开产物提交为 `d75acdcebd90e3397b478f456d9fbcb2963b5636`，[Pages 部署](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/36810513143)成功。当前预加载 95 项（10 张图、76 条语音、9 首音乐），成品为 104 个运行文件。

首轮重新查询私有仓库项目 Secret 返回 404，公钥读取为 200，加密写入为 403；当时凭据无 Secrets 写权限。[首轮源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/36810357060)的 42 项加载／报告 CPU、56 项游戏逻辑、23 项产物检查、构建及上传均成功；发布步骤失败，当时项目发布 Secret 未配置。随后使用上述源码提交的干净检出，锁定依赖、重新测试构建及两端本地浏览器验收均已完成，104 个成品文件再次逐项匹配验收哈希后，沿用既有发布器本地补发。凭据只用于本项目 API、临时 Git 认证及发布环境，不写入源码、公开产物、远程 URL 或全局配置。

线上 `deployment.json` 的版本与完整源码 SHA 正确；104 个 HTTPS 文件的路径、字节数与 SHA-256 均与同提交干净构建一致，扫描前后部署身份未变。103 个文件首次下载通过，`audio/music-workshop.mp3` 首次响应后传输中断，第二次完整下载及哈希通过；原始异常保留，分类为 `recovered`。公开站点另经 dbh、音乐、场景动作三个 runner 的桌面／手机共六次视口检查，全部通过；包括音乐刷新在内的八个加载阶段均为 95/95 `clean`，浏览器错误计数均为零。实际动作、PNG 合影、存档、音乐记忆和场景交互的范围见 [验证记录](../../docs/VALIDATION.md)，不将文件扫描等同于实际交互检查。

原始证据与截图位于 Git 外 `../research/dbh-release-1.6.0/`，不上传。历史精修本地模型记录保留于 `../research/dbh-refinement/`，与本次线上证据分开；两个路径均相对代码根目录。历史 1.2 离线 ZIP 未更新。

## 自动发布启用与验证（2026-10-01）

用户补齐权限后，05:06:53 UTC 在私有源码仓库成功创建项目级 `PAGES_DEPLOY_TOKEN`：加密写入返回 201，随后查询返回 200。令牌由该仓库的 GitHub Actions Secret 加密保存，仅发布步骤使用；本地认证采用临时进程与 Git helper，不配置全局认证或组织共享 Secret。

对 `main` 发起手动运行，[源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/36818277232)的 `build`、`publish` 及整体结果全部成功。42 项加载／报告 CPU、56 项逻辑、23 项产物边界检查、生产构建与上传均通过，发布日志确认从完整源码 `f8f399bffddbbe37de4d0a352726c685c1f14fae` 自动推送 104 个运行文件。公开提交为 `9dc767379b8122879faf4056dfc0b1879c412c78`，[Pages 部署](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/36818357376)的构建、部署及状态回报全部成功。本轮由 Actions 完成发布，没有本地补发。

版本仍为 1.6.0；该源码比首轮 `67fcd00` 只改四份文档，其余 215 个跟踪路径的 Git 内容不变。线上 `deployment.json` 的完整源码与版本正确，104 个实际 HTTPS 文件的路径、字节数与 SHA-256 全部首次通过，和首轮已验收产物相同；这是未变生产输入的产物比较，不是把旧构建配上新源码提交。

固定新源码 SHA 的桌面／手机 `pages-smoke` 均通过，冷加载和刷新共四阶段都是 95/95 `clean`，音乐、关闭／刷新记忆、挥手及投喂正常，页面／控制台／网络错误为零。模型和场景动作源码未改，本次未重新执行首轮全部专项；详细边界见 [验证记录](../../docs/VALIDATION.md)。新日志、报告与截图位于代码根目录之外 `../research/auto-publish-2026-10-01/`，不上传。后续正常推送 `main` 沿用已有自动流程；轮换令牌时更新同一项目 Secret。

## 1.7.0 dbh 造型重做自动发布（2026-10-01）

源码 `d7c0dae308eb466a0770a9f86aa198b7adb93e6f` 已由 [源码 Actions](https://github.com/HardFishDev/MyHardFish-web/actions/runs/36836488608)自动构建并发布，`build` 与 `publish` 全部成功；公开提交为 `3952d6305d5a160255612627feb60ee43489eb7a`，[Pages 部署](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/36836593217)成功。本轮直接沿用已配置项目 Secret，无本地补发。

1.7.0 重做 dbh 立体五官、分层长发和服装／手脚，保留原交互与存档。旧脸／发 PNG 退出运行素材，生产文件为 102 个，预加载为 93 项；本地 56 项逻辑、49 项加载／响应 CPU、23 项产物边界检查及生产构建通过。模型摄影棚的 11 动作、资源释放和 GLB 回读均通过，但不将技术检查等同于完全还原参考图。

线上完整源码与版本一致，102 个实际 HTTPS 文件的字节和 SHA-256 全部首次匹配本地验收构建。固定源码 SHA 的桌面／手机 `pages-dbh` 均通过，93/93 冷加载为 `clean`；实际 JS/CSS／HTML 哈希、寻路、动作、PNG 合影与存档正常，页面、控制台和网络错误为零。本地 `no-store` 服务下的两个失败记录与后续缓存策略对照分别保留，详见 [验证说明](../../docs/VALIDATION.md)。

同一源码的 `pages-smoke` 桌面／手机也通过，包含四个 93/93 `clean` 冷加载／刷新阶段、实际音乐播放和关闭记忆、挥手及投喂。与 dbh 专项共四个线上视口运行、六个加载阶段，错误为零。

所有本轮证据位于 Git 外 `../research/dbh-third/`（相对代码根目录）；没有上传研究图片、日志、GLB 或凭据。本轮未更新历史离线 ZIP。

## 1.7.1 脸型与体型校正自动发布（2026-10-01）

源码 `81affe6fbc3e93a90b2ea33835c129e442e8b28b` 经 [源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/36846627885)自动构建并发布，`build` 与 `publish` 成功；公开提交 `16b095b3a578a1ba4918a67d7bca0b782ee664a8` 的 [Pages](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/36846730410)构建、部署和状态回报均成功。沿用现有项目 Secret，没有本地补发。

线上版本为 1.7.1，完整源码 SHA 一致；102 个运行文件的路径、字节数与 SHA-256 全部首次匹配本地同提交生产构建。桌面／手机的本地生产预览和公开地址 `pages-dbh` 均通过，每端 93/93 冷加载为 `clean`，实际 HTML 与 7 个 JS/CSS 响应哈希正确；寻路、挥手、舞蹈、伸展、递礼物、PNG 合影和记忆存档正常。页面、控制台与网络错误为零。

同一源码的 `pages-smoke` 另通过桌面／手机的真实 WebGL、挥手／投喂、三个场景音乐与关闭后刷新记忆；两个冷加载和两个刷新阶段均为 93/93 `clean`，页面、控制台和网络错误为零。与 dbh 专项合计四次线上视口运行、六个加载阶段通过；未重新执行与本轮无关的全部剧情专项。手机为浏览器视口模拟，不代表实体手机帧率。

模型与中间预览／修正过程保留于 Git 外 `../research/dbh-proportions/`。本次主要修正大形，仍有程序化面部、发束和手足细节同插画的差距；几何有效与动作检查不代表完全还原。没有上传原图、研究数据、GLB 或凭据，历史离线 ZIP 未更新。

## 1.8.0 连续曲面与材质自动发布（2026-10-02）

源码 `3593d43227af43dd2774f587483c1ed3143368b2` 经 [源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/36905072601)自动构建并发布，`build` 与 `publish` 均成功；公开提交 `d965435986a8d7c49a17748b36f406a0e7543b2a` 的 [Pages](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/36905199174)构建、部署和状态回报均成功。沿用私有仓库已有项目 Secret，没有本地补发。

线上 `deployment.json` 的版本为 1.8.0、完整源码 SHA 一致。103 个 HTTPS 运行文件的路径、字节数和 SHA-256 全部首次匹配该提交的本地验收构建，扫描前后部署身份未变。当前预加载为 94 项（9 张图片、76 条语音、9 首音乐），新增发束材质随本站加载。

桌面 1440×1000、手机 390×844 的本地生产预览与公开网址 `pages-dbh` 均通过。每端冷加载 94/94 为 `clean`，实际 HTML 与 7 个 JS/CSS 响应哈希正确；寻路、挥手、舞蹈、伸展、递礼物、PNG 合影、共同记忆及关闭重开对话正常，页面／控制台／网络错误为零。已实际查看桌面实景和手机合影；视口模拟不代表实体手机性能。

`pages-smoke` 首轮在两个视口读取 `deployment.json` 时遇到 TLS 建连中断，尚未开始游戏加载，失败报告保留于 `online-smoke/`。没有关闭 TLS 校验或修改游戏、断言；同一源码的 `online-smoke-retry/` 完整重跑通过，桌面／手机均验证真实 WebGL、挥手／投喂、小窝／公园／夜市音乐播放及署名、关闭后刷新记忆和重新播放。四个冷加载／刷新阶段均为 94/94 `clean`，页面／控制台／网络错误为零。与 dbh 专项合计四次成功线上视口运行、六个加载阶段；不将首轮连接失败抹去。

本轮证据位于 Git 外 `../research/dbh-reconstruction/`，包含原图对照、中间失败、最终模型、同提交构建清单、发布身份、HTTPS 扫描和实际交互截图。原始三视图、研究数据、GLB 与凭据没有上传。模型仍有皮肤质感、眼神、发梢与手足明暗的还原差距，不把技术通过写作完全还原；历史离线 ZIP 未更新。

## 1.8.1 恢复旧造型覆盖发布（2026-10-02）

按用户明确要求，将 dbh 恢复为 1.7.1 的造型，以 1.8.1 覆盖 1.8.0。源码 `fcf1ecc4e74b1f8fa79b3367f354baf2502000cf` 由 [同次源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/36959310623)完成构建与发布，`build`、`publish` 均成功；公开提交 `52d6d5140b505b7270a8aacd8e7654b13bdcdd94` 的 [Pages](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/36959387361)构建、部署和状态回报成功。使用既有项目 Secret，正常推送历史，没有本地补发或强制推送。

本轮重新构建并检查 102 个运行文件；线上 `deployment.json` 的版本与源码一致，全部文件的 HTTPS 字节数和 SHA-256 首次匹配本地同提交构建，扫描前后部署身份未变。预加载为 93 项（8 张图片、76 条语音、9 首音乐），1.8.0 发束 PNG 已移除。158 个 `src/` 与 `public/` 生产文件的内容与 1.7.1 源码一致，交互和存档协议没有额外改动。

公开网址的桌面 1440×1000、手机 390×844 `pages-dbh` 均通过，冷加载均为 93/93 `clean`。实际 HTML 与 7 个 JS/CSS 响应哈希正确；寻路、挥手、舞蹈、伸展、递礼物、PNG 合影、共同记忆及关闭重开对话正常，页面／控制台／网络错误为零。已实际查看线上恢复造型与手机合影；视口模拟不代表实体手机帧率。

同一源码的 `pages-smoke` 桌面／手机均通过，验证真实 WebGL、挥手／投喂、小窝／公园／夜市音乐及署名、关闭后刷新记忆和重新播放。两个冷加载及两个刷新阶段均为 93/93 `clean`，各阶段源码身份及实际 HTML 哈希正确，页面／控制台／网络错误为零。与 dbh 专项合计四次线上视口运行、六个加载阶段通过。

本轮原图对照、模型检查、构建清单、流水线状态、HTTPS 扫描与实景证据保存在 Git 外 `../research/dbh-rollback-1.8.1/`。本次只恢复用户选择的旧造型，不宣称完成原图还原；没有发布研究图、GLB 或凭据，历史离线 ZIP 未更新。

## 1.9.0 骑行小游戏自动发布（2026-10-03）

新增独立的 600 米骑行地图、原版难鱼踩踏动画、三视角、拾取／避障与会话奖励。源码 `9766ac55b5531660e9d9f1b3ef7ede37cb3ab5d8` 的 [源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/37095564417)中构建与发布均成功；公开提交 `bc0b4bb564d8f3e9cfcef5ddf0841d3c9d1dfd24` 的 [Pages](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/37095621204)全部成功。使用既有项目 Secret，正常推送历史，没有本地补发。

线上版本及完整源码 SHA 正确，102 个运行文件的 HTTPS 字节数和 SHA-256 首次完整匹配本地验收构建，扫描前后部署身份不变。桌面／手机线上骑行控制、三视角、拾取、碰撞、单次领奖、刷新存档与退出重开均通过；基础 WebGL、挥手、投喂和场景音乐专项也通过。具体范围、前期失败与重跑边界见 [验证记录](../../docs/VALIDATION.md)。

原始证据留在 Git 外 `../research/cycling-v1/`，未上传截图、报告或临时认证材料。仅通过临时项目目录向 Git/API 提供凭据，不配置全局认证，不改动既有发布 Secret；用户未提交的互动文档改动保留，历史离线 ZIP 未更新。

## 1.9.1 骑行自由视角自动发布（2026-10-03）

三种骑行预设新增鼠标／触摸自由环绕、俯仰、缩放及复位，暂停时可观察，恢复骑行后跟随换道。源码 `a234ce0384498884f34d76161c529a5b8795c3fc` 的 [源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/37122448151)中构建与发布均成功；公开产物 `bde379ee5dac4dc228cbf8693498439583e5efe7` 的 [Pages](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/37122510289)全部成功。沿用现有项目 Secret，无本地补发。

线上完整源码 SHA 与 1.9.1 版本正确，102 个运行文件 HTTPS 字节与哈希完整匹配本地验收构建；一首音乐首次传输中断，第二次完整通过，原始失败记录保留。扫描前后部署身份不变。桌面／手机线上自由旋转、俯仰、缩放、复位、暂停及继续骑行检查通过，基础互动与音乐专项也通过，四个冷加载／刷新阶段均 93/93 `clean`。范围及结果见 [验证记录](../../docs/VALIDATION.md)。

原始证据留在 Git 外 `../research/cycling-rotation-v1.9.1/`。凭据仅用于临时项目目录的 Git/API 操作，没有写入源码、产物、远程 URL 或全局认证。用户已有互动文档修改保留，历史离线 ZIP 未更新。

## 1.10.0 独立骑行与三档地图自动发布（2026-10-04）

源码 `fb9139b6a8850bf50a679ad0cf794e416c1de7f2` 经 [同次源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/37176695403)完成构建与发布，两个作业均成功；公开产物 `1307850ab2089531878abc47928414d9a7e4cb72` 的 [Pages 部署](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/37176740701)全部成功。继续使用既有项目 Secret，没有本地补发。

本轮增加 `#cycling` 直链、复制分享、三档难度及独立地图、拾取与碰撞动画、4 个骑行 MP3 和资源按需加载。主世界预加载仍为 93 项，独立骑行只预加载自己的 4 个音频；音频名单由专用清单限定并纳入产物检查。

线上版本与完整源码 SHA 一致，111 个 HTTPS 运行文件的路径、字节数及 SHA-256 全部首次匹配本地最终生产构建，无重试或失败；扫描前后部署身份一致。 本地 75 项逻辑、94 项 CPU／产物检查通过；线上骑行专项最终 8 项通过、2 项重复场景跳过，主游戏音乐及两端各 11 项场景动作检查也通过。测试时序及网络失败记录保留，具体复验范围见 [验证记录](../../docs/VALIDATION.md)。证据留在 Git 外 `../research/cycling-expansion-v1.10.0/`，用户已有互动文档修改未纳入发布。

## 1.11.0 骑行自定义操作与场景加载自动发布（2026-10-04）

源码 `df519044999299ae35a8f435cecbaf0bd3ff03f4` 经 [源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/37182991948)完成构建和发布，两项作业均成功；公开产物 `7ced95417539a15d7aa3cf98f64eb812565ff31b` 的 [Pages 部署](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/37183038088)成功。继续使用已有私有仓库项目 Secret，没有本地补发。

新增键位自定义、手机左右手／大小／上移／拖动布局、按住减速及设置暂停；骑行换图复用渲染器和角色，骑行与主世界换区均先绘制小加载提示，再构建场景并恢复操作。浏览器回归识别并修复了原生弹窗内触摸合成点击造成的重复变道，以及暂停提示遮挡按钮的问题。

线上版本与完整源码 SHA 一致，113 个运行文件的实际 HTTPS 字节数、SHA-256 和完整名单全部首次匹配本地最终生产构建，无重试或失败，扫描前后部署身份保持一致。线上自定义操作及换图专项 7 项通过，音乐与场景动作的桌面／手机共四轮也通过，六个冷加载／刷新阶段均 93/93 `clean`。本地 89 项逻辑、94 项 CPU／产物检查，以及 13 项相关浏览器场景覆盖通过；各构建阶段及线上操作结果见 [验证记录](../../docs/VALIDATION.md)。证据留在 Git 外 `../research/cycling-controls-v1.11.0/`，用户已有互动文档改动未纳入发布。

## 后续更新的标准步骤

1. **修改与校验。** 在私有源码仓库完成修改，按影响范围跑逻辑、产物及浏览器检查。Node.js 与依赖版本以工作流和锁文件为准；不要跳过产物检查来迁就新增文件。
2. **提交源码。** 检查 `git status` 与暂存差异，确保测试运行产物、研究资料、聊天导出和密钥未被纳入。提交后记录完整源码 SHA，并推送私有仓库 `main`。
3. **等待自动发布。** 确认同次 `Build and publish game` 的 `build`、`publish` 两个作业都成功，再确认公开仓库的 Pages 部署成功。只看到 `build` 通过不能宣告网站更新完成。
4. **核对线上版本。** 获取网站根目录的 `deployment.json`，检查 `sourceCommit` 与本次发布提交一致；按其中的路径、字节数和 SHA-256 核对运行文件，避免只凭 HTTP 200 或缓存画面判断版本。
5. **实际游玩检查。** 运行 `QA_EXPECTED_SOURCE=<本次完整源码SHA> node tools/qa/pages-smoke.mjs`，确认桌面和竖屏手机显示及基本交互；根据本次改动补充受影响的模型、导航、玩法或存档检查。动作改动还运行 `QA_EXPECTED_SOURCE=<完整源码 SHA> node tools/qa/pages-interactions.mjs`，检查真实座位、投喂道具、探索点镜头遮挡及厨房操作；默认使用当前公开网址，两端串行执行。测试输出不随 Git 上传。
6. **交付记录。** 记录源码 SHA、公开产物提交、Actions/Pages 运行链接、实际验证结果和未解决问题。原始日志、截图与 JSON 留在 `../research/` 或被 Git 忽略的本地目录；项目文档只维护流程与必要的文字摘要，不记录密钥值。

若自动发布缺少凭据或权限，说明真实阻塞并使用项目级 Secret 的配置方式解决，不修改全局认证或组织策略。只有在需要补发时才按下方的本地流程执行，并明确报告其为本地补发。

## 流水线

[publish-pages.yml](../../.github/workflows/publish-pages.yml) 在 `main` 推送、面向 `main` 的 PR 和手动触发时运行。构建作业使用 Node.js 22，依次执行：

1. `npm ci` 安装锁文件依赖。
2. `node --test tools/qa/cycling-audio.test.mjs tools/qa/resource-preloader.test.mjs tools/qa/pages-preload-observer.test.mjs tools/qa/pages-runtime-observer.test.mjs` 的骑行音频、加载恢复、时限、清理与线上报告分类测试。
3. Playwright `logic` 项目的游戏规则与存档测试。
4. `node --test tools/deploy/artifact.test.mjs` 的产物边界测试。各测试数量按本次实际执行结果记录，不套用历史版本数量。
5. `npm run build` 和 `node tools/deploy/artifact.mjs dist`。
6. 上传保留 3 天的 `game-dist`，供发布作业使用。

仅 `main` 的推送或手动运行会进入发布作业；PR 只验证，不接触发布凭据。发布器固定推送公开仓库的 `main`，不接受任意目标仓库参数。公开仓库 Pages 配置为 **Deploy from a branch → main → / (root)**。源码仓库的 `GITHUB_TOKEN` 仅有读取内容权限，跨仓库写入使用独立 Secret。

工作流不包含全部图形和交互回归。修改模型、导航或界面时，仍需按 [验证说明](../../docs/VALIDATION.md) 在本地完成相应浏览器检查。

## 配置发布凭据

组织对公开仓库的 Deploy key 创建请求返回 422（Deploy keys are disabled for this repository），因此使用该项目专用 PAT。不要修改组织策略，也不要把 PAT 放入仓库文件、提交、远程 URL、聊天、命令行字面量或全局 Git 配置。

在**私有源码仓库**的 **Settings → Secrets and variables → Actions → New repository secret** 中创建 `PAGES_DEPLOY_TOKEN`。令牌值通过 GitHub Secret 表单保存，由 GitHub 加密保管；不创建组织级 Secret，也不在公开仓库保存令牌。发布作业通过环境变量取得它，构建和 PR 作业不会取得它。

权限按操作区分，不能用“能读仓库”代替相应写权限：

| 操作 | 目标仓库 | 所需仓库权限 |
| --- | --- | --- |
| 发布编译产物 | 公开产物仓库 | Contents: Read and write |
| 推送包含工作流的源码变更 | 私有源码仓库 | Contents、Workflows: Read and write |
| 通过 API 创建或更新发布 Secret | 私有源码仓库 | Secrets: Read and write |
| 通过 API 初次配置 Pages | 公开产物仓库 | Pages: Read and write |

其中 Workflows、Secrets 和 Pages 写权限用于初始化或对应管理操作，不是每次发布产物的必要权限。若管理员在 GitHub 网页创建 Secret 或配置 Pages，对应初始化操作无需授予该 PAT 的 API 写权限。首次配置时曾出现 Secret 公钥读取成功而写入返回 403；读取成功不能证明有 Secrets 写权限。

令牌轮换时，在同一私有仓库更新 `PAGES_DEPLOY_TOKEN`，再从 Actions 页面运行 `Build and publish game`，分支选择 `main`。检查 `build` 与 `publish` 作业，以及公开仓库的 Pages 发布结果。

## 本地校验与维护

以下命令只校验产物，不接触 GitHub：

```bash
node --test tools/deploy/artifact.test.mjs
node tools/deploy/artifact.mjs dist
```

站点部署后可执行 `QA_EXPECTED_SOURCE=<本次完整源码SHA> node tools/qa/pages-smoke.mjs`，默认检查上述公开 Pages 地址；本机先安装当前 Playwright 的 Chromium，或通过 `PLAYWRIGHT_CHROMIUM_EXECUTABLE` 指定已安装浏览器。用 `QA_OUTPUT_DIR` 指定 Git 根之外的新结果目录；已存在的报告不会覆盖。冷加载与刷新分别核对版本、完整源码 SHA、实际 HTML 哈希和当前素材清单的全部预加载下载；自动重试成功标为 `recovered`，首轮错误仍原样保留。`deployment.json` 中全部运行文件的字节／SHA 核对另外执行，不能把 HTML 校验表述成浏览器 JS/CSS 全量哈希校验。

`artifact.mjs` 只接受入口、第三方许可、规定类型的 `assets/`、76 条与 `quotes.json` 精确对应的语音，以及 `src/music-catalog.json` 定义的场景音乐和 `src/cycling-audio-catalog.json` 定义的骑行音频；当前为 9 首场景音乐与 4 个骑行 MP3，分别使用 `audio/music-{场景}.mp3` 与 `audio/cycling-*.mp3` 文件名。曲目数量由清单推导，不把音乐计为台词；拒绝旧 `audio/bgm.mp3`、缺曲、等数量改名、多余音频、错误目录和不允许的音频格式。验证入口使用相对资源路径，拒绝符号链接、空文件、源码映射、研究/测试输出和已知凭据格式，并计算每个文件的 SHA-256。格式扫描只是辅助检查，不能替代素材与上传范围审阅。

需要本地发布时，先提交要发布的源码，在该提交的干净检出中安装锁定依赖、执行对应检查并运行 `npm run build`。确认该检出的 `package.json` 版本、源码 SHA 和新生成的 `dist/` 属于同一版本。发布器只检查 SHA 格式，不能证明旧 `dist/` 与某个 SHA 的对应关系；不能仅改变 `SOURCE_COMMIT` 就重用其他版本的产物。

由既有安全凭据注入机制提供 `PAGES_DEPLOY_TOKEN`，同时提供指向本次构建源码的完整 40 位 `SOURCE_COMMIT`；Actions 可使用自身的 `GITHUB_SHA`。不要在终端直接写入带令牌值的命令。环境与构建已准备好后执行：

```bash
node tools/deploy/publish.mjs dist
```

发布器在临时目录检出公开仓库，以 `GIT_ASKPASS` 仅向固定仓库的 Git 请求提供凭据。它禁用持久凭据 helper 和全局 Git 配置，复制并逐项核对文件哈希，生成 `.nojekyll` 与记录版本、源码提交和文件清单的 `deployment.json`，正常提交到 `main`，最后清理临时目录。失败时查看经过凭据脱敏的错误信息，不要把未经检查的环境变量或认证输出粘贴到 Issue。

## 域名与存档

目前使用 GitHub 默认项目域名，没有设置 `CNAME`。单独的 `myhardfish` 不是可用于 Pages 的完整自有域名；如需自定义域名，应先确认实际拥有的完整域名并配置 DNS。发布器保留公开仓库中已经存在且格式有效的 `CNAME`，不会自行创建裸名称。

浏览器存档属于当前站点。由本地版迁移到 Pages，或未来更换域名时，先在游戏内导出存档 ZIP，再在新地址导入。网页成品 ZIP 与游戏存档 ZIP 是不同文件。
