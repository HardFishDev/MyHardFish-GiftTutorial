import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { validateArtifact, sha256 } from './artifact.mjs';

const repository = 'https://github.com/HardFishDev/MyHardFish-web-public.git';
const token = process.env.PAGES_DEPLOY_TOKEN;
if (!token) throw new Error('Configure PAGES_DEPLOY_TOKEN in the private source repository Actions secrets.');
const commit = process.env.SOURCE_COMMIT || process.env.GITHUB_SHA;
if (!/^[a-f0-9]{40}$/.test(commit || '')) throw new Error('SOURCE_COMMIT/GITHUB_SHA must identify the source commit');
const files = await validateArtifact(process.argv[2] || 'dist');
const version = JSON.parse(await fs.readFile(new URL('../../package.json', import.meta.url), 'utf8')).version;
const temporary = await fs.mkdtemp(path.join(os.tmpdir(), 'myhardfish-pages-'));
await fs.chmod(temporary, 0o700);
const destination = path.join(temporary, 'site');
const askpass = path.join(temporary, 'askpass.sh');
// Only Git receives the project token. No credentials enter a URL or Git config.
const env = { ...process.env, MF_PAGES_TOKEN: token, GIT_ASKPASS: askpass, GIT_TERMINAL_PROMPT: '0', GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_NOSYSTEM: '1' };
delete env.PAGES_DEPLOY_TOKEN;
const options = ['-c', 'credential.helper=', '-c', 'credential.useHttpPath=true', '-c', 'core.hooksPath=/dev/null', '-c', 'commit.gpgsign=false', '-c', 'user.name=github-actions[bot]', '-c', 'user.email=41898282+github-actions[bot]@users.noreply.github.com'];
function git(args) {
  const result = spawnSync('git', [...options, ...args], { env, encoding: 'utf8', timeout: 120000 });
  const output = ((result.stdout || '') + (result.stderr || '')).replaceAll(token, '[REDACTED]');
  if (result.status !== 0) throw new Error(`Git operation failed (${result.status}): ${output}`);
  return output.trim();
}

try {
  await fs.writeFile(askpass, `#!/bin/sh
case "$1" in
  "Username for 'https://github.com/HardFishDev/MyHardFish-web-public"*) printf '%s\\n' 'x-access-token' ;;
  "Password for 'https://x-access-token@github.com/HardFishDev/MyHardFish-web-public"*) printf '%s\\n' "$MF_PAGES_TOKEN" ;;
  *) exit 1 ;;
esac
`, { mode: 0o700 });
  git(['clone', '--quiet', '--depth=1', repository, destination]);
  git(['-C', destination, 'checkout', '-B', 'main']);
  const cnamePath = path.join(destination, 'CNAME');
  let cname;
  try {
    if (!(await fs.lstat(cnamePath)).isFile()) throw new Error('CNAME must be a regular file');
    cname = (await fs.readFile(cnamePath, 'utf8')).trim();
    if (!/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,63}$/i.test(cname)) throw new Error('CNAME needs a complete custom domain');
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  for (const entry of await fs.readdir(destination)) {
    if (entry !== '.git' && entry !== 'CNAME') await fs.rm(path.join(destination, entry), { recursive: true, force: true });
  }
  for (const file of files) {
    const target = path.join(destination, file.name);
    await fs.mkdir(path.dirname(target), { recursive: true });
    await fs.writeFile(target, file.data);
    if (sha256(await fs.readFile(target)) !== file.sha256) throw new Error(`Copied asset differs: ${file.name}`);
  }
  await fs.writeFile(path.join(destination, '.nojekyll'), '');
  await fs.writeFile(path.join(destination, 'deployment.json'), JSON.stringify({ version, sourceCommit: commit, files: files.map(({ name, bytes, sha256 }) => ({ path: name, bytes, sha256 })) }, null, 2) + '\n');
  git(['-C', destination, 'add', '--all']);
  if (!git(['-C', destination, 'status', '--porcelain'])) {
    console.log('Published files already match this source commit.');
  } else {
    git(['-C', destination, 'commit', '--quiet', '-m', `Deploy game ${version} from ${commit.slice(0, 12)}`]);
    git(['-C', destination, 'push', 'origin', 'HEAD:main']);
    console.log(`Published ${files.length} runtime files from ${commit} to HardFishDev/MyHardFish-web-public.`);
  }
  console.log('Pages target: https://hardfishdev.github.io/MyHardFish-web-public/');
} finally {
  await fs.rm(temporary, { recursive: true, force: true });
}
