import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { validateArtifact } from './artifact.mjs';

const musicCatalog = {
  home: { file: 'music-home.mp3', duration: 60 },
  park: { file: 'music-park.mp3', duration: 75 },
};

const cyclingCatalog = {
  fixtureEffect: { file: 'cycling-fixture-effect.mp3', role: 'effect' },
  fixtureVoice: { file: 'cycling-fixture-voice.mp3', role: 'voice' },
};

async function fixture(run) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'hardfish-artifact-test-'));
  try {
    await fs.mkdir(path.join(root, 'assets'));
    await fs.mkdir(path.join(root, 'audio'));
    await fs.writeFile(path.join(root, 'index.html'), '<script type="module" src="./assets/index-fixture.js"></script>');
    await fs.writeFile(path.join(root, 'assets/index-fixture.js'), 'document.title="fixture";');
    await fs.writeFile(path.join(root, 'audio/fixture.mp3'), 'audio fixture');
    for (const track of Object.values(musicCatalog))
      await fs.writeFile(path.join(root, 'audio', track.file), 'music fixture');
    for (const track of Object.values(cyclingCatalog))
      await fs.writeFile(path.join(root, 'audio', track.file), 'cycling fixture');
    await fs.writeFile(path.join(root, 'THIRD_PARTY_NOTICES.txt'), 'fixture license');
    await run(root);
  } finally { await fs.rm(root, { recursive: true, force: true }); }
}
const verify = root => validateArtifact(root, { voiceIds: ['fixture'], musicCatalog, cyclingCatalog });
test('accepts exact voices, scene tracks and cycling clips, with relative assets and file digests', () => fixture(async root => {
  const files = await verify(root);
  assert.equal(files.length, 8);
  assert.deepEqual(files.filter(file => file.name.endsWith('.mp3')).map(file => file.name), ['audio/cycling-fixture-effect.mp3', 'audio/cycling-fixture-voice.mp3', 'audio/fixture.mp3', 'audio/music-home.mp3', 'audio/music-park.mp3']);
  assert.ok(files.every(file => /^[a-f0-9]{64}$/.test(file.sha256)));
}));
test('requires every catalogued scene track', () => fixture(async root => {
  await fs.unlink(path.join(root, 'audio/music-park.mp3'));
  await assert.rejects(verify(root), /Missing scene music: audio\/music-park.mp3/);
}));
test('does not count scene music as a replacement for a missing voice', () => fixture(async root => {
  await fs.unlink(path.join(root, 'audio/fixture.mp3'));
  await assert.rejects(verify(root), /Missing voice asset/);
}));
test('rejects a renamed voice even when the total MP3 count matches', () => fixture(async root => {
  await fs.rename(path.join(root, 'audio/fixture.mp3'), path.join(root, 'audio/unlisted.mp3'));
  await assert.rejects(verify(root), /Missing voice asset/);
}));
test('rejects additional music or unlisted voice files', () => fixture(async root => {
  await fs.writeFile(path.join(root, 'audio/extra-music.mp3'), 'extra audio');
  await assert.rejects(verify(root), /Unexpected audio asset/);
}));
test('rejects the obsolete global bgm.mp3 even with all scene tracks present', () => fixture(async root => {
  await fs.writeFile(path.join(root, 'audio/bgm.mp3'), 'legacy music');
  await assert.rejects(verify(root), /Unexpected audio asset/);
}));
test('rejects a renamed scene track even when the MP3 count is unchanged', () => fixture(async root => {
  await fs.rename(path.join(root, 'audio/music-home.mp3'), path.join(root, 'audio/music-unlisted.mp3'));
  await assert.rejects(verify(root), /Missing scene music/);
}));
for (const name of ['music-home', 'fixture']) {
  test(`rejects empty ${name} audio`, () => fixture(async root => {
    await fs.writeFile(path.join(root, `audio/${name}.mp3`), '');
    await assert.rejects(verify(root), /Empty runtime asset/);
  }));
}
test('uses the production quote and scene catalogs without a hardcoded music count', () => fixture(async root => {
  await fs.unlink(path.join(root, 'audio/fixture.mp3'));
  const quotes = JSON.parse(await fs.readFile(new URL('../../src/quotes.json', import.meta.url), 'utf8'));
  const catalog = JSON.parse(await fs.readFile(new URL('../../src/music-catalog.json', import.meta.url), 'utf8'));
  for (const filename of await fs.readdir(path.join(root, 'audio'))) await fs.unlink(path.join(root, 'audio', filename));
  assert.equal(quotes.length, 76);
  for (const { id } of quotes) await fs.writeFile(path.join(root, `audio/${id}.mp3`), 'voice fixture');
  for (const track of Object.values(catalog)) await fs.writeFile(path.join(root, 'audio', track.file), 'music fixture');
  const cycling = JSON.parse(await fs.readFile(new URL('../../src/cycling-audio-catalog.json', import.meta.url), 'utf8'));
  for (const track of Object.values(cycling)) await fs.writeFile(path.join(root, 'audio', track.file), 'cycling fixture');
  const files = await validateArtifact(root);
  assert.equal(files.filter(file => file.name.endsWith('.mp3')).length, quotes.length + Object.keys(catalog).length + Object.keys(cycling).length);
  await fs.unlink(path.join(root, `audio/${quotes[0].id}.mp3`));
  await assert.rejects(validateArtifact(root), /Missing voice asset/);
}));
for (const directory of ['music', 'audio/nested']) {
  test(`rejects an unapproved music directory ${directory}`, () => fixture(async root => {
    await fs.mkdir(path.join(root, directory));
    await fs.writeFile(path.join(root, directory, 'music-home.mp3'), 'misplaced music');
    await assert.rejects(verify(root), /Unexpected artifact directory/);
  }));
}
test('rejects music stored under assets instead of audio', () => fixture(async root => {
  await fs.rename(path.join(root, 'audio/music-home.mp3'), path.join(root, 'assets/music-home.mp3'));
  await assert.rejects(verify(root), /Unexpected artifact file/);
}));
test('rejects unlisted audio formats instead of ignoring them in the MP3 count', () => fixture(async root => {
  await fs.writeFile(path.join(root, 'audio/extra.ogg'), 'unlisted audio');
  await assert.rejects(verify(root), /Unexpected artifact file/);
}));
test('rejects a catalog filename that escapes or disagrees with its scene', () => fixture(async root => {
  for (const file of ['../music-home.mp3', 'music-park.mp3']) {
    await assert.rejects(validateArtifact(root, { voiceIds: ['fixture'], musicCatalog: { home: { file, duration: 60 } } }), /matching music-\{place\}/);
  }
}));
test('rejects an empty scene catalog or an invalid duration', () => fixture(async root => {
  await assert.rejects(validateArtifact(root, { voiceIds: ['fixture'], musicCatalog: {} }), /non-empty object/);
  await assert.rejects(validateArtifact(root, { voiceIds: ['fixture'], musicCatalog: { home: { file: 'music-home.mp3', duration: 0 } } }), /positive duration/);
}));
for (const name of ['report.json', 'assets/source.js.map', '.env', 'chat.jsonl']) {
  test(`rejects non-runtime output ${name}`, () => fixture(async root => {
    await fs.writeFile(path.join(root, name), '{}');
    await assert.rejects(verify(root), /Unexpected artifact file/);
  }));
}
test('rejects symlinks instead of following them outside the artifact', () => fixture(async root => {
  await fs.symlink('/etc/hostname', path.join(root, 'assets/leak.js'));
  await assert.rejects(verify(root), /Symlinks/);
}));
test('rejects a credential signature without printing its contents', () => fixture(async root => {
  await fs.writeFile(path.join(root, 'assets/secret.js'), ['github', 'pat', 'x'.repeat(30)].join('_'));
  await assert.rejects(verify(root), /Credential signature/);
}));
test('rejects missing or site-root script paths that break project Pages', () => fixture(async root => {
  await fs.writeFile(path.join(root, 'index.html'), '<script src="/assets/index-fixture.js"></script>');
  await assert.rejects(verify(root), /Pages-relative/);
}));

test('requires every catalogued cycling clip', () => fixture(async root => {
  await fs.unlink(path.join(root, 'audio/cycling-fixture-voice.mp3'));
  await assert.rejects(verify(root), /Missing cycling audio/);
}));
test('rejects an unlisted cycling clip even when its prefix is valid', () => fixture(async root => {
  await fs.writeFile(path.join(root, 'audio/cycling-extra.mp3'), 'extra');
  await assert.rejects(verify(root), /Unexpected audio asset/);
}));
test('does not accept a renamed cycling clip with the same MP3 count', () => fixture(async root => {
  await fs.rename(path.join(root, 'audio/cycling-fixture-effect.mp3'), path.join(root, 'audio/cycling-renamed.mp3'));
  await assert.rejects(verify(root), /Missing cycling audio/);
}));
test('validates exact cycling filenames, roles, duplicates and nonempty catalogs', () => fixture(async root => {
  const custom = cyclingCatalog => validateArtifact(root, { voiceIds: ['fixture'], musicCatalog, cyclingCatalog });
  for (const file of ['../cycling-voice.mp3', 'voice.mp3', 'cycling-voice.ogg']) {
    await assert.rejects(custom({ voice: { file, role: 'voice' } }), /Cycling audio needs/);
  }
  await assert.rejects(custom({ voice: { file: 'cycling-fixture-voice.mp3', role: 'music' } }), /voice or effect/);
  await assert.rejects(custom({ a: cyclingCatalog.fixtureVoice, b: cyclingCatalog.fixtureVoice }), /cannot repeat filenames/);
  await assert.rejects(custom({}), /non-empty object/);
}));
