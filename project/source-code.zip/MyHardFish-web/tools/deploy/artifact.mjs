import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const allowed = /^(?:index\.html|THIRD_PARTY_NOTICES\.txt|assets\/[a-zA-Z0-9][a-zA-Z0-9._-]*\.(?:js|css|png|jpg|jpeg|webp|svg|woff2?)|audio\/[a-z0-9_-]+\.mp3)$/;
const credential = /github_pat_[A-Za-z0-9_]{25,}|gh[pousr]_[A-Za-z0-9_]{25,}|-----BEGIN (?:OPENSSH |RSA |EC )?PRIVATE KEY-----/;
export const sha256 = data => createHash('sha256').update(data).digest('hex');

async function expectedVoices() {
  const quotes = JSON.parse(await fs.readFile(new URL('../../src/quotes.json', import.meta.url), 'utf8'));
  if (!Array.isArray(quotes) || quotes.length !== 76) throw new Error('Expected 76 curated voice definitions');
  return quotes.map(quote => quote.id);
}

async function expectedMusic(catalog) {
  catalog ??= JSON.parse(await fs.readFile(new URL('../../src/music-catalog.json', import.meta.url), 'utf8'));
  if (!catalog || typeof catalog !== 'object' || Array.isArray(catalog) || !Object.keys(catalog).length)
    throw new Error('Scene music catalog must be a non-empty object');
  return Object.entries(catalog).map(([place, track]) => {
    if (!/^[a-z][a-z0-9_-]*$/.test(place) || !track || typeof track !== 'object'
        || track.file !== `music-${place}.mp3` || !Number.isFinite(track.duration) || track.duration <= 0)
      throw new Error('Scene music needs a matching music-{place}.mp3 filename and positive duration');
    return `audio/${track.file}`;
  });
}

async function expectedCycling(catalog) {
  catalog ??= JSON.parse(await fs.readFile(new URL('../../src/cycling-audio-catalog.json', import.meta.url), 'utf8'));
  if (!catalog || typeof catalog !== 'object' || Array.isArray(catalog) || !Object.keys(catalog).length)
    throw new Error('Cycling audio catalog must be a non-empty object');
  const names = Object.values(catalog).map(track => {
    if (!track || typeof track !== 'object' || !/^cycling-[a-z0-9-]+\.mp3$/.test(track.file)
        || !['voice', 'effect'].includes(track.role))
      throw new Error('Cycling audio needs a cycling-*.mp3 filename and voice or effect role');
    return `audio/${track.file}`;
  });
  if (new Set(names).size !== names.length) throw new Error('Cycling audio catalog cannot repeat filenames');
  return names;
}

// The deployment carries runtime files only, never a checkout or test output.
export async function validateArtifact(directory, { voiceIds, musicCatalog, cyclingCatalog } = {}) {
  voiceIds ??= await expectedVoices();
  if (!Array.isArray(voiceIds) || !voiceIds.length || new Set(voiceIds).size !== voiceIds.length
      || voiceIds.some(id => typeof id !== 'string' || !/^[a-z0-9_-]+$/.test(id) || id === 'bgm' || id.startsWith('music-') || id.startsWith('cycling-')))
    throw new Error('Voice definitions must contain unique valid IDs, distinct from scene and cycling audio');
  const musicFiles = await expectedMusic(musicCatalog);
  const cyclingFiles = await expectedCycling(cyclingCatalog);
  const root = path.resolve(directory);
  const files = [];
  async function visit(folder, prefix = '') {
    if (!(await fs.lstat(folder)).isDirectory()) throw new Error('Artifact must contain real directories');
    for (const entry of await fs.readdir(folder, { withFileTypes: true })) {
      const name = prefix + entry.name;
      const filename = path.join(folder, entry.name);
      if (entry.isSymbolicLink()) throw new Error(`Symlinks are not publishable: ${name}`);
      if (entry.isDirectory()) {
        if (prefix || !['assets', 'audio'].includes(entry.name)) throw new Error(`Unexpected artifact directory: ${name}`);
        await visit(filename, name + '/');
      } else {
        if (!entry.isFile() || !allowed.test(name)) throw new Error(`Unexpected artifact file: ${name}`);
        const data = await fs.readFile(filename);
        if (!data.length) throw new Error(`Empty runtime asset: ${name}`);
        if (/\.(?:html|txt|js|css|svg)$/.test(name) && credential.test(data.toString('utf8')))
          throw new Error(`Credential signature in artifact: ${name}`);
        files.push({ name, data, bytes: data.length, sha256: sha256(data) });
      }
    }
  }
  await visit(root);
  const names = new Set(files.map(file => file.name));
  if (!names.has('index.html') || !names.has('THIRD_PARTY_NOTICES.txt')) throw new Error('Missing entry or component licenses');
  for (const id of voiceIds) {
    if (!names.has(`audio/${id}.mp3`)) throw new Error(`Missing voice asset: audio/${id}.mp3`);
  }
  for (const name of musicFiles) {
    if (!names.has(name)) throw new Error(`Missing scene music: ${name}`);
  }
  for (const name of cyclingFiles) {
    if (!names.has(name)) throw new Error(`Missing cycling audio: ${name}`);
  }
  const expectedAudio = new Set([...voiceIds.map(id => `audio/${id}.mp3`), ...musicFiles, ...cyclingFiles]);
  if (files.some(file => file.name.endsWith('.mp3') && !expectedAudio.has(file.name)))
    throw new Error('Unexpected audio asset; only curated voices, catalogued scene music and catalogued cycling audio are publishable');
  const html = files.find(file => file.name === 'index.html').data.toString('utf8');
  const scripts = [...html.matchAll(/<script\b[^>]*\bsrc=["']([^"']+)["']/g)].map(match => match[1]);
  if (!scripts.length || scripts.some(src => !src.startsWith('./assets/') || !names.has(src.slice(2))))
    throw new Error('Entry scripts must exist and use the Pages-relative assets path');
  return files.sort((a, b) => a.name.localeCompare(b.name));
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const files = await validateArtifact(process.argv[2] || 'dist');
  const music = files.filter(file => file.name.startsWith('audio/music-')).length;
  const cycling = files.filter(file => file.name.startsWith('audio/cycling-')).length;
  const voices = files.filter(file => file.name.endsWith('.mp3')).length - music - cycling;
  console.log(`Validated ${files.length} runtime files, ${voices} voices and ${music} scene music files and ${cycling} cycling audio files; source, reports and credential signatures excluded.`);
}
