import { chromium, expect } from '@playwright/test';
import { existsSync } from 'node:fs';
import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { unzipSync, strFromU8 } from 'fflate';

// Run after the final build. This deliberately serves files without Vite or a SPA fallback.
const project = fileURLToPath(new URL('../../', import.meta.url));
const output = path.resolve(project, '../research/expansion-v3');
const dist = path.join(project, 'dist');
await fs.mkdir(output, { recursive: true });
if (!existsSync(path.join(dist, 'index.html'))) throw Error('先生成最终 dist，再运行 production.mjs');
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.mp3': 'audio/mpeg', '.woff2': 'font/woff2' };
let server;
let baseURL = process.env.QA_BASE_URL;
if (!baseURL) {
  server = http.createServer(async (req, res) => {
    try {
      const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
      if (!pathname.startsWith('/dist/')) { res.writeHead(404).end(); return; }
      const relative = pathname.slice('/dist/'.length) || 'index.html';
      const filename = path.resolve(dist, relative);
      if (!filename.startsWith(dist + path.sep)) { res.writeHead(403).end(); return; }
      const bytes = await fs.readFile(filename);
      res.writeHead(200, { 'Content-Type': mime[path.extname(filename)] || 'application/octet-stream', 'Content-Length': bytes.length });
      res.end(req.method === 'HEAD' ? undefined : bytes);
    } catch { res.writeHead(404).end(); }
  });
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  baseURL = `http://127.0.0.1:${server.address().port}/dist/`;
}
const base = new URL(baseURL);
if (base.pathname !== '/dist/') throw Error('QA_BASE_URL 必须指向普通静态服务的 /dist/ 子路径');
const report = { checkedAt: new Date().toISOString(), baseURL, server: server ? 'plain Node HTTP static files' : 'externally supplied static server', checks: [] };
let browser;
const menu = async (page, name) => {
  await page.getByRole('button', { name: '打开生活菜单', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name, exact: true }).click();
};
const close = (page) => page.getByRole('button', { name: '关闭窗口', exact: true }).click();
async function layout(page) {
  const measured = await page.evaluate(() => {
    const rect = document.querySelector('[data-testid="scene"] canvas').getBoundingClientRect();
    return { width: innerWidth, height: innerHeight, scrollWidth: document.documentElement.scrollWidth, canvas: { x: rect.x, y: rect.y, width: rect.width, height: rect.height } };
  });
  expect(measured.scrollWidth).toBeLessThanOrEqual(measured.width);
  expect(measured.canvas.width * measured.canvas.height / (measured.width * measured.height)).toBeGreaterThanOrEqual(0.98);
  return measured;
}
try {
  browser = await chromium.launch({ executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath(), args: ['--no-sandbox', '--enable-unsafe-swiftshader'] });
  for (const [name, viewport] of [['desktop', { width: 1440, height: 1000 }], ['mobile', { width: 390, height: 844 }], ['narrow', { width: 320, height: 740 }]]) {
    console.log(`Production check: ${name} ${viewport.width}×${viewport.height}`);
    const context = await browser.newContext({ viewport, deviceScaleFactor: 1, hasTouch: name !== 'desktop', isMobile: name !== 'desktop' });
    const page = await context.newPage();
    page.setDefaultTimeout(20000);
    const pendingRequests = new Set();
    const result = { name, viewport, errors: [], external: [], outsideSubpath: [], failedRequests: [], badResponses: [], requestedURLs: [], result: 'pending' };
    page.on('pageerror', (e) => result.errors.push(e.message));
    page.on('console', (m) => { if (m.type() === 'error') result.errors.push(m.text()); });
    page.on('request', (r) => {
      if (/^(data|blob):/.test(r.url())) return;
      pendingRequests.add(r);
      const url = new URL(r.url());
      result.requestedURLs.push(r.url());
      if (url.origin !== base.origin) result.external.push(r.url());
      else if (!url.pathname.startsWith(base.pathname)) result.outsideSubpath.push(r.url());
    });
    page.on('requestfinished', (r) => pendingRequests.delete(r));
    page.on('requestfailed', (r) => { pendingRequests.delete(r); result.failedRequests.push({ url: r.url(), error: r.failure()?.errorText }); });
    page.on('response', (r) => { if (r.status() >= 400) result.badResponses.push({ status: r.status(), url: r.url() }); });
    // Observe native playback, including detached new Audio() elements, without mocking it.
    await page.addInitScript(() => {
      window.__qaAudio = [];
      const nativePlay = HTMLMediaElement.prototype.play;
      HTMLMediaElement.prototype.play = function (...args) {
        const record = { src: this.currentSrc || this.src, playing: false, duration: null };
        window.__qaAudio.push(record);
        this.addEventListener('playing', () => { record.playing = true; record.duration = this.duration; }, { once: true });
        return nativePlay.apply(this, args);
      };
    });
    try {
      const response = await page.goto(baseURL, { waitUntil: 'domcontentloaded' });
      expect(response?.status()).toBe(200);
      const scene = page.getByTestId('scene');
      await expect(scene).toHaveAttribute('data-ready', 'true', { timeout: 60000 });
      await expect(scene).toHaveAttribute('data-position', /^-?[\d.]+,-?[\d.]+$/);
      await expect.poll(() => pendingRequests.size, { timeout: 20000 }).toBe(0);
      result.layout = await layout(page);
      await page.screenshot({ path: path.join(output, `final-${name}.png`), animations: 'disabled' });

      const photoPromise = page.waitForEvent('download');
      await page.getByRole('button', { name: '拍张难鱼的照片', exact: true }).click();
      const photo = await photoPromise;
      expect(await photo.failure()).toBeNull();
      const photoBytes = await fs.readFile(await photo.path());
      expect(photoBytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))).toBe(true);
      expect(photoBytes.length).toBeGreaterThan(10000);
      result.photo = { filename: photo.suggestedFilename(), bytes: photoBytes.length, width: photoBytes.readUInt32BE(16), height: photoBytes.readUInt32BE(20) };
      expect(result.photo.width).toBeGreaterThan(100);
      expect(result.photo.height).toBeGreaterThan(100);
      await photo.saveAs(path.join(output, `production-photo-${name}.png`));

      await page.getByRole('button', { name: '重播这句语音', exact: true }).click();
      await expect.poll(() => page.evaluate(() => window.__qaAudio.some((a) => a.src.endsWith('/audio/greeting.mp3') && a.playing && Number.isFinite(a.duration) && a.duration > 0)), { timeout: 20000 }).toBe(true);
      result.audio = await page.evaluate(() => window.__qaAudio);
      await menu(page, '设置');
      await page.getByRole('checkbox', { name: /难鱼开麦/ }).uncheck();
      await close(page);

      await page.getByRole('button', { name: '打开村民手帐', exact: true }).click();
      await expect(page.getByRole('dialog')).toContainText('把开村日写进日历');
      result.notebookLayout = await layout(page);
      await page.screenshot({ path: path.join(output, `notebook-${name}.png`), animations: 'disabled' });
      await close(page);
      await page.getByRole('button', { name: '打开地图', exact: true }).click();
      await expect(page.locator('.atlas-pin')).toHaveCount(9);
      await page.screenshot({ path: path.join(output, `atlas-${name}.png`), animations: 'disabled' });
      await close(page);
      if (name !== 'desktop') {
        const stick = page.getByRole('button', { name: '拖动摇杆移动难鱼', exact: true });
        await expect(stick).toBeVisible();
        const position = await scene.getAttribute('data-position');
        const box = await stick.boundingBox();
        await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
        await page.mouse.down();
        await page.mouse.move(box.x + box.width / 2 + 24, box.y + box.height / 2);
        await expect(scene).not.toHaveAttribute('data-position', position);
        await page.mouse.up();
        result.joystick = 'pointer movement changed actual world position';
      }
      if (name === 'mobile') {
        // Walk with the visible stick to the home's physical village doorway.
        // Position is observed only; all movement and travel use public controls.
        const stick = page.getByRole('button', { name: '拖动摇杆移动难鱼', exact: true });
        const box = await stick.boundingBox();
        const center = { x: box.x + box.width / 2, y: box.y + box.height / 2 };
        const [tx, tz] = [0.4, 6];
        await page.mouse.move(center.x, center.y); await page.mouse.down();
        try {
          await expect.poll(async () => {
            const [x,z] = (await scene.getAttribute('data-position')).split(',').map(Number);
            const dx=tx-x,dz=tz-z,distance=Math.hypot(dx,dz);
            if(distance < 0.8) return true;
            // Home camera offset (6.4, 6.7, 10.9): camera-relative ground basis.
            const basis=Math.hypot(6.4,10.9),jx=(dx*10.9-dz*6.4)/basis,jy=(dx*6.4+dz*10.9)/basis;
            await page.mouse.move(center.x+26*jx/distance,center.y+26*jy/distance);
            return false;
          },{timeout:30000,intervals:[250,400,500]}).toBe(true);
        } finally { await page.mouse.up(); }
        await page.getByRole('button', { name: /互动.*前往老母猪村/ }).click();
        await expect(scene).toHaveAttribute('data-place','village');
        const villageEntry=(await scene.getAttribute('data-position')).split(',').map(Number);
        expect(Math.hypot(villageEntry[0]+28.5,villageEntry[1]-14)).toBeLessThan(0.8);
        await page.getByRole('button', { name: /互动.*前往难鱼的家/ }).click();
        await expect(scene).toHaveAttribute('data-place','home');
        const homeEntry=(await scene.getAttribute('data-position')).split(',').map(Number);
        expect(Math.hypot(homeEntry[0]-.4,homeEntry[1]-6)).toBeLessThan(.8);
        result.physicalTravel={route:['home','village','home'],villageEntry,homeEntry,method:'visible joystick and nearby interaction button'};
      }
      result.scenes = [];
      for (const [placeName, id] of [['厨房', 'kitchen'], ['公园', 'park'], ['便利店', 'shop'], ['教室', 'school'], ['村中心', 'village'], ['联机工坊', 'workshop'], ['瓶信河岸', 'river'], ['夜市', 'market'], ['小窝', 'home']]) {
        await page.getByRole('button', { name: '打开地图', exact: true }).click();
        await page.getByRole('dialog').getByRole('button', { name: placeName, exact: true }).click();
        await expect(scene).toHaveAttribute('data-place', id);
        result.scenes.push(id);
      }
      await menu(page, '衣柜');
      await expect(page.getByRole('dialog')).toContainText('原装难鱼');
      await page.screenshot({ path: path.join(output, `final-closet-${name}.png`), animations: 'disabled' });
      await close(page);
      await page.getByRole('button', { name: /^聊聊天/ }).click();
      await page.getByRole('textbox', { name: '给难鱼发消息' }).fill('聊聊雨夜');
      await page.getByRole('textbox', { name: '给难鱼发消息' }).press('Enter');
      await expect(page.getByRole('log')).toContainText('心意能收到');
      await close(page);
      await page.getByRole('button', { name: '给她投喂', exact: true }).click();
      await expect(page.getByRole('button', { name: '投喂热乎小包子', exact: true })).toBeVisible();
      await close(page);

      await menu(page, '存档');
      const zipPromise = page.waitForEvent('download');
      await page.getByRole('button', { name: '导出 ZIP', exact: true }).click();
      const zip = await zipPromise;
      expect(await zip.failure()).toBeNull();
      const bytes = await fs.readFile(await zip.path());
      const files = unzipSync(bytes);
      const manifest = JSON.parse(strFromU8(files['manifest.json']));
      expect(manifest).toMatchObject({ game: 'my-groupmate-hardfish', version: 1 });
      const state = JSON.parse(strFromU8(files['save.json']));
      expect(state.messages.some((m) => m.text === '聊聊雨夜')).toBe(true);
      await page.getByLabel('选择存档 ZIP').setInputFiles({ name: 'round-trip.zip', mimeType: 'application/zip', buffer: bytes });
      await expect(page.getByRole('heading', { name: '已检查这份存档' })).toBeVisible();
      result.zip = { bytes: bytes.length, filename: zip.suggestedFilename(), files: Object.keys(files), importPreviewValidated: true };
      await page.getByRole('button', { name: '取消导入', exact: true }).click();
      await close(page);
      await menu(page, '一起玩吧');
      await page.getByRole('button', { name: /火候刚刚好/ }).click();
      await expect(page.getByRole('button', { name: '和难鱼一起开始', exact: true })).toBeVisible();
      await page.screenshot({ path: path.join(output, name === 'narrow' ? 'final-320.png' : `final-game-${name}.png`), animations: 'disabled' });
      result.dialogLayout = await layout(page);
      await expect.poll(() => pendingRequests.size, { timeout: 20000 }).toBe(0);
      expect(result.errors).toEqual([]);
      expect(result.external).toEqual([]);
      expect(result.outsideSubpath).toEqual([]);
      expect(result.failedRequests).toEqual([]);
      expect(result.badResponses).toEqual([]);
      result.result = 'pass';
    } catch (error) {
      result.result = 'fail';
      result.failure = error.stack || String(error);
      process.exitCode = 1;
      await page.screenshot({ path: path.join(output, `production-failure-${name}.png`), animations: 'disabled' }).catch(() => {});
    } finally {
      result.requestedURLs = [...new Set(result.requestedURLs)];
      report.checks.push(result);
      await context.close();
    }
  }
} finally {
  await browser?.close();
  if (server) await new Promise((resolve) => server.close(resolve));
  await fs.writeFile(path.join(output, 'production-check.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
}
