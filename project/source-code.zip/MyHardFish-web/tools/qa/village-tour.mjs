import { chromium, expect } from '@playwright/test';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';

// Visual inspection of the built game; never mutates shipped assets.
const project = fileURLToPath(new URL('../../', import.meta.url));
const output = path.resolve(project, '../research/expansion-v3');
await fs.mkdir(output, { recursive: true });
const bundled = await build({ entryPoints: [path.join(project, 'src/engine.ts')], bundle: true, write: false, platform: 'node', format: 'esm' });
const { newGame } = await import(`data:text/javascript;base64,${Buffer.from(bundled.outputFiles[0].text).toString('base64')}`);
const fresh = newGame(); fresh.settings.voice = false;
const complete = JSON.parse(await fs.readFile(path.join(output, 'completed-campaign-fixture.json'), 'utf8'));
complete.settings.voice = false; complete.settings.lowQuality = false;
const baseURL = process.env.QA_BASE_URL || 'http://127.0.0.1:5184/dist/';
const report = { checkedAt: new Date().toISOString(), baseURL, quality: 'default shadows and native viewport resolution', fixtureScope: 'Fresh game with voice disabled. Separate late-game views use an engine-generated 10-quest fixture, not a claim of browser campaign completion.', views: [], errors: [] };
const browser = await chromium.launch({ executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath(), args: ['--no-sandbox', '--enable-unsafe-swiftshader'] });
const areas = [['小窝','home'],['厨房','kitchen'],['公园','park'],['便利店','shop'],['教室','school'],['村中心','village'],['联机工坊','workshop'],['瓶信河岸','river'],['夜市','market']];
const frame = page => page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
try {
  for (const [name, viewport] of [['desktop',{width:1440,height:1000}],['mobile',{width:390,height:844}]]) {
    const context = await browser.newContext({viewport,deviceScaleFactor:1,hasTouch:name==='mobile',isMobile:name==='mobile'});
    await context.addInitScript(state => {if (!localStorage.getItem('hardfish.save.v1')) localStorage.setItem('hardfish.save.v1', JSON.stringify(state));}, fresh);
    const page = await context.newPage(); page.setDefaultTimeout(30000);
    page.on('pageerror', e => report.errors.push(e.message));
    page.on('console', m => {if(m.type()==='error')report.errors.push(m.text());});
    await page.goto(baseURL,{waitUntil:'domcontentloaded'});
    const scene = page.getByTestId('scene');
    await expect(scene).toHaveAttribute('data-ready','true',{timeout:60000});
    if(await page.getByRole('button',{name:'收起新手提示',exact:true}).isVisible()) await page.getByRole('button',{name:'收起新手提示',exact:true}).click();
    for(const [label,id] of areas) {
      console.log(`Visual tour ${name}: ${id}`);
      await page.getByRole('button',{name:'打开地图',exact:true}).click();
      await page.getByRole('dialog').getByRole('button',{name:label,exact:true}).click();
      await expect(scene).toHaveAttribute('data-place',id); await frame(page);
      await expect(page.locator('.toast')).toBeHidden({timeout:15000});
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth);
      expect(overflow).toBe(false);
      const filename = `scene-${id}-${name}.png`;
      await page.screenshot({path:path.join(output,filename),animations:'disabled'});
      report.views.push({name,id,mode:'follow',file:filename,overflow});
      if(name==='desktop' && ['village','workshop','river','market'].includes(id)) {
        await page.getByRole('button',{name:'俯瞰这片区域',exact:true}).click();
        await expect(scene).toHaveAttribute('data-camera-mode','overview'); await frame(page);
        const overviewFile=`overview-${id}.png`;
        await page.screenshot({path:path.join(output,overviewFile),animations:'disabled'});
        report.views.push({name,id,mode:'overview',file:overviewFile});
        await page.getByRole('button',{name:'跟随难鱼',exact:true}).click(); await frame(page);
      }
    }
    await context.close();
  }
  // Finished campaign has visible shared decorations; UI state is read, not fabricated stage-by-stage.
  const context=await browser.newContext({viewport:{width:1440,height:1000},deviceScaleFactor:1});
  await context.addInitScript(state => localStorage.setItem('hardfish.save.v1',JSON.stringify(state)),complete);
  const page=await context.newPage(); page.setDefaultTimeout(30000);
  page.on('pageerror',e=>report.errors.push(e.message)); page.on('console',m=>{if(m.type()==='error')report.errors.push(m.text());});
  await page.goto(baseURL,{waitUntil:'domcontentloaded'});
  await expect(page.getByTestId('scene')).toHaveAttribute('data-ready','true',{timeout:60000});
  for(const [label,id] of areas.slice(5)) {
    console.log(`Visual tour completed: ${id}`);
    await page.getByRole('button',{name:'打开地图',exact:true}).click();
    await page.getByRole('dialog').getByRole('button',{name:label,exact:true}).click(); await frame(page);
    await expect(page.locator('.toast')).toBeHidden({timeout:15000});
    const filename=`completed-${id}.png`;
    await page.screenshot({path:path.join(output,filename),animations:'disabled'});
    report.views.push({name:'completed-fixture',id,mode:'follow',file:filename});
  }
  await page.getByRole('button',{name:'打开村民手帐',exact:true}).click();
  await expect(page.getByRole('dialog')).toContainText('10 / 10');
  await page.screenshot({path:path.join(output,'completed-notebook.png'),animations:'disabled'});
  await context.close();
  expect(report.errors).toEqual([]); report.result='pass';
} catch(error) {
  report.result='fail';report.failure=error.stack||String(error);process.exitCode=1;
} finally {
  await browser.close();await fs.writeFile(path.join(output,'village-tour-check.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
}
