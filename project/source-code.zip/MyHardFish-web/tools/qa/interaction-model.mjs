import { chromium, expect } from '@playwright/test';
import { build } from 'esbuild';
import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
const project = fileURLToPath(new URL('../../', import.meta.url));
const output = path.resolve(project, process.env.QA_OUTPUT_DIR || '../research/interaction-v7/model');
await fs.mkdir(output, { recursive: true });
const bundle = await build({ entryPoints: [path.join(project, 'src/character.ts')], bundle: true, write: false, metafile: true, format: 'esm', platform: 'browser', external: ['three', 'three/*'], define: { 'import.meta.env.BASE_URL': '"/"' } });
const fingerprint = async () => {
  const files = {};
  for (const input of [...Object.keys(bundle.metafile.inputs), fileURLToPath(import.meta.url)]) {
    const absolute = path.resolve(input), bytes = await fs.readFile(absolute);
    files[path.relative(project, absolute)] = { bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') };
  }
  return files;
};
const testedSource = await fingerprint();
const viewer = `
import * as THREE from 'three';
import {NanyuCharacter} from '/model.js';
const renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});renderer.setSize(760,900);renderer.shadowMap.enabled=true;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;
document.body.appendChild(renderer.domElement);
const scene=new THREE.Scene();scene.background=new THREE.Color('#dce3dc');scene.add(new THREE.HemisphereLight('#fff9eb','#7e9175',2));
const light=new THREE.DirectionalLight('#fff2dc',3.4);light.position.set(-4,7,6);light.castShadow=true;scene.add(light);
const floor=new THREE.Mesh(new THREE.PlaneGeometry(100,100),new THREE.MeshStandardMaterial({color:'#bdc8b6',roughness:.9}));floor.rotation.x=-Math.PI/2;floor.receiveShadow=true;scene.add(floor);
const seat=new THREE.Mesh(new THREE.BoxGeometry(1.2,.12,1.1),new THREE.MeshStandardMaterial({color:'#a08a69'}));seat.position.set(0,1.05,-.16);seat.visible=false;scene.add(seat);
const camera=new THREE.PerspectiveCamera(36,760/900,.1,40);camera.position.set(4.7,3.7,7.6);camera.lookAt(0,1.9,.1);
const model=new NanyuCharacter();
const render=()=>{scene.updateMatrixWorld(true);renderer.render(scene,camera);};
seat.visible=true;render();const baseline={...renderer.info.memory};seat.visible=false;scene.add(model.root);render();
window.qa={
  pose(context){model.setActivity(context);seat.visible=!!context.seated||context.kind==='sit';for(let i=0;i<120;i++)model.update(i/60,1/60,'idle',false);render();return {snapshot:model.getActivitySnapshot(),memory:{...renderer.info.memory},render:{...renderer.info.render}};},
  sample(){const results=[];for(let i=0;i<180;i++){model.update(i/60,1/60,'idle',false);const s=model.getActivitySnapshot();results.push({distance:s.gripToMouth,handDistance:s.handToMouth,food:s.foodGrip,mouth:s.mouth});}render();return results;},
  quality(low){model.setQuality(low);model.update(0,1/60,'idle',false);render();return model.getActivitySnapshot();},
  cancel(){model.setActivity(null);for(let i=0;i<120;i++)model.update(i/60,1/60,'idle',true);seat.visible=false;render();return model.getActivitySnapshot();},
  dispose(){scene.remove(model.root);model.dispose();render();return {memory:{...renderer.info.memory},baseline,lost:renderer.getContext().isContextLost(),error:renderer.getContext().getError()};}
};`;
const html = '<!doctype html><meta charset="utf-8"><link rel="icon" href="data:,"><style>body{margin:0}canvas{display:block}</style><script type="importmap">{"imports":{"three":"/vendor/build/three.module.js","three/addons/":"/vendor/examples/jsm/","three/":"/vendor/"}}</script><script type="module" src="/viewer.js"></script>';
const server = http.createServer(async (req, res) => {
  try {
    const route = new URL(req.url, 'http://localhost').pathname;
    if (route === '/') { res.writeHead(200, { 'content-type': 'text/html' }); res.end(html); return; }
    if (route === '/model.js' || route === '/viewer.js') { res.writeHead(200, { 'content-type': 'text/javascript' }); res.end(route === '/model.js' ? bundle.outputFiles[0].text : viewer); return; }
    const base = route.startsWith('/vendor/') ? path.join(project, 'node_modules/three') : path.join(project, 'public');
    const relative = route.startsWith('/vendor/') ? route.slice(8) : route.slice(1);
    const target = path.resolve(base, relative); if (!target.startsWith(base + path.sep)) throw Error('Bad path');
    const bytes = await fs.readFile(target); res.writeHead(200, { 'content-type': target.endsWith('.png') ? 'image/png' : 'text/javascript' }); res.end(bytes);
  } catch { res.writeHead(404).end(); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const browser = await chromium.launch({ executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath(), args: ['--no-sandbox', '--enable-unsafe-swiftshader'] });
const page = await browser.newPage({ viewport: { width: 760, height: 900 } });
const report = { checkedAt: new Date().toISOString(), scope: 'Isolated real WebGL character; fixed studio, actual cached props and geometry. This is not physical device FPS or a full world test.', testedSource, errors: [], poses: [], foods: [] };
page.on('pageerror', error => report.errors.push(error.message));
page.on('console', message => { if (message.type() === 'error') report.errors.push(message.text()); });
try {
  await page.goto(`http://127.0.0.1:${server.address().port}/`); await page.waitForFunction(() => !!window.qa, null, { timeout: 60000 });
  const props = { sit: 'none', read: 'book', cook: 'spatula', water: 'wateringCan', shop: 'bag', play: 'ball', write: 'pencil', inspect: 'magnifier', talk: 'none', celebrate: 'lantern', eat: 'food' };
  for (const [kind, prop] of Object.entries(props)) {
    const result = await page.evaluate(context => qa.pose(context), { kind, prop, seated: kind === 'sit' || kind === 'read', seatHeight: 1.11, surfaceHeight: 1.65, target: [0, 1.65, 1.1] });
    expect(result.snapshot.kind).toBe(kind);
    if (prop !== 'none') expect(result.snapshot.visibleProps.length).toBeGreaterThan(0);
    if (kind === 'sit' || kind === 'read') expect(Math.abs(result.snapshot.seatContact[1] - 1.11)).toBeLessThan(.02);
    await page.screenshot({ path: path.join(output, `${kind}.png`) }); report.poses.push({ kind, ...result });
  }
  for (const food of ['bun', 'milk', 'peach', 'rice', 'coffee']) {
    const context = { kind: 'eat', prop: food === 'milk' || food === 'coffee' ? 'cup' : 'food', food };
    await page.evaluate(context => qa.pose(context), context);
    const samples = await page.evaluate(() => qa.sample());
    const minimum = Math.min(...samples.map(sample => sample.distance)); expect(minimum).toBeLessThan(.42);
    await page.screenshot({ path: path.join(output, `eat-${food}.png`) }); report.foods.push({ food, minimum });
  }
  await page.evaluate(() => qa.pose({ kind: 'read', prop: 'book', seated: true, seatHeight: 1.11 }));
  for (const low of [true, false]) { const s = await page.evaluate(low => qa.quality(low), low); expect(s.kind).toBe('read'); expect(s.visibleProps.length).toBeGreaterThan(0); }
  const cancelled = await page.evaluate(() => qa.cancel()); expect(cancelled.kind).toBeNull(); expect(cancelled.visibleProps).toEqual([]);
  report.disposal = await page.evaluate(() => qa.dispose()); expect(report.disposal.error).toBe(0); expect(report.disposal.lost).toBe(false);
  expect(report.disposal.memory.geometries).toBe(report.disposal.baseline.geometries);
  expect(report.disposal.memory.textures).toBe(report.disposal.baseline.textures);
  expect(report.errors).toEqual([]); report.sourceUnchanged = JSON.stringify(await fingerprint()) === JSON.stringify(testedSource); expect(report.sourceUnchanged).toBe(true); report.status = 'passed';
} catch (error) { report.status = 'failed'; report.failure = error.stack || String(error); process.exitCode = 1; }
finally { await browser.close(); await new Promise(resolve => server.close(resolve)); await fs.writeFile(path.join(output, 'model-webgl-check.json'), JSON.stringify(report, null, 2)); console.log(JSON.stringify({ status: report.status, poses: report.poses.length, foods: report.foods, failure: report.failure, errors: report.errors })); }
