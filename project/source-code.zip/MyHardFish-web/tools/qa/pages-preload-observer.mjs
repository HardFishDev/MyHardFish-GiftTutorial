import fs from 'node:fs/promises';
import path from 'node:path';

// Match resources.ts's public glob, rather than treating every asset request as
// a preload attempt (images and HTMLAudioElement also request these URLs).
export async function localPreloadManifest(project, base) {
  const files = [];
  async function visit(directory, prefix, extension) {
    for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
      const relative = `${prefix}/${entry.name}`;
      if (entry.isDirectory()) await visit(path.join(directory, entry.name), relative, extension);
      else if (entry.isFile() && extension.test(entry.name)) files.push(relative);
      else if (entry.isSymbolicLink()) throw new Error(`Unexpected public symlink: ${relative}`);
    }
  }
  await visit(path.join(project, 'public/assets'), 'assets', /\.(?:png|jpg|jpeg|webp|gif|svg|avif)$/);
  await visit(path.join(project, 'public/audio'), 'audio', /\.(?:mp3|ogg|wav|m4a)$/);
  if (!files.length) throw new Error('Local preload manifest is empty.');
  return files.filter(file => !file.startsWith('audio/cycling-')).sort().map(file => ({ path: file, url: new URL(file, base).href }));
}

export async function requireFreshReport(filename) {
  try { await fs.access(filename); }
  catch (error) { if (error.code === 'ENOENT') return; throw error; }
  throw new Error(`Refusing to overwrite an earlier QA report: ${filename}. Set a fresh QA_OUTPUT_DIR.`);
}

// Conservative transport-only classification. HTTP failures, blocked requests,
// JS exceptions and unrecognized errors never become successful attempts.
const transportError = /^net::ERR_(?:ABORTED|FAILED|TIMED_OUT|CONNECTION_CLOSED|CONNECTION_RESET|CONNECTION_REFUSED|CONNECTION_ABORTED|NETWORK_CHANGED|NAME_NOT_RESOLVED|INTERNET_DISCONNECTED|EMPTY_RESPONSE|HTTP2_PROTOCOL_ERROR|QUIC_PROTOCOL_ERROR|CONTENT_LENGTH_MISMATCH|INCOMPLETE_CHUNKED_ENCODING)$/;
const succeeded = attempt => attempt?.outcome === 'finished' && attempt.status >= 200 && attempt.status < 300;

export async function observePreloads(page, result, {
  base, manifest, isClosing = () => false, mixedLegacyErrors = false, now = Date.now,
}) {
  const started = now(), urls = new Set(manifest.map(item => item.url));
  const requests = new Map(), pending = new Set(), phases = [];
  let current = null, serial = 0;
  for (const field of ['errors', 'pageErrors', 'consoleErrors', 'consoleEvents', 'failedRequests',
    'cleanupRequests', 'badResponses', 'foreignRequests', 'outsideSubpath', 'unexpectedPreloadRequests']) result[field] ??= [];
  const elapsed = () => now() - started;

  // Observation only: do not intercept fetch or alter loading controls.
  await page.addInitScript(() => {
    window.__hardfishPreloadControlClicks = [];
    document.addEventListener('click', event => {
      const button = event.target instanceof Element
        ? event.target.closest('.resource-loading__retry,.resource-loading__continue') : null;
      if (button) window.__hardfishPreloadControlClicks.push({ label: button.textContent, at: Date.now() });
    }, true);
  });
  page.on('pageerror', error => {
    result.errors.push(error.message);
    result.pageErrors.push({ message: error.message, elapsedMs: elapsed() });
  });
  page.on('console', message => {
    if (message.type() !== 'error') return;
    result.consoleErrors.push(message.text());
    if (mixedLegacyErrors) result.errors.push(message.text());
    result.consoleEvents.push({ text: message.text(), location: message.location(), phase: current?.name ?? null, elapsedMs: elapsed() });
  });
  page.on('request', request => {
    if (!/^https?:/.test(request.url())) return;
    pending.add(request);
    const target = new URL(request.url());
    if (target.origin !== base.origin) result.foreignRequests.push(request.url());
    else if (!target.pathname.startsWith(base.pathname)) result.outsideSubpath.push(request.url());
    const attempt = {
      requestId: ++serial, url: request.url(), method: request.method(), type: request.resourceType(),
      phase: current?.name ?? null, startedMs: elapsed(), endedMs: null, status: null, outcome: 'pending', error: null,
      preload: !!current && request.method() === 'GET' && request.resourceType() === 'fetch' && urls.has(request.url()),
    };
    requests.set(request, attempt);
    if (current && attempt.type === 'fetch' && !attempt.preload)
      result.unexpectedPreloadRequests.push({ ...attempt });
  });
  page.on('response', response => {
    const attempt = requests.get(response.request());
    if (attempt) attempt.status = response.status();
    if (response.status() >= 400) result.badResponses.push({ url: response.url(), status: response.status(), requestId: attempt?.requestId, elapsedMs: elapsed() });
  });
  page.on('requestfinished', request => {
    pending.delete(request);
    const attempt = requests.get(request);
    if (attempt) { attempt.outcome = 'finished'; attempt.endedMs = elapsed(); }
  });
  page.on('requestfailed', request => {
    pending.delete(request);
    const attempt = requests.get(request), error = request.failure()?.errorText ?? 'Unknown transport error';
    if (attempt) { attempt.outcome = 'failed'; attempt.error = error; attempt.endedMs = elapsed(); }
    // Append an independent record; recovery never rewrites or removes it.
    (isClosing() ? result.cleanupRequests : result.failedRequests).push({
      url: request.url(), error, elapsedMs: elapsed(), requestId: attempt?.requestId ?? null, phase: attempt?.phase ?? null,
    });
  });

  function snapshot() {
    const attempts = [...requests.values()], recoveredIds = new Set(), initialIds = new Set();
    const phaseReports = phases.map(phase => {
      const resources = manifest.map(item => {
        const list = attempts.filter(attempt => attempt.preload && attempt.phase === phase.name && attempt.url === item.url);
        const [first, second] = list;
        if (first) initialIds.add(first.requestId);
        const recovered = list.length === 2 && first.outcome === 'failed' && transportError.test(first.error)
          && (first.status === null || first.status >= 200 && first.status < 300)
          && second.startedMs >= first.endedMs && succeeded(second);
        if (recovered && phase.automaticEntry) recoveredIds.add(first.requestId);
        const status = list.length === 1 && succeeded(first) ? 'clean' : recovered ? 'recovered' : 'failed';
        return { ...item, status, attempts: list.map(attempt => ({ ...attempt })) };
      });
      const resourcesSuccessful = resources.filter(resource => resource.status !== 'failed').length;
      return {
        ...phase, resourcesExpected: manifest.length, resourcesSuccessful, resources,
        status: !phase.automaticEntry || resourcesSuccessful !== manifest.length ? 'failed'
          : resources.some(resource => resource.status === 'recovered') ? 'recovered' : 'clean',
      };
    });
    const recoveredInitialTransportErrors = result.failedRequests.filter(error => recoveredIds.has(error.requestId));
    const unrecoveredFailures = result.failedRequests.filter(error => !recoveredIds.has(error.requestId));
    const recoverableConsoleErrors = [], unclassifiedConsoleErrors = [];
    for (const event of result.consoleEvents) {
      const code = /^Failed to load resource: (net::ERR_[A-Z0-9_]+)$/.exec(event.text)?.[1];
      const matching = recoveredInitialTransportErrors.find(error => code === error.error && event.location?.url === error.url && event.phase === error.phase);
      (matching ? recoverableConsoleErrors : unclassifiedConsoleErrors).push({ ...event, ...(matching ? { recoveredRequestId: matching.requestId } : {}) });
    }
    const failed = !phaseReports.length || phaseReports.some(phase => phase.status === 'failed')
      || unrecoveredFailures.length || unclassifiedConsoleErrors.length || result.pageErrors.length
      || result.badResponses.length || result.foreignRequests.length || result.outsideSubpath.length || result.unexpectedPreloadRequests.length;
    return {
      status: failed ? 'failed' : recoveredInitialTransportErrors.length ? 'recovered' : 'clean',
      policy: 'At most two sequential GET fetch attempts per exact local resource URL per phase; first failed attempt remains failed. Only a later complete 2xx response plus automatic entry can recover a recognized transport failure. This is not a runtime-byte SHA check.',
      phases: phaseReports, initialFailures: result.failedRequests.filter(error => initialIds.has(error.requestId)),
      recoveredInitialTransportErrors, unrecoveredFailures, recoverableConsoleErrors, unclassifiedConsoleErrors,
    };
  }
  return {
    pending,
    beginPhase(name) {
      if (current || phases.some(phase => phase.name === name)) throw new Error(`Invalid/duplicate preload phase: ${name}`);
      current = { name, startedMs: elapsed(), endedMs: null, automaticEntry: false, controlClicks: null };
      phases.push(current);
    },
    async completePhase() {
      if (!current) throw new Error('No active preload phase.');
      const observation = await page.evaluate(() => ({
        loaderGone: !document.querySelector('.resource-loading'),
        sceneReady: document.querySelector('[data-testid="scene"]')?.getAttribute('data-ready') === 'true',
        controlClicks: window.__hardfishPreloadControlClicks ?? null,
      }));
      Object.assign(current, observation, { endedMs: elapsed(), automaticEntry: observation.loaderGone && observation.sceneReady && Array.isArray(observation.controlClicks) && observation.controlClicks.length === 0 });
      current = null;
      result.preload = snapshot();
      return result.preload.phases.at(-1);
    },
    snapshot() { result.preload = snapshot(); return result.preload; },
    assertHealthy() {
      result.preload = snapshot();
      if (result.preload.status === 'failed') throw new Error('Online resource/console checks failed; see preload phases, attempts and unchanged raw error arrays.');
      return result.preload;
    },
  };
}
