import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const project = fileURLToPath(new URL('../../', import.meta.url));
const output = path.resolve(project, '../research/character-v4');
const dist = path.join(project, 'dist');
await fs.mkdir(output, { recursive: true });
const expectedEntry = 'assets/index-DAx1cH7Q.js';
const index = await fs.readFile(path.join(dist, 'index.html'), 'utf8');
const entryBundle = index.match(/src="\.\/([^" ]+\.js)"/)?.[1];
if (entryBundle !== expectedEntry) throw Error(`Final bundle mismatch: expected ${expectedEntry}, found ${entryBundle}`);
const bootFiles = [...new Set(['index.html', ...[...index.matchAll(/(?:src|href)="\.\/([^" ]+\.(?:js|css))"/g)].map(m => m[1])])];
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const files = {};
for (const file of bootFiles) { const bytes = await fs.readFile(path.join(dist, file)); files['dist/' + file] = { bytes: bytes.length, sha256: digest(bytes) }; }
const summary = {
  version: '1.2.0', checkedAt: new Date().toISOString(), status: 'pending',
  scope: 'Six targeted browser regressions only: contextual chat/feeding/shop/save, preserving the open notebook on commission arrival, and the introductory four-stage commission across places/reload; each desktop and mobile. Actual final static /dist/; no runtime mocks, no full campaign replay.',
  testedBuild: { version: '1.2.0', pathBase: 'code/', entryBundle, files },
  settings: { workers: 1, retries: 0, trace: 'off', screenshots: 'only-on-failure plus explicit arrival notebook screenshots', fixture: 'Existing specs seed an actual newGame save with the supported lowQuality setting; expansion also mutes voice. Actual WebGL rendering remains enabled.' },
  counts: { passed: 0, failed: 0, skipped: 0, total: 0 }, checks: [], errors: [],
  rawReport: 'targeted-regression-playwright.json', artifacts: 'targeted-regression-artifacts/',
  limits: ['This checks three selected flows on two viewports, not the complete historical game E2E suite.', 'Software Chromium WebGL is not a physical-device frame-rate measurement.'],
};
const served = { documents: 0, entryRequests: 0, entryHashes: new Set(), missing: [] };
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.mp3': 'audio/mpeg', '.txt': 'text/plain; charset=utf-8' };
const server = http.createServer(async (req, res) => {
  try {
    const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    if (!pathname.startsWith('/dist/')) { served.missing.push(pathname); res.writeHead(404).end(); return; }
    const relative = pathname.slice('/dist/'.length) || 'index.html';
    const filename = path.resolve(dist, relative);
    if (!filename.startsWith(dist + path.sep)) { res.writeHead(403).end(); return; }
    const bytes = await fs.readFile(filename);
    if (relative === 'index.html') served.documents++;
    if (relative === entryBundle) { served.entryRequests++; served.entryHashes.add(digest(bytes)); }
    res.writeHead(200, { 'Content-Type': mime[path.extname(filename)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
    res.end(req.method === 'HEAD' ? undefined : bytes);
  } catch { served.missing.push(req.url); res.writeHead(404).end(); }
});
await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
const baseURL = `http://127.0.0.1:${server.address().port}/dist/`; summary.baseURL = baseURL;
const args = [path.join(project, 'node_modules/@playwright/test/cli.js'), 'test', 'tests/game.spec.ts', 'tests/expansion.spec.ts', '--project=desktop', '--project=mobile', '--grep=chat follows context, feeding changes needs|arriving at a commission preserves|an introductory commission follows real paths', '--workers=1', '--retries=0', '--trace=off', '--reporter=json', `--output=${path.join(output, 'targeted-regression-artifacts')}`];
summary.command = [process.execPath, ...args];
let stdout = '', stderr = '', exitCode = null;
const started = Date.now();
console.log(`Targeted regression: 6 cases, static ${baseURL}, entry ${entryBundle}`);
const heartbeat = setInterval(() => console.log(`Targeted regression running ${Math.round((Date.now() - started) / 1000)}s; ${served.documents} document / ${served.entryRequests} final-bundle requests`), 45000);
try {
  const child = spawn(process.execPath, args, { cwd: project, env: { ...process.env, CI: '1', PLAYWRIGHT_BASE_URL: baseURL, QA_ARTIFACT_DIR: output }, stdio: ['ignore', 'pipe', 'pipe'] });
  child.stdout.setEncoding('utf8'); child.stderr.setEncoding('utf8');
  child.stdout.on('data', text => { stdout += text; });
  child.stderr.on('data', text => { stderr += text; process.stderr.write(text); });
  exitCode = await new Promise((resolve, reject) => { child.once('error', reject); child.once('close', resolve); });
  await fs.writeFile(path.join(output, summary.rawReport), stdout);
  await fs.writeFile(path.join(output, 'targeted-regression-stderr.log'), stderr);
  const result = JSON.parse(stdout); summary.playwrightStats = result.stats;
  function collect(suites) {
    for (const suite of suites || []) {
      for (const spec of suite.specs || []) for (const test of spec.tests || []) {
        const last = test.results.at(-1);
        summary.checks.push({ id: `${test.projectName}: ${spec.title}`, file: spec.file || suite.file, project: test.projectName, status: last?.status === 'passed' ? 'passed' : last?.status === 'skipped' ? 'skipped' : 'failed', playwrightStatus: test.status, durationMs: last?.duration, errors: last?.errors || [], attachments: last?.attachments || [] });
      }
      collect(suite.suites);
    }
  }
  collect(result.suites);
  summary.errors.push(...(result.errors || []));
  summary.counts = { passed: summary.checks.filter(c => c.status === 'passed').length, failed: summary.checks.filter(c => c.status === 'failed').length, skipped: summary.checks.filter(c => c.status === 'skipped').length, total: summary.checks.length };
  summary.buildUnchanged = true;
  for (const [file, original] of Object.entries(files)) if (digest(await fs.readFile(path.join(project, file))) !== original.sha256) { summary.buildUnchanged = false; summary.errors.push(`Build changed during test: ${file}`); }
  const receivedExactBundle = served.entryRequests >= 6 && served.entryHashes.size === 1 && served.entryHashes.has(files['dist/' + entryBundle].sha256);
  summary.receivedExactBundle = receivedExactBundle;
  summary.status = exitCode === 0 && summary.counts.total === 6 && summary.counts.passed === 6 && summary.counts.failed === 0 && summary.counts.skipped === 0 && summary.buildUnchanged && receivedExactBundle && summary.errors.length === 0 ? 'passed' : 'failed';
} catch (error) { summary.errors.push(error.stack || String(error)); summary.status = 'failed'; }
finally {
  clearInterval(heartbeat); summary.exitCode = exitCode; summary.durationMs = Date.now() - started;
  summary.served = { ...served, entryHashes: [...served.entryHashes] };
  await fs.writeFile(path.join(output, 'targeted-regression-summary.json'), JSON.stringify(summary, null, 2) + '\n');
  server.closeAllConnections(); await new Promise(resolve => server.close(resolve));
  console.log(`Targeted regression ${summary.status}: ${summary.counts.passed} passed / ${summary.counts.failed} failed / ${summary.counts.skipped} skipped; server closed.`);
}
if (summary.status !== 'passed') process.exitCode = 1;
