import {chromium} from '@playwright/test';
import fs from 'node:fs/promises';
const browser=await chromium.launch({executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath(),args:['--no-sandbox','--enable-unsafe-swiftshader']});
const root='../research/upgrade';
await fs.mkdir(root,{recursive:true});
const errors=[];
const results=[];
for(const [name,width,height] of [['desktop',1440,900],['mobile',390,844],['narrow',320,740],['landscape',844,390]]) {
  const page=await browser.newPage({viewport:{width,height},hasTouch:width<600,deviceScaleFactor:1});
  page.on('pageerror',e=>errors.push(`${name}: ${e.message}`));
  page.on('console',e=>{if(e.type()==='error')errors.push(`${name}: ${e.text()}`);});
  await page.goto(process.env.GAME_URL||'http://localhost:5173');
  await page.getByTestId('scene').waitFor();
  await page.waitForFunction(()=>document.querySelector('[data-testid="scene"]')?.dataset.ready==='true');
  await page.screenshot({animations:'disabled',path:`${root}/after-${name}.png`});
  const layout=await page.evaluate(()=>({width:innerWidth,overflow:document.documentElement.scrollWidth>innerWidth,canvas:document.querySelector('canvas').getBoundingClientRect().toJSON(),dataset:{...document.querySelector('[data-testid="scene"]').dataset}}));
  results.push({name,...layout});
  if(name==='desktop'||name==='mobile') {
    await page.getByRole('button',{name:'群友圈',exact:true}).click();
    await page.screenshot({animations:'disabled',path:`${root}/friends-${name}.png`});
    await page.getByRole('button',{name:'关闭窗口',exact:true}).click();
    await page.getByRole('button',{name:'聊聊天',exact:false}).click();
    await page.getByRole('textbox',{name:'给难鱼发消息'}).fill('聊聊雨夜');
    await page.getByRole('textbox',{name:'给难鱼发消息'}).press('Enter');
    await page.screenshot({animations:'disabled',path:`${root}/chat-${name}.png`});
    await page.getByRole('button',{name:'关闭窗口',exact:true}).click();
  }
  if(name==='desktop') {
    for(const [id,label] of [['kitchen','厨房'],['park','公园'],['shop','便利店'],['school','教室'],['home','小窝']]) {
      await page.getByRole('button',{name:'打开地图',exact:true}).click();
      await page.getByRole('button',{name:label,exact:true}).click();
      await page.waitForFunction(place=>document.querySelector('[data-testid="scene"]')?.dataset.place===place,id);
      await page.screenshot({animations:'disabled',path:`${root}/world-${id}.png`});
    }
  }
  await page.close();
}
await fs.writeFile(`${root}/review.json`,JSON.stringify({results,errors},null,2));
console.log(JSON.stringify({results,errors},null,2));
await browser.close();
if(errors.length||results.some(r=>r.overflow))process.exitCode=1;
