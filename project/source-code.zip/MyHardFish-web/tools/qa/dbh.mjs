import { chromium, expect } from '@playwright/test';
import { build } from 'esbuild';
import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

// Isolated real WebGL model check: generated evidence is never a runtime asset.
const project = fileURLToPath(new URL('../../', import.meta.url));
const preview = process.env.DBH_PREVIEW_ONLY === '1';
const skinShadowDiagnostic = process.env.DBH_DIAGNOSTIC_SKIN_NO_SHADOWS === '1';
const faceShadowDiagnostic = process.env.DBH_DIAGNOSTIC_FACE_SHADOWS === '1';
if ((skinShadowDiagnostic || faceShadowDiagnostic) && !preview) throw new Error('Shadow diagnostic requires preview mode; it is not model acceptance.');
const previewView = preview ? process.env.DBH_PREVIEW_VIEW : undefined;
const output = path.resolve(project, process.env.QA_OUTPUT_DIR || '../research/dbh-npc/model');
await fs.mkdir(output, { recursive: true });
const referencePath = path.resolve(project, process.env.DBH_REFERENCE || '../../人物三视图_dbh_(80117801).png');
const reference = await fs.readFile(referencePath).catch(() => null);
const detailViews = [
  { name: 'face-front', target: [0, 3.72, .02], height: 1.35, direction: [0, 0, 1] },
  { name: 'face-quarter', target: [0, 3.72, .02], height: 1.35, direction: [.65, .03, 1] },
  { name: 'face-profile', target: [0, 3.72, .02], height: 1.35, direction: [1, 0, 0] },
  { name: 'hair-back', target: [0, 3.15, 0], height: 2.3, direction: [0, 0, -1] },
  { name: 'clothes-front', target: [0, 2.53, .03], height: 2.05, direction: [0, 0, 1] },
  { name: 'clothes-quarter', target: [0, 2.53, .03], height: 2.05, direction: [.6, .1, 1] },
  { name: 'clothes-back', target: [0, 2.75, .03], height: 1.8, direction: [0, .05, -1] },
  { name: 'hand', target: [.47, 1.97, .05], height: .78, direction: [.5, .12, 1] },
  { name: 'knees', target: [0, 1.12, .02], height: 1.35, direction: [0, 0, 1] },
  { name: 'sandals', target: [0, .23, .04], height: .75, direction: [.55, .55, 1] },
];
const standardViews = ['front', 'side', 'back', 'quarter'];
if (previewView && ![...standardViews, ...detailViews.map(view => view.name)].includes(previewView)) throw new Error('Unknown DBH_PREVIEW_VIEW: ' + previewView);
const selectedViews = previewView ? standardViews.filter(view => view === previewView) : standardViews;
const selectedDetails = previewView ? detailViews.filter(view => view.name === previewView) : preview ? detailViews.filter(view => ['face-front', 'face-quarter', 'face-profile', 'clothes-quarter', 'clothes-back', 'hand', 'sandals'].includes(view.name)) : detailViews;
const bundle = await build({
  entryPoints: [path.join(project, 'src/dbh-character.ts')], bundle: true, write: false,
  metafile: true, format: 'esm', platform: 'browser', external: ['three', 'three/*'],
  define: { 'import.meta.env.BASE_URL': '"/"' },
});
const fingerprint = async () => {
  const result = {};
  const assets = (await fs.readdir(path.join(project, 'public/assets'))).filter(name => /^dbh[-.]/.test(name)).map(name => path.join(project, 'public/assets', name));
  for (const input of [...Object.keys(bundle.metafile.inputs), ...assets, fileURLToPath(import.meta.url)]) {
    const absolute = path.resolve(input), bytes = await fs.readFile(absolute);
    result[path.relative(project, absolute)] = { bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') };
  }
  return result;
};
const testedSource = await fingerprint();
const viewer = `
import * as THREE from 'three';
import { createDbhCharacter } from '/model.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
const renderer = new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});
renderer.setSize(760,900);renderer.setPixelRatio(1);renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
document.body.appendChild(renderer.domElement);
const scene=new THREE.Scene();scene.background=new THREE.Color('#ddd8ce');
scene.add(new THREE.HemisphereLight('#fff9f0','#888875',1.9));
for(const [color,intensity,position,shadow] of [['#fff1dc',2.7,[-3,7,5],true],['#e9f0ff',.9,[4,4,2],false],['#ffffff',1.6,[0,6,-5],false]]){
  const light=new THREE.DirectionalLight(color,intensity);light.position.set(...position);light.castShadow=shadow;
  if(shadow){light.shadow.mapSize.set(1024,1024);Object.assign(light.shadow.camera,{left:-4,right:4,top:6,bottom:-4,near:.1,far:20});light.shadow.bias=-.0003;light.shadow.normalBias=.02;}
  scene.add(light);
}
const floor=new THREE.Mesh(new THREE.PlaneGeometry(200,200),new THREE.MeshStandardMaterial({color:'#c8c2b7',roughness:.9}));floor.rotation.x=-Math.PI/2;floor.position.y=-.015;floor.receiveShadow=true;scene.add(floor);
const height=5,aspect=760/900,camera=new THREE.OrthographicCamera(-height*aspect/2,height*aspect/2,height/2,-height/2,.1,40);
camera.position.set(0,2.05,10);camera.lookAt(0,2.05,0);
let activeFrame={name:'front',height:5,target:[0,2.05,0],direction:[0,0,1]};
const frame=config=>{
 activeFrame=config;camera.left=-config.height*aspect/2;camera.right=config.height*aspect/2;
 camera.top=config.height/2;camera.bottom=-config.height/2;camera.updateProjectionMatrix();
 const target=new THREE.Vector3(...config.target);camera.position.copy(target).add(new THREE.Vector3(...config.direction).normalize().multiplyScalar(10));camera.lookAt(target);
};
const render=()=>{scene.updateMatrixWorld(true);renderer.render(scene,camera);};
render();const baseline={...renderer.info.memory};let model=createDbhCharacter(),elapsed=0;scene.add(model.root);
if (${skinShadowDiagnostic}) model.root.traverse(node=>{if(node.name==='dbh-continuous-anatomy')node.receiveShadow=false;});
if (${faceShadowDiagnostic}) model.root.traverse(node=>{if(node.name==='dbh-continuous-face-neck')node.receiveShadow=true;});
const update=(action,frames=100)=>{for(let i=0;i<frames;i++){elapsed+=1/60;model.update(elapsed,1/60,action);}render();};
const textureStates=(root=model.root)=>{const states=[];root.traverse(node=>{if(node.userData.textureStatus)states.push({name:node.name,status:node.userData.textureStatus});});return states;};
const inventory=(root=model.root,visibleOnly=false)=>{
 const geometries=new Set(),materials=new Set(),textures=new Set(),errors=[];let meshes=0,vertices=0,triangles=0,skinnedMeshes=0,bones=0,morphTargets=0;
 root.updateMatrixWorld(true);
 root[visibleOnly?'traverseVisible':'traverse'](node=>{
  if(node.matrixWorld.elements.some(n=>!Number.isFinite(n)))errors.push(node.name+': nonfinite transform');
  if(!node.isMesh)return;meshes++;
  morphTargets+=node.morphTargetInfluences?.length||0;
  const g=node.geometry;
  if(node.isSkinnedMesh){
   skinnedMeshes++;bones+=node.skeleton.bones.length;
   const weights=g.getAttribute('skinWeight'),indices=g.getAttribute('skinIndex');
   if(!weights||!indices||weights.count!==g.attributes.position.count||indices.count!==weights.count)errors.push(node.name+': invalid skin attributes');
   else for(let i=0;i<weights.count;i++){
    let sum=0;for(let j=0;j<4;j++){const w=weights.getComponent(i,j),index=indices.getComponent(i,j);sum+=w;if(w<0||w>1||(w>0&&(index<0||index>=node.skeleton.bones.length)))errors.push(node.name+': invalid bone weight');}
    if(Math.abs(sum-1)>.00001){errors.push(node.name+': unnormalized skin weights');break;}
   }
   if(node.skeleton.boneInverses.some(matrix=>matrix.elements.some(n=>!Number.isFinite(n))))errors.push(node.name+': nonfinite bind matrix');
  }
  if(!geometries.has(g)){geometries.add(g);const count=g.attributes.position?.count||0;vertices+=count;triangles+=(g.index?.count||count)/3;
   if(!count)errors.push(node.name+': empty geometry');
   for(const [name,attribute] of Object.entries(g.attributes))for(const value of attribute.array)if(!Number.isFinite(value)){errors.push(node.name+': nonfinite '+name);break;}
   if(g.index)for(const index of g.index.array)if(index<0||index>=count){errors.push(node.name+': invalid index');break;}
   for(const [name,attributes] of Object.entries(g.morphAttributes))for(const attribute of attributes){if(attribute.count!==count)errors.push(node.name+': morph count '+name);for(const value of attribute.array)if(!Number.isFinite(value)){errors.push(node.name+': nonfinite morph '+name);break;}}
  }
  for(const material of Array.isArray(node.material)?node.material:[node.material]){materials.add(material);for(const value of Object.values(material))if(value?.isTexture)textures.add(value);}
 });
 // Precise traversal uses current skinned/morphed vertex positions instead of cached bind-pose boxes.
 const box=new THREE.Box3();
 if(visibleOnly){const point=new THREE.Vector3();root.traverseVisible(node=>{if(!node.isMesh)return;for(let i=0;i<node.geometry.attributes.position.count;i++){node.getVertexPosition(i,point);box.expandByPoint(point.applyMatrix4(node.matrixWorld));}});}else box.setFromObject(root,true);
 const size=box.getSize(new THREE.Vector3());
 const top=new THREE.Vector3(0,box.max.y,0).project(camera),bottom=new THREE.Vector3(0,box.min.y,0).project(camera);
 return {meshes,skinnedMeshes,bones,morphTargets,geometries:geometries.size,materials:materials.size,textures:textures.size,vertices,triangles,textureStates:textureStates(root),
 bounds:{min:box.min.toArray(),max:box.max.toArray(),size:size.toArray()},errors,
 framing:{...activeFrame,projectedVertical:{top:(1-top.y)*450,bottom:(1-bottom.y)*450}},
 memory:{...renderer.info.memory},render:{...renderer.info.render},
 allocation:{geometries:[...geometries].map(g=>g.uuid).sort(),materials:[...materials].map(m=>m.uuid).sort(),textures:[...textures].map(t=>t.uuid).sort()}};
};
let imported=null;
const disposeImported=()=>{
 if(!imported)return;scene.remove(imported);
 const geometries=new Set(),materials=new Set(),textures=new Set(),skeletons=new Set();
 imported.traverse(node=>{if(node.geometry)geometries.add(node.geometry);if(node.skeleton)skeletons.add(node.skeleton);for(const material of Array.isArray(node.material)?node.material:node.material?[node.material]:[]){materials.add(material);for(const value of Object.values(material))if(value?.isTexture)textures.add(value);}});
 for(const value of [...geometries,...materials,...textures,...skeletons])value.dispose();imported=null;scene.add(model.root);render();
};
const dispose=()=>{disposeImported();scene.remove(model.root);model.dispose();render();return {memory:{...renderer.info.memory},baseline,lost:renderer.getContext().isContextLost(),error:renderer.getContext().getError()};};
window.qa={
 textureStates,inspect(){render();return inventory();},
 view(name){const views={front:[0,0,1],side:[1,0,0],back:[0,0,-1],quarter:[.7,.125,.9]};frame({name,height:5,target:[0,2.05,0],direction:views[name]});render();return inventory();},
 detail(config){frame(config);render();return inventory();},
 pose(action){update(action);return inventory();},
 sample(action,time){elapsed=time;model.update(time,1/60,action);render();return inventory();},
 cycle(actions){for(const action of actions)update(action,60);return inventory();},
 recreate(){const disposed=dispose();model=createDbhCharacter();scene.add(model.root);elapsed=0;update('idle');return {disposed,created:inventory()};},
 async exportModel(){
  update('idle');model.root.updateMatrixWorld(true);
  const data=await new GLTFExporter().parseAsync(model.root,{binary:true,onlyVisible:true,trs:true});
  const bytes=new Uint8Array(data);let binary='';
  for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));
  return btoa(binary);
 },
 async loadExport(){
  const original=inventory(model.root,true);const gltf=await new GLTFLoader().loadAsync('/exported.glb');
  scene.remove(model.root);imported=gltf.scene;scene.add(imported);
  frame({name:'roundtrip-front',height:5,target:[0,2.05,0],direction:[0,0,1]});render();
  return {original,restored:inventory(imported),animationClips:gltf.animations.length};
 },
 disposeImported,
 dispose
};update('idle');`;
const html = '<!doctype html><html><head><meta charset="utf-8"><link rel="icon" href="data:,"><style>body{margin:0}canvas{display:block}</style><script type="importmap">{"imports":{"three":"/vendor/build/three.module.js","three/addons/":"/vendor/examples/jsm/","three/":"/vendor/"}}</script></head><body><script type="module" src="/viewer.js"></script></body></html>';
const server = http.createServer(async (request, response) => {
  try {
    const route = new URL(request.url, 'http://localhost').pathname;
    if (route === '/') { response.writeHead(200, { 'content-type': 'text/html' }); response.end(html); return; }
    if (route === '/model.js' || route === '/viewer.js') { response.writeHead(200, { 'content-type': 'text/javascript' }); response.end(route === '/model.js' ? bundle.outputFiles[0].text : viewer); return; }
    if (route === '/reference.png' && reference) { response.writeHead(200, { 'content-type': 'image/png' }); response.end(reference); return; }
    if (route === '/exported.glb') { response.writeHead(200, { 'content-type': 'model/gltf-binary' }); response.end(await fs.readFile(path.join(output, 'dbh.glb'))); return; }
    if (/^\/evidence\/[a-z-]+\.png$/.test(route)) { response.writeHead(200, { 'content-type': 'image/png' }); response.end(await fs.readFile(path.join(output, path.basename(route)))); return; }
    const vendor = route.startsWith('/vendor/'), base = path.join(project, vendor ? 'node_modules/three' : 'public');
    const target = path.resolve(base, vendor ? route.slice(8) : route.slice(1));
    if (!target.startsWith(base + path.sep)) throw Error('Bad path');
    const bytes = await fs.readFile(target);
    response.writeHead(200, { 'content-type': target.endsWith('.png') ? 'image/png' : 'text/javascript' }); response.end(bytes);
  } catch { response.writeHead(404).end(); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const browser = await chromium.launch({ executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath(), args: ['--no-sandbox', '--enable-unsafe-swiftshader'] });
const page = await browser.newPage({ viewport: { width: 760, height: 900 } });
const report = { checkedAt: new Date().toISOString(), mode: preview ? 'visual-preview' : 'full-validation', scope: preview ? 'Visual iteration capture only. Waits for all textures and checks captured geometry, but skips full action coverage, allocation/recreation cycles and GLB round trip. This is not model acceptance.' : 'Isolated actual WebGL model; studio screenshots, all action geometry and repeated allocation/disposal. Technical checks do not establish likeness: review the comparison and detail images. Software rendering is not a physical device performance measurement.', previewView, testedSource, reference: reference ? { path: referencePath, sha256: createHash('sha256').update(reference).digest('hex') } : null, views: [], details: [], poses: [], errors: [] };
if (skinShadowDiagnostic || faceShadowDiagnostic) report.diagnostic = {
  limbReceiveShadowDisabled: skinShadowDiagnostic, faceReceiveShadowEnabled: faceShadowDiagnostic,
  scope: 'Viewer-only shadow comparison to isolate surface artifacts; this capture is not model acceptance.',
};
page.on('pageerror', error => report.errors.push(error.message));
page.on('console', message => { if (message.type() === 'error') report.errors.push(message.text()); });
page.on('requestfailed', request => report.errors.push('Request failed: ' + request.url() + ' · ' + request.failure()?.errorText));
page.on('response', response => { if (response.status() >= 400) report.errors.push('HTTP ' + response.status() + ': ' + response.url()); });
const actions = ['idle', 'wave', 'talk', 'nod', 'think', 'cheer', 'dance', 'stretch', 'photo', 'gift', 'bye'];
const check = result => {
  expect(result.errors).toEqual([]);
  expect(result.vertices).toBeGreaterThan(100);
  expect(result.bounds.size.every(Number.isFinite)).toBe(true);
  expect(result.bounds.size[1]).toBeGreaterThan(3);
  expect(result.bounds.size[1]).toBeLessThan(6);
  expect(Math.max(...result.bounds.size)).toBeLessThan(7);
  expect(result.bounds.min[1]).toBeGreaterThan(-.45);
};
const disposed = result => {
  expect(result.lost).toBe(false); expect(result.error).toBe(0);
  expect(result.memory.geometries).toBe(result.baseline.geometries);
  expect(result.memory.textures).toBe(result.baseline.textures);
};
const ready = async () => {
  await page.waitForFunction(() => window.qa.textureStates().every(item => item.status !== 'loading'), null, { timeout: 60000 });
  const result = await page.evaluate(() => window.qa.inspect());
  expect(result.textureStates.every(item => item.status === 'ready')).toBe(true);
  return result;
};
try {
  await page.goto(`http://127.0.0.1:${server.address().port}/`);
  await page.waitForFunction(() => !!window.qa, null, { timeout: 60000 });
  await ready();
  for (const view of selectedViews) {
    const result = await page.evaluate(view => window.qa.view(view), view); check(result);
    await page.screenshot({ path: path.join(output, `${view}.png`) }); report.views.push({ view, ...result });
  }
  for (const config of selectedDetails) {
    const result = await page.evaluate(config => window.qa.detail(config), config); check(result);
    await page.screenshot({ path: path.join(output, `detail-${config.name}.png`) }); report.details.push({ detail: config.name, ...result });
  }
  if (!preview) {
    await page.evaluate(config => window.qa.detail(config), detailViews[0]);
    for (const { name, action, time } of [{ name: 'blink', action: 'idle', time: 4.205 }, { name: 'speaking', action: 'talk', time: 2.34 }]) {
      const result = await page.evaluate(({ action, time }) => window.qa.sample(action, time), { action, time }); check(result);
      await page.screenshot({ path: path.join(output, `detail-${name}.png`) }); report.details.push({ detail: name, sampledTime: time, ...result });
    }
    await page.evaluate(() => window.qa.pose('idle'));
  }
  if (reference && !previewView) {
    const comparisons = await page.evaluate(async ({ views, details }) => {
      const image = async url => { const result = new Image(); result.src = url; await result.decode(); return result; };
      const original = await image('/reference.png');
      const canvas = document.createElement('canvas'); canvas.width = 1680; canvas.height = 875;
      const ctx = canvas.getContext('2d'); ctx.fillStyle = '#f7f5f0'; ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#252a31'; ctx.font = '18px sans-serif'; ctx.fillText('DBH — source / actual model, aligned crown to sole; 10% height grid', 20, 28);
      const referenceCenters = { front: 410, side: 838, back: 1258 };
      for (const [i, view] of views.filter(item => item.view !== 'quarter').entries()) {
        const rendered = await image('/evidence/' + view.view + '.png');
        const { top, bottom } = view.framing.projectedVertical;
        for (const [j, picture] of [original, rendered].entries()) {
          const x = (i * 2 + j) * 280, sourceTop = j ? top : 26, sourceBottom = j ? bottom : 895;
          const s = 758 / (sourceBottom - sourceTop), cx = j ? 380 : referenceCenters[view.view];
          ctx.save(); ctx.beginPath(); ctx.rect(x + 2, 66, 276, 775); ctx.clip();
          ctx.drawImage(picture, x + 140 - cx * s, 76 - sourceTop * s, picture.width * s, picture.height * s);
          ctx.strokeStyle = 'rgba(62,119,152,.23)'; ctx.lineWidth = 1;
          for (let line = 0; line <= 10; line++) { ctx.beginPath(); ctx.moveTo(x, 76 + line * 75.8); ctx.lineTo(x + 280, 76 + line * 75.8); ctx.stroke(); }
          ctx.restore(); ctx.fillStyle = '#252a31'; ctx.font = '14px sans-serif';
          ctx.fillText((j ? 'MODEL' : 'SOURCE') + ' · ' + view.view.toUpperCase(), x + 12, 57);
          ctx.fillText('Crown / sole aligned · width unaltered', x + 8, 859);
        }
      }
      const body = canvas.toDataURL('image/png').split(',')[1];
      canvas.width = 1600; canvas.height = 650; ctx.fillStyle = '#f7f5f0'; ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#252a31'; ctx.font = '18px sans-serif'; ctx.fillText('DBH — face / profile detail, equal whole-body scale and aligned crown', 20, 28);
      for (const [i, name] of ['face-front', 'face-profile'].entries()) {
        const detail = details.find(item => item.detail === name), rendered = await image('/evidence/detail-' + name + '.png');
        for (const [j, picture] of [original, rendered].entries()) {
          const x = (i * 2 + j) * 400, scale = j ? 1450 / (detail.bounds.size[1] * 900 / detail.framing.height) : 1450 / 869;
          const top = j ? detail.framing.projectedVertical.top : 26, cx = j ? 380 : i ? 838 : 410;
          ctx.save(); ctx.beginPath(); ctx.rect(x + 2, 68, 396, 542); ctx.clip();
          ctx.drawImage(picture, x + 200 - cx * scale, 96 - top * scale, picture.width * scale, picture.height * scale); ctx.restore();
          ctx.fillStyle = '#252a31'; ctx.font = '15px sans-serif'; ctx.fillText((j ? 'MODEL' : 'SOURCE') + ' · ' + (i ? 'PROFILE' : 'FRONT'), x + 15, 57);
        }
      }
      ctx.fillStyle = '#252a31'; ctx.font = '14px sans-serif'; ctx.fillText('Compare facial landmarks, profile visibility, crown / fringe continuity, ear integration and material detail. Likeness requires human review.', 20, 636);
      return { body, face: canvas.toDataURL('image/png').split(',')[1] };
    }, { views: report.views, details: report.details });
    await fs.writeFile(path.join(output, 'reference-comparison.png'), Buffer.from(comparisons.body, 'base64'));
    await fs.writeFile(path.join(output, 'reference-face-comparison.png'), Buffer.from(comparisons.face, 'base64'));
    report.comparisons = ['reference-comparison.png', 'reference-face-comparison.png'];
  }
  const selectedActions = preview ? previewView ? [] : ['idle', 'wave'] : actions;
  if (selectedActions.length) await page.evaluate(() => window.qa.view('quarter'));
  for (const action of selectedActions) {
    const result = await page.evaluate(action => window.qa.pose(action), action); check(result);
    await page.screenshot({ path: path.join(output, `action-${action}.png`) }); report.poses.push({ action, ...result });
  }
  if (!preview) {
  const warm = await page.evaluate(actions => window.qa.cycle(actions), actions);
  report.afterRepeatedActions = await page.evaluate(actions => window.qa.cycle([...actions, ...actions, ...actions]), actions);
  check(report.afterRepeatedActions);
  expect(report.afterRepeatedActions.allocation).toEqual(warm.allocation);
  expect(report.afterRepeatedActions.memory).toEqual(warm.memory);
  report.recreated = [];
  for (let cycle = 0; cycle < 3; cycle++) {
    const result = await page.evaluate(() => window.qa.recreate()); disposed(result.disposed); result.created = await ready(); check(result.created); report.recreated.push(result);
  }
  if (process.env.DBH_EXPORT_GLB !== '0') {
    const binary = Buffer.from(await page.evaluate(() => window.qa.exportModel()), 'base64');
    expect(binary.toString('ascii', 0, 4)).toBe('glTF');
    expect(binary.readUInt32LE(4)).toBe(2);
    expect(binary.readUInt32LE(8)).toBe(binary.length);
    expect(binary.toString('ascii', 16, 20)).toBe('JSON');
    const contents = JSON.parse(binary.toString('utf8', 20, 20 + binary.readUInt32LE(12)).trim());
    expect(contents.meshes.length).toBeGreaterThan(0);
    expect(contents.nodes.length).toBeGreaterThan(0);
    const target = path.join(output, 'dbh.glb');
    await fs.writeFile(target, binary);
    // glTF uses one primitive per material. GLTFLoader restores those as
    // separate meshes, so a multi-material shirt legitimately becomes several
    // skinned meshes while retaining its original skeleton and triangles.
    const skinNodes = contents.nodes.filter(node => node.skin !== undefined && node.mesh !== undefined);
    const skinPrimitives = skinNodes.reduce((count, node) => count + contents.meshes[node.mesh].primitives.length, 0);
    const primitiveBoneReferences = skinNodes.reduce((count, node) => count + contents.meshes[node.mesh].primitives.length * contents.skins[node.skin].joints.length, 0);
    report.export = { path: target, bytes: binary.length, meshes: contents.meshes.length, nodes: contents.nodes.length, skinNodes: skinNodes.length, skinPrimitives, primitiveBoneReferences, animations: contents.animations?.length || 0, pose: 'static idle pose; game animations are procedural' };
    report.roundtrip = await page.evaluate(() => window.qa.loadExport());
    await page.screenshot({ path: path.join(output, 'roundtrip-front.png') });
    check(report.roundtrip.restored);
    expect(skinNodes.length).toBe(report.roundtrip.original.skinnedMeshes);
    expect(report.roundtrip.restored.skinnedMeshes).toBe(skinPrimitives);
    expect(report.roundtrip.restored.bones).toBe(primitiveBoneReferences);
    expect(report.roundtrip.restored.triangles).toBe(report.roundtrip.original.triangles);
    expect(report.roundtrip.restored.morphTargets).toBe(report.roundtrip.original.morphTargets);
    expect(report.roundtrip.restored.textures).toBeGreaterThanOrEqual(report.roundtrip.original.textures);
    expect(report.roundtrip.restored.bounds.size.map((size, i) => Math.abs(size - report.roundtrip.original.bounds.size[i]) < .015).every(Boolean)).toBe(true);
    await page.evaluate(() => window.qa.disposeImported());
  }
  }
  report.disposal = await page.evaluate(() => window.qa.dispose());
  if (!preview) disposed(report.disposal);
  expect(report.errors).toEqual([]);
  report.finishedSource = await fingerprint();
  report.changedSource = [...new Set([...Object.keys(testedSource), ...Object.keys(report.finishedSource)])].filter(name => JSON.stringify(testedSource[name]) !== JSON.stringify(report.finishedSource[name]));
  report.sourceUnchanged = report.changedSource.length === 0;
  if (!preview) expect(report.sourceUnchanged).toBe(true);
  report.status = preview ? 'preview-captured' : 'passed';
} catch (error) { report.status = 'failed'; report.failure = error.stack || String(error); process.exitCode = 1; }
finally {
  await browser.close(); await new Promise(resolve => server.close(resolve));
  await fs.writeFile(path.join(output, preview ? 'model-preview-check.json' : 'model-webgl-check.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ status: report.status, mode: report.mode, views: report.views.length, details: report.details.length, actions: report.poses.length, changedSource: report.changedSource, failure: report.failure, errors: report.errors, output }));
}
