/** Deterministic CPU contract tests; no browser, network, build, or real waiting.
 * Run: node --test tools/qa/resource-preloader.test.mjs
 * QA_OUTPUT_DIR overrides the default report directory outside the source repo.
 */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { after, test } from 'node:test';
import ts from 'typescript';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const output = path.resolve(process.env.QA_OUTPUT_DIR
  || path.join(project, '../research/interaction-v7/preload-v1.5.1'));
const source = await fs.readFile(path.join(project, 'src/resources.ts'), 'utf8');
const sourceHash = createHash('sha256').update(source).digest('hex');
const sourceFile = ts.createSourceFile('resources.ts', source, ts.ScriptTarget.Latest, true);
const declaration = sourceFile.statements
  .filter(ts.isVariableStatement)
  .flatMap(statement => [...statement.declarationList.declarations])
  .find(node => ts.isIdentifier(node.name) && node.name.text === 'publicPaths');
assert.ok(declaration?.initializer, 'resources.ts must expose the publicPaths Vite initializer');
assert.match(declaration.initializer.getText(sourceFile), /import\.meta\.glob/);
const manifest = Array.from({ length: 93 }, (_, index) =>
  index < 31 ? `/public/assets/fixture-${String(index).padStart(3, '0')}.png`
    : index < 40 ? `/public/audio/music-fixture-${index}.mp3`
      : `/public/audio/voice-fixture-${index}.mp3`);
const cyclingCatalog = JSON.parse(await fs.readFile(path.join(project, 'src/cycling-audio-catalog.json'), 'utf8'));
const cyclingManifest = Object.values(cyclingCatalog).map(entry => `/public/audio/${entry.file}`);
assert.equal(cyclingManifest.length, 4, 'the cycling-only sound bank currently has four files');
for (const filename of cyclingManifest)
  assert.ok((await fs.stat(path.join(project, filename.slice(1)))).isFile(), `cycling asset exists: ${filename}`);
// Only the two Vite-specific inputs are replaced; all preload logic is original.
let executableSource = source.slice(0, declaration.initializer.getStart(sourceFile))
  + JSON.stringify([...manifest, ...cyclingManifest])
  + source.slice(declaration.initializer.end);
assert.equal(executableSource.match(/import\.meta\.env\.BASE_URL/g)?.length, 1);
executableSource = executableSource.replace('import.meta.env.BASE_URL', JSON.stringify('./'));
const compiled = ts.transpileModule(executableSource, {
  compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022 },
  fileName: 'resources.ts', reportDiagnostics: true,
});
assert.equal(compiled.diagnostics?.filter(item => item.category === ts.DiagnosticCategory.Error).length, 0);
const resources = await import(`data:text/javascript;base64,${Buffer.from(compiled.outputText).toString('base64')}`);
assert.equal(resources.RESOURCE_URLS.length, 93);
assert.deepEqual(resources.RESOURCE_URLS, manifest.map(item => `./${item.slice('/public/'.length)}`).sort());
const cyclingUrls = Object.freeze(cyclingManifest.map(item => `./${item.slice('/public/'.length)}`));

const native = {
  setTimeout: globalThis.setTimeout, clearTimeout: globalThis.clearTimeout,
  fetch: globalThis.fetch, AbortController: globalThis.AbortController,
};
const flush = () => new Promise(resolve => setImmediate(resolve));
const checks = [];

class Clock {
  now = 0;
  nextId = 0;
  timers = new Map();
  setTimeout = (callback, delay = 0, ...args) => {
    const id = ++this.nextId;
    this.timers.set(id, { at: this.now + Math.max(0, Number(delay)), callback, args });
    return id;
  };
  clearTimeout = id => { this.timers.delete(id); };
  async advanceTo(end) {
    assert.ok(end >= this.now, 'the fake clock cannot run backwards');
    let turns = 0;
    for (;;) {
      await flush();
      const entry = [...this.timers.entries()]
        .filter(([, timer]) => timer.at <= end)
        .sort((a, b) => a[1].at - b[1].at || a[0] - b[0])[0];
      if (!entry) break;
      assert.ok(++turns < 100_000, 'timer loop must be bounded');
      this.now = entry[1].at;
      this.timers.delete(entry[0]);
      entry[1].callback(...entry[1].args);
    }
    this.now = end;
    await flush();
  }
}

class Harness {
  clock = new Clock();
  listeners = [];
  requests = [];
  progress = [];
  attempts = new Map();
  active = 0;
  maximumActive = 0;
  readerLocks = 0;
  settled = false;
  value = undefined;
  error = undefined;
  urls = resources.RESOURCE_URLS;
  constructor(plan) {
    const harness = this;
    globalThis.setTimeout = this.clock.setTimeout;
    globalThis.clearTimeout = this.clock.clearTimeout;
    globalThis.AbortController = class extends native.AbortController {
      constructor() {
        super();
        const signal = this.signal;
        const add = signal.addEventListener.bind(signal);
        const remove = signal.removeEventListener.bind(signal);
        signal.addEventListener = (type, listener, options) => {
          if (type !== 'abort' || !listener) return add(type, listener, options);
          const capture = typeof options === 'boolean' ? options : Boolean(options?.capture);
          if (harness.listeners.some(item => item.active && item.signal === signal
            && item.listener === listener && item.capture === capture)) return;
          const item = { signal, listener, capture, active: true };
          item.wrapped = function (event) {
            if (typeof options === 'object' && options?.once) item.active = false;
            if (typeof listener === 'function') listener.call(this, event);
            else listener.handleEvent(event);
          };
          harness.listeners.push(item);
          return add(type, item.wrapped, options);
        };
        signal.removeEventListener = (type, listener, options) => {
          const capture = typeof options === 'boolean' ? options : Boolean(options?.capture);
          const item = harness.listeners.find(record => record.active && record.signal === signal
            && record.listener === listener && record.capture === capture);
          if (type === 'abort' && item) {
            item.active = false;
            return remove(type, item.wrapped, options);
          }
          return remove(type, listener, options);
        };
      }
    };
    this.external = new AbortController();
    globalThis.fetch = (url, options) => this.fetch(url, options, plan);
  }
  wait(at, signal, value, error) {
    return new Promise((resolve, reject) => {
      let timer;
      const cleanup = () => {
        if (timer !== undefined) clearTimeout(timer);
        signal.removeEventListener('abort', cancel);
      };
      const cancel = () => { cleanup(); reject(signal.reason || new Error('aborted')); };
      const finish = () => { cleanup(); if (error) reject(error); else resolve(value); };
      if (signal.aborted) { cancel(); return; }
      signal.addEventListener('abort', cancel, { once: true });
      if (at <= this.clock.now) finish();
      else if (Number.isFinite(at)) timer = setTimeout(finish, at - this.clock.now);
    });
  }
  async fetch(url, options, choosePlan) {
    const index = this.urls.indexOf(url);
    assert.ok(index >= 0, `fetch must belong to the selected preload scope: ${url}`);
    const attempt = (this.attempts.get(index) || 0) + 1;
    this.attempts.set(index, attempt);
    const plan = choosePlan(index, attempt, this);
    const request = {
      index, url, attempt, start: this.clock.now, cache: options.cache,
      abortedAt: null, end: null, acquired: 0, released: 0,
    };
    this.requests.push(request);
    this.active++;
    this.maximumActive = Math.max(this.maximumActive, this.active);
    const signal = options.signal;
    let transportTimer;
    const finish = () => {
      if (request.end !== null) return;
      if (transportTimer !== undefined) clearTimeout(transportTimer);
      request.end = this.clock.now;
      this.active--;
      signal.removeEventListener('abort', monitor);
    };
    const monitor = () => { request.abortedAt = this.clock.now; finish(); };
    signal.addEventListener('abort', monitor, { once: true });
    if (signal.aborted) monitor();
    else if (Number.isFinite(plan.transportEnd)) {
      // A server can keep sending an unread/error body after headers or after a
      // reader rejects. Only completion or explicit cancellation owns its end.
      transportTimer = setTimeout(finish, plan.transportEnd);
    }
    try {
      await this.wait(request.start + (plan.headers || 0), signal);
      if (plan.headerError) throw new TypeError('simulated transport failure');
      const status = plan.status || 200;
      // HTTP status alone does not finish the response body or release a socket.
      let cursor = 0;
      const harness = this;
      return {
        ok: status >= 200 && status < 300, status,
        headers: { get(name) {
          if (name.toLowerCase() === 'content-length') return String(plan.length ?? 100);
          if (name.toLowerCase() === 'content-encoding') return plan.encoding || null;
          return null;
        } },
        body: plan.bodyNull ? null : { getReader() {
          assert.equal(request.acquired, 0, 'a response acquires only one reader');
          request.acquired++;
          harness.readerLocks++;
          return {
            async read() {
              const event = plan.events?.[cursor++] || { at: Infinity };
              try {
                await harness.wait(request.start + event.at, signal, undefined,
                  event.error ? new TypeError('simulated stream failure') : undefined);
                if (event.done) { finish(); return { done: true, value: undefined }; }
                return { done: false, value: new Uint8Array(event.bytes ?? 1) };
              } catch (error) {
                if (!plan.keepTransportOnStreamError || signal.aborted) finish();
                throw error;
              }
            },
            releaseLock() {
              assert.equal(request.released, 0, 'reader locks cannot be released twice');
              request.released++;
              harness.readerLocks--;
            },
            async cancel() { finish(); },
          };
        }, async cancel() { finish(); } },
        async arrayBuffer() {
          try {
            await harness.wait(request.start + (plan.bufferAt || 0), signal);
            finish();
            return new ArrayBuffer(plan.bufferBytes ?? 1);
          } catch (error) { finish(); throw error; }
        },
      };
    } catch (error) { finish(); throw error; }
  }
  start(options) {
    assert.equal(this.pending, undefined, 'one invocation per isolated harness');
    this.urls = options?.urls ?? resources.RESOURCE_URLS;
    this.pending = resources.preloadResources(
      progress => this.progress.push({ ...progress, time: this.clock.now }),
      this.external.signal, options,
    ).then(value => { this.value = value; this.settled = true; },
      error => { this.error = error; this.settled = true; });
  }
  async completeAt(time) {
    await this.clock.advanceTo(time);
    assert.ok(this.settled, `preloader must settle by simulated ${time} ms`);
    if (this.error) throw this.error;
    return this.value;
  }
  forIndex(index = 0) { return this.requests.filter(item => item.index === index); }
  assertClean() {
    assert.equal(this.clock.timers.size, 0, 'all idle/hard/global/network timers are removed');
    assert.equal(this.listeners.filter(item => item.active).length, 0, 'all abort listeners are removed');
    assert.equal(this.readerLocks, 0, 'all acquired stream readers are released');
    assert.equal(this.active, 0, 'no request remains active');
    assert.ok(this.maximumActive <= 6, 'retries cannot add a seventh worker');
    assert.ok([...this.attempts.values()].every(count => count <= 2), 'at most two requests per slot');
    assert.ok(this.progress.every(item => item.total === this.urls.length && item.completed <= this.urls.length));
  }
  async restore() {
    this.external.abort();
    await flush();
    this.clock.timers.clear();
    Object.assign(globalThis, native);
  }
}

const instant = { length: 1, events: [{ at: 0, bytes: 1 }, { at: 0, done: true }] };
const flowing = { length: 100, events: Array.from({ length: 100 }, (_, index) =>
  ({ at: (index + 1) * 10_000, bytes: 1 })) };
const onlyFirst = plan => (index, attempt, harness) => index === 0
  ? (typeof plan === 'function' ? plan(attempt, harness) : plan) : instant;
function success(result, total = 93) {
  assert.deepEqual(result, { failed: [], completed: total, total, aborted: false });
}
function oneFailure(result) {
  assert.deepEqual(result, {
    failed: [resources.RESOURCE_URLS[0]], completed: 93, total: 93, aborted: false,
  });
}
function check(name, plan, verify) {
  test(name, { concurrency: false, timeout: 5_000 }, async () => {
    const harness = new Harness(plan);
    let error;
    try {
      await verify(harness);
      harness.assertClean();
    } catch (caught) { error = caught; throw caught; }
    finally {
      checks.push({ name, passed: !error, simulatedTimeMs: harness.clock.now,
        requests: harness.requests.length, maximumActive: harness.maximumActive,
        retryCount: harness.requests.filter(item => item.attempt === 2).length,
        result: harness.value, finalProgress: harness.progress.at(-1),
        remainingTimers: harness.clock.timers.size,
        remainingListeners: harness.listeners.filter(item => item.active).length,
        remainingReaderLocks: harness.readerLocks,
        remainingRequests: harness.active,
        ...(error ? { error: String(error.stack || error) } : {}),
      });
      await harness.restore();
    }
  });
}

check('transport failure retries once with reload and recovers the same slot',
  onlyFirst(attempt => attempt === 1 ? { headerError: true } : instant), async h => {
    h.start(); success(await h.completeAt(0));
    assert.deepEqual(h.forIndex().map(item => item.cache), ['force-cache', 'reload']);
    assert.equal(h.requests.length, 94);
    assert.equal(h.progress.at(-1).loadedBytes, 93);
  });

check('a failed stream releases its reader before a successful retry',
  onlyFirst(attempt => attempt === 1
    ? { events: [{ at: 1_000, bytes: 25 }, { at: 2_000, error: true }] }
    : { length: 10, events: [{ at: 1_000, bytes: 10 }, { at: 2_000, done: true }] }), async h => {
    h.start(); success(await h.completeAt(4_000));
    assert.equal(h.progress.at(-1).loadedBytes, 127);
    assert.ok(h.forIndex().every(item => item.acquired === 1 && item.released === 1));
  });

check('a 30 second stall retries and can recover inside the original file budget',
  onlyFirst(attempt => attempt === 1 ? { events: [] }
    : { length: 1, events: [{ at: 5_000, bytes: 1 }, { at: 6_000, done: true }] }), async h => {
    h.start(); await h.clock.advanceTo(29_999);
    assert.equal(h.forIndex().length, 1); assert.equal(h.forIndex()[0].abortedAt, null);
    success(await h.completeAt(36_000));
    assert.equal(h.forIndex()[0].abortedAt, 30_000);
    assert.equal(h.forIndex()[1].start, 30_000);
  });

check('zero-byte chunks renew neither idle timer; manual retries still use reload',
  onlyFirst({ events: [{ at: 20_000, bytes: 0 }, { at: 40_000, bytes: 0 }] }), async h => {
    h.start({ retry: true }); oneFailure(await h.completeAt(60_000));
    assert.deepEqual(h.forIndex().map(item => item.abortedAt), [30_000, 60_000]);
    assert.ok(h.requests.every(item => item.cache === 'reload'));
    assert.equal(h.progress.at(-1).loadedBytes, 92);
  });

check('continuous real chunks allow a 70 second download without retry',
  onlyFirst({ length: 3, events: [
    { at: 20_000, bytes: 1 }, { at: 40_000, bytes: 1 },
    { at: 60_000, bytes: 1 }, { at: 70_000, done: true },
  ] }), async h => {
    h.start(); success(await h.completeAt(70_000));
    assert.equal(h.forIndex().length, 1);
    assert.equal(h.forIndex()[0].abortedAt, null);
    assert.equal(h.progress.at(-1).loadedBytes, 95);
  });

check('two transport failures settle one slot and report its URL only once',
  onlyFirst({ headerError: true }), async h => {
    h.start(); oneFailure(await h.completeAt(0));
    assert.equal(h.forIndex().length, 2);
    assert.equal(h.requests.length, 94);
    assert.deepEqual([...new Set(h.progress.map(item => item.completed))],
      Array.from({ length: 94 }, (_, index) => index));
    assert.equal(h.progress.at(-1).percent, 100);
  });

check('HTTP 503 cancels its unfinished large body without automatic retry',
  onlyFirst({ status: 503, headers: 250, length: 20_000_000, transportEnd: 120_000,
    events: [{ at: 60_000, bytes: 256 }, { at: 120_000, done: true }] }), async h => {
    h.start(); oneFailure(await h.completeAt(250));
    assert.equal(h.forIndex().length, 1);
    assert.equal(h.forIndex()[0].cache, 'force-cache');
    assert.equal(h.forIndex()[0].acquired, 0, 'the error response body is not consumed');
    assert.equal(h.forIndex()[0].abortedAt, 250, 'the unread body is explicitly aborted after headers');
    assert.equal(h.forIndex()[0].end, 250, 'its background transfer ends immediately');
    assert.equal(h.requests.length, 93);
  });

check('a rejected reader aborts its still-active transport before retrying',
  onlyFirst(attempt => attempt === 1 ? {
    keepTransportOnStreamError: true, transportEnd: 20_000, length: 1_000_000,
    events: [{ at: 1_000, bytes: 25 }, { at: 2_000, error: true }],
  } : instant), async h => {
    h.start(); success(await h.completeAt(2_000));
    const [abandoned, retry] = h.forIndex();
    assert.equal(abandoned.abortedAt, 2_000);
    assert.equal(abandoned.end, 2_000);
    assert.equal(abandoned.acquired, 1); assert.equal(abandoned.released, 1);
    assert.equal(retry.start, 2_000); assert.equal(retry.cache, 'reload');
    assert.equal(h.progress.at(-1).loadedBytes, 118);
  });

check('a late failed attempt and its retry share one original 90 second hard limit',
  onlyFirst(attempt => attempt === 1 ? { events: [
    { at: 20_000, bytes: 1 }, { at: 40_000, bytes: 1 },
    { at: 60_000, bytes: 1 }, { at: 80_000, error: true },
  ] } : { events: [{ at: 5_000, bytes: 1 }, { at: 20_000, done: true }] }), async h => {
    h.start(); oneFailure(await h.completeAt(90_000));
    assert.equal(h.forIndex().length, 2);
    assert.equal(h.forIndex()[1].start, 80_000);
    assert.equal(h.forIndex()[1].abortedAt, 90_000);
    assert.equal(h.progress.at(-1).loadedBytes, 96);
  });

check('continual progress cannot bypass 90 seconds or retry a hard timeout',
  onlyFirst(flowing), async h => {
    h.start(); oneFailure(await h.completeAt(90_000));
    assert.equal(h.forIndex().length, 1);
    assert.equal(h.forIndex()[0].abortedAt, 90_000);
  });

check('the 180 second global deadline fails active and unstarted slots without retry',
  () => flowing, async h => {
    h.start(); const result = await h.completeAt(180_000);
    assert.equal(h.requests.length, 12);
    assert.ok(h.requests.slice(0, 6).every(item => item.abortedAt === 90_000));
    assert.ok(h.requests.slice(6).every(item => item.abortedAt === 180_000));
    assert.equal(result.completed, 93); assert.equal(result.total, 93);
    assert.equal(new Set(result.failed).size, 93); assert.equal(result.aborted, false);
    assert.equal(h.progress.at(-1).percent, 100);
    assert.match(h.progress.at(-1).label, /网络等待超时/);
  });

check('retries already in flight are also stopped by the original global deadline',
  (index, attempt) => index < 6 || attempt === 2 ? flowing : { events: [
    { at: 20_000, bytes: 1 }, { at: 40_000, bytes: 1 },
    { at: 60_000, bytes: 1 }, { at: 80_000, error: true },
  ] }, async h => {
    h.start(); const result = await h.completeAt(180_000);
    assert.equal(h.requests.length, 18);
    const retries = h.requests.filter(item => item.attempt === 2);
    assert.equal(retries.length, 6);
    assert.ok(retries.every(item => item.start === 170_000 && item.abortedAt === 180_000));
    assert.equal(result.completed, 93); assert.equal(new Set(result.failed).size, 93);
    assert.equal(result.aborted, false);
  });

check('external cancellation aborts first attempts without retries or later UI notifications',
  () => flowing, async h => {
    h.start(); await h.clock.advanceTo(12_000);
    const notifications = h.progress.length;
    h.external.abort(); const result = await h.completeAt(12_000);
    assert.equal(result.aborted, true); assert.equal(result.completed, 6);
    assert.equal(h.requests.length, 6); assert.equal(h.progress.length, notifications);
    assert.ok(h.requests.every(item => item.abortedAt === 12_000));
  });

check('external cancellation stops active retry attempts without a third request',
  (_, attempt) => attempt === 1 ? { headers: 1_000, headerError: true } : flowing, async h => {
    h.start(); await h.clock.advanceTo(12_000);
    assert.equal(h.requests.length, 12);
    const notifications = h.progress.length;
    h.external.abort(); const result = await h.completeAt(12_000);
    assert.equal(result.aborted, true); assert.equal(result.completed, 6);
    assert.equal(h.requests.length, 12); assert.equal(h.progress.length, notifications);
    assert.ok(h.requests.filter(item => item.attempt === 2).every(item => item.abortedAt === 12_000));
  });

check('an already-aborted caller starts no requests and receives no progress',
  () => flowing, async h => {
    h.external.abort(); h.start(); const result = await h.completeAt(0);
    assert.equal(result.aborted, true); assert.equal(result.completed, 0);
    assert.equal(h.requests.length, 0); assert.equal(h.progress.length, 0);
  });

check('a retry resets its partial fraction while counting all actually transferred bytes',
  onlyFirst(attempt => attempt === 1 ? { length: 100, events: [
    { at: 1_000, bytes: 50 }, { at: 2_000, error: true },
  ] } : { length: 100, events: [{ at: 1_000, bytes: 20 }, { at: 2_000, done: true }] }), async h => {
    h.start(); await h.clock.advanceTo(1_000);
    assert.equal(h.progress.at(-1).completed, 92);
    assert.equal(h.progress.at(-1).percent, 99);
    assert.equal(h.progress.at(-1).loadedBytes, 142);
    await h.clock.advanceTo(2_000);
    assert.equal(h.progress.at(-1).completed, 92);
    assert.equal(h.progress.at(-1).percent, 98);
    assert.equal(h.progress.at(-1).loadedBytes, 142);
    await h.clock.advanceTo(3_000);
    assert.equal(h.progress.at(-1).completed, 92);
    assert.equal(h.progress.at(-1).loadedBytes, 162);
    success(await h.completeAt(4_000));
    assert.equal(h.progress.at(-1).loadedBytes, 162);
    assert.equal(h.progress.at(-1).percent, 100);
  });

check('response headers renew the idle timer before delayed body bytes arrive',
  onlyFirst({ headers: 25_000, events: [
    { at: 50_000, bytes: 1 }, { at: 60_000, done: true },
  ] }), async h => {
    h.start(); success(await h.completeAt(60_000));
    assert.equal(h.forIndex().length, 1); assert.equal(h.forIndex()[0].abortedAt, null);
  });

check('compressed lengths do not invent a decoded-byte download fraction',
  onlyFirst({ encoding: 'gzip', length: 1, events: [
    { at: 1_000, bytes: 500 }, { at: 2_000, done: true },
  ] }), async h => {
    h.start(); await h.clock.advanceTo(1_000);
    assert.equal(h.progress.at(-1).completed, 92);
    assert.equal(h.progress.at(-1).percent, 98);
    success(await h.completeAt(2_000));
    assert.equal(h.progress.at(-1).loadedBytes, 592);
  });

check('responses without a readable body preserve the arrayBuffer completion path',
  onlyFirst({ bodyNull: true, bufferAt: 2_000, bufferBytes: 7 }), async h => {
    h.start(); success(await h.completeAt(2_000));
    assert.equal(h.forIndex().length, 1); assert.equal(h.forIndex()[0].acquired, 0);
    assert.equal(h.progress.at(-1).loadedBytes, 99);
  });

check('all 93 slots drain through six workers with readers, listeners and timers cleaned',
  () => ({ length: 1, events: [{ at: 500, bytes: 1 }, { at: 1_000, done: true }] }), async h => {
    h.start(); success(await h.completeAt(16_000));
    assert.equal(h.maximumActive, 6); assert.equal(h.requests.length, 93);
    assert.equal(h.requests.at(-1).end, 16_000);
    assert.ok(h.requests.every(item => item.acquired === 1 && item.released === 1));
    assert.ok(h.requests.every(item => !cyclingUrls.includes(item.url)), 'the actual cycling audio files stay out of town startup');
  });

check('a four-file cycling scope fetches only its own URLs and reports its custom progress label',
  () => ({ length: 4, events: [{ at: 100, bytes: 2 }, { at: 200, bytes: 2 }, { at: 250, done: true }] }), async h => {
    const label = '正在准备自行车与路边声音';
    h.start({ urls: cyclingUrls, label });
    success(await h.completeAt(250), 4);
    assert.deepEqual(h.requests.map(request => request.url), cyclingUrls);
    assert.ok(h.requests.every(request => !resources.RESOURCE_URLS.includes(request.url)));
    assert.equal(h.maximumActive, 4);
    assert.equal(h.progress[0].label, label);
    assert.ok(h.progress.slice(0, -1).every(progress => progress.label === label));
    assert.ok(h.progress.some(progress => progress.percent > 0 && progress.percent < 100));
    assert.equal(h.progress.at(-1).loadedBytes, 16);
    assert.equal(h.progress.at(-1).completed, 4);
    assert.equal(h.progress.at(-1).percent, 100);
  });

check('an explicitly empty scope completes without falling back to the town manifest',
  () => instant, async h => {
    h.start({ urls: [], label: '没有需要下载的骑行素材' });
    success(await h.completeAt(0), 0);
    assert.equal(h.requests.length, 0);
    assert.equal(h.progress[0].label, '没有需要下载的骑行素材');
    assert.ok(h.progress.every(progress => progress.total === 0 && progress.percent === 100));
  });

check('a scoped transport failure retries only its own slot and preserves the four-file total',
  onlyFirst(attempt => attempt === 1 ? { headerError: true } : instant), async h => {
    h.start({ urls: cyclingUrls, label: '骑行素材' });
    success(await h.completeAt(0), 4);
    assert.deepEqual(h.forIndex().map(request => request.cache), ['force-cache', 'reload']);
    assert.equal(h.requests.length, 5);
    assert.ok(h.requests.every(request => cyclingUrls.includes(request.url)));
    assert.ok(h.progress.some(progress => /正在重试一次/.test(progress.label)));
    assert.equal(h.progress.at(-1).loadedBytes, 4);
  });

check('a scoped HTTP error fails exactly its own URL without an automatic retry',
  onlyFirst({ status: 503, transportEnd: 120_000 }), async h => {
    h.start({ urls: cyclingUrls, label: '骑行素材' });
    assert.deepEqual(await h.completeAt(0), { failed: [cyclingUrls[0]], completed: 4, total: 4, aborted: false });
    assert.equal(h.requests.length, 4);
    assert.equal(h.forIndex().length, 1);
    assert.equal(h.forIndex()[0].abortedAt, 0);
    assert.equal(h.progress.at(-1).percent, 100);
    assert.match(h.progress.at(-1).label, /部分素材/);
  });

check('manual scoped retries bypass cached failures without fetching town resources',
  () => instant, async h => {
    h.start({ urls: cyclingUrls, label: '重新准备骑行素材', retry: true });
    success(await h.completeAt(0), 4);
    assert.deepEqual(h.requests.map(request => request.url), cyclingUrls);
    assert.ok(h.requests.every(request => request.cache === 'reload'));
  });

check('cancelling a cycling scope stops active retry transfers and all subsequent progress',
  (_, attempt) => attempt === 1 ? { headers: 1_000, headerError: true } : flowing, async h => {
    h.start({ urls: cyclingUrls, label: '骑行素材' });
    await h.clock.advanceTo(12_000);
    assert.equal(h.requests.length, 8);
    const notifications = h.progress.length;
    h.external.abort();
    const result = await h.completeAt(12_000);
    assert.equal(result.aborted, true);
    assert.equal(result.total, 4);
    assert.equal(result.completed, 4);
    assert.deepEqual([...result.failed].sort(), [...cyclingUrls].sort());
    assert.equal(h.progress.length, notifications);
    assert.equal(h.requests.length, 8);
    assert.ok(h.requests.filter(request => request.attempt === 2).every(request => request.abortedAt === 12_000));
  });

check('a pre-cancelled cycling scope never starts requests or publishes loading progress',
  () => instant, async h => {
    h.external.abort(); h.start({ urls: cyclingUrls, label: '骑行素材' });
    assert.deepEqual(await h.completeAt(0), { failed: [], completed: 0, total: 4, aborted: true });
    assert.equal(h.requests.length, 0);
    assert.equal(h.progress.length, 0);
  });

check('scoped retries share the original 90-second deadline and fail only the timed-out cycling slot',
  onlyFirst(attempt => attempt === 1 ? { events: [
    { at: 20_000, bytes: 1 }, { at: 40_000, bytes: 1 },
    { at: 60_000, bytes: 1 }, { at: 80_000, error: true },
  ] } : { events: [{ at: 5_000, bytes: 1 }, { at: 20_000, done: true }] }), async h => {
    h.start({ urls: cyclingUrls, label: '骑行素材' });
    assert.deepEqual(await h.completeAt(90_000), { failed: [cyclingUrls[0]], completed: 4, total: 4, aborted: false });
    assert.equal(h.forIndex().length, 2);
    assert.equal(h.forIndex()[1].start, 80_000);
    assert.equal(h.forIndex()[1].abortedAt, 90_000);
    assert.equal(h.requests.length, 5);
    assert.ok(h.requests.every(request => cyclingUrls.includes(request.url)));
  });

after(async () => {
  await fs.mkdir(output, { recursive: true });
  const report = {
    generatedAt: new Date().toISOString(),
    source: { path: 'src/resources.ts', sha256: sourceHash },
    result: { passed: checks.filter(item => item.passed).length, failed: checks.filter(item => !item.passed).length },
    scope: 'Real TypeScript preload implementation; only Vite manifest/base URL replaced. Deterministic CPU clock/fetch/stream doubles, no browser, real network or cache claim.',
    manifest: { kind: 'fixed town fixture plus actual cycling catalog paths', slots: 93, excludedCyclingFiles: cyclingUrls, scopedSlots: 4 },
    limits: { concurrentRequests: 6, attemptsPerSlot: 2, idleMs: 30_000, slotMs: 90_000, overallMs: 180_000 },
    checks,
  };
  await fs.writeFile(path.join(output, 'resource-preloader-check.json'), `${JSON.stringify(report, null, 2)}\n`);
  console.log(`CPU resource report: ${path.join(output, 'resource-preloader-check.json')}`);
});
