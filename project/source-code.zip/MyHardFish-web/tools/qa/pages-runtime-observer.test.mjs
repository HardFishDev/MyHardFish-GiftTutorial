import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { createHash } from 'node:crypto';
import { runtimeManifest, observeRuntimeResponses, assertRuntimeMatches } from './pages-runtime-observer.mjs';

const base = new URL('https://example.test/game/');
const definitions = [
  ['assets/index-entry.js', 'import("./App-model.js")', 'script', 'text/javascript'],
  ['assets/App-model.js', 'const model = "dbh";', 'script', 'text/javascript'],
  ['assets/dbh-character-detail.js', 'const face = "sculpted";', 'script', 'application/javascript'],
  ['assets/index-style.css', 'body { margin: 0 }', 'stylesheet', 'text/css'],
];
const files = definitions.map(([path, text]) => ({ path, bytes: Buffer.byteLength(text), sha256: createHash('sha256').update(text).digest('hex') }));
const manifest = runtimeManifest({ files });
function fixture() {
  const page = new EventEmitter(), result = {}, observer = observeRuntimeResponses(page, result, base);
  const receive = (index, overrides = {}) => {
    const [filename, text, type, contentType] = definitions[index];
    page.emit('requestfinished', {
      url: () => overrides.url || new URL(filename, base).href,
      resourceType: () => type,
      response: async () => ({ status: () => overrides.status || 200,
        headers: () => ({ 'content-type': overrides.contentType || contentType }),
        body: async () => {
          if (overrides.error) throw overrides.error;
          return Buffer.from(overrides.body ?? text);
        } }),
    });
  };
  return { result, observer, receive };
}

test('hashes actual entry, lazy App, separate model module and CSS responses', async () => {
  const f = fixture(); definitions.forEach((_, i) => f.receive(i)); await f.observer.settle();
  const report = assertRuntimeMatches(f.result, manifest);
  assert.deepEqual(report.loaded, files.map(file => file.path).sort());
  assert.deepEqual(report.modelModules, ['assets/App-model.js', 'assets/dbh-character-detail.js']);
});
test('manifest entries cannot substitute for missing dynamic model requests', async () => {
  const f = fixture(); [0, 1, 3].forEach(f.receive); await f.observer.settle();
  assert.throws(() => assertRuntimeMatches(f.result, manifest), /never received.*dbh-character/);
});
test('a module with the right length but different bytes fails SHA validation', async () => {
  const f = fixture(); definitions.forEach((_, i) => f.receive(i, i === 1 ? { body: 'X'.repeat(files[i].bytes) } : {}));
  await f.observer.settle(); assert.throws(() => assertRuntimeMatches(f.result, manifest), /SHA256/);
});
test('a completed but unlisted runtime module fails', async () => {
  const f = fixture(); definitions.forEach((_, i) => f.receive(i));
  f.receive(0, { url: new URL('assets/unlisted.js', base).href });
  await f.observer.settle(); assert.throws(() => assertRuntimeMatches(f.result, manifest), /absent from deployment inventory/);
});
test('incorrect CSS MIME and module HTTP status each fail', async () => {
  for (const overrides of [{ contentType: 'text/plain' }, { status: 404 }]) {
    const f = fixture(); definitions.forEach((_, i) => f.receive(i, i === 3 ? overrides : {}));
    await f.observer.settle(); assert.throws(() => assertRuntimeMatches(f.result, manifest), /content type|HTTP status/);
  }
});
test('incomplete response bodies and foreign modules remain failures', async () => {
  for (const overrides of [{ error: new Error('body transport failed') }, { url: 'https://elsewhere.test/index.js' }]) {
    const f = fixture(); definitions.forEach((_, i) => f.receive(i, i === 0 ? overrides : {}));
    await f.observer.settle(); assert.throws(() => assertRuntimeMatches(f.result, manifest), /response capture failed/);
  }
});
test('inventory must include a valid, unique lazy App/model entry', () => {
  assert.throws(() => runtimeManifest({ files: files.filter(file => !file.path.includes('App-')) }), /Missing lazy App/);
  assert.throws(() => runtimeManifest({ files: [...files, files[0]] }), /Duplicate runtime module/);
  assert.throws(() => runtimeManifest({ files: files.map(file => ({ ...file, sha256: 'bad' })) }));
});
