import { chromium, expect } from '@playwright/test';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';

const output = fileURLToPath(new URL('../../../research/game/', import.meta.url));
const project = fileURLToPath(new URL('../../', import.meta.url));
await fs.mkdir(output, { recursive: true });
const fixtureModule = await build({ entryPoints: [path.join(project, 'src/engine.ts')], bundle: true, write: false, platform: 'node', format: 'esm' });
const { newGame } = await import(`data:text/javascript;base64,${Buffer.from(fixtureModule.outputFiles[0].text).toString('base64')}`);
const fixture = newGame();
fixture.settings.voice = false;
fixture.bond = 80;
fixture.shells = 1000;
const browser = await chromium.launch({ executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath(), args: ['--no-sandbox', '--enable-unsafe-swiftshader'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1 });
page.setDefaultTimeout(20000);
const report = { checkedAt: new Date().toISOString(), baseURL: process.env.GAME_URL || 'http://localhost:5173/', scenes: [], previews: [], outfits: [], errors: [] };
page.on('pageerror', (e) => report.errors.push(e.message));
page.on('console', (m) => { if (m.type() === 'error') report.errors.push(m.text()); });
const close = () => page.getByRole('button', { name: '关闭窗口', exact: true }).click();
const menu = async (name) => {
  await page.getByRole('button', { name: '打开生活菜单', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name, exact: true }).click();
};
const travel = async (name, id) => {
  await page.getByRole('button', { name: '打开地图', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name, exact: true }).click();
  await expect(page.getByTestId('scene')).toHaveAttribute('data-place', id);
  // Wait for rendering, rather than sleeping for an assumed loading duration.
  await page.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
};
try {
  // Seed before the application starts; changing live storage before reload is
  // overwritten by the application's legitimate beforeunload autosave.
  await page.addInitScript((state) => {
    if (!localStorage.getItem('hardfish.save.v1')) localStorage.setItem('hardfish.save.v1', JSON.stringify(state));
  }, fixture);
  await page.goto(report.baseURL, { waitUntil: 'domcontentloaded' });
  await expect(page.getByTestId('scene')).toHaveAttribute('data-ready', 'true', { timeout: 60000 });
  await expect.poll(() => page.evaluate(() => {
    const state = JSON.parse(localStorage.getItem('hardfish.save.v1'));
    // Bond-based achievements can legitimately grant shells on the first tick.
    return { bond: state.bond, enoughShells: state.shells >= 1000, voice: state.settings.voice };
  })).toEqual({ bond: 80, enoughShells: true, voice: false });
  const scene = page.getByTestId('scene');
  await expect(scene).toHaveAttribute('data-ready', 'true', { timeout: 60000 });
  for (const [name, id] of [['小窝', 'home'], ['厨房', 'kitchen'], ['公园', 'park'], ['便利店', 'shop'], ['教室', 'school']]) {
    console.log(`Tour scene: ${id}`);
    await travel(name, id);
    await scene.screenshot({ path: path.join(output, `scene-${id}.png`), animations: 'disabled' });
    const preview = await scene.locator('canvas').evaluate((canvas) => {
      const target = document.createElement('canvas');
      target.width = 560; target.height = 350;
      const context = target.getContext('2d');
      const aspect = target.width / target.height;
      const width = Math.min(canvas.width, canvas.height * aspect);
      const height = width / aspect;
      context.drawImage(canvas, (canvas.width - width) / 2, (canvas.height - height) / 2, width, height, 0, 0, target.width, target.height);
      return target.toDataURL('image/webp', 0.85);
    });
    expect(preview.startsWith('data:image/webp;base64,')).toBe(true);
    const bytes = Buffer.from(preview.split(',')[1], 'base64');
    expect(bytes.length).toBeGreaterThan(1000);
    for (const folder of ['public/assets', 'dist/assets']) {
      await fs.mkdir(path.join(project, folder), { recursive: true });
      await fs.writeFile(path.join(project, folder, `world-${id}.webp`), bytes);
    }
    report.previews.push({ id, file: `assets/world-${id}.webp`, width: 560, height: 350, bytes: bytes.length });
    report.scenes.push(id);
  }
  await travel('小窝', 'home');
  for (const [name, id] of [['薄荷围巾', 'mint'], ['暴躁主厨', 'chef'], ['放学别走', 'student'], ['晚安喵', 'night'], ['原装难鱼', 'classic']]) {
    console.log(`Tour outfit: ${id}`);
    await menu('衣柜');
    const card = page.locator('.outfit-card').filter({ has: page.getByRole('heading', { name, exact: true }) });
    await card.getByRole('button', { name: /买下并换上|换上这件/ }).click();
    await expect(scene).toHaveAttribute('data-outfit', id);
    await close();
    await scene.screenshot({ path: path.join(output, `outfit-${id}.png`), animations: 'disabled' });
    report.outfits.push(id);
  }
  await menu('衣柜');
  await page.screenshot({ path: path.join(output, 'closet-desktop.png'), animations: 'disabled' });
  await close();
  await page.getByRole('button', { name: '群友圈', exact: true }).click();
  await expect(page.getByRole('dialog')).toContainText('jin佬');
  await page.screenshot({ path: path.join(output, 'friends-desktop.png'), animations: 'disabled' });
  await close();
  await page.getByRole('button', { name: /^聊聊天/ }).click();
  await page.getByRole('tab', { name: '小故事', exact: true }).click();
  await page.getByRole('button', { name: /谢谢，但蛋糕先不用/ }).click();
  await expect(page.getByRole('button', { name: '那就只留一张祝福卡', exact: true })).toBeVisible();
  await page.screenshot({ path: path.join(output, 'story-desktop.png'), animations: 'disabled' });
  expect(report.errors).toEqual([]);
  report.result = 'pass';
} catch (error) {
  report.result = 'fail';
  report.failure = error.stack || String(error);
  process.exitCode = 1;
} finally {
  await fs.writeFile(path.join(output, 'tour-check.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
  await browser.close();
}
