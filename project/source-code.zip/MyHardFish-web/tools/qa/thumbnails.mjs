import { chromium } from '@playwright/test';
import fs from 'node:fs/promises';
const browser=await chromium.launch({executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath(),args:['--no-sandbox','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1280,height:800}});
await page.goto(process.env.GAME_URL||'http://localhost:5173');
await page.waitForFunction(()=>document.querySelector('[data-testid="scene"]')?.dataset.ready==='true');
for(const [id,label] of [['home','小窝'],['kitchen','厨房'],['park','公园'],['shop','便利店'],['school','教室']]) {
  if(id!=='home') {
    await page.getByRole('button',{name:'打开地图',exact:true}).click();
    await page.getByRole('button',{name:label,exact:true}).click();
  }
  await page.waitForFunction(id=>document.querySelector('[data-testid="scene"]')?.dataset.place===id,id);
  await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  const data=await page.evaluate(()=>{
    const source=document.querySelector('[data-testid="scene"] canvas');
    const preview=document.createElement('canvas');preview.width=560;preview.height=350;
    preview.getContext('2d').drawImage(source,0,0,560,350);
    return preview.toDataURL('image/webp',.85).split(',')[1];
  });
  await fs.writeFile(`public/assets/world-${id}.webp`,Buffer.from(data,'base64'));
}
await browser.close();
