import * as THREE from 'three';
import { NanyuCharacter } from '/qa/model.js';

const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.setSize(760, 900); renderer.setPixelRatio(1);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1;
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
document.body.appendChild(renderer.domElement);
const scene = new THREE.Scene(); scene.background = new THREE.Color('#d9dde0');
scene.add(new THREE.HemisphereLight('#f4f8ff', '#847c6d', 1.65));
function lamp(color, intensity, position, shadow = false) {
  const light = new THREE.DirectionalLight(color, intensity); light.position.set(...position);
  light.castShadow = shadow;
  if (shadow) { light.shadow.mapSize.set(1024, 1024); Object.assign(light.shadow.camera, { left: -4, right: 4, top: 5, bottom: -4, near: .1, far: 20 }); light.shadow.bias = -.0003; light.shadow.normalBias = .025; }
  scene.add(light); return light;
}
lamp('#fff2df', 3.1, [-3, 7, 5], true); lamp('#dcecff', 1.1, [4, 4, 1]); lamp('#ffffff', 1.7, [0, 5, -5]);
const floor = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), new THREE.MeshStandardMaterial({ color: '#bdc3c7', roughness: .88 }));
floor.rotation.x = -Math.PI / 2; floor.position.y = -.013; floor.receiveShadow = true; scene.add(floor);
const viewHeight = 4.85, aspect = 760 / 900;
const camera = new THREE.OrthographicCamera(-viewHeight * aspect / 2, viewHeight * aspect / 2, viewHeight / 2, -viewHeight / 2, .1, 40);
let model, elapsed = 0, constructorMs = 0;
function render() { scene.updateMatrixWorld(true); renderer.render(scene, camera); }
function view(name) {
  const positions = { front: [0, 2.4, 9], side: [9, 2.4, 0], back: [0, 2.4, -9], quarter: [6, 3, 8] };
  camera.position.set(...positions[name]); camera.lookAt(0, 2.02, 0); render();
}
function inventory() {
  const geos = new Set(), materials = new Set(), textures = new Set(); let bytes = 0, meshes = 0, vertices = 0;
  model?.root.traverse(node => {
    if (!node.isMesh) return; meshes++;
    const g = node.geometry;
    if (!geos.has(g)) { geos.add(g); vertices += g.attributes.position?.count || 0; for (const attr of Object.values(g.attributes)) bytes += attr.array?.byteLength || 0; for (const attrs of Object.values(g.morphAttributes)) for (const attr of attrs) bytes += attr.array?.byteLength || 0; bytes += g.index?.array.byteLength || 0; }
    for (const m of Array.isArray(node.material) ? node.material : [node.material]) { materials.add(m); for (const v of Object.values(m)) if (v?.isTexture) textures.add(v); }
  });
  const box = model ? new THREE.Box3().setFromObject(model.root) : null;
  return { meshes, geometries: geos.size, materials: materials.size, textures: textures.size, geometryBytes: bytes, vertices, bounds: box && { min: box.min.toArray(), max: box.max.toArray() }, renderer: { ...renderer.info.render }, memory: { ...renderer.info.memory }, programs: renderer.info.programs.length };
}
async function make() {
  if (model) { scene.remove(model.root); model.dispose(); render(); }
  const started = performance.now(); model = new NanyuCharacter(); constructorMs = performance.now() - started;
  scene.add(model.root); elapsed = 0;
  const startedWait = performance.now();
  while (model.root.userData.ready === false && performance.now() - startedWait < 15000) await new Promise(r => setTimeout(r, 25));
  // Old model signals readiness only after its asynchronous image has loaded.
  if (model.root.userData.ready === undefined) await new Promise(r => setTimeout(r, 350));
  model.update(0, 0, 'idle', false); render(); return { constructorMs, ...inventory() };
}
function update(mode = 'idle', frames = 1, dt = 1 / 60) {
  for (let i = 0; i < frames; i++) { elapsed += dt; model.update(elapsed, dt, mode, mode === 'walk'); }
  render(); return inventory();
}
function pose() {
  model.root.updateMatrixWorld(true); const values = [], point = new THREE.Vector3();
  model.root.traverseVisible(node => {
    if (!node.isMesh) return;
    const attr = node.geometry.attributes.position; if (!attr) return;
    values.push(...node.matrixWorld.elements);
    for (let j = 0; j < Math.min(32, attr.count); j++) {
      const index = Math.floor(j * (attr.count - 1) / 31);
      node.getVertexPosition(index, point); point.applyMatrix4(node.matrixWorld); values.push(point.x, point.y, point.z);
    }
  }); return values;
}
function namedNodes() {
  const nodes = []; model.root.updateMatrixWorld(true);
  model.root.traverse(node => { if (node.name || node.userData.qaRole) nodes.push({ name: node.name, role: node.userData.qaRole, type: node.type, position: node.getWorldPosition(new THREE.Vector3()).toArray(), bounds: node.isMesh || node.isGroup ? (() => { const b = new THREE.Box3().setFromObject(node); return { min: b.min.toArray(), max: b.max.toArray() }; })() : null }); }); return nodes;
}

function allocationIds() {
  const geometries = new Set(), materials = new Set(), textures = new Set();
  model.root.traverse(node => {
    if (!node.isMesh) return;
    geometries.add(node.geometry.uuid);
    for (const m of Array.isArray(node.material) ? node.material : [node.material]) {
      materials.add(m.uuid); for (const value of Object.values(m)) if (value?.isTexture) textures.add(value.uuid);
    }
  }); return { geometries: [...geometries].sort(), materials: [...materials].sort(), textures: [...textures].sort() };
}
function geometryCheck() {
  const checked = new Set(), errors = []; let vertexCount = 0, morphCount = 0;
  model.root.traverse(node => {
    if (!node.isMesh || checked.has(node.geometry)) return;
    const g = node.geometry; checked.add(g);
    const count = g.attributes.position?.count || 0; vertexCount += count;
    if (!count) errors.push(`${node.name}: empty geometry`);
    for (const [name, attr] of Object.entries(g.attributes)) for (const value of attr.array) if (!Number.isFinite(value)) { errors.push(`${node.name}: nonfinite ${name}`); break; }
    if (g.index) for (const index of g.index.array) if (index < 0 || index >= count) { errors.push(`${node.name}: index out of bounds`); break; }
    for (const [name, attrs] of Object.entries(g.morphAttributes)) for (const attr of attrs) {
      morphCount++; if (attr.count !== count) errors.push(`${node.name}: ${name} morph vertex count mismatch`);
      for (const value of attr.array) if (!Number.isFinite(value)) { errors.push(`${node.name}: nonfinite morph ${name}`); break; }
    }
  }); return { geometries: checked.size, vertices: vertexCount, morphAttributes: morphCount, errors };
}
function anatomy() {
  model.root.updateMatrixWorld(true);
  const nodes = [];
  model.root.traverse(node => nodes.push(node));
  const get = role => nodes.find(n => n.userData.qaRole === role || n.name === role);
  const worldPoint = node => node?.getWorldPosition(new THREE.Vector3());
  const point = new THREE.Vector3();
  function meshBounds(node) {
    const box = new THREE.Box3(); let count = 0;
    node?.traverse(mesh => { if (!mesh.isMesh) return; const positions = mesh.geometry.attributes.position; for (let i = 0; i < positions.count; i++) { mesh.getVertexPosition(i, point); point.applyMatrix4(mesh.matrixWorld); box.expandByPoint(point); count++; } });
    return count ? { min: box.min.toArray(), max: box.max.toArray(), vertexCount: count } : null;
  }
  function nearest(node, target) {
    if (!node || !target) return null;
    let distance = Infinity;
    node.traverse(mesh => { if (!mesh.isMesh) return; const positions = mesh.geometry.attributes.position; for (let i = 0; i < positions.count; i++) { mesh.getVertexPosition(i, point); point.applyMatrix4(mesh.matrixWorld); distance = Math.min(distance, point.distanceTo(target)); } });
    return Number.isFinite(distance) ? distance : null;
  }
  const sides = {};
  for (const side of ['left', 'right']) {
    const foot = get(`${side}-foot`), hand = get(`${side}-hand`), arm = get(`${side}-arm`);
    const shoulder = get(`${side}-shoulder`), wrist = get(`${side}-wrist`), ankle = get(`${side}-ankle`);
    const whiteLeg = get(`${side}-white-leg`), shin = get(`${side}-shin`), body = get('body');
    const shoulderPoint = worldPoint(shoulder), wristPoint = worldPoint(wrist), anklePoint = worldPoint(ankle), whiteLegPoint = worldPoint(whiteLeg);
    const footBounds = meshBounds(foot), handBounds = meshBounds(hand);
    sides[side] = {
      roles: { foot: !!foot, hand: !!hand, arm: !!arm, shoulder: !!shoulder, wrist: !!wrist, ankle: !!ankle, whiteLeg: !!whiteLeg, shin: !!shin, body: !!body },
      footBounds, handBounds,
      shoulder: shoulderPoint?.toArray(), wrist: wristPoint?.toArray(), ankle: anklePoint?.toArray(),
      armToShoulder: nearest(arm, shoulderPoint), armToWrist: nearest(arm, wristPoint), handToWrist: nearest(hand, wristPoint), footToAnkle: nearest(foot, anklePoint), shinToAnkle: nearest(shin, anklePoint), shinToWhiteLeg: nearest(shin, whiteLegPoint), whiteLegToBody: nearest(body, whiteLegPoint),
    };
  }
  return sides;
}


function limbWinding() {
  const result = [], a = new THREE.Vector3(), b = new THREE.Vector3(), c = new THREE.Vector3(), edge = new THREE.Vector3(), face = new THREE.Vector3(), normal = new THREE.Vector3(), n = new THREE.Vector3();
  model.root.traverse(mesh => {
    const role = mesh.userData.qaRole || mesh.name;
    if (!mesh.isMesh || !/^(left|right)-(arm|shin)$/.test(role)) return;
    const g = mesh.geometry, index = g.index, positions = g.attributes.position, normals = g.attributes.normal;
    let triangles = 0, degenerate = 0, sameDirection = 0, opposite = 0, minimumDot = 1, dotSum = 0, nonfinite = 0;
    const size = index ? index.count : positions.count;
    for (let i = 0; i + 2 < size; i += 3) {
      const ia = index ? index.getX(i) : i, ib = index ? index.getX(i + 1) : i + 1, ic = index ? index.getX(i + 2) : i + 2;
      mesh.getVertexPosition(ia, a); mesh.getVertexPosition(ib, b); mesh.getVertexPosition(ic, c);
      edge.subVectors(b, a); face.subVectors(c, a); face.crossVectors(edge, face);
      if (face.lengthSq() < 1e-16) { degenerate++; continue; }
      face.normalize(); normal.fromBufferAttribute(normals, ia); normal.add(n.fromBufferAttribute(normals, ib)); normal.add(n.fromBufferAttribute(normals, ic)).normalize();
      const dot = face.dot(normal); triangles++;
      if (!Number.isFinite(dot)) { nonfinite++; continue; }
      dotSum += dot; minimumDot = Math.min(minimumDot, dot); if (dot > 0) sameDirection++; else opposite++;
    }
    result.push({ role, triangles, degenerate, nonfinite, sameDirection, opposite, fraction: triangles ? sameDirection / triangles : 0, minimumDot, meanDot: triangles ? dotSum / triangles : null });
  }); return result;
}


function mouthPose() {
  let body, mouth;
  model.root.traverse(node => { if (node.userData.qaRole === 'body') body = node; if (node.userData.qaRole === 'mouth-expression') mouth = node; });
  if (!body || !mouth) return { found: false };
  model.root.updateMatrixWorld(true);
  const anchor = body.worldToLocal(mouth.getWorldPosition(new THREE.Vector3())).toArray(), meshCenters = [];
  mouth.traverse(mesh => {
    if (!mesh.isMesh) return;
    const center = new THREE.Vector3(); mesh.geometry.computeBoundingBox(); mesh.geometry.boundingBox.getCenter(center);
    mesh.localToWorld(center); body.worldToLocal(center); meshCenters.push(center.toArray());
  }); return { found: true, visible: mouth.visible, anchor, meshCenters };
}

view('front'); const stage = { memory: { ...renderer.info.memory }, render: { ...renderer.info.render }, programs: renderer.info.programs.length };
window.qa = {
  ready: false, make, view, inventory, pose, namedNodes, update, geometryCheck, anatomy, allocationIds, limbWinding, mouthPose,
  webglHealth() { const gl = renderer.getContext(); return { contextLost: gl.isContextLost(), glError: gl.getError(), version: gl.getParameter(gl.VERSION), renderer: gl.getParameter(gl.RENDERER) }; },
  outfit(id) { const start = performance.now(); model.setOutfit(id); const cpuMs = performance.now() - start; model.update(elapsed, 0, 'idle', false); render(); return { cpuMs, ...inventory() }; },
  motion(mode, frames = 105) { model.startMotion?.(mode); return update(mode, frames); },
  quality(low) { const supported = typeof model.setQuality === 'function'; model.setQuality?.(low); renderer.shadowMap.enabled = !low; scene.traverse(node => { if (node.isMesh) for (const m of Array.isArray(node.material) ? node.material : [node.material]) m.needsUpdate = true; }); render(); return { supported, low, ...inventory() }; },
  dispose() { const before = inventory(); scene.remove(model.root); model.dispose(); model = null; render(); return { before, stage, after: { memory: { ...renderer.info.memory }, programs: renderer.info.programs.length } }; },
  get constructorMs() { return constructorMs; },
  get modelReady() { return model.root.userData.ready; },
};
await make(); window.qa.ready = true;
