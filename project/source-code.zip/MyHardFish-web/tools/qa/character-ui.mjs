import { chromium, expect } from '@playwright/test';
import { build } from 'esbuild';
import { unzipSync, strFromU8 } from 'fflate';
import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import http from 'node:http';

// Actual final build and public controls. Only the desktop wardrobe fixture is seeded.
const project = fileURLToPath(new URL('../../', import.meta.url));
const output = path.resolve(project, '../research/character-v4');
await fs.mkdir(output, { recursive: true });
let baseURL = process.env.QA_BASE_URL;
let server;
if (!baseURL) {
  const dist = path.join(project, 'dist');
  const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.mp3': 'audio/mpeg', '.txt': 'text/plain; charset=utf-8' };
  server = http.createServer(async (req, res) => {
    try {
      const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
      if (!pathname.startsWith('/dist/')) { res.writeHead(404).end(); return; }
      const filename = path.resolve(dist, pathname.slice('/dist/'.length) || 'index.html');
      if (!filename.startsWith(dist + path.sep)) { res.writeHead(403).end(); return; }
      const bytes = await fs.readFile(filename);
      res.writeHead(200, { 'Content-Type': mime[path.extname(filename)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
      res.end(req.method === 'HEAD' ? undefined : bytes);
    } catch { res.writeHead(404).end(); }
  });
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  baseURL = `http://127.0.0.1:${server.address().port}/dist/`;
}
const base = new URL(baseURL);
if (base.pathname !== '/dist/') throw Error('Use the plain static /dist/ server.');
const bundled = await build({ entryPoints: [path.join(project, 'src/engine.ts')], bundle: true, write: false, platform: 'node', format: 'esm' });
const { newGame } = await import(`data:text/javascript;base64,${Buffer.from(bundled.outputFiles[0].text).toString('base64')}`);
const fixture = newGame();
fixture.owned = ['classic', 'mint', 'chef', 'student', 'night'];
const index = await fs.readFile(path.join(project, 'dist/index.html'), 'utf8');
const entryBundle = index.match(/src="\.\/([^" ]+\.js)"/)?.[1];
if (!entryBundle) throw Error('No relative entry bundle in dist.');
const assetFiles = ['index.html', entryBundle, ...[...index.matchAll(/href="\.\/([^" ]+\.css)"/g)].map(m => m[1])];
const files = await Promise.all(assetFiles.map(async file => {
  const bytes = await fs.readFile(path.join(project, 'dist', file));
  return { file, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') };
}));
const report = {
  version: '1.2.0', checkedAt: new Date().toISOString(),
  scope: 'Final static build: desktop plus two portrait widths, public gesture/food/wardrobe/quality/movement controls, native voice/photo/ZIP, saved outfit reload. Character close-up geometry and motion are checked separately in character-check.json.',
  baseURL, testedBuild: { version: '1.2.0', pathBase: 'code/', entryBundle, files: Object.fromEntries(files.map(({ file, ...meta }) => ['dist/' + file, meta])) },
  fixture: 'Desktop alone starts with five owned outfits; all other values are newGame defaults. Mobile and narrow begin with empty storage. No fixture ships in dist.',
  checks: [], status: 'pending',
  limits: ['Software Chromium WebGL is not a physical phone FPS/battery measurement.', 'No full story/quest campaign replay in this character-only release.'],
};
const browser = await chromium.launch({ executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath(), args: ['--no-sandbox', '--enable-unsafe-swiftshader'] });
const menu = async (page, label) => {
  await page.getByRole('button', { name: '打开生活菜单', exact: true }).click();
  if (label) await page.getByRole('dialog').getByRole('button', { name: label, exact: true }).click();
};
const close = page => page.getByRole('button', { name: '关闭窗口', exact: true }).click();
const frame = page => page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
async function screenshot(page, filename) {
  await frame(page);
  await page.screenshot({ path: path.join(output, filename), animations: 'disabled' });
  return filename;
}
async function layout(page) {
  const measured = await page.evaluate(() => {
    const canvas = document.querySelector('[data-testid="scene"] canvas');
    const r = canvas.getBoundingClientRect();
    const sample = document.createElement('canvas'); sample.width = sample.height = 40;
    const ctx = sample.getContext('2d'); ctx.drawImage(canvas, 0, 0, 40, 40);
    const pixels = ctx.getImageData(0, 0, 40, 40).data, colors = new Set();
    for (let i = 0; i < pixels.length; i += 4) colors.add(`${pixels[i] >> 4},${pixels[i + 1] >> 4},${pixels[i + 2] >> 4}`);
    return { width: innerWidth, height: innerHeight, dpr: devicePixelRatio, scrollWidth: document.documentElement.scrollWidth, canvas: { x: r.x, y: r.y, width: r.width, height: r.height, backingWidth: canvas.width, backingHeight: canvas.height }, colors: colors.size };
  });
  expect(measured.scrollWidth).toBeLessThanOrEqual(measured.width);
  expect(measured.canvas.width * measured.canvas.height / (measured.width * measured.height)).toBeGreaterThanOrEqual(.98);
  expect(measured.colors).toBeGreaterThan(16);
  expect(measured.canvas.backingWidth / measured.canvas.width).toBeLessThanOrEqual(1.66);
  return measured;
}
try {
  const sizes = [['desktop', { width: 1440, height: 1000 }], ['mobile', { width: 390, height: 844 }], ['narrow', { width: 320, height: 740 }]];
  for (const [name, viewport] of sizes) {
    console.log('Character UI: ' + name);
    const context = await browser.newContext({ viewport, deviceScaleFactor: name === 'mobile' ? 3 : 1, hasTouch: name !== 'desktop', isMobile: name !== 'desktop' });
    if (name === 'desktop') await context.addInitScript(state => {
      if (!localStorage.getItem('hardfish.save.v1')) localStorage.setItem('hardfish.save.v1', JSON.stringify(state));
    }, fixture);
    await context.addInitScript(() => {
      window.__qaAudio = [];
      const play = HTMLMediaElement.prototype.play;
      HTMLMediaElement.prototype.play = function (...args) {
        const entry = { src: this.currentSrc || this.src, playing: false };
        window.__qaAudio.push(entry);
        this.addEventListener('playing', () => { entry.playing = true; entry.duration = this.duration; }, { once: true });
        return play.apply(this, args);
      };
    });
    const page = await context.newPage(); page.setDefaultTimeout(30000);
    const pending = new Set();
    const result = { name, viewport, errors: [], external: [], outsideSubpath: [], failedRequests: [], badResponses: [], views: [], actions: [], status: 'pending' };
    page.on('pageerror', e => result.errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error') result.errors.push(m.text()); });
    page.on('request', r => {
      if (/^(data|blob):/.test(r.url())) return;
      pending.add(r); const url = new URL(r.url());
      if (url.origin !== base.origin) result.external.push(r.url());
      else if (!url.pathname.startsWith(base.pathname)) result.outsideSubpath.push(r.url());
    });
    page.on('requestfinished', r => pending.delete(r));
    page.on('requestfailed', r => { pending.delete(r); result.failedRequests.push({ url: r.url(), error: r.failure()?.errorText }); });
    page.on('response', r => { if (r.status() >= 400) result.badResponses.push({ url: r.url(), status: r.status() }); });
    try {
      await page.goto(baseURL, { waitUntil: 'domcontentloaded' });
      const scene = page.getByTestId('scene');
      await expect(scene).toHaveAttribute('data-ready', 'true', { timeout: 60000 });
      await expect(scene).toHaveAttribute('data-triangles', /\d+/);
      await expect.poll(() => pending.size).toBe(0);
      result.layout = await layout(page);
      result.sceneResources = await scene.evaluate(el => ({ drawCalls: Number(el.dataset.drawCalls), triangles: Number(el.dataset.triangles), geometries: Number(el.dataset.geometries), textures: Number(el.dataset.textures) }));
      result.views.push(await screenshot(page, `game-${name}.png`));

      // Public greeting starts a fresh animation and uses the existing authorized voice clip.
      await menu(page); await page.getByRole('button', { name: '打个招呼', exact: true }).click();
      await expect(page.getByRole('dialog')).toHaveCount(0);
      await expect(scene).toHaveAttribute('data-motion', 'happy');
      await expect.poll(() => page.evaluate(() => window.__qaAudio.some(a => a.src.endsWith('/audio/greeting.mp3') && a.playing && a.duration > 0))).toBe(true);
      result.audio = await page.evaluate(() => window.__qaAudio);
      result.actions.push('wave + native greeting audio');
      result.views.push(await screenshot(page, `wave-${name}.png`));
      await menu(page, '设置'); await page.getByRole('checkbox', { name: /难鱼开麦/ }).uncheck(); await close(page);

      await page.getByRole('button', { name: '给她投喂', exact: true }).click();
      const hunger = Number(await page.getByTestId('hunger').textContent());
      await page.getByRole('button', { name: '投喂热乎小包子', exact: true }).click();
      await expect(page.getByRole('dialog')).toHaveCount(0);
      await expect(scene).toHaveAttribute('data-motion', 'eat');
      await expect(page.getByTestId('hunger')).toHaveText(String(Math.min(100, hunger + 22)));
      result.actions.push('feed consumes food, raises hunger and closes modal to show eating');
      result.views.push(await screenshot(page, `eat-${name}.png`));

      await page.getByRole('button', { name: /^聊聊天/ }).click();
      await page.getByRole('button', { name: /故意逗她一下/ }).click();
      await expect(page.getByRole('dialog')).toHaveCount(0);
      await expect(scene).toHaveAttribute('data-motion', 'angry');
      result.actions.push('tease reveals angry pose');
      result.views.push(await screenshot(page, `angry-${name}.png`));

      for (const [label, motion] of [['叫她摇一个', 'dance'], ['歇一会儿', 'sleep']]) {
        await menu(page); await page.getByRole('button', { name: label, exact: true }).click();
        await expect(page.getByRole('dialog')).toHaveCount(0);
        await expect(scene).toHaveAttribute('data-motion', motion);
        result.actions.push(label + ' -> ' + motion);
        result.views.push(await screenshot(page, `${motion}-${name}.png`));
      }

      // New manual movement must interrupt sleep and move her in the real world.
      const before = await scene.getAttribute('data-position');
      if (name === 'desktop') {
        await scene.locator('canvas').focus(); await page.keyboard.down('ArrowRight');
        try { await expect(scene).not.toHaveAttribute('data-position', before); await expect(scene).toHaveAttribute('data-walking', 'true'); }
        finally { await page.keyboard.up('ArrowRight'); }
      } else {
        const stick = page.getByRole('button', { name: '拖动摇杆移动难鱼', exact: true });
        const b = await stick.boundingBox();
        await page.mouse.move(b.x + b.width / 2, b.y + b.height / 2); await page.mouse.down();
        try {
          await page.mouse.move(b.x + b.width / 2 + 25, b.y + b.height / 2);
          await expect(scene).not.toHaveAttribute('data-position', before);
          await expect(scene).toHaveAttribute('data-walking', 'true');
        } finally { await page.mouse.up(); }
      }
      await expect(scene).toHaveAttribute('data-motion', 'idle');
      result.actions.push('manual movement interrupts sleep; position and walking state change');

      if (name === 'desktop') {
        for (const [id, label] of [['mint', '薄荷围巾'], ['chef', '暴躁主厨'], ['student', '放学别走'], ['night', '晚安喵'], ['classic', '原装难鱼']]) {
          await menu(page, '衣柜');
          await page.locator('.outfit-card').filter({ has: page.getByRole('heading', { name: label, exact: true }) }).getByRole('button', { name: '换上这件', exact: true }).click();
          await expect(scene).toHaveAttribute('data-outfit', id); await close(page);
          result.views.push(await screenshot(page, `wardrobe-${id}-game.png`));
        }
        result.actions.push('five owned outfits equipped through wardrobe controls');
      } else {
        await menu(page, '衣柜');
        await page.locator('.outfit-card').filter({ has: page.getByRole('heading', { name: '薄荷围巾', exact: true }) }).getByRole('button', { name: /买下并换上/ }).click();
        await expect(scene).toHaveAttribute('data-outfit', 'mint'); await close(page);
        result.actions.push('mint purchased and equipped from fresh save');
      }
      const outfit = await scene.getAttribute('data-outfit');
      await menu(page, '设置'); await page.getByRole('checkbox', { name: /轻量画面/ }).check(); await close(page);
      await expect(scene).toHaveAttribute('data-quality', 'low');
      await frame(page); result.lowQualityLayout = await layout(page);
      result.views.push(await screenshot(page, `low-quality-${name}.png`));
      await menu(page, '设置'); await page.getByRole('checkbox', { name: /轻量画面/ }).uncheck(); await close(page);
      await expect(scene).toHaveAttribute('data-quality', 'high');
      result.actions.push('quality high -> low -> high without losing outfit');

      const photoPromise = page.waitForEvent('download');
      await page.getByRole('button', { name: '拍张难鱼的照片', exact: true }).click();
      const photo = await photoPromise; const photoBytes = await fs.readFile(await photo.path());
      expect(photoBytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))).toBe(true);
      expect(photoBytes.length).toBeGreaterThan(10000);
      result.photo = { bytes: photoBytes.length, width: photoBytes.readUInt32BE(16), height: photoBytes.readUInt32BE(20) };
      await photo.saveAs(path.join(output, `photo-${name}.png`));
      await menu(page, '存档');
      const zipPromise = page.waitForEvent('download'); await page.getByRole('button', { name: '导出 ZIP', exact: true }).click();
      const zip = await zipPromise; const zipBytes = await fs.readFile(await zip.path());
      const archive = unzipSync(zipBytes), manifest = JSON.parse(strFromU8(archive['manifest.json'])), state = JSON.parse(strFromU8(archive['save.json']));
      expect(manifest).toMatchObject({ game: 'my-groupmate-hardfish', version: 1 });
      expect(state.outfit).toBe(outfit); expect(state.counts.feed).toBe(1); expect(state.inventory.bun).toBe(2);
      await page.getByLabel('选择存档 ZIP').setInputFiles({ name: 'character-roundtrip.zip', mimeType: 'application/zip', buffer: zipBytes });
      await expect(page.getByRole('heading', { name: '已检查这份存档' })).toBeVisible();
      await page.getByRole('button', { name: '取消导入', exact: true }).click(); await close(page);
      result.zip = { bytes: zipBytes.length, files: Object.keys(archive), outfit, importPreviewValidated: true };
      await page.reload(); await expect(scene).toHaveAttribute('data-ready', 'true', { timeout: 60000 });
      await expect(scene).toHaveAttribute('data-outfit', outfit);
      result.actions.push('ZIP v1 preview and saved outfit reload');
      await expect.poll(() => pending.size).toBe(0);
      for (const key of ['errors', 'external', 'outsideSubpath', 'failedRequests', 'badResponses']) expect(result[key]).toEqual([]);
      result.status = 'passed';
    } catch (error) {
      result.status = 'failed'; result.failure = error.stack || String(error); process.exitCode = 1;
      await screenshot(page, `failure-${name}.png`).catch(() => {});
    } finally { report.checks.push(result); await context.close(); }
  }
  report.status = report.checks.every(check => check.status === 'passed') ? 'passed' : 'failed';
} finally {
  await browser.close();
  if (server) await new Promise(resolve => server.close(resolve));
  await fs.writeFile(path.join(output, 'character-ui-check.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
}
