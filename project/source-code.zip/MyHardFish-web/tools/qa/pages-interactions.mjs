import { chromium, expect } from '@playwright/test';
import { build } from 'esbuild';
import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { localPreloadManifest, observePreloads, requireFreshReport } from './pages-preload-observer.mjs';

// Run after deployment, for example:
// QA_EXPECTED_SOURCE=<full-source-commit> node tools/qa/pages-interactions.mjs
// This runner never builds/publishes dist. esbuild below only loads the local
// canonical newGame/data fixture into Node memory; the browser uses HTTPS assets.
const project = fileURLToPath(new URL('../../', import.meta.url));
const output = path.resolve(project, process.env.QA_OUTPUT_DIR || '../research/interaction-v7/online');
await fs.mkdir(output, { recursive: true });
await requireFreshReport(path.join(output, 'pages-interactions.json'));
const url = process.env.QA_PAGES_URL || 'https://hardfishdev.github.io/MyHardFish-web-public/';
const expectedSource = process.env.QA_EXPECTED_SOURCE?.trim().toLowerCase();
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const started = Date.now();
const report = {
  checkedAt: new Date().toISOString(), version: null, url, expectedSource: expectedSource || null,
  scope: 'Public HTTPS deployment: real WebGL, furniture sitting, keyboard cancellation, milk feeding, handbook navigation to pavilion/table, camera cutaway and cooking props. One Chromium, two sequential isolated contexts; no network/render/audio mocks.',
  fixture: 'Canonical newGame, changing only settings.voice=false and settings.lowQuality=true. Food, needs, progress and music preferences retain their new-game defaults.',
  limits: ['Screenshots and canvas color sampling are evidence, not a guarantee of complete visual beauty.', 'Software Chromium and mobile viewport emulation do not measure physical-phone FPS or battery use.', 'This focused release check does not replay the full story/commission campaign or complete a cooking round.'],
  testedSource: { pathBase: 'code/', files: {} }, checks: [], errors: [], status: 'pending',
};
let browser;
let firstDeployment;

async function activity(page) {
  const raw = await page.getByTestId('scene').getAttribute('data-activity-details');
  return raw ? JSON.parse(raw) : null;
}
async function active(page, kind) {
  await expect.poll(async () => {
    const value = await activity(page);
    return value?.kind === kind && value.phase === 'active';
  }, { timeout: 70000, message: `Real world activity reaches ${kind}` }).toBe(true);
  return activity(page);
}
async function occlusion(page) {
  const raw = await page.getByTestId('scene').getAttribute('data-camera-occlusion');
  return raw ? JSON.parse(raw) : null;
}
function assertSeat(value) {
  expect(value.seatAnchor).toBeTruthy();
  expect(value.seatContact).toBeTruthy();
  expect(Number.isFinite(value.seatContactError)).toBe(true);
  expect(value.seatContactError).toBeLessThan(.09);
  expect(Math.abs(value.seatContact.y - value.seatAnchor.y)).toBeLessThan(.07);
}
async function closePanel(page) {
  await page.getByRole('button', { name: '关闭窗口', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
}
async function openMenu(page) {
  await page.getByRole('button', { name: '打开生活菜单', exact: true }).click();
}
async function capture(page, result, label) {
  const filename = `${result.name}-${label}.png`;
  await page.screenshot({ path: path.join(output, filename), timeout: 30000 });
  result.screenshots.push(filename);
  return filename;
}
async function canvasSample(page) {
  const sample = await page.evaluate(() => {
    const canvas = document.querySelector('[data-testid="scene"] canvas');
    if (!(canvas instanceof HTMLCanvasElement)) throw new Error('World canvas is missing');
    const rect = canvas.getBoundingClientRect();
    const sampler = document.createElement('canvas'); sampler.width = sampler.height = 32;
    const context = sampler.getContext('2d'); context.drawImage(canvas, 0, 0, 32, 32);
    const pixels = context.getImageData(0, 0, 32, 32).data, colors = new Set();
    for (let i = 0; i < pixels.length; i += 4)
      colors.add(`${pixels[i] >> 4},${pixels[i + 1] >> 4},${pixels[i + 2] >> 4}`);
    return {
      width: innerWidth, height: innerHeight, scrollWidth: document.documentElement.scrollWidth,
      canvas: { x: rect.x, y: rect.y, width: rect.width, height: rect.height, backingWidth: canvas.width, backingHeight: canvas.height },
      colors: colors.size,
    };
  });
  expect(sample.scrollWidth).toBe(sample.width);
  expect(sample.canvas.width).toBe(sample.width);
  expect(sample.canvas.height).toBe(sample.height);
  expect(sample.colors).toBeGreaterThan(20);
  return sample;
}
async function panelVisibility(page, name) {
  let measured;
  await expect.poll(async () => {
    const pose = await activity(page), panel = await page.getByRole('dialog').boundingBox();
    if (!pose?.screen?.bounds || !panel) return false;
    const bounds = pose.screen.bounds;
    const center = { x: (bounds.left + bounds.right) / 2, y: (bounds.top + bounds.bottom) / 2 };
    const viewport = page.viewportSize();
    measured = { panel, bounds, center };
    return bounds.width > 18 && bounds.height > 50 && center.x > 0 && center.x < viewport.width
      && center.y > 0 && center.y < viewport.height
      && (name === 'mobile' ? center.y < panel.y : center.x < panel.x);
  }, { timeout: 15000, message: 'The activity stays visible beside the actual panel' }).toBe(true);
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(page.viewportSize().width);
  return measured;
}
async function saveSummary(page, key) {
  return page.evaluate(saveKey => {
    const state = JSON.parse(localStorage.getItem(saveKey) || 'null');
    return state ? { hunger: state.hunger, feedCount: state.counts.feed, milk: state.inventory.milk, place: state.place } : null;
  }, key);
}

try {
  const base = new URL(url);
  if (base.protocol !== 'https:' || base.username || base.password || !base.pathname.endsWith('/') || base.search || base.hash)
    throw new Error('QA_PAGES_URL must be a credential-free HTTPS directory URL with a trailing slash.');
  if (!expectedSource || !/^[a-f0-9]{40}$/.test(expectedSource))
    throw new Error('QA_EXPECTED_SOURCE must be the full 40-character source commit SHA.');
  const packageJson = JSON.parse(await fs.readFile(path.join(project, 'package.json'), 'utf8'));
  report.version = packageJson.version;
  const preloadManifest = await localPreloadManifest(project, base);
  report.preloadManifest = preloadManifest;
  report.limits.push('Deployment identity checks cover declared version/source commit and the actual HTML response SHA. JS/CSS and all runtime-byte hashes are the separate HTTPS asset scan, not this runner.');
  const runnerBytes = await fs.readFile(fileURLToPath(import.meta.url));
  report.testedSource.files['tools/qa/pages-interactions.mjs'] = { bytes: runnerBytes.length, sha256: sha256(runnerBytes) };
  const observerBytes = await fs.readFile(path.join(project, 'tools/qa/pages-preload-observer.mjs'));
  report.testedSource.files['tools/qa/pages-preload-observer.mjs'] = { bytes: observerBytes.length, sha256: sha256(observerBytes) };
  const fixtureModule = await build({
    stdin: {
      contents: "export {newGame} from './src/engine';export {SAVE_KEY} from './src/storage';export {discoveries} from './src/adventure-content';export {EXPLORATION_SPOTS} from './src/world-layout';",
      resolveDir: project,
    }, bundle: true, write: false, platform: 'node', format: 'esm', logLevel: 'silent',
  });
  const { newGame, SAVE_KEY, discoveries, EXPLORATION_SPOTS } = await import(`data:text/javascript;base64,${Buffer.from(fixtureModule.outputFiles[0].text).toString('base64')}`);
  const spots = ['park_pavilion', 'kitchen_table'].map(id => {
    const discovery = discoveries.find(item => item.hotspot === id), spot = EXPLORATION_SPOTS.find(item => item.id === id);
    if (!discovery || !spot) throw new Error(`Missing canonical discovery fixture: ${id}`);
    return { id, title: discovery.title, label: spot.label, place: spot.place };
  });
  browser = await chromium.launch({
    executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath(),
    args: ['--no-sandbox', '--enable-unsafe-swiftshader'], timeout: 60000,
  });
  for (const [name, viewport] of [['desktop', { width: 1440, height: 1000 }], ['mobile', { width: 390, height: 844 }]]) {
    console.error(`[pages-interactions] ${name}`);
    const result = {
      name, viewport, status: 'pending', checks: [], screenshots: [], errors: [], consoleErrors: [],
      failedRequests: [], cleanupRequests: [], badResponses: [], foreignRequests: [], outsideSubpath: [],
    };
    report.checks.push(result);
    let context, page, observer, closing = false, deadline, expired = false;
    const viewportStarted = Date.now();
    try {
      context = await browser.newContext({ viewport, deviceScaleFactor: name === 'mobile' ? 3 : 1, isMobile: name === 'mobile', hasTouch: name === 'mobile' });
      // A deadline closes a stalled context so an evaluate/screenshot cannot hang the whole runner.
      deadline = setTimeout(() => {
        expired = true; closing = true;
        void context.close().catch(() => {});
      }, 540000);
      const fixture = newGame(); fixture.settings.voice = false; fixture.settings.lowQuality = true;
      await context.addInitScript(({ key, state }) => {
        if (!localStorage.getItem(key)) localStorage.setItem(key, JSON.stringify(state));
      }, { key: SAVE_KEY, state: fixture });
      page = await context.newPage(); page.setDefaultTimeout(45000); page.setDefaultNavigationTimeout(90000);
      observer = await observePreloads(page, result, { base, manifest: preloadManifest, isClosing: () => closing });
      const metadataUrl = new URL('deployment.json', base);
      metadataUrl.searchParams.set('qa', String(Date.now()));
      const metadataResponse = await context.request.get(metadataUrl.href, { headers: { 'Cache-Control': 'no-cache' }, timeout: 45000 });
      expect(metadataResponse.status()).toBe(200);
      const metadataBytes = await metadataResponse.body(), deployment = JSON.parse(metadataBytes.toString('utf8'));
      expect(deployment.version).toBe(packageJson.version);
      expect(deployment.sourceCommit).toMatch(/^[a-f0-9]{40}$/i);
      if (expectedSource) expect(deployment.sourceCommit.toLowerCase()).toBe(expectedSource);
      if (firstDeployment) expect({ version: deployment.version, sourceCommit: deployment.sourceCommit }).toEqual(firstDeployment);
      else firstDeployment = { version: deployment.version, sourceCommit: deployment.sourceCommit };
      result.deployment = { version: deployment.version, sourceCommit: deployment.sourceCommit, files: deployment.files.length, manifestSha256: sha256(metadataBytes) };
      observer.beginPhase('cold');
      const response = await page.goto(url, { waitUntil: 'domcontentloaded' });
      expect(response?.status()).toBe(200);
      const html = await response.body(), index = deployment.files.find(file => file.path === 'index.html');
      expect(index).toBeTruthy(); expect(html.length).toBe(index.bytes); expect(sha256(html)).toBe(index.sha256);
      result.deployment.loadedIndexSha256 = sha256(html);
      result.checks.push({ id: 'deployed-version-source-and-index', status: 'passed', ...result.deployment });
      await expect(page.locator('.resource-loading')).toHaveCount(0, { timeout: 210000 });
      const scene = page.getByTestId('scene');
      await expect(scene).toHaveAttribute('data-ready', 'true', { timeout: 70000 });
      await expect(scene).toHaveAttribute('data-quality', 'low');
      await expect(scene).toHaveAttribute('data-place', 'home');
      await expect(scene).toHaveAttribute('data-triangles', /[1-9]\d*/);
      await expect.poll(() => observer.pending.size, { timeout: 45000 }).toBe(0);
      const preload = await observer.completePhase();
      observer.assertHealthy();
      result.checks.push({ id: 'automatic-preload', status: 'passed', outcome: preload.status, resourcesSuccessful: preload.resourcesSuccessful, resourcesExpected: preload.resourcesExpected });
      result.coldLoadMs = Date.now() - viewportStarted;
      result.layout = await canvasSample(page);
      await capture(page, result, 'home');
      result.checks.push({ id: 'real-webgl-and-full-viewport', status: 'passed', ...result.layout });

      await openMenu(page); await page.getByRole('button', { name: '歇一会儿', exact: true }).click();
      let pose = await active(page, 'sit'); assertSeat(pose);
      await capture(page, result, 'sit-home');
      result.checks.push({ id: 'rest-uses-actual-furniture', status: 'passed', activity: pose });
      const positionBefore = await scene.getAttribute('data-position');
      await scene.locator('canvas').focus(); await page.keyboard.down('ArrowLeft');
      try {
        await expect.poll(() => activity(page), { timeout: 10000 }).toBeNull();
        await expect(scene).not.toHaveAttribute('data-position', positionBefore);
      } finally { await page.keyboard.up('ArrowLeft'); }
      await expect(scene).toHaveAttribute('data-walking', 'false');
      result.checks.push({ id: 'keyboard-movement-cancels-seated-activity', status: 'passed', positionBefore, positionAfter: await scene.getAttribute('data-position') });

      const hungerBefore = Number(await page.getByTestId('hunger').textContent());
      await page.getByRole('button', { name: '给她投喂', exact: true }).click();
      await page.getByRole('button', { name: '投喂温牛奶', exact: true }).click();
      await expect(page.getByRole('dialog')).toHaveCount(0);
      pose = await active(page, 'eat'); expect(pose.prop).toBe('cup'); expect(pose.food).toBe('milk');
      expect(pose.visibleProps.some(prop => prop.prop === 'milk')).toBe(true);
      await expect.poll(async () => Number(await page.getByTestId('hunger').textContent())).toBeGreaterThan(hungerBefore);
      let nearestMouthDistance = Infinity;
      await expect.poll(async () => {
        const eating = await activity(page);
        if (eating?.kind === 'eat') nearestMouthDistance = Math.min(nearestMouthDistance, eating.foodMouthDistance ?? Infinity);
        return nearestMouthDistance;
      }, { timeout: 10000 }).toBeLessThan(.42);
      await capture(page, result, 'eat-milk');
      await expect.poll(async () => (await saveSummary(page, SAVE_KEY))?.milk).toBe(fixture.inventory.milk - 1);
      result.checks.push({ id: 'milk-reaches-mouth-and-increases-hunger', status: 'passed', activity: pose, nearestMouthDistance, hungerBefore, hungerAfter: Number(await page.getByTestId('hunger').textContent()), saved: await saveSummary(page, SAVE_KEY) });
      await expect.poll(() => activity(page), { timeout: 13000 }).toBeNull();

      for (const spot of spots) {
        await page.getByRole('button', { name: '打开村民手帐', exact: true }).click();
        await page.getByRole('tab', { name: '探索册', exact: true }).click();
        await page.locator('.discovery-groups button').filter({ has: page.getByText(spot.title, { exact: true }) }).click();
        await expect(page.getByRole('dialog')).toContainText(spot.label, { timeout: 70000 });
        await expect(scene).toHaveAttribute('data-place', spot.place);
        pose = await active(page, 'sit'); assertSeat(pose);
        expect(pose.hotspotId).toBe(`adventure:${spot.id}`); expect(pose.prop).toBe('cup');
        expect(pose.visibleProps.some(prop => ['cup', 'coffee', 'milk'].includes(prop.prop))).toBe(true);
        const panel = await panelVisibility(page, name);
        const expectedCutaway = spot.id === 'park_pavilion' ? 'pavilion-roof-and-eaves' : 'pendant:5.3:1.7';
        await expect.poll(async () => (await occlusion(page))?.hidden ?? [], { timeout: 15000 }).toContain(expectedCutaway);
        const cutaway = await occlusion(page), pixels = await canvasSample(page);
        await capture(page, result, spot.id);
        result.checks.push({ id: `handbook-navigation-${spot.id}`, status: 'passed', activity: pose, panel, cameraOcclusion: cutaway, canvas: pixels });
        await closePanel(page); await expect.poll(() => activity(page), { timeout: 10000 }).toBeNull();
      }

      await openMenu(page); await page.getByRole('button', { name: '一起玩吧', exact: true }).click();
      await page.getByRole('button', { name: /火候刚刚好/ }).click();
      const inspection = await active(page, 'inspect');
      expect(inspection.prop).toBe('magnifier');
      await page.getByRole('button', { name: '和难鱼一起开始', exact: true }).click();
      pose = await active(page, 'cook');
      expect(pose.visibleProps.some(prop => prop.prop === 'spatula')).toBe(true);
      expect(pose.visibleProps.some(prop => prop.prop === 'pan')).toBe(true);
      const cookingPanel = await panelVisibility(page, name);
      await capture(page, result, 'cooking');
      result.checks.push({ id: 'cooking-intro-to-real-pan-and-spatula', status: 'passed', inspection, activity: pose, panel: cookingPanel, cameraOcclusion: await occlusion(page) });
      await closePanel(page); await expect.poll(() => activity(page), { timeout: 10000 }).toBeNull();
      result.checks.push({ id: 'closing-cooking-panel-cleans-activity', status: 'passed' });
      await expect.poll(() => observer.pending.size, { timeout: 45000 }).toBe(0);
      const network = observer.assertHealthy();
      result.checks.push({ id: 'console-page-and-same-origin-resources', status: 'passed', networkOutcome: network.status, recoveredInitialTransportErrors: network.recoveredInitialTransportErrors.length });
      result.status = 'passed';
    } catch (error) {
      result.status = 'failed'; result.failure = expired ? 'Viewport deadline exceeded (540 seconds).' : error.stack || String(error);
      process.exitCode = 1;
      if (page && !page.isClosed()) {
        result.lastActivity = await activity(page).catch(() => null);
        result.lastCameraOcclusion = await occlusion(page).catch(() => null);
        await capture(page, result, 'failure').catch(() => {});
      }
    } finally {
      clearTimeout(deadline); closing = true; result.elapsedMs = Date.now() - viewportStarted;
      if (context) await context.close().catch(error => { result.cleanupError = String(error); result.status = 'failed'; process.exitCode = 1; });
      observer?.snapshot();
      if (result.status === 'passed') {
        try { observer.assertHealthy(); }
        catch (error) { result.status = 'failed'; result.failure = error.stack || String(error); process.exitCode = 1; }
      }
      await fs.writeFile(path.join(output, 'pages-interactions.json'), JSON.stringify(report, null, 2) + '\n');
    }
  }
} catch (error) {
  report.errors.push(error.stack || String(error)); process.exitCode = 1;
} finally {
  if (browser) await browser.close().catch(error => { report.errors.push(String(error)); process.exitCode = 1; });
  report.counts = { passed: report.checks.filter(check => check.status === 'passed').length, failed: report.checks.filter(check => check.status === 'failed').length };
  report.status = report.errors.length === 0 && report.checks.length === 2 && report.counts.passed === 2 ? 'passed' : 'failed';
  if (report.status === 'failed') process.exitCode = 1;
  report.elapsedMs = Date.now() - started;
  await fs.writeFile(path.join(output, 'pages-interactions.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(report, null, 2));
}
