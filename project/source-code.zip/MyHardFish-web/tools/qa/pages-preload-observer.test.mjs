import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { localPreloadManifest, observePreloads, requireFreshReport } from './pages-preload-observer.mjs';

const base = new URL('https://example.test/game/');
const resource = new URL('audio/music-home.mp3', base).href;
const manifest = [{ path: 'audio/music-home.mp3', url: resource }];

async function fixture() {
  class Page extends EventEmitter {
    observation = { loaderGone: true, sceneReady: true, controlClicks: [] };
    async addInitScript() {}
    async evaluate() { return this.observation; }
  }
  const page = new Page(), result = {};
  let time = 0, closing = false;
  const observer = await observePreloads(page, result, { base, manifest, now: () => ++time, isClosing: () => closing });
  observer.beginPhase('cold');
  const start = ({ url = resource, type = 'fetch', method = 'GET' } = {}) => {
    const request = { url: () => url, method: () => method, resourceType: () => type, failure: () => ({ errorText: request.error }) };
    page.emit('request', request); return request;
  };
  const respond = (request, status = 200) => page.emit('response', { request: () => request, url: request.url, status: () => status });
  const finish = request => page.emit('requestfinished', request);
  const fail = (request, error = 'net::ERR_ABORTED') => { request.error = error; page.emit('requestfailed', request); };
  const succeed = options => { const request = start(options); respond(request); finish(request); return request; };
  const consoleError = (url = resource, text = 'Failed to load resource: net::ERR_ABORTED') =>
    page.emit('console', { type: () => 'error', text: () => text, location: () => ({ url, lineNumber: 0, columnNumber: 0 }) });
  return { page, result, observer, start, respond, finish, fail, succeed, consoleError, close: () => { closing = true; } };
}
async function summary(f) { await f.observer.completePhase(); return f.observer.snapshot(); }

test('local town manifest includes current public images and audio while excluding cycling-only files, licenses and JS', async () => {
  const project = fileURLToPath(new URL('../../', import.meta.url));
  const files = await localPreloadManifest(project, base);
  const publicDirectory = path.join(project, 'public');
  const candidates = (await fs.readdir(publicDirectory, { recursive: true }))
    .map(file => file.split(path.sep).join('/'))
    .filter(file => /^(?:assets\/.*\.(?:png|jpg|jpeg|webp|gif|svg|avif)|audio\/.*\.(?:mp3|ogg|wav|m4a))$/.test(file));
  const expected = (await Promise.all(candidates.map(async file => (await fs.stat(path.join(publicDirectory, file))).isFile() ? file : null)))
    .filter(file => file && !file.startsWith('audio/cycling-')).sort();
  assert.ok(expected.length > 0);
  assert.deepEqual(files.map(file => file.path), expected);
  assert.deepEqual(files.map(file => file.url), expected.map(file => new URL(file, base).href));
  assert.equal(new Set(files.map(file => file.url)).size, files.length);
  assert.ok(files.every(file => !/\.(?:txt|js|css)$/.test(file.path)));
  const cycling = candidates.filter(file => file.startsWith('audio/cycling-'));
  assert.equal(cycling.length, 4, 'the real cycling sound bank exists in public but is not a town preload');
  assert.ok(cycling.every(file => !files.some(entry => entry.path === file)));
});
test('the manifest filter excludes actual cycling catalog filenames without dropping ordinary audio', async () => {
  const project = fileURLToPath(new URL('../../', import.meta.url));
  const catalog = JSON.parse(await fs.readFile(path.join(project, 'src/cycling-audio-catalog.json'), 'utf8'));
  const cycling = Object.values(catalog).map(entry => `audio/${entry.file}`);
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'hardfish-cycling-manifest-'));
  try {
    await fs.mkdir(path.join(directory, 'public/assets'), { recursive: true });
    await fs.mkdir(path.join(directory, 'public/audio'), { recursive: true });
    for (const file of ['assets/fish.svg', 'audio/music-home.mp3', 'audio/greeting.mp3', ...cycling])
      await fs.writeFile(path.join(directory, 'public', file), 'fixture');
    const files = await localPreloadManifest(directory, base);
    assert.deepEqual(files.map(file => file.path), ['assets/fish.svg', 'audio/greeting.mp3', 'audio/music-home.mp3']);
    assert.ok(files.every(file => !cycling.includes(file.path)));
  } finally {
    await fs.rm(directory, { recursive: true, force: true });
  }
});
test('a complete 2xx response enters cleanly; an image request is not another fetch attempt', async () => {
  const f = await fixture(); f.succeed(); f.succeed({ type: 'image' });
  assert.equal((await summary(f)).status, 'clean');
  assert.equal(f.observer.assertHealthy().phases[0].resources[0].attempts.length, 1);
});
test('a failed first attempt remains failed when a second complete response recovers it', async () => {
  const f = await fixture(); f.fail(f.start()); f.consoleError(); f.succeed();
  const raw = JSON.stringify(f.result.failedRequests), report = await summary(f);
  assert.equal(report.status, 'recovered'); assert.equal(report.initialFailures.length, 1);
  assert.equal(report.recoveredInitialTransportErrors.length, 1);
  assert.equal(report.recoverableConsoleErrors.length, 1);
  assert.equal(report.phases[0].resources[0].attempts[0].outcome, 'failed');
  assert.equal(JSON.stringify(f.result.failedRequests), raw);
  f.observer.assertHealthy();
});
test('a response whose body later fails can recover, but headers alone cannot', async () => {
  const f = await fixture(), first = f.start(); f.respond(first); f.fail(first, 'net::ERR_CONNECTION_RESET');
  const second = f.start(); f.respond(second);
  assert.equal((await summary(f)).status, 'failed');
  f.finish(second);
  assert.equal(f.observer.snapshot().status, 'recovered');
});
test('HTTP failure cannot be excused by a later successful fetch', async () => {
  const f = await fixture(), first = f.start(); f.respond(first, 503); f.fail(first); f.succeed();
  assert.equal((await summary(f)).status, 'failed');
  assert.equal(f.result.badResponses[0].status, 503);
});
test('unknown/blocked transport errors remain failures', async () => {
  const f = await fixture(); f.fail(f.start(), 'net::ERR_BLOCKED_BY_CLIENT'); f.succeed();
  assert.equal((await summary(f)).unrecoveredFailures.length, 1);
});
test('a third fetch attempt cannot produce a successful resource', async () => {
  const f = await fixture(); f.fail(f.start()); f.fail(f.start()); f.succeed();
  assert.equal((await summary(f)).status, 'failed');
  assert.equal(f.result.failedRequests.length, 2);
});
test('two successful fetches are not mistaken for recovery', async () => {
  const f = await fixture(); f.succeed(); f.succeed();
  assert.equal((await summary(f)).status, 'failed');
});
test('overlapping requests cannot be called sequential retry', async () => {
  const f = await fixture(), first = f.start(), second = f.start(); f.fail(first); f.respond(second); f.finish(second);
  assert.equal((await summary(f)).status, 'failed');
});
test('each reload phase gets a separate two-attempt slot', async () => {
  const f = await fixture(); f.fail(f.start()); f.succeed(); await summary(f);
  f.observer.beginPhase('reload'); f.fail(f.start()); f.succeed();
  const report = await summary(f);
  assert.equal(report.status, 'recovered'); assert.equal(report.phases.length, 2);
  assert.deepEqual(report.phases.map(phase => phase.resources[0].attempts.length), [2, 2]);
});
test('success after reload does not recover an earlier failed cold phase', async () => {
  const f = await fixture(); f.fail(f.start()); await summary(f);
  f.observer.beginPhase('reload'); f.succeed();
  const report = await summary(f);
  assert.equal(report.status, 'failed'); assert.equal(report.recoveredInitialTransportErrors.length, 0);
});
test('manual retry or continue is never automatic entry', async () => {
  const f = await fixture(); f.succeed(); f.page.observation.controlClicks = [{ label: '先进入小镇' }];
  const report = await summary(f);
  assert.equal(report.status, 'failed'); assert.equal(report.phases[0].automaticEntry, false);
});
test('loading UI still present or missing resources fails despite scene readiness', async () => {
  const f = await fixture(); f.page.observation.loaderGone = false;
  assert.equal((await summary(f)).status, 'failed');
});
test('unfinished phase cannot pass', async () => {
  const f = await fixture(); f.succeed(); assert.throws(() => f.observer.assertHealthy());
});
test('JS errors are fatal even alongside recovered transport', async () => {
  const f = await fixture(); f.fail(f.start()); f.succeed(); f.page.emit('pageerror', new Error('broken app'));
  assert.equal((await summary(f)).status, 'failed'); assert.equal(f.result.errors[0], 'broken app');
});
test('console recovery requires the exact URL and matching transport code', async () => {
  const f = await fixture(); f.fail(f.start()); f.succeed();
  f.consoleError(resource + '?other'); f.consoleError(resource, 'Failed to load resource: net::ERR_CONNECTION_RESET');
  const report = await summary(f);
  assert.equal(report.status, 'failed'); assert.equal(report.unclassifiedConsoleErrors.length, 2);
});
test('console error outside the loading phase is not excused by earlier recovery', async () => {
  const f = await fixture(); f.fail(f.start()); f.succeed(); await summary(f); f.consoleError();
  assert.equal(f.observer.snapshot().status, 'failed');
});
test('unknown same-origin fetch is reported and fails even when it succeeds', async () => {
  const f = await fixture(); f.succeed(); f.succeed({ url: new URL('audio/unlisted.mp3', base).href });
  assert.equal((await summary(f)).status, 'failed'); assert.equal(f.result.unexpectedPreloadRequests.length, 1);
});
test('foreign and outside-subpath requests remain fatal', async () => {
  const f = await fixture(); f.succeed(); f.succeed({ url: 'https://elsewhere.test/image.png', type: 'image' });
  f.succeed({ url: 'https://example.test/unrelated.png', type: 'image' });
  assert.equal((await summary(f)).status, 'failed');
  assert.equal(f.result.foreignRequests.length, 1); assert.equal(f.result.outsideSubpath.length, 1);
});
test('an image failure cannot be recovered by a successful preload of the same URL', async () => {
  const f = await fixture(); f.fail(f.start({ type: 'image' })); f.succeed();
  assert.equal((await summary(f)).unrecoveredFailures.length, 1);
});
test('cleanup cancellation stays in raw cleanup records without rewriting a completed phase', async () => {
  const f = await fixture(); f.succeed(); await summary(f);
  const image = f.start({ type: 'image' }); f.close(); f.fail(image);
  assert.equal(f.observer.snapshot().status, 'clean'); assert.equal(f.result.cleanupRequests.length, 1);
});
test('an existing historical report is refused, never overwritten', async () => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'hardfish-observer-'));
  try {
    const filename = path.join(directory, 'previous.json'); await requireFreshReport(filename);
    await fs.writeFile(filename, '{"status":"failed"}\n');
    await assert.rejects(requireFreshReport(filename), /Refusing to overwrite/);
    assert.equal(await fs.readFile(filename, 'utf8'), '{"status":"failed"}\n');
  } finally { await fs.rm(directory, { recursive: true, force: true }); }
});
