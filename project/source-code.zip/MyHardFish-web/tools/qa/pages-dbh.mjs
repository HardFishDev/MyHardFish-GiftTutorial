import { chromium, expect as baseExpect } from '@playwright/test';
import { build } from 'esbuild';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { validateArtifact } from '../deploy/artifact.mjs';
import { localPreloadManifest, observePreloads, requireFreshReport } from './pages-preload-observer.mjs';
import { runtimeManifest, observeRuntimeResponses, assertRuntimeMatches } from './pages-runtime-observer.mjs';

// Published: QA_EXPECTED_SOURCE=<full SHA> node tools/qa/pages-dbh.mjs
// Preview: add QA_BASE_URL=http://127.0.0.1:4173/ QA_DIST=/clean-checkout/dist
// A preview verifies served bytes against QA_DIST; it never claims a deployment.
const project = fileURLToPath(new URL('../../', import.meta.url));
const expect = baseExpect.configure({ timeout: 45000 });
const output = path.resolve(project, process.env.QA_OUTPUT_DIR || '../research/dbh-release/online');
await fs.mkdir(output, { recursive: true });
const reportPath = path.join(output, 'pages-dbh.json');
await requireFreshReport(reportPath);
const preview = !!process.env.QA_BASE_URL;
const url = process.env.QA_BASE_URL || process.env.QA_PAGES_URL || 'https://hardfishdev.github.io/MyHardFish-web-public/';
const expectedSource = process.env.QA_EXPECTED_SOURCE?.trim().toLowerCase();
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const report = {
  checkedAt: new Date().toISOString(), mode: preview ? 'local-preview' : 'published-https', url,
  expectedSource: expectedSource || null, version: null, status: 'pending', checks: [], errors: [],
  scope: 'Two isolated desktop/mobile contexts: real high-quality WebGL, village navigation, wave/dance/stretch/gift/photo, saved memories and responsive framing. Cold preload observation preserves initial transport failures and automatic recovery.',
  limits: [
    'Identity checks cover source/version, actual HTML and every completed JS/CSS response, including the lazy App/model module; other runtime-byte hashes need the separate asset scan.',
    'A local preview verifies the supplied production artifact and checkout commit, not a public deployment or independent proof of how dist was built.',
    'Viewport emulation and software WebGL do not measure physical-phone FPS or replace manual visual review.',
  ],
  testedSource: { pathBase: 'code/', files: {} },
};
let browser, firstIdentity;
const started = Date.now();

function fileFrom(deployment, filename) {
  const matches = deployment.files.filter(file => file.path === filename);
  expect(matches).toHaveLength(1);
  expect(matches[0].sha256).toMatch(/^[a-f0-9]{64}$/);
  expect(matches[0].bytes).toBeGreaterThan(0);
  return matches[0];
}

try {
  const base = new URL(url);
  const loopback = ['127.0.0.1', 'localhost', '[::1]'].includes(base.hostname);
  if (base.username || base.password || !base.pathname.endsWith('/') || base.search || base.hash
    || (preview ? !loopback || !['http:', 'https:'].includes(base.protocol) : base.protocol !== 'https:'))
    throw new Error('Use a credential-free HTTPS directory URL, or a loopback QA_BASE_URL preview; a trailing slash is required.');
  if (!expectedSource || !/^[a-f0-9]{40}$/.test(expectedSource))
    throw new Error('QA_EXPECTED_SOURCE must be the full 40-character source commit SHA.');
  const packageJson = JSON.parse(await fs.readFile(path.join(project, 'package.json'), 'utf8'));
  report.version = packageJson.version;
  const manifest = await localPreloadManifest(project, base);
  report.preloadManifest = manifest;
  for (const filename of ['tools/qa/pages-dbh.mjs', 'tools/qa/pages-preload-observer.mjs', 'tools/qa/pages-runtime-observer.mjs']) {
    const bytes = await fs.readFile(path.join(project, filename));
    report.testedSource.files[filename] = { bytes: bytes.length, sha256: sha256(bytes) };
  }

  let previewDeployment;
  if (preview) {
    const { stdout } = await promisify(execFile)('git', ['rev-parse', 'HEAD'], { cwd: project });
    expect(stdout.trim().toLowerCase()).toBe(expectedSource);
    const dist = path.resolve(project, process.env.QA_DIST || 'dist');
    const files = await validateArtifact(dist);
    previewDeployment = { version: packageJson.version, sourceCommit: expectedSource,
      files: files.map(file => ({ path: file.name, bytes: file.bytes, sha256: file.sha256 })) };
    report.previewArtifact = { directory: dist, checkedOutSource: stdout.trim(), files: previewDeployment.files };
  }
  const loadIdentity = async context => {
    let deployment, metadataSha256;
    if (preview) {
      deployment = previewDeployment;
      metadataSha256 = sha256(Buffer.from(JSON.stringify(deployment)));
    } else {
      const metadataUrl = new URL('deployment.json', base);
      metadataUrl.searchParams.set('qa', String(Date.now()));
      const response = await context.request.get(metadataUrl.href, { headers: { 'Cache-Control': 'no-cache' }, timeout: 45000 });
      expect(response.status()).toBe(200);
      const bytes = await response.body();
      deployment = JSON.parse(bytes.toString('utf8')); metadataSha256 = sha256(bytes);
    }
    expect(deployment.version).toBe(packageJson.version);
    expect(deployment.sourceCommit?.toLowerCase()).toBe(expectedSource);
    expect(Array.isArray(deployment.files)).toBe(true);
    const index = fileFrom(deployment, 'index.html');
    const runtime = runtimeManifest(deployment);
    const identity = { version: deployment.version, sourceCommit: deployment.sourceCommit.toLowerCase(), index, runtime };
    if (firstIdentity) expect(identity).toEqual(firstIdentity); else firstIdentity = identity;
    return { ...identity, files: deployment.files.length, metadataSha256 };
  };

  const fixtureModule = await build({ stdin: {
    contents: "export {newGame} from './src/engine';export {SAVE_KEY} from './src/storage';export {AUDIO_PREFERENCES_KEY} from './src/audio-preferences';",
    resolveDir: project,
  }, bundle: true, write: false, platform: 'node', format: 'esm', logLevel: 'silent' });
  const { newGame, SAVE_KEY, AUDIO_PREFERENCES_KEY } = await import(`data:text/javascript;base64,${Buffer.from(fixtureModule.outputFiles[0].text).toString('base64')}`);
  browser = await chromium.launch({ executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath(),
    args: ['--no-sandbox', '--enable-unsafe-swiftshader'], timeout: 60000 });

  for (const [name, viewport] of [['desktop', { width: 1440, height: 1000 }], ['mobile', { width: 390, height: 844 }]]) {
    console.error(`[pages-dbh] ${name}`);
    const result = { name, viewport, status: 'pending', actions: [], screenshots: [] };
    report.checks.push(result);
    let context, page, observer, runtimeObserver, deadline, closing = false, expired = false;
    const viewportStarted = Date.now();
    try {
      context = await browser.newContext({ viewport, isMobile: name === 'mobile', hasTouch: name === 'mobile' });
      deadline = setTimeout(() => { expired = true; closing = true; void context.close().catch(() => {}); }, 540000);
      const state = newGame(); state.place = 'village'; state.settings.voice = false; state.settings.lowQuality = false;
      await context.addInitScript(({ state, save, audio }) => {
        if (!localStorage.getItem(save)) localStorage.setItem(save, JSON.stringify(state));
        localStorage.setItem(audio, JSON.stringify({ music: false, effects: false, musicVolume: .3, effectsVolume: .6 }));
      }, { state, save: SAVE_KEY, audio: AUDIO_PREFERENCES_KEY });
      page = await context.newPage(); page.setDefaultTimeout(60000); page.setDefaultNavigationTimeout(90000);
      observer = await observePreloads(page, result, { base, manifest, isClosing: () => closing });
      // Hash actual completed responses, including modules loaded dynamically
      // after the HTML entry. Manifest-only checks would not prove execution.
      runtimeObserver = observeRuntimeResponses(page, result, base);
      result.identity = await loadIdentity(context);
      observer.beginPhase('cold');
      const response = await page.goto(url, { waitUntil: 'domcontentloaded' });
      expect(response?.status()).toBe(200);
      const html = await response.body();
      expect(html.length).toBe(result.identity.index.bytes);
      expect(sha256(html)).toBe(result.identity.index.sha256);
      result.identity.loadedIndexSha256 = sha256(html);
      await expect(page.locator('.resource-loading')).toHaveCount(0, { timeout: 210000 });
      const scene = page.getByTestId('scene');
      await expect(scene).toHaveAttribute('data-ready', 'true', { timeout: 90000 });
      await expect(scene).toHaveAttribute('data-place', 'village');
      await expect(scene).toHaveAttribute('data-quality', 'high');
      await expect(scene).toHaveAttribute('data-triangles', /[1-9]\d*/);
      await expect.poll(() => observer.pending.size, { timeout: 45000 }).toBe(0);
      await observer.completePhase(); observer.assertHealthy();
      result.coldLoadMs = Date.now() - viewportStarted;

      const panel = page.getByRole('dialog', { name: '与 dbh 聊天', exact: true });
      const details = async () => JSON.parse(await scene.getAttribute('data-dbh-details') || 'null');
      const capture = async label => {
        const filename = `${name}-${label}.png`;
        await page.screenshot({ path: path.join(output, filename), timeout: 30000 }); result.screenshots.push(filename);
      };
      const layout = async () => {
        await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth)).toBe(viewport.width);
        const box = await panel.boundingBox(); expect(box).toBeTruthy();
        expect(box.x).toBeGreaterThanOrEqual(0); expect(box.y).toBeGreaterThanOrEqual(0);
        expect(box.x + box.width).toBeLessThanOrEqual(viewport.width + 1);
        expect(box.y + box.height).toBeLessThanOrEqual(viewport.height + 1);
        await expect.poll(async () => {
          const point = (await details())?.screen;
          return Boolean(point && point.x > 0 && point.x < viewport.width && point.y > 0
            && (name === 'mobile' ? point.y < box.y : point.x < box.x));
        }, { timeout: 30000 }).toBe(true);
        result.panel = box; result.npc = await details();
      };
      await page.getByRole('button', { name: /去找 dbh/ }).click();
      await expect(panel).toBeVisible({ timeout: 120000 });
      await expect.poll(async () => (await details())?.conversation).toBe(true); await layout();
      await panel.getByRole('button', { name: '挥手打招呼', exact: true }).click();
      await expect.poll(async () => (await details())?.action).toBe('wave'); result.actions.push('wave'); await capture('meet');
      await panel.getByRole('button', { name: '一起做点事', exact: true }).click();
      for (const [label, action] of [['一起跳一小段', 'dance'], ['伸个懒腰', 'stretch'], ['一起折纸星', 'gift']]) {
        await panel.getByRole('button', { name: new RegExp(label) }).click();
        await expect.poll(async () => (await details())?.action).toBe(action); result.actions.push(action); await capture(action);
        if (action === 'dance') {
          for (let beat = 0; beat < 2; beat++) await panel.getByRole('button', { name: '跟上下一拍', exact: true }).click();
          await panel.getByRole('button', { name: '一起完成收尾', exact: true }).click();
        }
      }
      const pendingDownload = page.waitForEvent('download');
      await panel.getByRole('button', { name: /拍张合影/ }).click();
      const download = await pendingDownload, photo = path.join(output, `${name}-photo.png`);
      await download.saveAs(photo);
      const photoBytes = await fs.readFile(photo);
      expect(photoBytes.subarray(0, 8)).toEqual(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
      result.photo = { file: path.basename(photo), bytes: photoBytes.length, sha256: sha256(photoBytes) }; result.actions.push('photo');
      await expect.poll(() => page.evaluate(key => JSON.parse(localStorage.getItem(key) || '{}').dbh?.memories, SAVE_KEY))
        .toEqual(expect.arrayContaining(['first_meeting', 'dance', 'paper_star', 'photo']));
      result.saved = await page.evaluate(key => JSON.parse(localStorage.getItem(key)).dbh, SAVE_KEY);
      await panel.getByRole('button', { name: /^村中手记/ }).click();
      await expect(panel).toContainText('纸星约定'); await layout(); await capture('memories');
      result.framebufferColors = await scene.locator('canvas').evaluate(source => {
        const sample = document.createElement('canvas'); sample.width = sample.height = 32;
        const context = sample.getContext('2d'); context.drawImage(source, 0, 0, 32, 32);
        const pixels = context.getImageData(0, 0, 32, 32).data, colors = new Set();
        for (let i = 0; i < pixels.length; i += 4) colors.add(`${pixels[i] >> 4},${pixels[i + 1] >> 4},${pixels[i + 2] >> 4}`);
        return colors.size;
      });
      expect(result.framebufferColors).toBeGreaterThan(20);
      await panel.getByRole('button', { name: '结束与 dbh 的交谈', exact: true }).click();
      await expect(panel).toHaveCount(0); await expect.poll(async () => (await details())?.conversation).toBe(false);
      await page.getByRole('button', { name: /去找 dbh/ }).click(); await expect(panel).toBeVisible();
      await expect.poll(async () => (await details())?.conversation).toBe(true);

      await expect.poll(() => observer.pending.size, { timeout: 45000 }).toBe(0);
      await runtimeObserver.settle();
      result.runtimeVerification = assertRuntimeMatches(result, result.identity.runtime);
      result.networkOutcome = observer.assertHealthy().status;
      result.status = 'passed';
    } catch (error) {
      result.status = 'failed'; result.failure = expired ? 'Viewport deadline exceeded (540 seconds).' : error.stack || String(error);
      process.exitCode = 1;
      if (page && !page.isClosed()) await page.screenshot({ path: path.join(output, `${name}-failure.png`), timeout: 15000 }).catch(() => {});
    } finally {
      clearTimeout(deadline); closing = true;
      if (context) await context.close().catch(error => { result.cleanupError = String(error); result.status = 'failed'; process.exitCode = 1; });
      await runtimeObserver?.settle(); observer?.snapshot();
      if (result.status === 'passed') {
        try { observer.assertHealthy(); assertRuntimeMatches(result, result.identity.runtime); }
        catch (error) { result.status = 'failed'; result.failure = error.stack || String(error); process.exitCode = 1; }
      }
      result.elapsedMs = Date.now() - viewportStarted;
      await fs.writeFile(reportPath, JSON.stringify(report, null, 2) + '\n');
      console.error(JSON.stringify({ device: name, status: result.status, actions: result.actions, network: result.networkOutcome }));
    }
  }
} catch (error) {
  report.errors.push(error.stack || String(error)); process.exitCode = 1;
} finally {
  if (browser) await browser.close().catch(error => { report.errors.push(String(error)); process.exitCode = 1; });
  report.status = report.errors.length === 0 && report.checks.length === 2 && report.checks.every(check => check.status === 'passed') ? 'passed' : 'failed';
  if (report.status === 'failed') process.exitCode = 1;
  report.elapsedMs = Date.now() - started;
  await fs.writeFile(reportPath, JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ status: report.status, mode: report.mode, version: report.version, expectedSource, reportPath }));
}
