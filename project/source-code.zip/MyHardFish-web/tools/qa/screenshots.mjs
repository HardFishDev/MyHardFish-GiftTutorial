import { chromium, expect } from '@playwright/test';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const output = fileURLToPath(new URL('../../../research/game/', import.meta.url));
await fs.mkdir(output, { recursive: true });
const browser = await chromium.launch({ executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath(), args: ['--no-sandbox', '--enable-unsafe-swiftshader'] });
const report = { checkedAt: new Date().toISOString(), baseURL: process.env.GAME_URL || 'http://localhost:5173/', checks: [] };
try {
  for (const [name, viewport] of [['desktop', { width: 1440, height: 1000 }], ['mobile', { width: 390, height: 844 }], ['narrow', { width: 320, height: 740 }]]) {
    const context = await browser.newContext({ viewport, deviceScaleFactor: 1, hasTouch: name !== 'desktop', isMobile: name !== 'desktop' });
    const page = await context.newPage();
    const result = { name, viewport, errors: [] };
    page.on('pageerror', (e) => result.errors.push(e.message));
    page.on('console', (m) => { if (m.type() === 'error') result.errors.push(m.text()); });
    try {
      await page.goto(report.baseURL, { waitUntil: 'domcontentloaded' });
      await expect(page.getByTestId('scene')).toHaveAttribute('data-ready', 'true', { timeout: 60000 });
      await page.screenshot({ path: path.join(output, `${name}.png`), animations: 'disabled' });
      result.layout = await page.evaluate(() => {
        const canvas = document.querySelector('[data-testid="scene"] canvas');
        const rect = canvas.getBoundingClientRect();
        return { width: innerWidth, height: innerHeight, scrollWidth: document.documentElement.scrollWidth, canvas: { x: rect.x, y: rect.y, width: rect.width, height: rect.height }, webgl: !!canvas.getContext('webgl2') };
      });
      expect(result.layout.scrollWidth).toBeLessThanOrEqual(result.layout.width);
      expect(result.layout.webgl).toBe(true);
      expect(result.layout.canvas.width * result.layout.canvas.height / (viewport.width * viewport.height)).toBeGreaterThanOrEqual(0.98);
      await page.getByRole('button', { name: '打开生活菜单', exact: true }).click();
      await expect(page.getByRole('dialog').getByRole('button', { name: '衣柜', exact: true })).toBeVisible();
      await page.screenshot({ path: path.join(output, `menu-${name}.png`), animations: 'disabled' });
      expect(result.errors).toEqual([]);
      result.result = 'pass';
    } catch (error) {
      result.result = 'fail';
      result.failure = error.stack || String(error);
      process.exitCode = 1;
    } finally {
      report.checks.push(result);
      await context.close();
    }
  }
} finally {
  await fs.writeFile(path.join(output, 'console.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
  await browser.close();
}
