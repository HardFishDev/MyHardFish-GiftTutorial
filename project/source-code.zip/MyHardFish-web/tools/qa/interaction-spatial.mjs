import {createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {resolve,dirname,join} from 'node:path';
import {mkdtempSync,readFileSync,writeFileSync,rmSync,readdirSync,mkdirSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {createHash} from 'node:crypto';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'../..');
// QA artifacts stay outside Git; a relative override is resolved from the project.
const output=resolve(root,process.env.QA_OUTPUT_DIR||'../research/interaction-v7');
mkdirSync(output,{recursive:true});
const require=createRequire(join(root,'package.json'));
const {build}=require('esbuild');
const temporary=mkdtempSync(join(tmpdir(),'hardfish-activity-spatial-'));
const noop=()=>{};
const canvasContext=new Proxy({}, {get:(_,key)=>key==='createLinearGradient'||key==='createRadialGradient'?()=>({addColorStop:noop}):noop});
globalThis.document={createElement:()=>({width:0,height:0,getContext:()=>canvasContext})};
const report={version:JSON.parse(readFileSync(join(root,'package.json'),'utf8')).version,checkedAt:new Date().toISOString(),scope:'Real environment geometry, navigation, world activity API and character rig CPU checks. Canvas 2D paint API only is stubbed; no renderer, GPU, pixels, audio or hardware frame rate measured.',checks:[],regions:[],errors:[]};
try {
  await build({stdin:{contents:"export * as THREE from 'three';export {FishWorld} from './src/scene';export {NanyuCharacter} from './src/character';export {buildEnvironment} from './src/environment';export {WorldNavigation} from './src/world-navigation';export {WorldCameraCutaway} from './src/world-camera-cutaway';export {resolveActivityAnchors,resolveSeats} from './src/world-activity-anchors';export {stories} from './src/content';export {quests} from './src/adventure-content';export {GAME_ACTIVITIES,STORY_NODE_ACTIVITIES} from './src/interaction-feedback';",resolveDir:root},bundle:true,format:'esm',platform:'node',outfile:join(temporary,'index.mjs'),logLevel:'silent'});
  const {THREE,FishWorld,NanyuCharacter,buildEnvironment,WorldNavigation,WorldCameraCutaway,resolveActivityAnchors,resolveSeats,stories,quests,GAME_ACTIVITIES,STORY_NODE_ACTIVITIES}=await import(pathToFileURL(join(temporary,'index.mjs')));
  const model=new NanyuCharacter();model.root.scale.setScalar(.84);
  let skin;model.root.traverse(object=>{if(object.isMesh&&object.userData.qaRole==='body')skin=object;});
  const seatClearance=seat=>{const point=new THREE.Vector3();let minimum=Infinity;model.root.updateMatrixWorld(true);for(let i=0;i<skin.geometry.getAttribute('position').count;i++){skin.getVertexPosition(i,point);if(point.z<.65&&point.y<1.5){point.applyMatrix4(skin.matrixWorld);minimum=Math.min(minimum,point.y);}}return minimum-seat.position[1];};
  const vec=(x=0,y=0,z=0)=>new THREE.Vector3(x,y,z);
  const createWorld=environment=>{
    const world=Object.create(FishWorld.prototype),events=[];
    const camera=new THREE.PerspectiveCamera(44,1440/1000,.12,260);camera.position.set(7,8,12);camera.lookAt(0,1.8,0);camera.updateMatrixWorld();
    model.setActivity(null);model.root.position.copy(environment.spawn);model.root.rotation.y=0;
    Object.assign(world,{environment,place:environment.root.userData.place,character:model,fish:model.root,nav:new WorldNavigation(environment.bounds,environment.obstacles,environment.navigationStep),activityAnchors:resolveActivityAnchors(environment,environment.root.userData.place),seats:resolveSeats(environment),activity:null,pendingActivity:null,activityViewOpen:false,cutawayWalls:environment.root.children.filter(o=>o.userData.wallAxis),obstacles:environment.obstacles,target:environment.spawn.clone(),route:[],elapsed:0,lastMove:0,host:{dataset:{},clientWidth:1440,clientHeight:1000},moveMarker:{position:vec(),visible:false},routeLine:new THREE.Line(new THREE.BufferGeometry(),new THREE.LineBasicMaterial()),navigationBeacon:new THREE.Group(),navigationTarget:null,pendingInteraction:null,focusUntil:0,joystick:new THREE.Vector2(),keys:new Set(),tmpDirection:vec(),tmpForward:vec(),tmpRight:vec(),desiredLook:vec(),lastCharacterPosition:vec(),camera,controls:{target:vec(0,1.8,0)},cameraMode:'follow',orbiting:false,inspectUntil:0,motion:'idle',onInteract:id=>events.push({id,time:world.elapsed}),hotspotInfo:[]});
    world.events=events;world.cameraCutaway=new WorldCameraCutaway(environment.root,model.root);return world;
  };
  const tick=(world,seconds,rig=true)=>{const steps=Math.ceil(seconds/.025);for(let i=0;i<steps;i++){const dt=seconds/steps;world.elapsed+=dt;world.tickMovement(dt);if(rig)model.update(world.elapsed,dt,'idle',world.walking);}};
  const assert=(condition,id,details)=>{if(!condition)report.errors.push({check:id,...details});return condition;};
  const cornerNav=new WorldNavigation({minX:-5,maxX:5,minZ:-5,maxZ:5},[{x:0,z:0,w:2,d:2}]);
  report.segmentRegression=[
    {id:'short-corner-crossing',a:[1.59,1.61],b:[1.61,1.585],clear:false},
    {id:'reversed-corner-crossing',a:[1.61,1.585],b:[1.59,1.61],clear:false},
    {id:'exact-edge-is-clear',a:[1.6,-2],b:[1.6,2],clear:true},
    {id:'outside-parallel-is-clear',a:[2,-2],b:[2,2],clear:true},
    {id:'through-obstacle',a:[-3,0],b:[3,0],clear:false},
    {id:'outside-world-boundary',a:[4,0],b:[4.8,0],clear:false},
  ].map(item=>{const actual=cornerNav.clearSegment({x:item.a[0],z:item.a[1]},{x:item.b[0],z:item.b[1]});assert(actual===item.clear,'exact-route-segment', {...item,actual});return {...item,actual,status:actual===item.clear?'passed':'failed'};});

  const places=['home','kitchen','park','shop','school','village','workshop','river','market'];
  // Independent UI menu fixtures, plus every quest's actual playAt destination.
  const gamePlaces=new Map([['words:workshop',{game:'words',place:'workshop',origin:'menu'}],['harvest:workshop',{game:'harvest',place:'workshop',origin:'menu'}],['bottle:park',{game:'bottle',place:'park',origin:'menu'}],['cook:kitchen',{game:'cook',place:'kitchen',origin:'menu'}],['math:school',{game:'math',place:'school',origin:'menu'}],['words:school',{game:'words',place:'school',origin:'school-desk supported alias'}]]);
  for(const quest of quests)for(const stage of quest.stages)for(const req of stage.requirements??[])if(req.kind==='game')gamePlaces.set(`${req.game}:${stage.place}`,{game:req.game,place:stage.place,origin:`quest:${quest.id}/${stage.id}`});
  const reset=world=>{world.cancelActivity();world.clearNavigation();model.root.position.copy(world.environment.spawn);world.target.copy(model.root.position);model.root.rotation.y=0;model.setActivity(null);};
  const request=(world,kind,options,id,details={})=>{
    const started=world.elapsed,accepted=world.beginActivity(kind,options);let collision=false;const collisionSamples=[];
    for(let n=0;n<4000&&world.pendingActivity;n++){tick(world,.025,false);if(world.walking&&!world.activity&&world.nav.blocked(model.root.position.x,model.root.position.z)){collision=true;if(collisionSamples.length<3)collisionSamples.push({position:model.root.position.toArray(),obstacles:world.obstacles.filter(o=>Math.abs(model.root.position.x-o.x)<o.w/2+.6&&Math.abs(model.root.position.z-o.z)<o.d/2+.6)});}}
    tick(world,1.6);
    const actual=world.activity,pose=model.getActivitySnapshot(),snapshot=world.getSnapshot().activity;
    const prop=options.prop??({sit:'none',read:'book',cook:'spatula',water:'wateringCan',shop:'bag',play:'ball',write:'pencil',inspect:'magnifier',talk:'none',celebrate:'lantern',eat:'food'})[kind];
    const propVisible=prop==='none'||pose.visibleProps.some(p=>p.prop===prop||(prop==='cup'&&['milk','coffee'].includes(p.prop))||(prop==='food'&&p.prop===(options.food??'bun')));
    const sample={...details,kind,accepted,actualKind:actual?.kind??null,requestedHotspotId:snapshot?.requestedHotspotId??null,hotspotId:actual?.anchor?.hotspotId??null,anchorId:actual?.anchor?.id??null,seat:actual?.seat?.id??null,approach:actual?.returnPoint.toArray()??null,prop,propVisible,visibleProps:pose.visibleProps.map(p=>p.prop),seconds:world.elapsed-started,collision,collisionSamples,seatContactError:snapshot?.seatContactError??null};
    const physical=Boolean(actual?.anchor&&world.activityAnchors.includes(actual.anchor)&&actual.anchor.place===world.place);
    const safeReturn=actual?!world.nav.blocked(actual.returnPoint.x,actual.returnPoint.z):false;
    const expectedRequest=details.story?`story:${details.story}`:details.game??options.hotspotId;
    const requestPreserved=!expectedRequest||snapshot?.requestedHotspotId===expectedRequest;
    // Market's standing stall has no chair within reach: decline seated=true
    // instead of inventing an unsupported chair or dragging a distant seat over.
    const requiredSeat=(kind==='sit'||options.seated)&&!(details.game==='words'&&world.place==='market');
    const seatOk=!requiredSeat||Boolean(actual?.seat&&sample.seatContactError<.09&&seatClearance(actual.seat)>-.025);
    sample.status=accepted&&actual?.kind===kind&&!world.pendingActivity&&physical&&safeReturn&&!collision&&propVisible&&seatOk&&requestPreserved?'passed':'failed';
    assert(sample.status==='passed',id,{place:world.place,...sample,physical,safeReturn,seatOk,requestPreserved});return sample;
  };
  for(const place of places){
    const env=buildEnvironment(place);env.root.userData.place=place;
    const world=createWorld(env),region={place,hotspots:[],seats:[],exploration:[],ordinary:[],cutaway:[],games:[],storyStarts:[],storyContinues:[],storyNodes:[],crossRegionContinues:[],invalidRequests:[],activityCamera:[],storyCutaway:[]};
    for(const anchor of world.activityAnchors){
      model.root.position.copy(env.spawn);world.clearNavigation();world.activity=null;world.pendingActivity=null;model.setActivity(null);
      const approach=world.safeActivityPoint(...anchor.approach),path=approach?world.nav.findPath(model.root.position,approach.x,approach.z):[],end=path.at(-1);let previous=env.spawn,collision=false;
      for(const point of path){if(!world.nav.clearSegment(previous,point))collision=true;previous=point;}
      const ok=Boolean(approach&&end&&Math.hypot(end.x-approach.x,end.z-approach.z)<.25&&!collision);
      const seat=anchor.seat;region.hotspots.push({id:anchor.id,hotspotId:anchor.hotspotId,kind:anchor.activity?.kind??null,seat:seat?.id??null,approach:approach?.toArray()??null,fallbackDistance:approach?Math.hypot(approach.x-anchor.approach[0],approach.z-anchor.approach[1]):null,segments:path.length,status:ok?'passed':'failed'});
      assert(ok,'hotspot-route',{place,id:anchor.id});
    }
    for(const seat of world.seats){
      world.cancelActivity();model.root.position.copy(env.spawn);world.target.copy(env.spawn);
      const approach=world.safeActivityPoint(...seat.approach);
      if(!assert(Boolean(approach),'seat-approach',{place,seat:seat.id}))continue;
      const anchor=world.activityAnchors.find(a=>a.seat?.id===seat.id);
      model.root.position.copy(approach);world.startActivity('sit',{prop:'cup',seated:true},anchor,seat,approach.clone());tick(world,1.6);
      const pose=model.getActivitySnapshot(),contact=pose.seatContact,error=Math.hypot(...seat.position.map((x,i)=>x-contact[i]));
      const sample={id:seat.id,seatPosition:seat.position,approach:approach.toArray(),approachFallback:Math.hypot(approach.x-seat.approach[0],approach.z-seat.approach[1]),contact,error,root:model.root.position.toArray(),groundY:env.heightAt(model.root.position.x,model.root.position.z),seatHeight:world.activity.context.seatHeight,propVisible:pose.visibleProps.some(p=>['cup','milk','coffee'].includes(p.prop))};
      sample.whiteLegClearance=seatClearance(seat);
      assert(error<.09,'seat-contact',{place,...sample});
      assert(sample.whiteLegClearance>-.025&&sample.whiteLegClearance<.08,'seat-white-leg-plane',{place,...sample});
      world.cancelActivity();sample.returnSafe=!world.nav.blocked(model.root.position.x,model.root.position.z);sample.returnError=model.root.position.distanceTo(approach);assert(sample.returnSafe&&sample.returnError<.01,'seat-return',{place,...sample});region.seats.push(sample);
    }
    for(const anchor of world.activityAnchors.filter(a=>a.activity)){
      world.cancelActivity();world.clearNavigation();model.root.position.copy(env.spawn);world.target.copy(env.spawn);world.events.length=0;const accepted=world.walkToHotspot(anchor.hotspotId,{interactOnArrival:true,anchorId:anchor.id});const before=world.elapsed;
      for(let n=0;n<3200&&!world.events.length;n++)tick(world,.025,false);
      tick(world,1.6);
      const expected=anchor.activity.kind==='sit'&&!anchor.seat?'talk':anchor.activity.kind;
      const navigationPreserved=world.navigationTarget?.id===anchor.hotspotId;
      const sample={id:anchor.hotspotId,accepted,events:world.events.length,elapsed:world.elapsed-before,kind:world.activity?.kind??null,expected,seat:world.activity?.seat?.id??null,visibleProps:model.getActivitySnapshot().visibleProps.map(p=>p.prop),navigationPreserved};
      if(anchor.hotspotId==='write'&&['home','school','workshop'].includes(place)||anchor.hotspotId==='read'&&place==='park'){sample.whiteLegClearance=world.activity?.seat?seatClearance(world.activity.seat):null;assert(Boolean(world.activity?.seat)&&sample.whiteLegClearance>-.025&&sample.whiteLegClearance<.08,'ordinary-seated-label',{place,...sample});}
      sample.propVisible=anchor.activity.prop==='none'||sample.visibleProps.includes(anchor.activity.prop)||(anchor.activity.prop==='cup'&&sample.visibleProps.some(p=>['milk','coffee'].includes(p)));
      assert(accepted&&world.events.length===1&&sample.kind===expected&&navigationPreserved&&sample.propVisible,'hotspot-arrival',{place,...sample});(anchor.hotspotId.startsWith('adventure:')?region.exploration:region.ordinary).push(sample);
      if(anchor.hotspotId.startsWith('adventure:')) {
        for(const viewport of ['desktop','mobile']) {
          const cutaway=world.cameraCutaway;cutaway.restore();
          const offset=env.camera?.[viewport]??(viewport==='mobile'?[6.4,6.7,10.9]:[7.2,6.3,10.4]);
          const look=model.root.position.clone().add(vec(0,1.8,-.2));
          world.camera.position.copy(look).add(vec(...offset));world.camera.lookAt(look);world.camera.updateMatrixWorld();
          const geometryIds=[],visibility=[];
          env.root.traverse(object=>{if(object.isMesh)geometryIds.push(object.geometry.uuid);let owner=object;while(owner&&!owner.userData.cameraOccluder)owner=owner.parent;if(!owner)visibility.push([object,object.visible]);});
          cutaway.update(world.camera.position,world.elapsed);
          const state=cutaway.getSnapshot(),remainingHits=[];
          const visibleMeshes=[];env.root.traverseVisible(object=>{if(!object.isMesh)return;let owner=object;while(owner&&!owner.userData.cameraOccluder)owner=owner.parent;if(owner)visibleMeshes.push(object);});
          for(const name of ['eat-contact','left-eye','right-eye']) {
            const point=model.root.getObjectByName(name).getWorldPosition(vec());
            const delta=point.clone().sub(world.camera.position),distance=delta.length();
            const ray=new THREE.Raycaster(world.camera.position,delta.normalize(),0,Math.max(0,distance-.02));
            for(const hit of ray.intersectObjects(visibleMeshes,false))remainingHits.push({target:name,distance:hit.distance});
          }
          const mustHide=anchor.hotspotId==='adventure:park_pavilion'?'pavilion-roof-and-eaves':anchor.hotspotId==='adventure:kitchen_table'?'pendant:5.3:1.7':null;
          assert(!mustHide||state.hidden.includes(mustHide),'cutaway-reproduction',{place,viewport,hotspotId:anchor.hotspotId,mustHide,state});
          assert(remainingHits.length===0,'cutaway-visible-ray',{place,viewport,hotspotId:anchor.hotspotId,remainingHits});
          assert(visibility.every(([object,visible])=>object.visible===visible),'cutaway-retains-furniture',{place,viewport,hotspotId:anchor.hotspotId});
          for(let i=0;i<50;i++)cutaway.update(world.camera.position,world.elapsed+i/60);
          const after=[];env.root.traverse(object=>{if(object.isMesh)after.push(object.geometry.uuid);});
          assert(geometryIds.join('|')===after.join('|'),'cutaway-fixed-geometry',{place,viewport});
          const savedPosition=model.root.position.clone();model.root.position.copy(env.spawn);const away=env.spawn.clone().add(vec(0,1.8,-.2)).add(vec(...offset));cutaway.update(away,world.elapsed+2);
          assert(state.hidden.every(id=>!cutaway.getSnapshot().hidden.includes(id)),'cutaway-leaving-restores',{place,viewport,hotspotId:anchor.hotspotId});model.root.position.copy(savedPosition);
          cutaway.update(world.camera.position,world.elapsed+3,false);
          assert(cutaway.getSnapshot().hiddenCount===0&&cutaway.getSnapshot().hidden.length===0,'cutaway-restores',{place,viewport});
          region.cutaway.push({id:anchor.hotspotId,viewport,...state,remainingHits:remainingHits.length,unrelatedFurniturePreserved:true});
        }
      }

    }
    // Real activity anchors retain zoom/elevation while revealing hand props
    // from behind. These tests complement, not replace, default-offset cutaway.
    const cameraCases=world.activityAnchors.filter(a=>['read','write','cook','sit'].includes(a.activity?.kind)).map(anchor=>({anchor,preset:anchor.activity}));
    const mealAnchor=world.activityAnchors.find(anchor=>anchor.seat?.kinds.includes('eat'));
    if(mealAnchor)cameraCases.push({anchor:mealAnchor,preset:{kind:'eat',prop:'cup',food:'milk',seated:true}});
    for(const {anchor,preset} of cameraCases){
      reset(world);const kind=preset.kind,seat=preset.seated?anchor.seat:undefined;
      const approach=world.safeActivityPoint(...(seat?.approach??anchor.approach));
      if(!approach){assert(false,'activity-camera-approach',{place,id:anchor.id});continue;}
      model.root.position.copy(approach);world.target.copy(approach);
      const facing=seat?.facing??anchor.facing,center=seat?vec(...seat.position):approach.clone();
      world.controls.target.copy(center).add(vec(0,1.8,-.2));
      const offset=env.camera?.desktop??[7.2,6.3,10.4],radius=Math.hypot(offset[0],offset[2]);
      const behind=()=>world.camera.position.set(world.controls.target.x-Math.sin(facing)*radius,world.controls.target.y+offset[1],world.controls.target.z-Math.cos(facing)*radius);
      behind();const distance=world.camera.position.distanceTo(world.controls.target),height=world.camera.position.y;
      world.startActivity(kind,{...preset},anchor,seat,approach.clone());
      const horizontal=world.camera.position.clone().sub(world.activity.goal);horizontal.y=0;horizontal.normalize();
      const forwardDot=horizontal.dot(vec(Math.sin(facing),0,Math.cos(facing)));
      const distanceError=Math.abs(distance-world.camera.position.distanceTo(world.controls.target)),heightError=Math.abs(height-world.camera.position.y);
      const sample={id:anchor.id,kind,forwardDot,distanceError,heightError,wallClearances:world.cutawayWalls.map(wall=>world.camera.position[wall.userData.wallAxis]-wall.position[wall.userData.wallAxis])};
      assert(forwardDot>.05&&distanceError<1e-8&&heightError<1e-8,'activity-camera-facing',{place,...sample});
      assert(sample.wallClearances.every(clearance=>clearance>.1),'activity-camera-room-walls',{place,...sample});
      const position=world.camera.position.clone();world.setActivityView(true);world.setActivityView(false);world.setActivityView(true);
      assert(world.camera.position.distanceTo(position)<1e-8,'activity-camera-repeat-open',{place,id:anchor.id});
      behind();const manualPosition=world.camera.position.clone();
      world.startActivity(kind,{...preset},anchor,seat,approach.clone(),true);
      assert(world.camera.position.distanceTo(manualPosition)<1e-8,'activity-camera-reuse',{place,id:anchor.id});
      for(const guard of ['orbiting','recent-orbit','overview']){
        world.activity.cameraFramed=false;world.orbiting=guard==='orbiting';world.inspectUntil=guard==='recent-orbit'?world.elapsed+2:0;world.cameraMode=guard==='overview'?'overview':'follow';
        world.frameActivityCamera();assert(world.camera.position.distanceTo(manualPosition)<1e-8,'activity-camera-user-control',{place,id:anchor.id,guard});
      }
      world.orbiting=false;world.inspectUntil=0;world.cameraMode='follow';world.activity.cameraFramed=false;
      world.camera.position.set(world.controls.target.x+Math.sin(facing+.5)*radius,height,world.controls.target.z+Math.cos(facing+.5)*radius);const front=world.camera.position.clone();
      world.frameActivityCamera();assert(world.camera.position.distanceTo(front)<1e-8,'activity-camera-preserve-front',{place,id:anchor.id});
      sample.status=report.errors.some(e=>e.id===anchor.id&&e.check?.startsWith('activity-camera-'))?'failed':'passed';region.activityCamera.push(sample);
      world.setActivityView(false);
    }
    if(place==='home')for(const viewport of ['desktop','mobile']){
      reset(world);world.cameraCutaway.restore();world.mobile=viewport==='mobile';world.host.clientWidth=world.mobile?390:1440;world.host.clientHeight=world.mobile?844:1000;world.camera.aspect=world.host.clientWidth/world.host.clientHeight;
      const offset=env.camera?.[viewport]??(world.mobile?[6.4,6.7,10.9]:[7.2,6.3,10.4]);
      world.controls.target.copy(model.root.position).add(vec(0,1.8,-.2));world.camera.position.copy(world.controls.target).add(vec(...offset));world.camera.lookAt(world.controls.target);world.camera.updateMatrixWorld();world.setActivityView(true);
      const start=request(world,'talk',{hotspotId:'story:fanclub',prop:'none'},'story-cutaway-action',{story:'fanclub',node:'start',viewport});
      const action=request(world,'write',{prop:'pencil',duration:5.2},'story-cutaway-action',{story:'fanclub',node:'rename',viewport});
      world.camera.lookAt(world.controls.target);world.camera.updateMatrixWorld();env.root.updateMatrixWorld(true);model.root.updateMatrixWorld(true);
      const visibleHits=()=>{
        const meshes=[];env.root.traverseVisible(object=>{if(!object.isMesh)return;let owner=object;while(owner&&!owner.userData.cameraOccluder)owner=owner.parent;if(!owner)return;const materials=Array.isArray(object.material)?object.material:[object.material];if(materials.every(m=>!m.visible||m.opacity===0))return;meshes.push(object);});
        const hits=[];for(const name of ['eat-contact','left-eye','right-eye']){
          const point=model.root.getObjectByName(name).getWorldPosition(vec()),delta=point.clone().sub(world.camera.position),distance=delta.length();
          const ray=new THREE.Raycaster(world.camera.position,delta.normalize(),0,Math.max(0,distance-.02));
          for(const hit of ray.intersectObjects(meshes,false)){let owner=hit.object;while(owner&&!owner.userData.cameraOccluder)owner=owner.parent;hits.push({target:name,object:owner?.name??hit.object.name??'static',distance:hit.distance});}
        }return hits;
      };
      const beforeHits=visibleHits(),geometryIds=[],visibility=[];const obstaclesBefore=JSON.stringify(env.obstacles);
      env.root.traverse(object=>{if(object.isMesh)geometryIds.push(object.geometry.uuid);let owner=object;while(owner&&!owner.userData.cameraOccluder)owner=owner.parent;if(!owner)visibility.push([object,object.visible]);});
      world.cameraCutaway.update(world.camera.position,world.elapsed);const state=world.cameraCutaway.getSnapshot(),afterHits=visibleHits();
      assert(beforeHits.some(hit=>['home-wardrobe-upper','home-writing-screen'].includes(hit.object))&&['home-wardrobe-upper','home-writing-screen'].every(id=>state.hidden.includes(id)),'story-cutaway-reproduces',{viewport,beforeHits,state});
      assert(afterHits.length===0,'story-cutaway-visible-head',{viewport,afterHits,state});
      assert(visibility.every(([object,visible])=>object.visible===visible)&&obstaclesBefore===JSON.stringify(env.obstacles),'story-cutaway-preserves-furniture',{viewport});
      for(let i=0;i<60;i++)world.cameraCutaway.update(world.camera.position,world.elapsed+i/60);
      const afterGeometry=[];env.root.traverse(object=>{if(object.isMesh)afterGeometry.push(object.geometry.uuid);});
      assert(geometryIds.join('|')===afterGeometry.join('|'),'story-cutaway-fixed-geometry',{viewport});
      world.cancelActivity();model.root.position.copy(env.spawn);world.target.copy(env.spawn);world.controls.target.copy(env.spawn).add(vec(0,1.8,-.2));world.camera.position.copy(world.controls.target).add(vec(...offset));world.cameraCutaway.update(world.camera.position,world.elapsed+2);
      const restored=state.hidden.every(id=>!world.cameraCutaway.getSnapshot().hidden.includes(id));assert(restored,'story-cutaway-leaving-restores',{viewport,state,after:world.cameraCutaway.getSnapshot()});
      region.storyCutaway.push({viewport,start,action,rayScope:'All still-visible cameraOccluder geometry, excluding untagged trees whose canopy visibility is handled separately by the render loop.',beforeHits,afterHits,hidden:state.hidden,restored,furnitureRetained:true,fixedGeometry:true,status:report.errors.some(e=>e.check?.startsWith('story-cutaway-')&&e.viewport===viewport)?'failed':'passed'});
      world.cameraCutaway.restore();world.setActivityView(false);world.mobile=false;world.host.clientWidth=1440;world.host.clientHeight=1000;world.camera.aspect=1440/1000;world.camera.updateProjectionMatrix();
    }
    // Physical game hotspots also enter the mini-game through sceneAction.
    for(const game of Object.keys(GAME_ACTIVITIES))if(world.activityAnchors.some(a=>a.hotspotId===game)&&!gamePlaces.has(`${game}:${place}`))gamePlaces.set(`${game}:${place}`,{game,place,origin:'physical hotspot'});
    for(const fixture of [...gamePlaces.values()].filter(item=>item.place===place)){
      reset(world);const feedback=GAME_ACTIVITIES[fixture.game];
      if(fixture.game==='cook')region.games.push(request(world,'inspect',{...feedback,prop:'magnifier'},'logical-game-preview',{...fixture,phase:'preview'}));
      region.games.push(request(world,feedback.kind,feedback,'logical-game-action',{...fixture,phase:'playing'}));
      world.cancelActivity();assert(!world.nav.blocked(model.root.position.x,model.root.position.z),'logical-game-safe-return',{place,game:fixture.game});
    }
    for(const story of stories.filter(story=>story.place===place)){
      reset(world);const start=STORY_NODE_ACTIVITIES[story.id].start;
      region.storyStarts.push(request(world,start.kind,{...start,hotspotId:`story:${story.id}`},'logical-story-start',{story:story.id,node:'start'}));
      // Choice feedback has no hotspot ID in the real App; preserve the story's
      // logical context while testing every real node's semantic transition.
      for(const node of Object.keys(story.nodes)){
        const feedback=STORY_NODE_ACTIVITIES[story.id][node];
        if(!feedback){assert(false,'logical-story-node-mapping',{place,story:story.id,node});continue;}
        region.storyNodes.push(request(world,feedback.kind,{...feedback,duration:5.2},'logical-story-node',{story:story.id,node}));
      }
      const node=Object.keys(story.nodes).at(-1),feedback=STORY_NODE_ACTIVITIES[story.id][node];
      reset(world);region.storyContinues.push(request(world,feedback.kind,{...feedback,hotspotId:`story:${story.id}`},'logical-story-continue',{story:story.id,node}));
    }
    for(const [index,story] of stories.entries()){
      let destination=places[(index+1)%places.length];if(destination===story.place)destination=places[(places.indexOf(destination)+1)%places.length];
      if(destination!==place)continue;
      reset(world);const feedback=STORY_NODE_ACTIVITIES[story.id].start;
      region.crossRegionContinues.push(request(world,feedback.kind,{...feedback,hotspotId:`story:${story.id}`},'logical-story-cross-region',{story:story.id,originalPlace:story.place}));
    }
    // Bad explicit IDs must not borrow a nearby object or cancel a valid action.
    reset(world);world.beginActivity('talk',{duration:5});tick(world,1);
    const wrongArea=place==='home'?'adventure:park_pavilion':'adventure:home_notice';
    for(const id of ['adventure:missing','story:missing','wrods',wrongArea]){
      const before=world.activity,accepted=world.beginActivity('read',{hotspotId:id});
      const preserved=!accepted&&world.activity===before&&!world.pendingActivity;
      region.invalidRequests.push({id,accepted,preserved,status:preserved?'passed':'failed'});assert(preserved,'logical-invalid-request',{place,id});
    }
    // Lifecycle: timed approaches survive closing a panel; untimed approaches stop.
    const target=world.activityAnchors.find(a=>a.activity?.kind==='read'&&!a.activity.seated)??world.activityAnchors.find(a=>a.activity);
    if(target){
      world.cancelActivity();world.clearNavigation();model.root.position.copy(env.spawn);world.target.copy(env.spawn);
      world.beginActivity('read',{hotspotId:target.hotspotId,duration:5});const hadPending=Boolean(world.pendingActivity);world.cancelActivity({retainTimed:true});assert(Boolean(world.activity||world.pendingActivity),'retain-timed',{place});world.cancelActivity();
      const stoppedAfterCancel=!world.pendingActivity&&!world.activity&&world.route.length===0&&world.target.distanceTo(model.root.position)<.01;assert(stoppedAfterCancel,'cancel-route',{place,hadPending});
      world.beginActivity('read',{hotspotId:target.hotspotId});world.cancelActivity({retainTimed:true});assert(!world.activity&&!world.pendingActivity&&world.route.length===0,'cancel-untimed',{place});
    }
    region.hotspotCount=region.hotspots.length;region.seatCount=region.seats.length;
    report.regions.push(region);world.cancelActivity();world.routeLine.geometry.dispose();world.routeLine.material.dispose();world.cameraCutaway.dispose();env.dispose();console.log(JSON.stringify({place,hotspots:region.hotspotCount,seats:region.seatCount,errors:report.errors.filter(e=>e.place===place).length}));
  }
  model.dispose();
  report.logicalCoverage={gameLocations:[...gamePlaces.values()],storyCount:stories.length,nodeCount:stories.reduce((n,story)=>n+Object.keys(story.nodes).length,0)};
  report.checks=[{id:'exact-route-segment-corner-regressions',status:report.errors.some(e=>e.check==='exact-route-segment')?'failed':'passed',count:report.segmentRegression.length},{id:'all-hotspot-safe-routes',status:report.errors.some(e=>e.check==='hotspot-route')?'failed':'passed',count:report.regions.reduce((n,r)=>n+r.hotspots.length,0)},{id:'seat-contact-and-safe-return',status:report.errors.some(e=>e.check?.startsWith('seat-'))?'failed':'passed',count:report.regions.reduce((n,r)=>n+r.seats.length,0)},{id:'default-hotspot-actions-after-arrival',status:report.errors.some(e=>e.check==='hotspot-arrival')?'failed':'passed',count:report.regions.reduce((n,r)=>n+r.exploration.length+r.ordinary.length,0)},{id:'timed-and-canceled-navigation',status:report.errors.some(e=>['retain-timed','cancel-route','cancel-untimed'].includes(e.check))?'failed':'passed',count:27},{id:'ordinary-labels-use-real-seats',status:report.errors.some(e=>e.check==='ordinary-seated-label')?'failed':'passed',count:4},{id:'camera-cutaway-head-rays-and-restoration',status:report.errors.some(e=>e.check?.startsWith('cutaway-'))?'failed':'passed',count:report.regions.reduce((n,r)=>n+r.cutaway.length,0)},...[
    ['activity-camera-front-side-and-player-control',['activity-camera-approach','activity-camera-facing','activity-camera-room-walls','activity-camera-repeat-open','activity-camera-reuse','activity-camera-user-control','activity-camera-preserve-front'],'activityCamera'],
    ['story-writing-screen-head-rays-and-restoration',['story-cutaway-action','story-cutaway-reproduces','story-cutaway-visible-head','story-cutaway-preserves-furniture','story-cutaway-fixed-geometry','story-cutaway-leaving-restores'],'storyCutaway'],
    ['logical-game-entry-and-play',['logical-game-preview','logical-game-action','logical-game-safe-return'],'games'],
    ['logical-story-start',['logical-story-start'],'storyStarts'],
    ['logical-story-continue',['logical-story-continue'],'storyContinues'],
    ['logical-story-all-node-transitions',['logical-story-node','logical-story-node-mapping'],'storyNodes'],
    ['logical-story-resume-after-map-travel',['logical-story-cross-region'],'crossRegionContinues'],
    ['logical-invalid-requests-remain-strict',['logical-invalid-request'],'invalidRequests'],
  ].map(([id,ids,key])=>({id,status:report.errors.some(e=>ids.includes(e.check))?'failed':'passed',count:report.regions.reduce((n,r)=>n+r[key].length,0)}))];
} catch(error){report.errors.push({id:'exception',message:String(error),stack:error.stack});}
finally{
 const sources=['App.tsx','content.ts','relationships.ts','adventure-content.ts','interaction-feedback.ts','scene.ts','character.ts','character-activity.ts','character-props.ts','character-form.ts','character-rig.ts','world-activities.ts','world-activity-anchors.ts','world-interaction-props.ts','world-navigation.ts','world-camera-cutaway.ts','world-layout.ts','world-home-terrace.ts','world-town-props.ts','world-atmosphere.ts',...readdirSync(join(root,'src')).filter(f=>/^environment.*\.ts$/.test(f))].filter(f=>{try{readFileSync(join(root,'src',f));return true}catch{return false}});
 report.testedSource={pathBase:'code/',files:Object.fromEntries(sources.map(file=>{const data=readFileSync(join(root,'src',file));return['src/'+file,{bytes:data.length,sha256:createHash('sha256').update(data).digest('hex')}]}))};
 const runner=readFileSync(fileURLToPath(import.meta.url));report.testedSource.files['tools/qa/interaction-spatial.mjs']={bytes:runner.length,sha256:createHash('sha256').update(runner).digest('hex')};
 report.status=report.errors.length?'failed':'passed';writeFileSync(join(output,'world-activity-spatial-check.json'),JSON.stringify(report,null,2)+'\n');rmSync(temporary,{recursive:true,force:true});
 console.log(JSON.stringify({status:report.status,checks:report.checks,errors:report.errors},null,2));if(report.errors.length)process.exitCode=1;
}
