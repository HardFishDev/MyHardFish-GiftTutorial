/** Isolated sound lifecycle contracts; no network, browser or real audio device. */
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import vm from 'node:vm';
import { test } from 'node:test';
import ts from 'typescript';

const source = await fs.readFile(new URL('../../src/cycling-audio.ts', import.meta.url), 'utf8');
const catalog = JSON.parse(await fs.readFile(new URL('../../src/cycling-audio-catalog.json', import.meta.url), 'utf8'));
const compiled = ts.transpileModule(source, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
  fileName: 'cycling-audio.ts', reportDiagnostics: true,
});
assert.equal(compiled.diagnostics?.filter(item => item.category === ts.DiagnosticCategory.Error).length, 0);

function harness({ noContext = false, failFetch = false, failDecode = false } = {}) {
  const h = { now: 0, random: 0, requests: [], started: [], contexts: [] };
  class Target {
    listeners = new Map();
    hidden = false;
    addEventListener(name, callback) {
      if (!this.listeners.has(name)) this.listeners.set(name, new Set());
      this.listeners.get(name).add(callback);
    }
    removeEventListener(name, callback) { this.listeners.get(name)?.delete(callback); }
    emit(name) { for (const callback of this.listeners.get(name) || []) callback(); }
    count() { return [...this.listeners.values()].reduce((sum, listeners) => sum + listeners.size, 0); }
  }
  class Context {
    state = 'suspended';
    destination = {};
    closeCalls = 0;
    constructor() { h.contexts.push(this); }
    async decodeAudioData(bytes) {
      if (failDecode) throw new Error('unsupported');
      return { url: bytes.url, duration: bytes.url.includes('voice') ? 1.9 : 0.6 };
    }
    createBufferSource() {
      const node = {
        buffer: null, stopped: false, disconnected: false, onended: null,
        connect() {}, disconnect() { this.disconnected = true; },
        start() { h.started.push(this); },
        stop() { this.stopped = true; this.onended?.(); },
        finish() { this.onended?.(); },
      };
      return node;
    }
    createGain() { return { gain: { value: 1 }, connect() {}, disconnect() {} }; }
    async resume() { this.state = 'running'; }
    async suspend() { this.state = 'suspended'; }
    async close() { this.closeCalls++; this.state = 'closed'; }
  }
  h.window = new Target();
  h.document = new Target();
  if (!noContext) h.window.AudioContext = Context;
  const namespace = {};
  vm.runInNewContext(compiled.outputText, {
    exports: namespace, window: h.window, document: h.document, AbortController,
    performance: { now: () => h.now }, Math: Object.assign(Object.create(Math), { random: () => h.random }),
    require(name) {
      assert.equal(name, './cycling-assets', 'the cycling bank must not import town audio or its engine');
      return { cyclingAudioUrl: id => `./audio/${catalog[id].file}` };
    },
    fetch: async (url, options) => {
      h.requests.push({ url, options });
      if (failFetch) throw new Error('offline');
      return { ok: true, arrayBuffer: async () => ({ url }) };
    },
  });
  h.audio = new namespace.CyclingAudio({ effects: true, voice: true, volume: 0.7 });
  h.clips = id => h.started.filter(clip => clip.buffer.url.endsWith(catalog[id].file));
  h.activeVoices = () => h.clips('pickupVoice').filter(clip => !clip.disconnected);
  return h;
}

test('loads only the four cycling MP3s and stays silent before gesture unlock', async () => {
  const h = harness();
  await h.audio.ready;
  assert.deepEqual(h.requests.map(request => request.url).sort(), Object.values(catalog).map(track => `./audio/${track.file}`).sort());
  assert.ok(h.requests.every(request => request.options.cache === 'force-cache'));
  h.audio.pickup('cover'); h.audio.hit('hole');
  assert.equal(h.started.length, 0);
  h.audio.unlock();
  h.audio.pickup('cover');
  assert.equal(h.clips('pickupMetal').length, 1);
  assert.equal(h.clips('pickupVoice').length, 1);
  h.audio.dispose();
});

test('voice is probabilistic, exclusive to covers, with cooldown and no overlapping queue', async () => {
  const h = harness(); await h.audio.ready; h.audio.unlock();
  h.random = 0.99;
  h.audio.pickup('cover');
  assert.equal(h.clips('pickupVoice').length, 0);
  h.random = 0;
  h.now = 100; h.audio.pickup('bottle');
  h.now = 200; h.audio.pickup('parcel');
  assert.equal(h.clips('pickupVoice').length, 0);
  h.now = 300; h.audio.pickup('cover');
  assert.equal(h.clips('pickupVoice').length, 1);
  h.now = 9500; h.audio.pickup('cover');
  assert.equal(h.clips('pickupVoice').length, 1, 'an active voice owns the only slot even after the cooldown');
  h.clips('pickupVoice')[0].finish();
  h.now = 9600; h.audio.pickup('cover');
  assert.equal(h.clips('pickupVoice').length, 2);
  h.clips('pickupVoice')[1].finish();
  h.now = 12000; h.audio.pickup('cover');
  assert.equal(h.clips('pickupVoice').length, 2, 'ending a voice does not bypass its cooldown');
  assert.equal(h.activeVoices().length, 0, 'no queued voice starts when a preceding one ends');
  h.audio.dispose();
});

test('obstacle thud stays audible beside a pickup and caps effect layering', async () => {
  const h = harness(); await h.audio.ready; h.audio.unlock();
  h.random = 0.99;
  for (let i = 0; i < 12; i++) { h.now += 100; h.audio.pickup('bottle'); }
  assert.equal(h.started.filter(clip => !clip.stopped).length, 4);
  h.audio.hit('hole');
  assert.equal(h.clips('hit').length, 1, 'a hit bypasses the short pickup throttle');
  assert.equal(h.started.filter(clip => !clip.stopped).length, 1);
  h.audio.dispose();
});

test('effects and voice settings are independent and apply immediately', async () => {
  const h = harness(); await h.audio.ready; h.audio.unlock();
  h.audio.setEnabled({ effects: false, voice: true, volume: 0.7 });
  h.audio.pickup('cover');
  assert.equal(h.clips('pickupMetal').length, 0);
  assert.equal(h.clips('pickupVoice').length, 1);
  h.audio.setEnabled({ effects: true, voice: false, volume: 0.7 });
  assert.equal(h.activeVoices().length, 0);
  h.audio.hit('barrier');
  assert.equal(h.clips('hit').length, 1);
  h.audio.setEnabled({ effects: true, voice: true, volume: 0 });
  assert.ok(h.started.every(clip => clip.stopped));
  h.now = 10000; h.audio.pickup('cover');
  assert.equal(h.started.length, 2);
  h.audio.dispose();
});

test('pause, hidden tabs and pagehide stop playback until explicit unlock', async () => {
  const h = harness(); await h.audio.ready; h.audio.unlock();
  h.audio.pickup('cover');
  h.audio.pause();
  assert.ok(h.started.every(clip => clip.stopped));
  h.now = 9000; h.audio.pickup('cover');
  assert.equal(h.started.length, 2);
  h.audio.unlock(); h.audio.pickup('cover');
  assert.equal(h.started.length, 4);
  h.document.hidden = true; h.document.emit('visibilitychange');
  assert.ok(h.started.every(clip => clip.stopped));
  h.document.hidden = false;
  h.document.emit('visibilitychange');
  h.now = 18000; h.audio.pickup('cover');
  assert.equal(h.started.length, 4, 'returning to a tab does not autoplay or resume a paused ride');
  h.audio.unlock(); h.audio.pickup('cover');
  h.window.emit('pagehide');
  assert.ok(h.started.every(clip => clip.stopped));
  h.audio.dispose();
});

test('dispose cancels requests, releases every node and removes lifecycle listeners once', async () => {
  const h = harness(); await h.audio.ready; h.audio.unlock(); h.audio.pickup('cover');
  h.audio.dispose(); h.audio.dispose();
  assert.ok(h.requests.every(request => request.options.signal.aborted));
  assert.ok(h.started.every(clip => clip.stopped && clip.disconnected));
  assert.equal(h.window.count() + h.document.count(), 0);
  assert.equal(h.contexts[0].closeCalls, 1);
  h.audio.unlock(); h.audio.pickup('cover');
  assert.equal(h.started.length, 2);
});

for (const failure of [{ noContext: true }, { failFetch: true }, { failDecode: true }]) {
  test(`unavailable audio is nonfatal: ${Object.keys(failure)[0]}`, async () => {
    const h = harness(failure);
    await h.audio.ready;
    h.audio.unlock(); h.audio.pickup('cover'); h.audio.hit('hole');
    assert.equal(h.started.length, 0);
    h.audio.dispose();
  });
}
