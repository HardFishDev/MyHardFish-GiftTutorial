import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { tmpdir } from 'node:os';
import { createHash } from 'node:crypto';
// CPU-only regression suite: no browser, WebGL context, or built assets required.
// Run with: node tools/qa/interaction-character.mjs
// QA_OUTPUT_DIR is resolved against the project; the default stays outside Git.
const runner = fileURLToPath(import.meta.url);
const project = path.resolve(path.dirname(runner), '../..');
const output = path.resolve(project, process.env.QA_OUTPUT_DIR || '../research/interaction-v7');
await fs.mkdir(output, { recursive: true });
const require = createRequire(path.join(project, 'package.json')), { build } = require('esbuild');
const entry = "export {NanyuCharacter} from './src/character.ts';export {characterDistance} from './src/character-form.ts';export {Vector3,Box3} from 'three';";
const bundled = await build({ absWorkingDir: project, stdin: { contents: entry, resolveDir: project, loader: 'ts' }, bundle: true, write: false, platform: 'node', format: 'esm', target: 'es2022', metafile: true });
const temporaryDirectory = await fs.mkdtemp(path.join(tmpdir(), 'hardfish-activity-cpu-'));
const temp = path.join(temporaryDirectory, 'character.mjs');
try {
    await fs.writeFile(temp, bundled.outputFiles[0].contents);
    globalThis.document = { createElement: () => ({ width: 64, height: 64, getContext: () => ({ fillRect() { }, fillStyle: '' }) }) };
    let reduced = false;
    globalThis.matchMedia = () => ({ matches: reduced });
    const { NanyuCharacter, characterDistance, Vector3, Box3 } = await import(pathToFileURL(temp).href);
    const files = {};
    for (const file of Object.keys(bundled.metafile.inputs).filter(f => f.includes('src/character'))) {
        const p = path.isAbsolute(file) ? file : path.resolve(project, file), data = await fs.readFile(p);
        files[path.relative(project, p).split(path.sep).join('/')] = { bytes: data.length, sha256: createHash('sha256').update(data).digest('hex') };
    }
    const report = { runner: { path: path.relative(project, runner).split(path.sep).join('/'), sha256: createHash('sha256').update(await fs.readFile(runner)).digest('hex') }, checkedAt: new Date().toISOString(), scope: 'CPU-only actual Three.js character geometry, no renderer or browser. Canvas stub only supplies the existing cloth texture drawing context.', testedSource: files, checks: [], samples: {}, limits: ['Does not validate GPU render resources or aesthetic quality.', 'Analytic torso clearance samples only arm vertices above y1.50 after the shoulder attachment; does not prove clothing collision freedom.', 'Seat anchor agreement validates rig alignment, not environment chair placement.'] };
    const check = (id, passed, details = {}) => report.checks.push({ id, status: passed ? 'passed' : 'failed', ...details });
    const frames = (c, n = 150, motion = 'idle', walking = false) => { for (let i = 0; i < n; i++)
        c.update(i / 60, 1 / 60, motion, walking); c.root.updateMatrixWorld(true); };
    const objects = c => { const a = []; c.root.traverse(o => a.push(o)); return a; };
    const meshes = c => objects(c).filter(o => o.isMesh);
    const visible = o => { for (let n = o; n; n = n.parent)
        if (!n.visible)
            return false; return true; };
    const finite = c => meshes(c).every(m => m.matrixWorld.elements.every(Number.isFinite) && Object.values(m.geometry.attributes).every(a => Array.from(a.array).every(Number.isFinite)) && Object.values(m.geometry.morphAttributes).flat().every(a => Array.from(a.array).every(Number.isFinite)));
    const feet = c => ['right', 'left'].map(side => { const g = c.root.getObjectByName(`${side}-foot`), box = new Box3(); box.setFromObject(g, true); return box.min.y; });
    const count = c => ({ objects: objects(c).length, geometries: new Set(meshes(c).map(m => m.geometry)).size, materials: new Set(meshes(c).flatMap(m => Array.isArray(m.material) ? m.material : [m.material])).size });
    const expected = { sit: null, read: 'book', cook: 'spatula', water: 'wateringCan', shop: 'bag', play: 'ball', write: 'pencil', inspect: 'magnifier', talk: null, celebrate: null, eat: 'bun' };
    const c = new NanyuCharacter(), skin = meshes(c).find(m => m.userData.qaRole === 'body');
    for (const [kind, prop] of Object.entries(expected)) {
        c.setActivity({ kind, seatHeight: 1.0, surfaceHeight: 1.4 });
        frames(c);
        const s = c.getActivitySnapshot();
        let armMinimumPoint = null, armMinimumValue = Infinity;
        const armVertices = meshes(c).filter(m => /^(right|left)-arm$/.test(m.name)).flatMap(m => { const p = m.geometry.getAttribute('position'), v = []; for (let i = 66; i < p.count; i++) {
            const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
            if (y > 1.50) {
                const distance = characterDistance(x, y, z);
                v.push(distance);
                if (distance < armMinimumValue) {
                    armMinimumValue = distance;
                    armMinimumPoint = { arm: m.name, index: i, position: [x, y, z] };
                }
            }
        } return v; });
        const seatSurface = [];
        if (kind === 'sit') {
            const p = new Vector3();
            for (let i = 0; i < skin.geometry.getAttribute('position').count; i++) {
                skin.getVertexPosition(i, p);
                if (p.z < .30 && p.y < 1.5)
                    seatSurface.push(p.toArray());
            }
            seatSurface.sort((a, b) => a[1] - b[1]);
        }
        report.samples[kind] = { ...s, seatSurfaceMinimum: seatSurface.slice(0, 4), seatBins: [-.3, -.2, -.1, 0, .1, .2, .3].map(z => ({ z, minimum: Math.min(...seatSurface.filter(p => p[2] > z - .05 && p[2] < z + .05).map(p => p[1])) })), footMinY: feet(c), armTorsoMinimumDistance: Math.min(...armVertices), armMinimumPoint, visibleEffects: objects(c).filter(o => o.userData.qaRole && /water-drop|cook-steam|eat-crumb/.test(o.userData.qaRole) && visible(o)).map(o => o.userData.qaRole) };
        check(`finite-pose-and-cached-prop-${kind}`, finite(c) && s.prop === prop, { prop: s.prop, expected: prop });
    }
    const signatures = Object.entries(report.samples).map(([kind, s]) => [kind, [...s.rightHand, ...s.leftHand, ...s.seatContact]]);
    check('eleven-activities-have-distinct-poses', signatures.every(([, a], i) => signatures.slice(i + 1).every(([, b]) => a.some((x, j) => Math.abs(x - b[j]) > .025))), { signatures });
    check('steam-water-and-crumb-pools-visible', report.samples.cook.visibleEffects.includes('cook-steam') && report.samples.water.visibleEffects.includes('water-drop') && report.samples.eat.visibleEffects.includes('eat-crumb'));
    for (const height of [.65, 1.05, 1.5])
        for (const kind of ['sit', 'read', 'eat']) {
            c.setActivity({ kind, seated: true, seatHeight: height });
            frames(c);
            const s = c.getActivitySnapshot();
            check(`seated-contact-and-grounded-feet-${kind}-${height}`, Math.abs(s.seatContact[1] - height) < .001 && Math.abs(s.seatContact[0]) < .001 && Math.abs(s.seatContact[2] - .10) < .001 && feet(c).every(y => Math.abs(y) < .001), { contact: s.seatContact, footMinY: feet(c) });
            const surface = new Vector3();
            let minimum = Infinity;
            for (let i = 0; i < skin.geometry.getAttribute('position').count; i++) {
                skin.getVertexPosition(i, surface);
                if (surface.z < .65 && surface.y < 1.5) {
                    surface.applyMatrix4(skin.matrixWorld);
                    minimum = Math.min(minimum, surface.y);
                }
            }
            check(`seated-white-legs-stay-above-seat-${kind}-${height}`, minimum - height > -.015 && minimum - height < .08, { minimumWorldY: minimum, seatHeight: height, clearance: minimum - height });
        }
    c.setActivity({ kind: 'read', seated: true, seatHeight: 1.1 });
    frames(c);
    const seatInfluence = skin.morphTargetInfluences[2];
    c.setQuality(true);
    check('low-quality-preserves-seat-immediately', Math.abs(skin.morphTargetInfluences[2] - seatInfluence) < 1e-9);
    frames(c);
    const lowVertices = skin.geometry.getAttribute('position').count;
    c.setQuality(false);
    check('high-quality-restores-seat-and-detail', skin.geometry.getAttribute('position').count > lowVertices && skin.morphTargetInfluences[2] > .99);
    frames(c);
    for (const outfit of ['classic', 'mint', 'chef', 'student', 'night']) {
        c.setOutfit(outfit);
        frames(c, 2);
        const s = c.getActivitySnapshot();
        check(`wardrobe-preserves-seated-book-${outfit}`, s.kind === 'read' && s.prop === 'book' && s.seated > .99 && Math.abs(s.seatContact[1] - 1.1) < .001);
    }
    const eating = {}, foodContactSamples = {};
    function propSurface(c) { c.root.updateMatrixWorld(true); const mouth = c.root.getObjectByName('eat-contact').getWorldPosition(new Vector3()), body = meshes(c).find(m => m.userData.qaRole === 'body').parent, group = c.root.getObjectByName('cached-activity-props').children.find(g => g.visible && g.userData.qaRole === 'activity-prop'); let distance = Infinity, torsoDistance = Infinity; const p = new Vector3(); group?.traverse(m => { if (!m.isMesh || !visible(m))
        return; const attr = m.geometry.getAttribute('position'); for (let i = 0; i < attr.count; i++) {
        p.fromBufferAttribute(attr, i).applyMatrix4(m.matrixWorld);
        distance = Math.min(distance, p.distanceTo(mouth));
        body.worldToLocal(p);
        torsoDistance = Math.min(torsoDistance, characterDistance(p.x, p.y, p.z));
    } }); return { mouthToPropSurface: distance, minimumTorsoDistance: torsoDistance }; }
    for (const food of ['bun', 'milk', 'peach', 'rice', 'coffee']) {
        c.setActivity({ kind: 'eat', food, prop: ['milk', 'coffee'].includes(food) ? 'cup' : 'food' });
        frames(c);
        const s = c.getActivitySnapshot();
        eating[food] = s;
        check(`food-variant-${food}`, s.prop === food && s.visibleProps.length === 1 && s.visibleProps[0].prop === food);
    }
    report.foods = eating;
    for (const food of ['bun', 'milk', 'peach', 'rice', 'coffee']) {
        c.setActivity({ kind: 'eat', food, prop: ['milk', 'coffee'].includes(food) ? 'cup' : 'food' });
        const samples = [];
        for (let i = 0; i < 12; i++) {
            frames(c, 15);
            samples.push({ ...propSurface(c), gripToMouth: c.getActivitySnapshot().gripToMouth });
        }
        foodContactSamples[food] = samples;
    }
    report.foodContactSamples = foodContactSamples;
    for (const [food, samples] of Object.entries(foodContactSamples))
        check(`food-approaches-mouth-without-torso-penetration-${food}`, Math.min(...samples.map(s => s.mouthToPropSurface)) < .09 && samples.every(s => s.minimumTorsoDistance > -.003), { nearestMouthDistance: Math.min(...samples.map(s => s.mouthToPropSurface)), minimumTorsoDistance: Math.min(...samples.map(s => s.minimumTorsoDistance)), sampleCount: samples.length });
    check('activity-arms-clear-analytic-torso-after-shoulder-attachment', Object.values(report.samples).every(s => s.armTorsoMinimumDistance > -.001), { minimumDistances: Object.fromEntries(Object.entries(report.samples).map(([kind, s]) => [kind, s.armTorsoMinimumDistance])) });
    c.setActivity({ kind: 'cook' });
    frames(c);
    c.startMotion('angry');
    frames(c, 120, 'angry');
    check('reaction-does-not-cancel-activity', c.getActivitySnapshot().kind === 'cook' && c.root.userData.motion === 'cook');
    c.setActivity(null);
    frames(c);
    check('cancel-hides-all-props', c.getActivitySnapshot().prop === null && c.getActivitySnapshot().visibleProps.length === 0);
    c.setActivity({ kind: 'read', seated: true });
    frames(c);
    frames(c, 150, 'idle', true);
    check('walking-cancels-seated-props', c.getActivitySnapshot().kind === null && c.getActivitySnapshot().prop === null && c.getActivitySnapshot().seated < .001);
    c.setActivity({ kind: 'write', target: [NaN, Infinity, NaN], surfaceHeight: NaN });
    frames(c);
    check('invalid-target-cannot-poison-geometry', finite(c));
    const captured = meshes(c).map(m => ({ m, g: m.geometry, p: m.geometry.getAttribute('position').array, n: m.geometry.getAttribute('normal')?.array })), before = count(c);
    for (let i = 0; i < 2400; i++) {
        if (i % 80 === 0)
            c.setActivity({ kind: Object.keys(expected)[Math.floor(i / 80) % 11], food: 'rice', seated: i % 240 === 0, seatHeight: .85 });
        c.update(i / 60, 1 / 60, 'dance', false);
    }
    check('2400-updates-reuse-geometries-and-buffers', captured.every(({ m, g, p, n }) => m.geometry === g && g.getAttribute('position').array === p && g.getAttribute('normal')?.array === n) && JSON.stringify(before) === JSON.stringify(count(c)), { before, after: count(c) });
    const resources = new Set([...c.geometries, ...c.materials, c.clothTexture]);
    for (const m of meshes(c)) {
        resources.add(m.geometry);
        for (const material of Array.isArray(m.material) ? m.material : [m.material])
            resources.add(material);
    }
    let disposed = 0;
    for (const r of resources)
        r.addEventListener('dispose', () => disposed++);
    c.dispose();
    c.dispose();
    check('dispose-once-clears-root-and-active-props', disposed === resources.size && c.root.children.length === 0 && c.getActivitySnapshot().prop === null, { disposed, expected: resources.size });
    reduced = true;
    const small = new NanyuCharacter();
    small.setQuality(true);
    const reducedSamples = {};
    for (const kind of ['sit', 'read', 'cook', 'water', 'eat', 'play']) {
        small.setActivity({ kind, seatHeight: 1 });
        frames(small);
        reducedSamples[kind] = small.getActivitySnapshot();
    }
    check('reduced-motion-low-quality-keeps-recognizable-activities', Object.entries(reducedSamples).every(([kind, s]) => s.kind === kind && s.prop === expected[kind] && (kind !== 'sit' || Math.abs(s.seatContact[1] - 1) < .001)), { samples: reducedSamples });
    small.dispose();
    report.status = report.checks.every(c => c.status === 'passed') ? 'passed' : 'failed';
    report.result = { passed: report.checks.filter(c => c.status === 'passed').length, failed: report.checks.filter(c => c.status === 'failed').length };
    await fs.writeFile(path.join(output, 'character-cpu-check.json'), JSON.stringify(report, null, 2) + '\n');
    console.log(JSON.stringify({ status: report.status, result: report.result, failures: report.checks.filter(c => c.status === 'failed'), clearance: Object.fromEntries(Object.entries(report.samples).map(([k, v]) => [k, v.armTorsoMinimumDistance])) }, null, 2));
    if (report.status !== 'passed')
        process.exitCode = 1;
}
finally {
    await fs.rm(temporaryDirectory, { recursive: true, force: true });
}
