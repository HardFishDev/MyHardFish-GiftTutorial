import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const dist=fileURLToPath(new URL('../../dist/',import.meta.url));
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.mp3':'audio/mpeg','.txt':'text/plain; charset=utf-8'};
const server=http.createServer(async(req,res)=>{try{const url=new URL(req.url,'http://localhost');if(!url.pathname.startsWith('/dist/')){res.writeHead(404).end();return;}const filename=path.resolve(dist,decodeURIComponent(url.pathname.slice(6))||'index.html');if(!filename.startsWith(dist)){res.writeHead(403).end();return;}const bytes=await fs.readFile(filename);res.writeHead(200,{'content-type':mime[path.extname(filename)]||'application/octet-stream','cache-control':'no-store'});res.end(req.method==='HEAD'?undefined:bytes);}catch{res.writeHead(404).end();}});
server.listen(Number(process.env.QA_PORT||5184),'127.0.0.1',()=>console.log(`Static QA: http://127.0.0.1:${server.address().port}/dist/`));
