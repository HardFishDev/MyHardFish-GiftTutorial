import { chromium, expect } from '@playwright/test';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { localPreloadManifest, observePreloads, requireFreshReport } from './pages-preload-observer.mjs';

const root = fileURLToPath(new URL('../../', import.meta.url));
const output = path.resolve(root, process.env.QA_OUTPUT_DIR || '../research/github-pages');
await fs.mkdir(output, { recursive: true });
await requireFreshReport(path.join(output, 'pages-smoke.json'));
const url = process.env.QA_PAGES_URL || 'https://hardfishdev.github.io/MyHardFish-web-public/';
const base = new URL(url);
if (base.protocol !== 'https:' || base.username || base.password || !base.pathname.endsWith('/') || base.search || base.hash)
  throw new Error('QA_PAGES_URL must be a credential-free HTTPS directory URL with a trailing slash.');
const expectedSource = process.env.QA_EXPECTED_SOURCE?.trim().toLowerCase();
if (!expectedSource || !/^[a-f0-9]{40}$/.test(expectedSource))
  throw new Error('QA_EXPECTED_SOURCE must be the full 40-character source commit SHA.');
const packageJson = JSON.parse(await fs.readFile(path.join(root, 'package.json'), 'utf8'));
const preloadManifest = await localPreloadManifest(root, base);
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const report = { checkedAt: new Date().toISOString(), version: packageJson.version, expectedSource, url,
  scope: 'Public HTTPS Pages smoke test, real WebGL and controls; no authentication or mocked assets. Declared version/source and actual HTML SHA are checked at cold entry and reload.',
  limits: ['This runner does not hash browser JS/CSS or all runtime bytes; the separate HTTPS asset scan supplies that evidence.'],
  preloadManifest, testedSource: { pathBase: 'code/', files: {} }, checks: [] };
for (const file of ['tools/qa/pages-smoke.mjs', 'tools/qa/pages-preload-observer.mjs']) {
  const bytes = await fs.readFile(path.join(root, file));
  report.testedSource.files[file] = { bytes: bytes.length, sha256: sha256(bytes) };
}
let firstDeployment;
async function loadDeployment(context) {
  const metadataUrl = new URL('deployment.json', base);
  metadataUrl.searchParams.set('qa', String(Date.now()));
  const response = await context.request.get(metadataUrl.href, { headers: { 'Cache-Control': 'no-cache' }, timeout: 45000 });
  expect(response.status()).toBe(200);
  const bytes = await response.body(), deployment = JSON.parse(bytes.toString('utf8'));
  expect(deployment.version).toBe(packageJson.version);
  expect(deployment.sourceCommit?.toLowerCase()).toBe(expectedSource);
  expect(Array.isArray(deployment.files)).toBe(true);
  const index = deployment.files.find(file => file.path === 'index.html');
  expect(index).toBeTruthy();
  expect(index.sha256).toMatch(/^[a-f0-9]{64}$/);
  const identity = { version: deployment.version, sourceCommit: deployment.sourceCommit.toLowerCase(), index };
  if (firstDeployment) expect(identity).toEqual(firstDeployment); else firstDeployment = identity;
  return { ...identity, files: deployment.files.length, manifestSha256: sha256(bytes) };
}
async function verifyIndex(response, deployment, phase) {
  expect(response?.status()).toBe(200);
  const html = await response.body();
  expect(html.length).toBe(deployment.index.bytes);
  expect(sha256(html)).toBe(deployment.index.sha256);
  return { ...deployment, phase, loadedIndexSha256: sha256(html), status: 'passed' };
}
const browser = await chromium.launch({ executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath(), args: ['--no-sandbox', '--enable-unsafe-swiftshader'] });
try {
  for (const [name, width, height] of [['desktop', 1440, 1000], ['mobile', 390, 844]]) {
    const context = await browser.newContext({ viewport: { width, height }, isMobile: name === 'mobile', hasTouch: name === 'mobile' });
    await context.addInitScript(() => {
      const original = window.Audio;
      const tracks = window.__hardfishAudioTracks = [];
      window.Audio = function(src) { const track = new original(src); tracks.push(track); return track; };
      window.Audio.prototype = original.prototype;
    });
    const page = await context.newPage();
    page.setDefaultTimeout(45000);
    const started = Date.now();
    let closing = false;
    const result = { name, width, height, status: 'pending', deployments: [], errors: [], failedRequests: [], cleanupRequests: [], badResponses: [], foreignRequests: [] };
    const observer = await observePreloads(page, result, { base, manifest: preloadManifest, isClosing: () => closing, mixedLegacyErrors: true });
    try {
      const deployment = await loadDeployment(context);
      observer.beginPhase('cold');
      const response = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 90000 });
      result.deployments.push(await verifyIndex(response, deployment, 'cold'));
      await expect(page.locator('.resource-loading')).toHaveCount(0, { timeout: 210000 });
      result.coldLoadMs = Date.now() - started;
      const scene = page.getByTestId('scene');
      await expect(scene).toHaveAttribute('data-ready', 'true', { timeout: 90000 });
      await expect(scene).toHaveAttribute('data-triangles', /[1-9]\d*/);
      await expect.poll(() => observer.pending.size, { timeout: 45000 }).toBe(0);
      await observer.completePhase();
      observer.assertHealthy();
      await expect(page.getByRole('button', { name: '给她投喂', exact: true })).toBeInViewport();
      result.layout = await page.evaluate(() => {
        const canvas = document.querySelector('[data-testid="scene"] canvas');
        const rect = canvas.getBoundingClientRect();
        const sampler = document.createElement('canvas'); sampler.width = sampler.height = 32;
        const ctx = sampler.getContext('2d'); ctx.drawImage(canvas, 0, 0, 32, 32);
        const pixels = ctx.getImageData(0, 0, 32, 32).data, colors = new Set();
        for (let i = 0; i < pixels.length; i += 4) colors.add(`${pixels[i] >> 4},${pixels[i + 1] >> 4},${pixels[i + 2] >> 4}`);
        return { width: innerWidth, scrollWidth: document.documentElement.scrollWidth, canvasWidth: rect.width, canvasHeight: rect.height, colorCount: colors.size };
      });
      expect(result.layout.scrollWidth).toBe(width);
      expect(result.layout.canvasWidth).toBe(width);
      expect(result.layout.canvasHeight).toBe(height);
      expect(result.layout.colorCount).toBeGreaterThan(20);
      await page.screenshot({ path: path.join(output, `${name}.png`) });
      await page.getByRole('button', { name: '打开生活菜单', exact: true }).click();
      await expect.poll(() => page.evaluate(() => {
        const track = window.__hardfishAudioTracks.find(a => a.dataset.audioRole === 'background-music');
        return track && !track.paused && track.currentTime > 0 && track.loop;
      })).toBe(true);
      await page.getByRole('button', { name: '打个招呼', exact: true }).click();
      await expect(scene).toHaveAttribute('data-motion', 'happy');
      const hungerBefore = Number(await page.getByTestId('hunger').textContent());
      await page.getByRole('button', { name: '给她投喂', exact: true }).click();
      await page.getByRole('button', { name: '投喂热乎小包子', exact: true }).click();
      await expect(page.getByRole('dialog')).toHaveCount(0);
      await expect(scene).toHaveAttribute('data-motion', 'eat');
      await expect.poll(async () => Number(await page.getByTestId('hunger').textContent())).toBeGreaterThan(hungerBefore);
      result.musicScenes = ['home'];
      for (const [place, label] of [['park', '公园'], ['market', '夜市']]) {
        await page.getByRole('button', { name: '打开地图', exact: true }).click();
        await page.getByRole('dialog').getByRole('button', { name: label, exact: true }).click();
        await expect(scene).toHaveAttribute('data-place', place);
        await expect.poll(() => page.evaluate(expected => {
          const tracks = window.__hardfishAudioTracks.filter(a => a.dataset.audioRole === 'background-music' && a.getAttribute('src'));
          return tracks.length === 1 && tracks[0].dataset.musicScene === expected && !tracks[0].paused && tracks[0].currentTime > 0;
        }, place)).toBe(true);
        result.musicScenes.push(place);
      }
      await page.getByRole('button', { name: '打开生活菜单', exact: true }).click();
      await page.getByRole('button', { name: '设置', exact: true }).click();
      await expect(page.getByTestId('current-music-title')).toHaveText('Sidewalk Shade');
      await page.locator('.music-credits summary').click();
      await expect(page.locator('.music-credits li')).toHaveCount(9);
      await page.screenshot({ path: path.join(output, `${name}-scene-music.png`) });
      await page.getByRole('button', { name: '关闭窗口', exact: true }).click();
      await page.getByRole('button', { name: '关闭背景音乐', exact: true }).click();
      await expect.poll(() => page.evaluate(() => window.__hardfishAudioTracks.filter(a => a.dataset.audioRole === 'background-music' && a.getAttribute('src')).every(a => a.paused))).toBe(true);
      const reloadDeployment = await loadDeployment(context);
      observer.beginPhase('reload');
      const reloadResponse = await page.reload({ waitUntil: 'domcontentloaded', timeout: 90000 });
      result.deployments.push(await verifyIndex(reloadResponse, reloadDeployment, 'reload'));
      await expect(page.locator('.resource-loading')).toHaveCount(0, { timeout: 210000 });
      await expect(page.getByRole('button', { name: '开启背景音乐', exact: true })).toBeVisible();
      await expect(scene).toHaveAttribute('data-place', 'market');
      await expect(scene).toHaveAttribute('data-ready', 'true', { timeout: 90000 });
      await expect.poll(() => observer.pending.size, { timeout: 45000 }).toBe(0);
      await observer.completePhase();
      observer.assertHealthy();
      await page.getByRole('button', { name: '开启背景音乐', exact: true }).click();
      await expect.poll(() => page.evaluate(() => window.__hardfishAudioTracks.some(a => a.dataset.musicScene === 'market' && !a.paused && a.currentTime > 0))).toBe(true);
      result.audio = { realBgmPlayed: true, loopEnabled: true, offPausedImmediately: true, offRememberedAfterReload: true };
      await expect.poll(() => observer.pending.size, { timeout: 45000 }).toBe(0);
      observer.assertHealthy();
      result.status = 'passed';
    } catch (error) {
      result.status = 'failed'; result.failure = error.stack || String(error); process.exitCode = 1;
      await page.screenshot({ path: path.join(output, `${name}-failure.png`) }).catch(() => {});
    } finally {
      closing = true; report.checks.push(result);
      await context.close().catch(error => { result.cleanupError = String(error); result.status = 'failed'; process.exitCode = 1; });
      observer.snapshot();
      if (result.status === 'passed') {
        try { observer.assertHealthy(); }
        catch (error) { result.status = 'failed'; result.failure = error.stack || String(error); process.exitCode = 1; }
      }
    }
  }
} finally {
  await browser.close();
  report.status = report.checks.length === 2 && report.checks.every(check => check.status === 'passed') ? 'passed' : 'failed';
  await fs.writeFile(path.join(output, 'pages-smoke.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
}
