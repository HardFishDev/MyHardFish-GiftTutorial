import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

// Model geometry and procedural materials are shipped inside executable modules.
// Manifest entries alone are not evidence that a browser received those bytes.
export function runtimeManifest(deployment) {
  assert.ok(Array.isArray(deployment.files), 'Missing deployment file inventory');
  const files = deployment.files.filter(file => /\.(?:js|css)$/.test(file.path));
  assert.equal(new Set(files.map(file => file.path)).size, files.length, 'Duplicate runtime module');
  for (const file of files) {
    assert.match(file.sha256, /^[a-f0-9]{64}$/);
    assert.ok(file.bytes > 0, `Empty runtime module: ${file.path}`);
  }
  const modelModules = files.filter(file => /^assets\/(?:App|dbh-character)-[^/]+\.js$/.test(file.path)).map(file => file.path);
  assert.ok(modelModules.some(file => /^assets\/App-/.test(file)), 'Missing lazy App module containing the village/model entry');
  return { files, modelModules };
}

export function observeRuntimeResponses(page, result, base) {
  result.runtimeAssets = []; result.runtimeErrors = [];
  const pending = new Set();
  page.on('requestfinished', request => {
    const url = new URL(request.url());
    if (!['script', 'stylesheet'].includes(request.resourceType()) && !/\.(?:js|css)$/.test(url.pathname)) return;
    const task = (async () => {
      assert.equal(url.origin, base.origin, 'Foreign runtime module');
      assert.ok(url.pathname.startsWith(base.pathname), 'Runtime module outside deployment directory');
      const filename = url.pathname.slice(base.pathname.length);
      const response = await request.response();
      assert.ok(response, `Missing completed module response: ${filename}`);
      const bytes = await response.body();
      result.runtimeAssets.push({ path: filename, type: request.resourceType(), status: response.status(),
        contentType: response.headers()['content-type'] || '', bytes: bytes.length,
        sha256: createHash('sha256').update(bytes).digest('hex') });
    })().catch(error => result.runtimeErrors.push(String(error)));
    pending.add(task); void task.finally(() => pending.delete(task));
  });
  return { async settle() { while (pending.size) await Promise.all([...pending]); } };
}

export function assertRuntimeMatches(result, manifest) {
  assert.deepEqual(result.runtimeErrors, [], 'Runtime response capture failed');
  const expected = new Map(manifest.files.map(file => [file.path, file]));
  for (const actual of result.runtimeAssets) {
    const file = expected.get(actual.path);
    assert.ok(file, `Loaded module absent from deployment inventory: ${actual.path}`);
    assert.equal(actual.status, 200, `Module HTTP status: ${actual.path}`);
    assert.equal(actual.bytes, file.bytes, `Module byte length: ${actual.path}`);
    assert.equal(actual.sha256, file.sha256, `Module SHA256: ${actual.path}`);
    assert.match(actual.contentType, actual.path.endsWith('.css') ? /text\/css/i : /(?:java|ecma)script/i,
      `Module content type: ${actual.path}`);
  }
  const received = new Set(result.runtimeAssets.map(file => file.path));
  assert.ok(result.runtimeAssets.some(file => file.type === 'script'), 'No actual script response observed');
  for (const filename of manifest.modelModules)
    assert.ok(received.has(filename), `Model/App module was never received: ${filename}`);
  if (manifest.files.some(file => file.path.endsWith('.css')))
    assert.ok(result.runtimeAssets.some(file => file.path.endsWith('.css')), 'No actual CSS response observed');
  return { loaded: [...received].sort(), modelModules: manifest.modelModules };
}
