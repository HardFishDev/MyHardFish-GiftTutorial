import { chromium } from '@playwright/test';
import { build } from 'esbuild';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import http from 'node:http';

const project = fileURLToPath(new URL('../../', import.meta.url));
const baseline = process.argv.includes('--baseline');
const quick = process.argv.includes('--quick');
const labelArg = process.argv.indexOf('--label');
const label = labelArg < 0 ? (baseline ? 'baseline' : 'final') : process.argv[labelArg + 1];
if (!/^[a-z0-9_-]+$/i.test(label)) throw Error('Unsafe output label');
const modelArg = process.argv.indexOf('--model');
const modelPath = path.resolve(project, modelArg >= 0 ? process.argv[modelArg + 1] : baseline ? '../research/character-v4/character-before.ts' : 'src/character.ts');
const outfitArg = process.argv.indexOf('--outfits');
const captureOutfits = outfitArg < 0 ? ['classic', 'mint', 'chef', 'student', 'night'] : process.argv[outfitArg + 1].split(',');
const output = path.resolve(project, '../research/character-v4');
await fs.mkdir(path.join(output, label), { recursive: true });
const capturedSources = new Map();
const bundled = await build({ entryPoints: [modelPath], bundle: true, write: false, metafile: true, format: 'esm', platform: 'browser', target: 'es2022', external: ['three', 'three/*'], define: { 'import.meta.env.BASE_URL': '"/"' }, plugins: [{ name: 'record-exact-model-sources', setup(builder) {
  builder.onLoad({ filter: /\.[cm]?[jt]sx?$/ }, async args => {
    const bytes = await fs.readFile(args.path); capturedSources.set(args.path, bytes);
    return { contents: bytes, loader: /\.tsx?$/.test(args.path) ? 'ts' : 'js' };
  });
} }] });
const files = {};
for (const [file, bytes] of capturedSources) files[path.relative(project, file)] = { bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') };
const formSource = [...capturedSources].find(([file]) => file.endsWith('/src/character-form.ts'))?.[1].toString('utf8');
const expectedMouthY = formSource ? Number(formSource.match(/mouthY\s*:\s*([\d.]+)/)?.[1]) : null;
const report = { version: '1.2.0', checkedAt: new Date().toISOString(), scope: quick ? 'Preview only: selected outfits and fixed studio views; no complete motion/allocation/quality acceptance. May use a temporary form wrapper; inspect testedSource.' : baseline ? 'Isolated old-character baseline: fixed studio, five outfits, three views, construction and resource measurements. Not acceptance of new model.' : 'Isolated character: five outfits/three views, geometry poses, grounding/connection anchors, idle allocation, quality round trip and resource disposal.', testedSource: { pathBase: 'code/', files }, status: 'pending', checks: [], errors: [], metricDefinitions: { cpuMs: 'performance.now around synchronous constructor/setOutfit only, excludes shader compilation and GPU render; one software-browser run, not a benchmark distribution.', geometryBytes: 'Unique active geometry attribute, index and morph-attribute typed arrays; excludes driver buffers, textures and inactive cached wardrobe/LOD geometries.', render: 'Three renderer.info render counters include the fixed studio floor. Memory includes lights/shadow resources; model disposal is compared against the same empty studio.' }, studio: { viewport: [760, 900], pixelRatio: 1, camera: 'orthographic fixed height 4.85m, target y2.02', lighting: 'Hemisphere1.65; directional warm key3.1, cool fill1.1, rim1.7; ACES exposure1; no environment map; shadow1024. Same studio for old/new.', renderer: 'Chromium real WebGL / SwiftShader; explicit frame rendering, one character at a time' }, outfits: {}, limitations: ['No physical-device FPS/battery benchmark.', 'Visual evidence and anchor proximity are not a proof of watertight mesh topology.'] };
const html = '<!doctype html><meta charset="utf-8"><link rel="icon" href="data:,"><style>html,body{margin:0;background:#d9dde0}canvas{display:block}</style><script type="importmap">{"imports":{"three":"/vendor/three/build/three.module.js","three/addons/":"/vendor/three/examples/jsm/","three/":"/vendor/three/"}}</script><script type="module" src="/qa/viewer.js"></script>';
const server = http.createServer(async (req, res) => {
  try {
    const route = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    let content, mime = 'text/javascript';
    if (route === '/') { content = html; mime = 'text/html'; }
    else if (route === '/qa/model.js') content = bundled.outputFiles[0].text;
    else if (route === '/qa/viewer.js') content = await fs.readFile(path.join(project, 'tools/qa/character-viewer.mjs'));
    else {
      let base, relative;
      if (route.startsWith('/vendor/three/')) { base = path.join(project, 'node_modules/three'); relative = route.slice('/vendor/three/'.length); }
      else if (route.startsWith('/assets/')) { base = path.join(project, 'public'); relative = route.slice(1); }
      else throw Error('Unknown route');
      const target = path.resolve(base, relative); if (!target.startsWith(base + path.sep)) throw Error('Unsafe path');
      content = await fs.readFile(target); if (target.endsWith('.png')) mime = 'image/png'; else if (target.endsWith('.jpg')) mime = 'image/jpeg';
    }
    res.writeHead(200, { 'Content-Type': mime, 'Cache-Control': 'no-store' }); res.end(content);
  } catch { res.writeHead(404); res.end('Not found'); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const browser = await chromium.launch({ executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || chromium.executablePath(), args: ['--no-sandbox', '--enable-unsafe-swiftshader'] });
const page = await browser.newPage({ viewport: { width: 760, height: 900 }, deviceScaleFactor: 1 });
page.on('pageerror', error => report.errors.push(String(error)));
page.on('console', message => { if (message.type() === 'error' || (message.type() === 'warning' && /GL_INVALID|GL_OUT_OF_MEMORY|Shader Error|WebGL context lost|INVALID_OPERATION/.test(message.text()))) report.errors.push(message.text()); });
const check = (id, passed, details) => report.checks.push({ id, status: passed ? 'passed' : 'failed', ...details });
async function shot(name) { const file = `${label}/${name}.png`; await page.screenshot({ path: path.join(output, file), animations: 'disabled' }); return file; }
try {
  await page.goto(`http://127.0.0.1:${server.address().port}/`); await page.waitForFunction(() => window.qa?.ready, null, { timeout: 60000 });
  report.constructorMs = await page.evaluate(() => qa.constructorMs); console.log(`Constructor ${report.constructorMs.toFixed(1)} ms`);
  for (const outfit of captureOutfits) {
    const metrics = await page.evaluate(id => qa.outfit(id), outfit); const screenshots = {};
    for (const view of ['front', 'side', 'back']) { await page.evaluate(v => qa.view(v), view); screenshots[view] = await shot(`${outfit}-${view}`); }
    report.outfits[outfit] = { ...metrics, screenshots }; console.log(`${outfit}: ${metrics.cpuMs.toFixed(1)}ms, ${metrics.renderer.calls} calls, ${metrics.renderer.triangles} triangles`);
  }
  check(captureOutfits.length === 5 ? 'five-outfits-three-view-render-captures' : 'selected-outfits-three-view-render-captures', true, { outfits: Object.keys(report.outfits), imageCount: captureOutfits.length * 3, meaning: 'Render/capture coverage; aesthetic assessment is separate manual review.' });
  if (!baseline && !quick) await extendedQA();
  report.disposal = await page.evaluate(() => qa.dispose());
  const disposed = report.disposal.after.memory.geometries === report.disposal.stage.memory.geometries && report.disposal.after.memory.textures === report.disposal.stage.memory.textures;
  check('dispose-returns-to-stage-resources', disposed, report.disposal);
  report.webgl = await page.evaluate(() => qa.webglHealth());
  check('webgl-no-errors', report.errors.length === 0 && !report.webgl.contextLost && report.webgl.glError === 0, { ...report.webgl, errors: report.errors });
  report.status = report.checks.every(c => c.status === 'passed') ? 'passed' : 'failed';
} catch (error) { report.errors.push(error.stack || String(error)); report.status = 'failed'; }
finally {
  if (!baseline) {
    try { const old = JSON.parse(await fs.readFile(path.join(output, 'character-baseline.json'), 'utf8')); report.baseline = { report: 'character-baseline.json', testedSource: old.testedSource, constructorMs: old.constructorMs, outfits: Object.fromEntries(Object.entries(old.outfits).map(([id, data]) => [id, { cpuMs: data.cpuMs, calls: data.renderer.calls, triangles: data.renderer.triangles, memory: data.memory }])) }; } catch { report.baseline = { unavailable: true }; }
  }
  const name = baseline ? 'character-baseline.json' : quick ? `character-preview-${label}.json` : 'character-check.json';
  await fs.writeFile(path.join(output, name), JSON.stringify(report, null, 2) + '\n');
  await browser.close(); await new Promise(resolve => server.close(resolve));
  console.log(`Saved ${name}: ${report.status}`);
}
if (report.status !== 'passed') process.exitCode = 1;

async function extendedQA() {
  await page.evaluate(() => { qa.outfit('classic'); qa.view('front'); });
  report.geometry = await page.evaluate(() => qa.geometryCheck());
  check('finite-indexed-geometry-and-morphs', report.geometry.errors.length === 0, report.geometry);
  const poseSamples = {}, motions = {};
  for (const mode of ['idle', 'walk', 'happy', 'angry', 'eat', 'sleep', 'dance']) {
    const created = await page.evaluate(() => qa.make());
    const samples = [], anatomySamples = [], windingSamples = [], mouthSamples = [];
    for (const frameCount of [90, 18, 18]) {
      await page.evaluate(({ mode, frameCount, first }) => first ? qa.motion(mode, frameCount) : qa.update(mode, frameCount), { mode, frameCount, first: samples.length === 0 });
      samples.push(await page.evaluate(() => qa.pose()));
      anatomySamples.push(await page.evaluate(() => qa.anatomy()));
      windingSamples.push(await page.evaluate(() => qa.limbWinding()));
      mouthSamples.push(await page.evaluate(() => qa.mouthPose()));
    }
    poseSamples[mode] = samples;
    await page.evaluate(() => qa.view('front')); const front = await shot(`motion-${mode}`);
    await page.evaluate(() => qa.view('side')); const side = await shot(`motion-${mode}-side`);
    await page.evaluate(() => qa.view('front'));
    motions[mode] = { constructorMs: created.constructorMs, screenshot: front, screenshots: { front, side }, anatomy: anatomySamples, limbWinding: windingSamples, mouth: mouthSamples };
    console.log(`Motion ${mode}: sampled 1.50 / 1.80 / 2.10 seconds`);
  }
  report.motions = motions;
  function difference(a, b) {
    if (a.length !== b.length) return { different: true, reason: 'Visible geometry signature lengths differ', lengths: [a.length, b.length] };
    let squared = 0, maximum = 0;
    for (let i = 0; i < a.length; i++) { const delta = Math.abs(a[i] - b[i]); squared += delta * delta; maximum = Math.max(maximum, delta); }
    const rms = Math.sqrt(squared / Math.max(1, a.length)); return { different: maximum > .003 && rms > .0002, rms, maximum, values: a.length };
  }
  const pairs = [];
  const modes = Object.keys(poseSamples);
  for (let i = 0; i < modes.length; i++) for (let j = i + 1; j < modes.length; j++) {
    const samples = poseSamples[modes[i]].map((pose, index) => difference(pose, poseSamples[modes[j]][index]));
    pairs.push({ modes: [modes[i], modes[j]], different: samples.some(s => s.different), samples });
  }
  check('seven-motions-distinct-geometric-poses', pairs.every(p => p.different), { sampling: 'Each motion starts with a new single model. Same times 1.50/1.80/2.10 seconds; world matrices plus 32 deformed vertices per visible mesh. Tests geometric difference, not perceived emotion.', pairs });
  const mouthPositions = Object.entries(motions).flatMap(([mode, data]) => data.mouth.map((value, sample) => ({ mode, sample, ...value })));
  const mouthStable = Number.isFinite(expectedMouthY) && mouthPositions.every(m => m.found && Math.abs(m.anchor[1] - expectedMouthY) < .02 && Math.abs(m.anchor[0]) < .05 && m.anchor[2] > .15 && m.meshCenters.length > 0 && m.meshCenters.every(c => Math.abs(c[1] - expectedMouthY) < .025));
  check('mouth-expression-stays-at-face-center-during-animation', mouthStable, { expectedMouthY, reference: 'FORM.mouthY parsed from the exact bundled character-form.ts source. Group anchor and actual child mesh center transformed into body-local coordinates.', maximumAnchorError: .02, maximumMeshCenterError: .025, samples: mouthPositions });
  const winding = Object.entries(motions).flatMap(([mode, data]) => data.limbWinding.flatMap((meshes, sample) => meshes.map(mesh => ({ mode, sample, ...mesh }))));
  check('arm-shin-triangle-winding-matches-outward-normals', winding.length === 7 * 3 * 4 && winding.every(m => m.nonfinite === 0 && m.fraction > .95), { threshold: .95, method: 'Geometric triangle cross product dot mean vertex normal in local coordinates; only arm/shin, skip area squared <1e-16. Sampled all seven motions at three phases.', samples: winding });
  const connectionResults = [], legConnections = [];
  const grounding = [];
  for (const [mode, data] of Object.entries(motions)) {
    for (const [sample, anatomy] of data.anatomy.entries()) {
      for (const [side, a] of Object.entries(anatomy)) {
        const required = ['foot', 'hand', 'arm', 'shoulder', 'wrist'];
        const rolesPresent = required.every(role => a.roles[role]);
        const legDistances = { footToAnkle: a.footToAnkle, shinToAnkle: a.shinToAnkle, shinToWhiteLeg: a.shinToWhiteLeg, whiteLegToBody: a.whiteLegToBody };
        legConnections.push({ mode, sample, side, ...legDistances, passed: Object.values(legDistances).every(Number.isFinite) && a.footToAnkle < .14 && a.shinToAnkle < .13 && a.shinToWhiteLeg < .13 && a.whiteLegToBody < .24 });
        connectionResults.push({ mode, sample, side, rolesPresent, armToShoulder: a.armToShoulder, armToWrist: a.armToWrist, handToWrist: a.handToWrist, passed: rolesPresent && [a.armToShoulder, a.armToWrist, a.handToWrist].every(Number.isFinite) && a.armToShoulder < .13 && a.armToWrist < .13 && a.handToWrist < .19 });
      }
      const bottoms = Object.values(anatomy).map(a => a.footBounds?.min[1]).filter(Number.isFinite);
      grounding.push({ mode, sample, footBottoms: bottoms, minimum: bottoms.length ? Math.min(...bottoms) : null, shouldContactFloor: mode === 'idle' || mode === 'walk', passed: bottoms.length === 2 && Math.min(...bottoms) >= -.045 && (!(mode === 'idle' || mode === 'walk') || Math.min(...bottoms) <= .09) });
    }
  }
  check('hand-arm-anchor-proximity', connectionResults.every(c => c.passed), { limits: 'Nearest actual deformed mesh vertices to named anchors. Limits: arm endpoints .13m, hand/wrist .19m. Does not prove surface topology.', samples: connectionResults });
  check('white-leg-shin-foot-anchor-proximity', legConnections.every(c => c.passed), { limits: 'Nearest deformed surface vertices: ankle/foot .14m, shin endpoints .13m, white-leg anchor/body .24m. Anchors are deliberately inside connecting volumes; this is a basic continuity check, not topology proof.', samples: legConnections });
  check('feet-no-floor-penetration-and-standing-contact', grounding.every(g => g.passed), { penetrationTolerance: .045, standingContactTolerance: .09, samples: grounding });
  report.animationAllocations = {};
  for (const mode of ['idle', 'walk', 'eat', 'dance']) {
    const results = await page.evaluate(mode => {
      qa.outfit('classic'); qa.motion(mode, 90);
      const before = qa.allocationIds(), beforeMemory = qa.inventory().memory;
      const sampled = [];
      for (let block = 0; block < 10; block++) { qa.update(mode, 60); sampled.push({ ids: qa.allocationIds(), memory: qa.inventory().memory }); }
      return { simulatedSeconds: 10, updates: 600, renderedSamples: 10, before, beforeMemory, sampled };
    }, mode);
    report.animationAllocations[mode] = results;
    const stable = results.sampled.every(s => JSON.stringify(s.ids) === JSON.stringify(results.before) && s.memory.geometries === results.beforeMemory.geometries && s.memory.textures === results.beforeMemory.textures);
    check(`${mode}-keeps-geometry-material-texture-identities`, stable, { simulatedSeconds: 10, updates: 600, renderedSamples: 10, stable });
  }
  // The model caches each outfit after first use; warm that finite cache before checking for growth.
  for (const outfit of ['classic', 'mint', 'chef', 'student', 'night']) await page.evaluate(id => qa.outfit(id), outfit);
  const cycles = [];
  for (let cycle = 0; cycle < 3; cycle++) {
    const values = {};
    for (const outfit of ['classic', 'mint', 'chef', 'student', 'night']) values[outfit] = await page.evaluate(id => qa.outfit(id), outfit);
    cycles.push(values);
  }
  report.outfitCycles = cycles;
  const stableOutfits = Object.keys(cycles[0]).every(outfit => cycles.every(cycle => cycle[outfit].memory.geometries === cycles[0][outfit].memory.geometries && cycle[outfit].memory.textures === cycles[0][outfit].memory.textures && cycle[outfit].geometries === cycles[0][outfit].geometries));
  check('three-wardrobe-cycles-resource-stability', stableOutfits, { cycles: 3, warmup: 'All five outfits built and rendered once before measured cycles', outfits: Object.keys(cycles[0]) });
  await page.evaluate(() => { qa.outfit('classic'); qa.motion('idle', 60); qa.quality(false); qa.quality(true); qa.quality(false); });
  const qualityCycles = [];
  for (let cycle = 0; cycle < 3; cycle++) {
    const high = await page.evaluate(() => qa.quality(false));
    const low = await page.evaluate(() => qa.quality(true));
    const highAgain = await page.evaluate(() => qa.quality(false));
    qualityCycles.push({ high, low, highAgain });
  }
  await page.evaluate(() => qa.quality(true)); const lowShot = await shot('quality-low');
  await page.evaluate(() => qa.quality(false)); const highShot = await shot('quality-high-restored');
  report.quality = { warmup: 'high -> low -> high before measurements, allows lazy LOD caching', cycles: qualityCycles, screenshots: [lowShot, highShot] };
  const sameResources = (a, b) => a.memory.geometries === b.memory.geometries && a.memory.textures === b.memory.textures && a.geometries === b.geometries && a.materials === b.materials;
  const stableQuality = qualityCycles.every(({ high, low, highAgain }) => high.supported && low.supported && highAgain.supported && low.renderer.triangles < high.renderer.triangles && high.renderer.triangles === highAgain.renderer.triangles && sameResources(high, highAgain) && sameResources(high, qualityCycles[0].high) && sameResources(low, qualityCycles[0].low));
  check('quality-three-round-trips-reduce-triangles-and-keep-resources', stableQuality, { cycles: 3, highTriangles: qualityCycles[0].high.renderer.triangles, lowTriangles: qualityCycles[0].low.renderer.triangles });

}

