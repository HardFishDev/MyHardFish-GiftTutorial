"""Generate the cycling game's original effects and portable synthetic voice.

Requirements: Python 3, ffmpeg with libmp3lame; edge-tts for the voice only.
The voice follows the project's existing Xiaoyi TTS style, not a voice clone.
Run `python tools/audio/generate-cycling.py` to regenerate all four MP3 files.
Pass --effects-only to regenerate the deterministic effects without network use.
"""
import argparse
import asyncio
import math
import pathlib
import random
import struct
import subprocess
import tempfile
import wave

ROOT = pathlib.Path(__file__).resolve().parents[2]
OUTPUT = ROOT / 'public' / 'audio'
RATE = 44100


def encode(samples, filename, temporary):
    wav = temporary / f'{filename}.wav'
    with wave.open(str(wav), 'wb') as stream:
        stream.setnchannels(1)
        stream.setsampwidth(2)
        stream.setframerate(RATE)
        stream.writeframes(b''.join(struct.pack('<h', round(max(-0.94, min(0.94, value)) * 32767)) for value in samples))
    subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-i', str(wav),
                    '-codec:a', 'libmp3lame', '-b:a', '128k', '-map_metadata', '-1',
                    str(OUTPUT / f'{filename}.mp3')], check=True)


def note(time, start, frequency, decay, amplitude):
    age = time - start
    if age < 0:
        return 0
    envelope = (1 - math.exp(-age * 850)) * math.exp(-age / decay)
    return amplitude * envelope * math.sin(math.tau * frequency * age)


def effects(temporary):
    metal = []
    for index in range(round(0.58 * RATE)):
        t = index / RATE
        # A warm metallic clink followed by two quiet, rising reward tones.
        value = sum(note(t, 0, frequency, decay, amplitude) for frequency, decay, amplitude in
                    [(830, .10, .17), (1390, .065, .065), (2390, .035, .025)])
        value += note(t, .09, 1109, .12, .10) + note(t, .17, 1661, .10, .075)
        metal.append(value * min(1, (.58 - t) * 80))
    encode(metal, 'cycling-pickup-metal', temporary)

    chime = []
    for index in range(round(0.47 * RATE)):
        t = index / RATE
        value = note(t, 0, 659, .09, .15) + note(t, .075, 988, .10, .12)
        value += note(t, .14, 1318, .085, .075)
        chime.append(value * min(1, (.47 - t) * 80))
    encode(chime, 'cycling-pickup-chime', temporary)

    rng = random.Random(20261004)
    hit = []
    low_noise = 0
    for index in range(round(0.61 * RATE)):
        t = index / RATE
        low_noise = low_noise * .94 + rng.uniform(-1, 1) * .06
        attack = min(1, t * 900)
        # Short tire/ground thud, low frame rattle, then a soft scrape.
        thud = .31 * math.sin(math.tau * (98 * t - 25 * t * t)) * math.exp(-t / .075)
        grit = .48 * low_noise * math.exp(-t / .17)
        rattle = note(t, .065, 190, .035, .08) + note(t, .145, 235, .045, .055)
        hit.append((attack * (thud + grit) + rattle) * min(1, (.61 - t) * 80))
    encode(hit, 'cycling-hit', temporary)


async def voice(temporary):
    import edge_tts
    raw = temporary / 'voice-raw.mp3'
    await asyncio.wait_for(edge_tts.Communicate(
        '这是俺拾嘞。', voice='zh-CN-XiaoyiNeural', rate='+18%', pitch='+12Hz',
    ).save(str(raw)), timeout=45)
    subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-i', str(raw),
                    '-af', 'loudnorm=I=-19:TP=-3:LRA=7,afade=t=in:st=0:d=0.012',
                    '-ar', '44100', '-ac', '1', '-codec:a', 'libmp3lame', '-b:a', '128k',
                    '-map_metadata', '-1', str(OUTPUT / 'cycling-voice-pickup.mp3')], check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--effects-only', action='store_true')
    options = parser.parse_args()
    OUTPUT.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='hardfish-cycling-audio-') as folder:
        temporary = pathlib.Path(folder)
        effects(temporary)
        if not options.effects_only:
            asyncio.run(voice(temporary))
    print('Cycling MP3 assets generated in public/audio.')


if __name__ == '__main__':
    main()
