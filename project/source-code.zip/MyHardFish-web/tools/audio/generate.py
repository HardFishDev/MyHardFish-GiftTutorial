"""Generate stylized, fast Chinese TTS. Not a clone of anyone's voice."""
import asyncio,json,pathlib
import edge_tts
root=pathlib.Path(__file__).resolve().parents[2]
quotes=json.loads((root/'src/quotes.json').read_text())
sem=asyncio.Semaphore(3)
async def one(q):
 async with sem:
  path=root/'public/audio'/f"{q['id']}.mp3"
  if path.exists() and path.stat().st_size>1000:return
  for attempt in range(3):
   try:
    await asyncio.wait_for(edge_tts.Communicate(q['text']+'。',voice='zh-CN-XiaoyiNeural',rate='+32%',pitch='+12Hz').save(str(path)),40)
    print(q['id'],path.stat().st_size,flush=True);return
   except Exception as e:print(q['id'],type(e).__name__,flush=True)
  raise RuntimeError(q['id'])
async def main():await asyncio.gather(*(one(q) for q in quotes))
asyncio.run(main())
