import {pathToFileURL} from 'node:url';
const {Raycaster,PerspectiveCamera,Vector3,Group,Box3}=await import(pathToFileURL(process.env.HARDFISH_CODE_ROOT+'/node_modules/three/build/three.module.js').href);
const noop=()=>{};const ctx=new Proxy({}, {get:(_,key)=>key==='createLinearGradient'||key==='createRadialGradient'?()=>({addColorStop:noop}):noop});globalThis.document={createElement:()=>({getContext:()=>ctx})};
const {buildEnvironment}=await import('./environment.js');const {EXPLORATION_SPOTS,WORLD_EXITS}=await import('./world-layout.js');const {FishWorld}=await import('./scene.js');
const results=[];
for(const place of Object.keys(WORLD_EXITS)){
 const env=buildEnvironment(place);env.root.updateMatrixWorld(true);
 const camera=new PerspectiveCamera(44,800/600,.12,260),world=Object.create(FishWorld.prototype);let selected='';
 Object.assign(world,{camera,ray:new Raycaster(),fish:new Group(),hotspots:env.hotspots,hotspotMarkers:env.hotspots.flatMap(h=>h.userData.marker?[h.userData.marker]:[]),host:{dataset:{}},renderer:{domElement:{style:{},getBoundingClientRect:()=>({left:0,top:0,width:800,height:600})}},walkToHotspot:id=>{selected=id;},onInteract:id=>{selected=id;},faceCamera:noop});
 for(const spot of EXPLORATION_SPOTS.filter(s=>s.place===place)){
  const hotspot=env.hotspots.find(h=>h.userData.action===`adventure:${spot.id}`),marker=hotspot.userData.marker,point=new Vector3().setFromMatrixPosition(marker.matrixWorld);
  const offset=env.camera?.desktop??[7.2,6.3,10.4];camera.position.set(spot.approach[0]+offset[0],offset[1],spot.approach[1]+offset[2]);camera.lookAt(spot.approach[0],1.8,spot.approach[1]);camera.updateMatrixWorld();const ndc=point.clone().project(camera);selected='';world.pick((ndc.x+1)*400,(1-ndc.y)*300,true);
  results.push({place,id:spot.id,containsMarker:new Box3().setFromObject(hotspot).containsPoint(point),onscreen:Math.abs(ndc.x)<=1&&Math.abs(ndc.y)<=1,selected,ok:selected===`adventure:${spot.id}`});
 }
 env.dispose();
}
console.log(JSON.stringify(results,null,2));const fs=await import('node:fs');fs.writeFileSync(process.env.HARDFISH_QA_DIR+'/markers.json',JSON.stringify(results,null,2));
