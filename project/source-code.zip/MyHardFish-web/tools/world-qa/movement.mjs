const noop=()=>{};const context=new Proxy({}, {get:(_,key)=>key==='createLinearGradient'||key==='createRadialGradient'?()=>({addColorStop:noop}):noop});globalThis.document={createElement:()=>({getContext:()=>context})};
const {FishWorld}=await import('./scene.js');const {buildEnvironment}=await import('./environment.js');const {WorldNavigation}=await import('./world-navigation.js');
const reports=[];
for(const fps of [60,10,4]){
 const environment=buildEnvironment('river'),Vec=environment.spawn.constructor,world=Object.create(FishWorld.prototype),events=[];
 // This existing synthetic endpoint tests the complete bridge route, not an
 // activity. Register it in the current physical-anchor lookup without a pose.
 const bridgeAnchor={id:'qa:bridge-end',hotspotId:'adventure:bridge_qa',label:'bridge',place:'river',approach:[23,-11],activity:null};
 Object.assign(world,{activityAnchors:[bridgeAnchor],activity:null,pendingActivity:null});
 Object.assign(world,{environment,obstacles:environment.obstacles,nav:new WorldNavigation(environment.bounds,environment.obstacles,.5),fish:{position:new Vec(0,0,-11),rotation:{y:0}},target:new Vec(0,0,-11),route:[],elapsed:0,host:{dataset:{}},moveMarker:{position:new Vec(),visible:false},routeLine:{geometry:{dispose:noop},visible:false},navigationBeacon:{position:new Vec(),visible:false},navigationTarget:null,focusUntil:0,joystick:{x:0,y:0},keys:new Set(),tmpDirection:new Vec(),tmpForward:new Vec(),tmpRight:new Vec(),desiredLook:new Vec(),lastCharacterPosition:new Vec(),camera:{position:new Vec(7,8,0)},controls:{target:new Vec(0,2,-11)},cameraMode:'follow',orbiting:false,inspectUntil:0,motion:'idle',onInteract:id=>events.push({id,time:world.elapsed}),hotspotInfo:[{id:'adventure:bridge_qa',label:'bridge',x:23,z:-11,w:.5,d:.5,approach:[23,-11],kind:'adventure',radius:2.5}]});
 const accepted=world.walkToHotspot('adventure:bridge_qa',{interactOnArrival:true});let blocked=0,highest=0,arrived;
 for(let frame=0;frame<fps*14;frame++){const dt=1/fps;world.elapsed+=dt;const count=Math.ceil(dt/.04);for(let n=0;n<count;n++){world.tickMovement(dt/count);if(world.blocked(world.fish.position.x,world.fish.position.z))blocked++;highest=Math.max(highest,world.fish.position.y);}if(events.length&&!arrived)arrived=world.elapsed;}
 reports.push({fps,accepted,position:world.fish.position.toArray(),blocked,highest,events,arrived,routeRemaining:world.route.length});environment.dispose();world.routeLine.geometry.dispose();
}
console.log(JSON.stringify(reports,null,2));const fs=await import('node:fs');fs.writeFileSync(process.env.HARDFISH_QA_DIR+'/movement.json',JSON.stringify(reports,null,2));
