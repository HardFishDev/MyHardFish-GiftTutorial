import {performance} from 'node:perf_hooks';
const noop=()=>{};const ctx=new Proxy({}, {get:(_,key)=>key==='createLinearGradient'||key==='createRadialGradient'?()=>({addColorStop:noop}):noop});
globalThis.document={createElement:()=>({width:0,height:0,getContext:()=>ctx})};
const {buildEnvironment}=await import('./environment.js');const {WorldNavigation}=await import('./world-navigation.js');const {WORLD_EXITS,EXPLORATION_SPOTS}=await import('./world-layout.js');
const result=[];for(const place of Object.keys(WORLD_EXITS)){
 const t=performance.now(),env=buildEnvironment(place),buildMs=performance.now()-t,nt=performance.now(),nav=new WorldNavigation(env.bounds,env.obstacles,env.navigationStep),navigationBuildMs=performance.now()-nt;
 const errors=[],routes=[];const starts=[['spawn',env.spawn],...Object.entries(env.entries).map(([id,p])=>[id,p])];
 for(const [id,p]of starts)if(nav.blocked(p.x,p.z))errors.push({type:'blocked_start',id,x:p.x,z:p.z});
 const goals=[...EXPLORATION_SPOTS.filter(s=>s.place===place).map(s=>({id:s.id,x:s.approach[0],z:s.approach[1]})),...Object.entries(env.entries).map(([id,p])=>({id:'travel:'+id,...p}))];
 for(const [from,start]of starts)for(const goal of goals){
  if(nav.blocked(goal.x,goal.z))errors.push({type:'blocked_goal',id:goal.id,x:goal.x,z:goal.z});
  const t=performance.now(),path=nav.findPath(start,goal.x,goal.z),ms=performance.now()-t,end=path.at(-1);let origin=start;
  if(!end||Math.hypot(end.x-goal.x,end.z-goal.z)>.15)errors.push({type:'unreachable',from,id:goal.id,end:end?.toArray()});
  for(const point of path){if(!nav.clearSegment(origin,point))errors.push({type:'collision',from,id:goal.id});origin=point;}
  routes.push({from,to:goal.id,segments:path.length,ms:+ms.toFixed(2)});
 }
 let sampled=0;for(let x=env.bounds.minX+1;x<env.bounds.maxX;x+=5)for(let z=env.bounds.minZ+1;z<env.bounds.maxZ;z+=5){const path=nav.findPath(env.spawn,x,z);let origin=env.spawn;for(const point of path){if(!nav.clearSegment(origin,point))errors.push({type:'sample_collision',x,z});origin=point;}sampled++;}
 const geometries=new Set(),materials=new Set(),textures=new Set();let triangles=0,meshCount=0;env.root.traverse(o=>{if(o.isMesh){meshCount++;geometries.add(o.geometry);triangles+=(o.geometry.index?.count??o.geometry.getAttribute('position').count)/3*(o.isInstancedMesh?o.count:1);for(const m of Array.isArray(o.material)?o.material:[o.material]){materials.add(m);for(const value of Object.values(m))if(value?.isTexture)textures.add(value);}}});
 const disposed={geometry:new Set(),material:new Set(),texture:new Set()};for(const g of geometries)g.addEventListener('dispose',()=>disposed.geometry.add(g));for(const m of materials)m.addEventListener('dispose',()=>disposed.material.add(m));for(const tex of textures)tex.addEventListener('dispose',()=>disposed.texture.add(tex));
 const heights=place==='river'?[-2,1.7,6,11,16,20.3].map(x=>[x,env.heightAt(x,-11)]):undefined;
 env.dispose();if(disposed.geometry.size!==geometries.size||disposed.material.size!==materials.size||disposed.texture.size!==textures.size)errors.push({type:'dispose_mismatch'});
 const report={place,buildMs:Math.round(buildMs),navigationBuildMs:Math.round(navigationBuildMs),cells:nav.points.length,obstacles:env.obstacles.length,meshCount,triangles,geometries:geometries.size,materials:materials.size,textures:textures.size,checks:routes.length,sampled,slowestPathMs:Math.max(...routes.map(r=>r.ms)),errors,heights};result.push(report);console.log(JSON.stringify(report));
}
const fs=await import('node:fs');fs.writeFileSync(process.env.HARDFISH_QA_DIR+'/navigation.json',JSON.stringify({method:'Real environment geometry and WorldNavigation in Node; only Canvas 2D paint API stubbed. No WebGL, FPS, or browser rendering measured.',result},null,2));
