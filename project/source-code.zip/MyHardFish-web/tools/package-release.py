#!/usr/bin/env python3
"""Package a release only when current-version evidence passes the retained checks.

Run from any directory: python3 path/to/code/tools/package-release.py
Use --check to validate the reports and built files without writing anything.
All paths are relative to this script; only dist/ enters the distribution ZIP.
The retained report contract is the 1.2 character suite. A newer package version
must not reuse those historical reports; no later audio-report adapter is supplied.
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
from urllib.parse import urlparse
import zipfile


CODE = Path(__file__).resolve().parent.parent
PROJECT = CODE.parent
DIST = CODE / "dist"
REPORTS = PROJECT / "research" / "character-v4"
RELEASE = PROJECT / "release"
VERSION = json.loads((CODE / "package.json").read_text(encoding="utf-8"))["version"]
ZIP_NAME = "我的群友难鱼-网页游戏.zip"
MANIFEST_NAME = "构建清单.json"
INSTRUCTIONS_NAME = "使用说明.txt"
REPORT_NAMES = ("engine-check.json", "character-check.json", "character-ui-check.json")
SUPPLEMENTAL_REPORT = "targeted-regression-summary.json"
PLACES = {"home", "kitchen", "park", "shop", "school", "village", "workshop", "river", "market"}
CONTENT = {"places": 9, "quests": 10, "questStages": 37, "discoveries": 27,
           "questItems": 19, "minigames": 5, "legacyStories": 21,
           "legacyEndings": 45, "outfits": 5, "voiceFiles": 76}
BLOCKED_PARTS = {"research", "exports", "src", "tests", "test", "fixtures", "fixture",
                 "node_modules", "test-results", "playwright-report", ".git", "__pycache__"}
BLOCKED_SUFFIXES = {".jsonl", ".sqlite", ".sqlite3", ".db", ".map", ".ts", ".tsx",
                    ".py", ".pyc", ".zip", ".7z", ".rar", ".log"}


class ReleaseError(Exception):
    pass


def require(condition: object, message: str) -> None:
    if not condition:
        raise ReleaseError(message)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def relative(path: Path) -> str:
    return path.relative_to(PROJECT).as_posix()


def iso_time(ns: int) -> str:
    return datetime.fromtimestamp(ns / 1e9, timezone.utc).isoformat()


def read_stable(path: Path) -> tuple[bytes, dict]:
    require(path.is_file() and not path.is_symlink(), f"缺少普通文件或遇到符号链接：{path}")
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
            and len(data) == after.st_size, f"读取期间文件发生变化：{path}")
    return data, {"path": relative(path), "bytes": len(data), "sha256": digest(data),
                  "mtimeNs": after.st_mtime_ns, "modifiedAt": iso_time(after.st_mtime_ns)}


def tree_files(directory: Path) -> list[Path]:
    require(directory.is_dir() and not directory.is_symlink(), f"缺少普通目录：{directory}")
    entries = sorted(directory.rglob("*"))
    require(not any(p.is_symlink() for p in entries), f"目录中存在符号链接，停止打包：{directory}")
    require(all(p.is_file() or p.is_dir() for p in entries), f"目录中存在特殊文件：{directory}")
    return [p for p in entries if p.is_file()]


def read_json_file(path: Path) -> tuple[dict, dict]:
    raw, meta = read_stable(path)
    try:
        value = json.loads(raw.decode("utf-8-sig"))
    except (UnicodeError, json.JSONDecodeError) as error:
        raise ReleaseError(f"JSON 无法解析：{path}：{error}") from error
    require(isinstance(value, dict), f"报告必须为 JSON 对象：{path}")
    return value, meta


def scene_music_files() -> set[str]:
    catalog, _ = read_json_file(CODE / "src" / "music-catalog.json")
    require(bool(catalog), "场景音乐清单不能为空")
    files = set()
    for place, track in catalog.items():
        require(isinstance(place, str) and re.fullmatch(r"[a-z][a-z0-9_-]*", place)
                and isinstance(track, dict) and track.get("file") == f"music-{place}.mp3",
                "场景音乐必须使用与地点相符的 music-{place}.mp3 文件名")
        duration = track.get("duration")
        require(isinstance(duration, (int, float)) and not isinstance(duration, bool)
                and math.isfinite(duration) and duration > 0, "场景音乐必须记录有效正数时长")
        files.add(f"audio/{track['file']}")
    require(len(files) == len(catalog), "场景音乐文件名重复")
    return files


def validate_audio_files(files: dict[str, bytes]) -> dict[str, int]:
    raw, _ = read_stable(CODE / "src" / "quotes.json")
    quotes = json.loads(raw.decode("utf-8"))
    require(isinstance(quotes, list) and len(quotes) == CONTENT["voiceFiles"], "台词定义必须恰好为 76 条")
    ids = [quote.get("id") if isinstance(quote, dict) else None for quote in quotes]
    require(all(isinstance(value, str) and re.fullmatch(r"[a-z0-9_-]+", value)
                and value != "bgm" and not value.startswith("music-") for value in ids), "台词 ID 无效或与场景音乐冲突")
    require(len(set(ids)) == len(ids), "台词 ID 重复")
    music = scene_music_files()
    expected = {f"audio/{value}.mp3" for value in ids} | music
    actual = {name for name in files if name.startswith("audio/")
              or name.lower().endswith((".mp3", ".ogg", ".wav", ".m4a", ".aac", ".flac"))}
    require(actual == expected,
            "音频文件集合必须为 76 个已定义台词和音乐清单中的各场景曲目；缺少："
            + ", ".join(sorted(expected - actual)) + "；多余：" + ", ".join(sorted(actual - expected)))
    require(all(files[name] for name in expected), "存在空台词或场景音乐")
    return {"voiceFiles": len(ids), "musicFiles": len(music), "audioFiles": len(expected)}


def integer(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def passed_counts(value: object, label: str) -> dict:
    require(isinstance(value, dict), f"{label} 需要 passed / failed 数字，不能仅声明通过")
    require(integer(value.get("passed")) and value["passed"] > 0, f"{label} 没有实际通过用例")
    require(integer(value.get("failed")) and value["failed"] == 0, f"{label} 存在失败或缺失 failed 计数")
    for key in ("skipped", "interrupted", "timedOut", "unexpected"):
        require(value.get(key, 0) == 0, f"{label} 仍有未完成用例：{key}")
    return value


def checked_time(report: dict, label: str) -> datetime:
    stamp = report.get("checkedAt") or report.get("reportedAt")
    require(isinstance(stamp, str), f"{label} 缺少 checkedAt / reportedAt")
    try:
        value = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
        require(value.tzinfo is not None, f"{label} 时间必须带时区")
        require(value.timestamp() <= datetime.now(timezone.utc).timestamp() + 300,
                f"{label} 的检查时间位于未来")
        return value
    except ValueError as error:
        raise ReleaseError(f"{label} 检查时间无法解析：{stamp}") from error


def validate_fingerprint(value: object, label: str, *, built: bool) -> dict:
    """Tie actual checks to current bytes, rather than inheriting old pass counts."""
    require(isinstance(value, dict) and isinstance(value.get("files"), dict)
            and bool(value["files"]), f"{label} 缺少文件 SHA / bytes")
    require(value.get("pathBase", "code/") in {"code/", "code"}, f"{label} 路径基准必须为 code/")
    if built:
        require(value.get("version") == VERSION, f"{label} 版本不是 {VERSION}")
        require("dist/index.html" in value["files"], f"{label} 未记录构建入口")
        bundle = value.get("entryBundle", "")
        require(isinstance(bundle, str) and bundle.startswith("assets/")
                and f"dist/{bundle}" in value["files"], f"{label} 未记录入口 JS")
    else:
        require("src/character.ts" in value["files"], f"{label} 未记录角色模型源码")
    for name, recorded in value["files"].items():
        require(isinstance(name, str) and not Path(name).is_absolute()
                and ".." not in Path(name).parts and "\\" not in name,
                f"{label} 文件路径越界")
        require(name.startswith("dist/") if built else not name.startswith("dist/"),
                f"{label} 文件来源与检查方式不符：{name}")
        actual, _ = read_stable(CODE / name)
        require(isinstance(recorded, dict) and recorded.get("bytes") == len(actual)
                and recorded.get("sha256") == digest(actual),
                f"当前文件与本轮实测版本不同：{label} / {name}")
    return value


def check_entries(report: dict, label: str) -> int:
    """Check explicitly reported results without inventing a fixed suite size.

    Reports may use a list of named checks or a mapping of names to checks.
    Historical baseline metrics and image lists are deliberately not counted as
    current pass cases. Detailed shape is finalized with the real QA reports.
    """
    checks = report.get("checks")
    require(isinstance(checks, (list, dict)) and bool(checks), f"{label} 没有实际检查记录")
    entries = list(checks.values()) if isinstance(checks, dict) else checks
    for index, item in enumerate(entries):
        require(isinstance(item, dict), f"{label} 检查项 {index} 不是对象")
        status = item.get("status", item.get("result"))
        require(status in {"pass", "passed"}, f"{label} 检查项 {index} 未明确通过")
        require(not item.get("failure") and not item.get("errors"), f"{label} 检查项 {index} 存在错误")
    return len(entries)


def character_summary(report: dict) -> dict:
    """Keep actual measured facts; leave thousands of vertex samples in research."""
    summary = {key: report[key] for key in
               ("version", "checkedAt", "scope", "status", "testedSource", "metricDefinitions",
                "studio", "outfits", "constructorMs", "disposal", "webgl", "limitations")
               if key in report}
    checks = report["checks"]
    entries = list(checks.values()) if isinstance(checks, dict) else checks
    summary["checks"] = [{key: value for key, value in item.items()
                          if isinstance(value, (str, int, float, bool)) or value is None}
                         for item in entries]
    summary["checkCount"] = len(entries)
    summary["detailsReport"] = relative(REPORTS / "character-check.json")
    if isinstance(report.get("baseline"), dict):
        summary["historicalBaseline"] = {key: report["baseline"][key]
                                         for key in ("report", "testedSource") if key in report["baseline"]}
    return summary


def require_image(filename: object, label: str) -> None:
    require(isinstance(filename, str) and not Path(filename).is_absolute()
            and ".." not in Path(filename).parts and "\\" not in filename,
            f"{label} 截图必须是本轮报告目录中的相对路径")
    data, _ = read_stable(REPORTS / filename)
    require(len(data) > 1000 and data.startswith(b"\x89PNG\r\n\x1a\n"), f"{label} 缺少有效 PNG 截图：{filename}")


def validate_ui_evidence(report: dict) -> None:
    expected = {"desktop": (1440, 1000), "mobile": (390, 844), "narrow": (320, 740)}
    checks = report["checks"]
    require(isinstance(checks, list) and len(checks) == 3
            and {item.get("name") for item in checks} == set(expected), "角色 UI 三种实际视口结果不完整")
    for item in checks:
        name = item["name"]
        viewport = item.get("viewport", {})
        require((viewport.get("width"), viewport.get("height")) == expected[name], f"{name} 视口尺寸与验收范围不符")
        for key in ("errors", "external", "outsideSubpath", "failedRequests", "badResponses"):
            require(item.get(key) == [], f"{name} 的 {key} 未通过")
        audio = item.get("audio", [])
        require(isinstance(audio, list) and any(a.get("playing") is True
                and isinstance(a.get("duration"), (int, float)) and a["duration"] > 0 for a in audio),
                f"{name} 缺少原生音频实际播放记录")
        photo = item.get("photo", {})
        require(photo.get("bytes", 0) > 10000 and photo.get("width", 0) > 100
                and photo.get("height", 0) > 100, f"{name} 缺少有效 PNG 下载记录")
        saved = item.get("zip", {})
        require(saved.get("importPreviewValidated") is True and saved.get("bytes", 0) > 0
                and {"manifest.json", "save.json"}.issubset(saved.get("files", [])), f"{name} 缺少 ZIP v1 导出 / 导入预览证据")
        require(isinstance(item.get("views"), list) and bool(item["views"]), f"{name} 缺少成品截图")
        for filename in item["views"]:
            require_image(filename, name)
        require_image(f"photo-{name}.png", name)


def validate_reports(entry_ns: int) -> tuple[dict, list[dict]]:
    missing = [name for name in REPORT_NAMES if not (REPORTS / name).is_file()]
    require(not missing, f"{VERSION} 打包所需的角色专项报告尚未齐全，拒绝打包：" + "、".join(missing))
    loaded, evidence = {}, []
    names = [*REPORT_NAMES]
    if (REPORTS / SUPPLEMENTAL_REPORT).exists():
        names.append(SUPPLEMENTAL_REPORT)
    for name in names:
        data, meta = read_json_file(REPORTS / name)
        checked = checked_time(data, name)
        require(data.get("version") == VERSION, f"{name} 不是 {VERSION} 本轮报告")
        require(data.get("status") in {"pass", "passed"}, f"{name} 未明确通过")
        require(isinstance(data.get("scope"), str) and bool(data["scope"].strip()), f"{name} 未说明验证范围")
        require(not data.get("failure") and not data.get("errors"), f"{name} 包含 failure / errors")
        if name in {"character-ui-check.json", SUPPLEMENTAL_REPORT}:
            require(checked.timestamp() >= entry_ns / 1e9,
                    f"{name} 早于最终构建，请针对当前 dist 重新执行")
        loaded[name] = data
        evidence.append({**meta, "checkedAt": checked.isoformat(), "version": data["version"], "scope": data["scope"]})

    engine = loaded["engine-check.json"]
    passed_counts(engine.get("result"), "engine-check.result")
    require(engine.get("typecheck", {}).get("exitCode") == 0, "本轮 TypeScript 检查未通过")
    validate_fingerprint(engine.get("testedSource"), "engine-check.testedSource", built=False)

    character = loaded["character-check.json"]
    validate_fingerprint(character.get("testedSource"), "character-check.testedSource", built=False)
    check_entries(character, "character-check")
    outfits = character.get("outfits", {})
    require(isinstance(outfits, dict) and set(outfits) == {"classic", "mint", "chef", "student", "night"},
            "模型检查没有覆盖五套装扮")
    for outfit, data in outfits.items():
        screenshots = data.get("screenshots", {})
        require(isinstance(screenshots, dict) and set(screenshots) == {"front", "side", "back"},
                f"{outfit} 缺少三视角截图记录")
        for filename in screenshots.values():
            require_image(filename, outfit)

    ui = loaded["character-ui-check.json"]
    validate_fingerprint(ui.get("testedBuild"), "character-ui-check.testedBuild", built=True)
    require(urlparse(ui.get("baseURL", "")).path == "/dist/", "角色 UI 不是最终 /dist/ 静态子路径")
    check_entries(ui, "character-ui-check")
    validate_ui_evidence(ui)

    # The full reports remain hash-addressed evidence outside the player ZIP.
    # Historical 1.1 metrics and detailed vertex samples are not new pass cases.
    summaries = {"engine": engine, "character": character_summary(character), "characterUI": ui}
    if SUPPLEMENTAL_REPORT in loaded:
        targeted = loaded[SUPPLEMENTAL_REPORT]
        passed_counts(targeted.get("counts"), "targeted-regression-summary.counts")
        check_entries(targeted, "targeted-regression-summary")
        validate_fingerprint(targeted.get("testedBuild"), "targeted-regression-summary.testedBuild", built=True)
        summaries["targetedRegression"] = targeted
    return summaries, evidence


def build_inputs() -> list[Path]:
    files = tree_files(CODE / "src") + tree_files(CODE / "public")
    # tsbuildinfo is compiler output, not a build configuration input.
    files += [p for p in CODE.iterdir() if p.is_file() and
              (p.name.startswith("package") or p.name == "index.html"
               or ("config" in p.name and p.suffix in {".json", ".ts", ".js", ".mjs", ".cjs"})
               or p.name == ".env" or p.name.startswith(".env."))]
    return sorted(set(files))


def validate_distribution() -> tuple[dict[str, bytes], list[dict], list[dict], int]:
    entry = DIST / "index.html"
    _, entry_meta = read_stable(entry)
    entry_ns = entry_meta["mtimeNs"]
    inputs = []
    for path in build_inputs():
        _, meta = read_stable(path)
        inputs.append(meta)
    newer = [item["path"] for item in inputs if item["mtimeNs"] > entry_ns]
    require(not newer, "dist/index.html 早于构建输入，请重新构建：\n" + "\n".join(newer))
    package, _ = read_json_file(CODE / "package.json")
    require(package.get("version") == VERSION, f"预期 package.json version={VERSION}")
    files, inventory = {}, []
    for path in tree_files(DIST):
        name = path.relative_to(DIST).as_posix()
        parts = {part.lower() for part in path.relative_to(DIST).parts}
        require(not parts & BLOCKED_PARTS and path.suffix.lower() not in BLOCKED_SUFFIXES
                and not any(part.startswith(".") for part in parts)
                and "fixture" not in path.name.lower() and "\\" not in name and ":" not in name,
                f"dist 中出现非分发文件，拒绝悄悄省略：{name}")
        data, meta = read_stable(path)
        files[name] = data
        inventory.append({**meta, "archivePath": name})
    require(INSTRUCTIONS_NAME not in files, f"dist 已含 {INSTRUCTIONS_NAME}，请消除命名冲突")
    require(len({name.casefold() for name in files}) == len(files), "ZIP 文件名在 Windows 上会发生大小写冲突")
    require("index.html" in files and "THIRD_PARTY_NOTICES.txt" in files, "dist 缺少入口或第三方许可说明")
    validate_audio_files(files)
    for path in tree_files(CODE / "public"):
        name = path.relative_to(CODE / "public").as_posix()
        require(name in files and files[name] == path.read_bytes(), f"public 与 dist 字节不一致：{name}")
    return files, inventory, inputs, entry_ns


def instructions() -> bytes:
    return f"""我的群友难鱼 · {VERSION}

开始游玩
1. 把这个 ZIP 完整解压到一个文件夹；index.html 与 assets、audio 必须保持相对位置。
2. 使用普通静态 HTTP 服务打开，不要直接双击 index.html（file://）。例如电脑已安装 Python 时，
   在解压目录打开终端执行：python3 -m http.server 8080 --bind 0.0.0.0
   Windows 可改用：py -m http.server 8080 --bind 0.0.0.0
3. 电脑浏览器打开 http://localhost:8080/ 。支持放进网站子目录，无需后端或路由重写。
4. 手机与电脑连接同一局域网，打开 http://电脑的局域网IP:8080/ 。必要时允许该端口通过电脑防火墙。
   WSL2 内的 localhost 不等于手机可访问的地址；最简单的方式是在 Windows 的解压目录运行服务。
   若从 WSL2 提供服务，需按自己的 WSL 网络模式配置宿主端口转发或镜像网络，并使用宿主局域网 IP。

怎么玩
主画面就是难鱼所在的世界。电脑用 WASD / 方向键，手机拖动摇杆；也可以点地面走过去。
地图可前往九个区域；靠近带标记的物件可调查。村民手帐记录当前委托、路线和任务物品。
本版有九区、10 个连贯委托 / 37 阶段、27 处发现、19 种任务物品、5 个小游戏，
并保留 21 段日常故事 / 45 个结局、5 套服装和 76 段本地语音，以及 {len(scene_music_files())} 首场景纯音乐。
开村日是以群聊相处方式为原型的游戏改编，委托不是历史事件原样复现。
小游戏完成一轮即可满足主线要求，正确率不阻挡推进。钱与普通食品用光仍可继续委托。
生活菜单中有衣柜、小游戏、设置和存档；画面上的聊天、投喂、拍照也可以直接使用。
1.2 根据新增三视角重做立体角色，生活菜单“打个招呼”会挥手；投喂、逗她和跳舞会收起弹窗以展示动作。
主动互动先停下当前路径，再次移动可以打断动作。低画质会切换角色精细度并减少阴影负担。

存档和隐私
自动存档保存在当前浏览器的网站本地存储中；更换浏览器、域名、端口或清除网站数据会使用另一份存档。
在生活菜单 → 存档中导出 ZIP 备份，另一台设备上可检查并导入。请在清理浏览器前导出。
继续使用 v1 存档格式，保留旧版的委托进度与服装选择；升级不要求重新开始。
游戏为纯前端，不上传聊天输入、游戏进度或存档，不连接群聊账号，不需要账号和 API 密钥。
发布包不含完整聊天记录、分析数据库、研究文档、源码或测试存档；只保留游戏所需的少量授权台词和角色素材。

语音与画面
76 段台词使用合成语音（synthetic voice），不是难鱼本人的录音或声音克隆。
各场景使用独立的背景音乐，曲目来源和授权见 THIRD_PARTY_NOTICES.txt。
交互音效由本项目原创的 Web Audio 合成生成，不使用下载音效素材。
点击语音按钮可播放；浏览器需先收到一次点击才可能允许声音。部分新增文本使用浏览器语音能力，
其音色和可用性取决于设备。设置中可调整音量、关闭语音、开启温和模式或低画质。
卡顿时可打开低画质，并关闭其他占用图形资源的页面。游戏需要支持 WebGL 的现代浏览器。

验证边界
本次验证包含真实前端引擎、ZIP 往返、Chromium 浏览器与手机 / 320px 窄屏模拟、普通静态 HTTP /dist/ 子路径。
具体检查范围与构建哈希见构建清单；历史版本的通过记录不能替代当前版本验收。
手机模拟不是 iOS / Android 真机验收；具体设备的帧率、浏览器语音、下载行为和系统内存限制仍以真机为准。
程序不携带远程模型 / CDN 依赖，联网仅用于从你提供的静态服务读取本地包资源。

第三方组件许可见 THIRD_PARTY_NOTICES.txt。发布包哈希与实际检查摘要见 ZIP 外的 构建清单.json。
""".encode("utf-8")


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def write_bytes(path: Path, data: bytes) -> None:
    with path.open("wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def unchanged(metadata: list[dict]) -> None:
    for meta in metadata:
        data, current = read_stable(PROJECT / meta["path"])
        require(current["mtimeNs"] == meta["mtimeNs"] and len(data) == meta["bytes"]
                and current["sha256"] == meta["sha256"], f"验收后文件又变了，停止发布：{meta['path']}")


def backup(path: Path, previous: Path) -> dict | None:
    if not path.exists():
        require(not path.is_symlink(), f"发布目标为无效符号链接：{path}")
        return None
    data, meta = read_stable(path)
    target = previous / f"{path.stem}-{meta['sha256']}{path.suffix}"
    if target.exists():
        require(not target.is_symlink() and target.read_bytes() == data, f"旧版哈希备份发生冲突：{target}")
    else:
        # Exclusive creation never overwrites a previous release, even if another
        # process happens to create the same hash-named backup concurrently.
        with target.open("xb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        shutil.copystat(path, target)
        require(target.read_bytes() == data, f"旧版备份回读不一致：{target}")
    return {"original": relative(path), "backup": relative(target),
            "sha256": meta["sha256"], "bytes": meta["bytes"]}


def publish(staged: list[tuple[Path, Path]], temporary: Path) -> None:
    """Rollback already replaced targets if a later replacement fails."""
    old = {}
    expected = {target: source.read_bytes() for source, target in staged}
    for index, (_, target) in enumerate(staged):
        require(not target.is_symlink(), f"发布目标不能为符号链接：{target}")
        if target.exists():
            copy = temporary / f"rollback-{index}"
            shutil.copy2(target, copy)
            old[target] = copy
        else:
            old[target] = None
    replaced = []
    try:
        for source, target in staged:
            os.replace(source, target)
            replaced.append(target)
        for target in replaced:
            require(target.read_bytes() == expected[target], f"发布后回读异常：{target}")
    except BaseException:
        for target in reversed(replaced):
            if old[target] is None:
                target.unlink(missing_ok=True)
            else:
                os.replace(old[target], target)
        raise


def run(check_only: bool) -> None:
    files, inventory, inputs, entry_ns = validate_distribution()
    summaries, evidence = validate_reports(entry_ns)
    if check_only:
        print(json.dumps({"mode": "check-only", "version": VERSION, "distFiles": len(files),
                          **validate_audio_files(files),
                          "reports": [e["path"] for e in evidence], "writtenFiles": []}, ensure_ascii=False, indent=2))
        return
    require(not RELEASE.is_symlink(), "release 目录不能为符号链接")
    RELEASE.mkdir(parents=True, exist_ok=True)
    previous = RELEASE / "previous"
    require(not previous.is_symlink(), "previous 目录不能为符号链接")
    previous.mkdir(exist_ok=True)
    lock = RELEASE / ".package-release.lock"
    try:
        lock_fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as error:
        raise ReleaseError(f"另一发布进程正在运行，或存在未清理锁：{lock}") from error
    try:
        with os.fdopen(lock_fd, "w") as stream:
            stream.write(str(os.getpid()))
        with tempfile.TemporaryDirectory(prefix=".package-stage-", dir=RELEASE) as stage_dir:
            stage = Path(stage_dir)
            files[INSTRUCTIONS_NAME] = instructions()
            archive = stage / ZIP_NAME
            with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
                for name, data in sorted(files.items()):
                    zipped.writestr(name, data)
            with zipfile.ZipFile(archive) as zipped:
                names = zipped.namelist()
                require(len(names) == len(set(names)) and set(names) == set(files), "ZIP 条目不完整或重名")
                require(zipped.testzip() is None, "ZIP CRC 完整性检查失败")
                for name, expected in files.items():
                    require(zipped.read(name) == expected, f"ZIP 逐字节回读不一致：{name}")
                validate_audio_files({name: zipped.read(name) for name in names if name.startswith("audio/")
                                      or name.lower().endswith((".mp3", ".ogg", ".wav", ".m4a", ".aac", ".flac"))})
            # Recheck file membership as well as bytes before touching the release.
            require(set(build_inputs()) == {PROJECT / m["path"] for m in inputs}, "构建输入文件集合在打包期间变化")
            require({p.relative_to(DIST).as_posix() for p in tree_files(DIST)} == set(files) - {INSTRUCTIONS_NAME},
                    "dist 文件集合在打包期间变化")
            unchanged(inputs + inventory + evidence)
            backups = [item for name in (ZIP_NAME, MANIFEST_NAME)
                       if (item := backup(RELEASE / name, previous)) is not None]
            archive_bytes = archive.read_bytes()
            generated = datetime.now(timezone.utc).isoformat()
            package_inventory = [{"path": name, "bytes": len(data), "sha256": digest(data)}
                                 for name, data in sorted(files.items())]
            manifest = {
                "file": ZIP_NAME, "version": VERSION, "generatedAt": generated,
                "bytes": len(archive_bytes), "sha256": digest(archive_bytes),
                "content": {**CONTENT, **validate_audio_files(files)}, "distributionFiles": len(files), "distFiles": len(inventory),
                "uncompressedBytes": sum(len(data) for data in files.values()),
                "entrySHA256": digest(files["index.html"]), "buildEntryModifiedAt": iso_time(entry_ns),
                "validation": {"archiveCRCChecked": True, "allEntriesByteCompared": True,
                               "publicAssetsByteCompared": True, "sourceNewerThanBuild": []},
                "testReports": evidence, "verification": summaries,
                "saveFormatVersion": 1, "backwardCompatibleSaveVersion": 1,
                "privateChatExportsIncluded": False,
                "limitations": ["Chromium browser and mobile viewport emulation are not iOS / Android hardware verification.",
                                "This release uses current character-focused checks; the 1.1 full-world regression is historical evidence, not a rerun on this build.",
                                "Voice is synthetic; it is not the subject's recording or a voice clone."],
                "previousBackups": backups,
            }
            build_inventory = {
                "version": VERSION, "checkedAt": generated, "release": relative(RELEASE / ZIP_NAME),
                "releaseSHA256": manifest["sha256"], "releaseBytes": manifest["bytes"],
                "buildFiles": len(inventory), "packageFiles": len(files), **validate_audio_files(files),
                "fileTypes": dict(sorted(Counter(Path(name).suffix.lower() for name in files).items())),
                "files": package_inventory, "buildInputs": inputs, "distFiles": inventory,
                "sourceNewerThanBuild": [], "privateExportFiles": [], "testReports": evidence,
                "verification": summaries, "archiveValidation": manifest["validation"],
            }
            staged_manifest = stage / MANIFEST_NAME
            staged_inventory = stage / "build-inventory.json"
            write_bytes(staged_manifest, json_bytes(manifest))
            write_bytes(staged_inventory, json_bytes(build_inventory))
            # Reports stay outside the player ZIP. REPORTS already exists because
            # all three current character-release reports were required above.
            publish([(archive, RELEASE / ZIP_NAME), (staged_manifest, RELEASE / MANIFEST_NAME),
                     (staged_inventory, REPORTS / "build-inventory.json")], stage)
            print(json.dumps({"file": relative(RELEASE / ZIP_NAME), "version": VERSION,
                              "bytes": manifest["bytes"], "sha256": manifest["sha256"],
                              "files": len(files), "backups": backups,
                              "manifest": relative(RELEASE / MANIFEST_NAME),
                              "inventory": relative(REPORTS / "build-inventory.json")}, ensure_ascii=False, indent=2))
    finally:
        lock.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="仅校验，不创建或替换任何文件")
    args = parser.parse_args()
    try:
        run(args.check)
    except (ReleaseError, OSError, zipfile.BadZipFile, KeyError, TypeError, ValueError) as error:
        print(f"发布失败：{error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
