# 我的群友难鱼 · 1.11.0 骑行操作设置与场景加载

纯前端 3D 陪伴与探索游戏。React 19 + TypeScript + Three.js + Vite，浏览器本地保存，不需要后端或 API Key。

1.11.0 优化手机骑行按钮，新增左右手、按钮大小、横竖屏拖动布局与键盘自定义。减速改为长按、松开恢复；操作设置会暂停骑行并支持本地保存。切换骑行地图和主世界区域时先显示加载提示，快速改选以最后一次为准。

**1.11.0 已发布**：源码 `df519044999299ae35a8f435cecbaf0bd3ff03f4` 的 [源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/37182991948)构建与发布成功；公开产物 `7ced95417539a15d7aa3cf98f64eb812565ff31b` 的 [Pages 部署](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/37183038088)成功。线上 113 个运行文件的字节和 SHA-256 全部首次匹配本地生产构建；操作设置、换区导航、音乐和场景动作的桌面／手机验证通过。交互验收及范围见 [验证说明](docs/VALIDATION.md)。

1.10.0 新增 [独立骑行入口](https://hardfishdev.github.io/MyHardFish-web-public/#cycling) 与复制直链分享。简单河畔、普通村道、困难夜港分别提供不同画面、速度、障碍密度和得分奖励；新增碰撞颠簸／短暂减速、拾取飞入车篮的动画及专用音效。井盖语音「这是俺拾嘞」以站内 MP3 随机播放，避免叠音。骑行代码和素材进入时单独加载，直链只加载骑行所需内容，沿用原有爆破加载动画。详情见 [骑行说明](docs/CYCLING.md)。

**1.10.0 历史发布**：源码 `fb9139b6a8850bf50a679ad0cf794e416c1de7f2` 经 [同次源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/37176695403)完成构建与发布，两个作业均成功；公开产物 `1307850ab2089531878abc47928414d9a7e4cb72` 的 [Pages 部署](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/37176740701)全部成功。继续使用既有项目 Secret，没有本地补发。线上版本与完整源码 SHA 一致，111 个 HTTPS 运行文件的路径、字节数及 SHA-256 全部首次匹配本地最终生产构建，无重试或失败；扫描前后部署身份一致。 桌面／手机的直链、地图、声音、碰撞、奖励与存档验证通过，主游戏音乐和场景动作回归也通过。验证范围见 [验证说明](docs/VALIDATION.md)。

1.9.1 在骑行小游戏中加入自由旋转视角：拖动鼠标或单指滑动，围绕难鱼观察正面、侧面和背面；滚轮或双指捏合缩放。支持暂停观察、Q / E 环视、Shift + Q / E 调整俯仰，R 或按钮复位，并保留原有三种快捷视角。

1.9.0 新增「难鱼骑自行车」：生活菜单 → 一起玩吧，进入独立的 600 米村外环线。难鱼使用现有 3D 模型踩踏自行车，提供跟随、俯视与侧后视角；左右变道拾取井盖、空瓶和包裹，避开空井与施工路障，终点或耐久耗尽后结算贝壳和熟悉度。键盘与手机按钮均可操作，支持暂停、减速和最高分存档。玩法及实现说明见 [骑行小游戏](docs/CYCLING.md)。

**1.9.1 历史发布**：源码 `a234ce0384498884f34d76161c529a5b8795c3fc`，公开产物 `bde379ee5dac4dc228cbf8693498439583e5efe7`。[源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/37122448151)与 [Pages 部署](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/37122510289)均成功。线上 102 个运行文件字节与哈希匹配本地验收构建，桌面／手机自由旋转、俯仰、缩放、复位及骑行跟随测试通过，基础互动与音乐回归也通过。详见 [验证说明](docs/VALIDATION.md)。

**1.9.0 历史发布**：源码 `9766ac55b5531660e9d9f1b3ef7ede37cb3ab5d8`，公开产物 `bc0b4bb564d8f3e9cfcef5ddf0841d3c9d1dfd24`。[源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/37095564417)与 [Pages 部署](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/37095621204)均成功。线上 102 个运行文件字节与哈希完整匹配本地验收构建；桌面／手机骑行操作、拾取、碰撞、奖励及存档检查通过。详见 [验证说明](docs/VALIDATION.md)。

1.8.1 将 **dbh（QQ 80117801）** 的模型恢复为 1.7.1 造型，撤回 1.8.0 的脸颈、头发、衣物与腿脚重构及新增发束材质。聊天、动作、合影、纪念物、散步委托与存档协议保持现状。此次恢复用于纠正视觉退步，不表示已经完全还原参考图。说明见 [DBH 角色](docs/DBH.md) 与 [验证记录](docs/VALIDATION.md)。

**在线游玩：[我的群友难鱼](https://hardfishdev.github.io/MyHardFish-web-public/)**。保留 1.5 新增的真实坐姿、五种食物的进食与饮用、读书、写字、做饭、浇水、抛球、采购和手持小灯。九区的物件先走近再互动，37 个委托阶段与 108 个剧情节点按情境选择动作；拒收甜点和安静陪伴也有对应表现。互动窗口在桌面靠侧边、手机靠下方，让世界与动作保持可见。说明见 [场景互动](docs/INTERACTIONS.md)，验收与上线记录见 [验证说明](docs/VALIDATION.md) 和 [发布流程](tools/deploy/README.md)。

**1.8.1 历史覆盖发布**：dbh 恢复为 1.7.1 造型，源码为 `fcf1ecc4e74b1f8fa79b3367f354baf2502000cf`，公开产物为 `52d6d5140b505b7270a8aacd8e7654b13bdcdd94`。[源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/36959310623)的构建与发布、[Pages 部署](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/36959387361)均成功；102 个 HTTPS 运行文件首次完成字节与 SHA-256 核对。桌面和手机的 dbh 动作、合影、存档及基础音乐回归均通过。沿用私有源码 → 公开产物 → Pages 流程，具体验证边界见 [验证说明](docs/VALIDATION.md)。

项目级 `PAGES_DEPLOY_TOKEN` 于 2026-10-01 启用；1.6.0 的首次自动发布为源码 `f8f399bffddbbe37de4d0a352726c685c1f14fae`，对应公开提交 `9dc767379b8122879faf4056dfc0b1879c412c78`。这些历史记录不代替后续版本的检查。

1.6.0 首轮发布的源码为 `67fcd00c47a5628f8c44f987926c9941821ae2da`，公开产物为 `d75acdcebd90e3397b478f456d9fbcb2963b5636`，[首次 Pages 部署](https://github.com/HardFishDev/MyHardFish-web-public/actions/runs/36810513143)成功。该轮 104 个实际 HTTPS 运行文件的字节与哈希全部匹配干净构建；dbh、音乐与场景动作三个检查组的桌面／手机共六次浏览器运行通过，八个冷加载／刷新阶段均为 95/95 `clean`。独立文件扫描的一次音乐传输中断在重试后完整校验通过，原始记录保留。这些是首轮检查，不作为本次检查已重跑的声明；详见 [验证说明](docs/VALIDATION.md)。

首轮[源码流水线](https://github.com/HardFishDev/MyHardFish-web/actions/runs/36810357060)构建成功，发布因缺少项目 Secret 失败；当时确认 Secret 不存在，项目凭据没有 Secrets 写权限。随后从该轮同一源码提交干净重建，104 个文件比对通过后使用现有发布器本地补发。详细过程见 [发布记录](tools/deploy/README.md)。

1.5.1 的历史发布已通过两端线上动作与声音检查，并补上资源中断后的一次自动重试；当时同样按已记录的同提交干净构建流程补发。

1.4.1 的场景纯音乐继续保留：九区各用一首曲目，切歌约 1.2 秒交叉淡变，支持开关、音量和长期记忆。曲目、作者和许可见 [音乐名单](docs/MUSIC.md)，也可在游戏内「生活设置 → 音乐名单与署名」查看。

1.3.0 的历史发布包含背景音乐、交互音效和爆破加载动画；30 项逻辑、15 项产物边界及桌面/手机共 8 个专项浏览器案例通过，线上 93 个运行文件哈希与两个视口的音乐、挥手和投喂检查均通过。当时 `PAGES_DEPLOY_TOKEN` 尚未配置，网站通过已记录的本地补发流程上线。本轮结果另见 [验证说明](docs/VALIDATION.md)。从本地版迁移时，先在「存档」中导出存档 ZIP，再到在线版导入；不同站点地址的浏览器存档不自动共享。

角色保留 1.2 三视角参考的形体、立体五官和五套服装，新增弯腿坐姿、手臂活动与随手道具；九区与开村日内容沿用 1.1。历史 1.2.0 离线成品经过 30 项逻辑、16 项模型、三种尺寸静态检查及 6 个定向 UI 回归；这些是旧版结果。本轮仅更新网页，工作区成品 ZIP 仍为 1.2.0，不是后续网页版本的分发文件；更早的 1.1 旧包保留在哈希归档中。

## 启动

在本目录使用 Node.js 20.19+ 或 22.12+：

```bash
npm ci
npm run dev
```

打开终端显示的地址，默认 `http://localhost:5173`。手机和电脑在同一网络时可打开可访问的局域网地址；WSL 网络需要按本机环境配置转发。

```bash
npm run build
npm run preview
```

`dist/` 可部署到普通静态 HTTP 服务，支持子目录。请通过 HTTP 打开，不直接双击 `index.html`。模型、纹理、76 条原话音频与 9 首场景纯音乐随网页提供，无运行时外部 CDN。场景音乐由 **Kevin MacLeod** 创作，依据 **CC BY 4.0** 使用，保留来源、作者、许可和剪辑说明。音乐从本站 `audio/music-{场景}.mp3` 读取，不向外域音频服务器请求；来源和许可链接仅供查阅。主世界交互音效由 Web Audio 合成；骑行另有 4 个站内 MP3，在进入小游戏时独立下载。

原开发工作区的离线成品位于 `HardFish_web/release/我的群友难鱼-网页游戏.zip`，附使用说明和第三方许可；这是本地文件，不随源码仓库上传。它与游戏内导出的「存档 ZIP」是两种不同文件。旧版成品保留在同目录的 `previous/` 哈希归档中。

当前离线 ZIP 保持 1.2.0。打包脚本从 `package.json` 读取版本，并要求报告版本与当前代码一致；旧角色报告不能用于验收后续网页版本，新增动作、场景音乐及 dbh 的检查也尚未接入离线打包流程。

第一次点击后播放所在场景的纯音乐；前往另一场景时，新曲就绪后与旧曲进行约 1.2 秒交叉淡变。右上角音符按钮可以快速开关，「生活设置」可调整音乐音量或关闭互动音效，并查看该场景曲名和全部署名。偏好持久保存在当前浏览器，读档不覆盖。难鱼说话时音乐降低，离开页面暂停，返回后恢复；如果设备限制自动恢复，再点一下即可。

主世界加载时预先下载 **93 项资源：85 个音频文件（76 条语音 + 9 首音乐）和 8 张图片**，进度下方显示已处理数量；「难鱼的🐴」会反复蓄力、爆开、消失。失败素材可以重试或先进入游戏。当前静态构建共 **111 个运行文件**，预加载数量不包括 HTML、JS、CSS 和许可文本；发布器另生成 `.nojekyll` 与 `deployment.json`，二者不计入这 111 项。独立 `#cycling` 入口仅预加载 4 个骑行 MP3，复用同样的加载动画。

自 1.5.1 起，在传输中断或停滞后自动重试一次，重试使用新请求并清零该资源的未完成进度，不重复增加已处理数量；HTTP 错误仍显示重试与继续入口。两次请求共用单文件 90 秒预算，保留 30 秒无进展和整体 180 秒上限；正常收到响应头或非空数据块会续期，字节与进度来自实际传输。

## 仓库与发布

| 位置 | 用途 |
| --- | --- |
| [HardFishDev/MyHardFish-web](https://github.com/HardFishDev/MyHardFish-web) | 私有源码仓库；开发与测试代码、配置和运行资源 |
| [HardFishDev/MyHardFish-web-public](https://github.com/HardFishDev/MyHardFish-web-public) | 公开产物仓库；保存编译后的静态网页，由 GitHub Pages 提供访问 |
| [源码仓库 Actions](https://github.com/HardFishDev/MyHardFish-web/actions) | 查看构建、逻辑测试与发布结果，需要源码仓库访问权限 |

源码 `main` 分支推送后，流水线安装锁定依赖、构建并运行逻辑测试，通过后把 `dist/` 内容发布到公开仓库 `main` 分支根目录。公开仓库 Pages 使用 `main` / 根目录；Vite 使用相对资源路径，支持上述项目子路径。当前使用 GitHub 默认域名，没有配置自定义域名或 `CNAME`。

产物校验按 `src/quotes.json` 的 ID 精确匹配 76 条角色语音，并从 `src/music-catalog.json` 推导场景音乐清单；当前为 9 首，并按 `src/cycling-audio-catalog.json` 限定 4 个骑行音频，二者均不计入台词数量。旧 `audio/bgm.mp3` 已移除。缺少或改名的台词/曲目、多余音频、错误目录和空文件都会阻止发布。

仓库禁用了 Deploy key，因此项目专用发布凭据已配置于私有源码仓库的 Actions Secret `PAGES_DEPLOY_TOKEN`，仅发布作业使用，推送目标固定为公开产物仓库。1.3 发布时自动写入 Secret 返回 403 的记录保留为历史；本次补齐权限后创建成功。后续发布前应重新确认 Secret 状态及令牌有效期，轮换时更新该私有仓库的项目 Secret。发布时通过临时 `GIT_ASKPASS` 传递凭据，不把令牌写入远程 URL、Git 配置、日志或版本文件；不设置全局凭据或组织级 Secret。详细配置和维护步骤见 [部署工具说明](tools/deploy/README.md)。

`.gitignore` 保留测试源码，排除依赖、构建目录、Playwright 结果、测试报告、截图、测试存档和临时文件。完整群聊、账号映射、研究资料及新增高清三视图的原图备份留在本地，不进入两个仓库；公开网页仅包含游戏运行所需的授权素材、精选台词和改编内容。

## 从小窝出发

新游戏会收到一张开村日草稿。打开「村民手帐」，跟着当前委托走到发光标记：先看现场、记录发现，再与难鱼决定怎么办。手机用左下摇杆或点击地面移动；桌面用 W A S D / 方向键，E 与邻近物件互动，J 打开手帐，M 打开地图。拖动转镜头，滚轮或双指缩放；可切换俯瞰视角、拍照或隐藏界面。

- **九个区域**：小窝、厨房、公园、便利店、教室、村中心、联机工坊、瓶信河岸、夜市。道路有实体出口，也可用地图直接前往。村中心为 80×80 的完整街区；工坊、河岸与夜市各有独立空间、道路和陈设。
- **十条委托、37 个阶段**：八条主线把公告改名、浆果回收、共同搭建、瓶信、英语标签、共餐、展览、开村夜市串起来，另有安静陪伴和贴纸两条支线。阶段之间有道具交接、地点条件与群友关系变化；十种成果会出现在实际场景中。
- **27 处发现、19 种委托物品**：手帐保存线索、背包、关系与共同回忆。委托导航会让难鱼沿可走的道路前往目标，到达后打开现场；看不清时可用概览镜头。
- **六种小游戏**：漂流瓶配对、火候挑战、口算、英文路牌、浆果分拣，以及独立 3D 地图中的难鱼骑自行车。英文路牌和浆果分拣可答错后重试，无倒计时；所有小游戏开局消耗精力，正常结算获得保底与得分奖励。离开未结束的一局不会发奖。
- **骑行操作**：`#cycling` 可直接进入并分享；三档难度各有独立地图。左侧变道、右侧长按减速，设置支持左右手、大号按钮、上移、横竖屏分别拖动布局，以及键盘主键／备用键与冲突提示。打开设置会暂停骑行，保存后记在当前浏览器。切换骑行地图或主世界区域时先显示小加载提示，再准备场景；连续选择以前往最后一次选择为准。
- **陪伴日常**：聊天、喂食、休息、互损、五套立体服装、购物、每日小事、成就；原有 21 篇分支故事和 45 个结局继续保留。猴、狐狸、酒窝、胡辣汤、雨夜和 jin佬按群内常用称呼进入故事。
- **存档**：自动保存、三个手动位置、ZIP 导入导出和恢复前备份。旧 v1 存档会补齐新手帐；旧存档没有的任务从初始状态开始。小游戏中途状态不跨刷新续局，进行中的委托和故事可以。

生活菜单的“打个招呼”会让难鱼挥手；投喂、逗她、叫她跳舞后会收起弹窗，直接看动作。主动互动会先让她停下，重新移动可以打断动作；低画质也会降低角色精细度，不保证所有真机达到相同帧率。

主线不要求刷熟悉度；所有区域可以自由探索。某些旧日常故事仍有原来的熟悉度条件。卡住时可以直接问难鱼「下一步去哪」，或打开手帐查看尚未满足的条件。

## 角色与资料

角色依据授权参考图设计；1.2 新增的三视角图提供了正、侧、背形体依据。奶白身体与鼻梁由连续体积生成，眼睛、浅微笑线、黑色四肢都是立体几何，不再以原图贴脸。五套服装按身体表面贴合，动作在挥手、迈步、进食、休息与舞蹈间平滑切换；桌面、竖屏和 320px 窄屏的实际交互已验证。1.1 内容分析完整遍历本地导出的 1,001,849 条群记录，并以难鱼的 52,980 条记录、引用链、常用称呼和跨年语境复核内容。全量扫描与人工重点阅读的范围分开说明，详见 [设计依据](docs/DESIGN.md)。地图、职务、任务与结局属于游戏改编，源说明在群友卡、故事和手帐中可展开。

聊天是记住话题和游戏进度的本地规则回应，并非云端大模型。原话使用快速俏皮的合成音，不是本人克隆；追加对白依赖设备的中文朗读能力。原始群聊图片附件未准确恢复，收藏贴纸是本项目创作。

## 验证与结构

```bash
npx playwright install chromium
npx playwright test --project=logic --reporter=list
npx playwright test --project=desktop --project=mobile --trace=off --reporter=list
```

浏览器需要 WebGL 2；可通过 `PLAYWRIGHT_CHROMIUM_EXECUTABLE` 指定 Chromium，通过 `PLAYWRIGHT_BASE_URL` 指定已启动的服务（例如以 `/dist/` 结尾的静态子目录）。默认单 worker，避免多个软件 WebGL 实例争抢资源。最终结果与真机测试边界见 [验证记录](docs/VALIDATION.md)。

| 文件 | 职责 |
| --- | --- |
| `src/character.ts` | 五套服装、立体五官、材质、资源缓存与动作组合 |
| `src/character-form.ts`、`character-rig.ts` | 一次性身体雕塑、高低精细度、曲线四肢与动作时钟 |
| `src/scene.ts`、`world-navigation.ts` | 跟随/概览镜头、空间索引与寻路、交互、资源清理 |
| `src/environment*.ts`、`world-town-props.ts` | 九区域几何、光照、家具、道路与任务成果 |
| `src/world-layout.ts` | 发现点、安全落点、双向出口 |
| `src/adventure-content.ts` | 十条委托、发现与道具的内容定义 |
| `src/adventure.ts`、`adventure-types.ts` | 任务状态、条件、物品、奖励与日志 |
| `src/engine.ts`、`storage.ts` | 日常、故事、规则聊天、小游戏会话与存档兼容 |
| `src/relationships.ts`、`quotes.json` | 群友称呼、语境与精选原话 |
| `src/audio.ts`、`audio-preferences.ts`、`music-catalog.json` | 场景切歌、语音与音效混音、本地声音偏好、曲目署名 |
| `src/resources.ts`、`LoadingScreen.tsx` | 真实资源进度、失败重试和入场动画 |
| `src/AdventurePanel.tsx`、`VillageAtlas.tsx`、`WorldControls.tsx` | 手帐、地图、移动与邻近互动 |
| `src/MiniGame.tsx`、`FieldGames.tsx` | 小游戏入口与五种原有玩法 |
| `src/CyclingGame.tsx`、`cycling.ts`、`cycling-scene.ts` | 独立骑行地图、3D 骑行动画与得分规则 |
| `src/CyclingControlSettings.tsx`、`CyclingTouchControls.tsx`、`cycling-controls.ts` | 骑行键位、触控布局、本地偏好与多指按住减速 |
| `src/scene-transition.ts`、`SceneTransitionIndicator.tsx` | 场景重建前让加载提示绘制、取消陈旧切换 |
| `tools/check-world-cpu.mjs`、`tools/qa/` | 实际世界导航验证、浏览器与静态成品检查 |

完整私人 QQ 导出、账号映射、研究语境、测试存档与截图在仓库外的 `HardFish_web/exports/`、`HardFish_web/research/`，不进入静态游戏包。Git 根仅为本 `code/` 目录。资源许可见 [ASSETS](docs/ASSETS.md) 和成品中的 `THIRD_PARTY_NOTICES.txt`。
