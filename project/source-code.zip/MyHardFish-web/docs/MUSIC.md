# 场景音乐与署名

九个区域各使用一首器乐曲。音乐均由 **Kevin MacLeod** 创作，从其官方网站 Incompetech 下载，依据 **Creative Commons Attribution 4.0 International（CC BY 4.0）** 使用。这里保留原曲名；场景用途、片段剪辑和音量处理由本项目完成。

官网目前明确标注 BY 4.0，而非旧资料中常见的 BY 3.0。许可允许分享、再分发和改编，包括商业用途；须保留作者署名、许可链接及修改说明，不暗示作者为本游戏背书。参见[官网授权页](https://incompetech.com/music/royalty-free/licenses/)、[官网常见问题](https://incompetech.com/music/royalty-free/faq.html)及[CC BY 4.0 许可](https://creativecommons.org/licenses/by/4.0/)。

## 曲目表

下表时长来自最终 MP3 的 `ffprobe` 实测值；来源链接指向作者官网的对应曲目。运行时清单为 `src/music-catalog.json`。

| 场景 | 原曲名与官网来源 | 作者 | 配器与氛围 | 成品时长 | 文件 |
| --- | --- | --- | --- | ---: | --- |
| 小窝 | [Touching Moments Four - Melody](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100040) | Kevin MacLeod | 独奏钢琴的短旋律，轻柔、留白，适合回到小窝聊天休息。 | 109.270 秒 | `public/audio/music-home.mp3` |
| 厨房 | [Investigations](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100646) | Kevin MacLeod | 拨弦、木琴与木管交替，轻巧又略带调皮，陪难鱼在灶台前忙活。 | 93.544 秒 | `public/audio/music-kitchen.mp3` |
| 公园 | [Carefree](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1400037) | Kevin MacLeod | 尤克里里、吉他与钟琴的明亮旋律，适合树荫下散步。 | 100.023 秒 | `public/audio/music-park.mp3` |
| 便利店 | [Bossa Antigua](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1700069) | Kevin MacLeod | 吉他、贝司和轻鼓组成的悠闲巴萨诺瓦，给购物留出从容的节奏。 | 109.714 秒 | `public/audio/music-shop.mp3` |
| 学校 | [Meditation Impromptu 01](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100163) | Kevin MacLeod | 舒缓的独奏钢琴，弱化鼓点和刺激感，适合安静读书与做题。 | 104.046 秒 | `public/audio/music-school.mp3` |
| 村中心 | [Life of Riley](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1400054) | Kevin MacLeod | 钟琴、尤克里里与木吉他的轻快合奏，让村中心保持明亮闲适。 | 112.901 秒 | `public/audio/music-village.mp3` |
| 联机工坊 | [Pamgaea](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1300036) | Kevin MacLeod | 清脆与柔和的合成器交织，带着轻盈的规律节拍，适合联机工坊。 | 102.113 秒 | `public/audio/music-workshop.mp3` |
| 瓶信河岸 | [Dream Culture](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1300046) | Kevin MacLeod | 水感钢琴搭配轻打击乐，缓慢舒展，适合码头与河岸的晚风。 | 109.662 秒 | `public/audio/music-river.mp3` |
| 夜市 | [Sidewalk Shade](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1200103) | Kevin MacLeod | 钢琴、颤音琴、贝司与鼓的轻爵士，给夜市一点热闹而不喧闹的摇摆。 | 105.169 秒 | `public/audio/music-market.mp3` |


## 可直接使用的署名

下列九首曲目的作者和许可相同：

- “Touching Moments Four - Melody” — Kevin MacLeod ([incompetech.com](https://incompetech.com/))。
- “Investigations” — Kevin MacLeod ([incompetech.com](https://incompetech.com/))。
- “Carefree” — Kevin MacLeod ([incompetech.com](https://incompetech.com/))。
- “Bossa Antigua” — Kevin MacLeod ([incompetech.com](https://incompetech.com/))。
- “Meditation Impromptu 01” — Kevin MacLeod ([incompetech.com](https://incompetech.com/))。
- “Life of Riley” — Kevin MacLeod ([incompetech.com](https://incompetech.com/))。
- “Pamgaea” — Kevin MacLeod ([incompetech.com](https://incompetech.com/))。
- “Dream Culture” — Kevin MacLeod ([incompetech.com](https://incompetech.com/))。
- “Sidewalk Shade” — Kevin MacLeod ([incompetech.com](https://incompetech.com/))。

Licensed under Creative Commons: By Attribution 4.0.
[https://creativecommons.org/licenses/by/4.0/](https://creativecommons.org/licenses/by/4.0/)

修改说明：本游戏使用原曲的片段或完整短乐段，做了响度标准化、首尾淡入淡出以及 MP3 转码，未添加人声或环境音效。各音轨继续适用 CC BY 4.0，不因被打包进游戏而改用本项目其他资产的许可。作者并未为本项目背书。

## 剪辑和音频规格

- 44.1 kHz、双声道、96 kbps MP3；九首合计 **11,363,547 字节（约 11.36 MB）**。
- 归一化目标约 −22 LUFS；编码后实测 **−22.45～−22.49 LUFS**。九首真峰值均低于 −2 dBTP，最高为 **−2.43 dBTP**。
- 开头淡入 0.65 秒、结尾淡出 0.9 秒，避免切换和循环边缘爆音。这里只保证温和收尾，不将淡入淡出片段称为无缝循环。
- 小窝与厨房保留原曲完整短乐段和自然收尾；其余节奏曲按官方拍速选择整八小节组附近的低能量切点，学校钢琴在候选段落内选择低能量收尾。起点均为原曲开头。

| 场景 | 原曲所用区间 | 成品响度 | 成品真峰值 |
| --- | --- | ---: | ---: |
| 小窝 | 0.000–109.230 秒 | -22.45 LUFS | -4.49 dBTP |
| 厨房 | 0.000–93.504 秒 | -22.45 LUFS | -4.10 dBTP |
| 公园 | 0.000–99.980 秒 | -22.46 LUFS | -7.72 dBTP |
| 便利店 | 0.000–109.674 秒 | -22.45 LUFS | -4.95 dBTP |
| 学校 | 0.000–104.000 秒 | -22.48 LUFS | -2.43 dBTP |
| 村中心 | 0.000–112.861 秒 | -22.49 LUFS | -7.96 dBTP |
| 联机工坊 | 0.000–102.068 秒 | -22.45 LUFS | -10.10 dBTP |
| 瓶信河岸 | 0.000–109.634 秒 | -22.45 LUFS | -6.07 dBTP |
| 夜市 | 0.000–105.120 秒 | -22.45 LUFS | -7.41 dBTP |


## 来源证据与检查范围

官网目录的逐曲配器均为乐器，没有 Voice、Vocals 或 Choir。筛选时排除了明确含人声/合唱的候选曲，例如 Porch Swing Days、At Rest 和 Deliberate Thought。完整解码、时长、文件哈希、响度、真峰值及首尾 PCM 边界均已检查。当前工具不支持音频感知，因此这份工程检查不声称包含人工听审。

原始完整 MP3、逐曲原网页、官网目录和许可快照、下载元数据、剪辑脚本、串听预览与验证报告保存在本地 `HardFish_web/research/scene-music-v6/`，不进入 Git 或公开站点。`source-evidence.json` 记录来源 URL、官方配器、原始文件哈希；`music-verification.json` 记录成品哈希、时长与音频测量。

公开游戏应保留可见的逐曲来源与署名入口，并在发布许可文本中包含上述作者、许可和修改说明。
