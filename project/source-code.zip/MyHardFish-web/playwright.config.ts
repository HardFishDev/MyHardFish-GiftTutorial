import { chromium, defineConfig } from "@playwright/test";
const executablePath =
  process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE ||
  chromium.executablePath();
export default defineConfig({
  testDir: "./tests",
  fullyParallel: false,
  workers: 1,
  timeout: 40000,
  expect: { timeout: 12000 },
  reporter: [["list"], ["html", { open: "never" }]],
  use: {
    baseURL: process.env.PLAYWRIGHT_BASE_URL || "http://localhost:5173",
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    launchOptions: {
      executablePath,
      args: ["--no-sandbox", "--enable-unsafe-swiftshader"],
    },
  },
  projects: [
    { name: "logic", testMatch: /(?:engine|adventure|interaction-feedback|dbh-state|dbh-storage|cycling-logic|cycling-controls|scene-transition-logic)\.spec\.ts/ },
    {
      name: "desktop",
      testMatch: /(?:game|expansion|audio-loading|scene-music|interactions|dbh|cycling-game|cycling-standalone|cycling-controls-ui|scene-transition-ui)\.spec\.ts/,
      // Headless CI uses software WebGL; default-quality scene tours override this.
      timeout: 120000,
      use: { viewport: { width: 1440, height: 1000 } },
    },
    {
      name: "mobile",
      testMatch: /(?:game|expansion|audio-loading|scene-music|interactions|dbh|cycling-game|cycling-standalone|cycling-controls-ui|scene-transition-ui)\.spec\.ts/,
      timeout: 120000,
      use: {
        viewport: { width: 390, height: 844 },
        isMobile: true,
        hasTouch: true,
      },
    },
  ],
  webServer: process.env.PLAYWRIGHT_BASE_URL ? undefined : {
    command: "npm run dev -- --port 5173",
    url: "http://localhost:5173",
    reuseExistingServer: !process.env.CI,
    timeout: 120000,
  },
});
