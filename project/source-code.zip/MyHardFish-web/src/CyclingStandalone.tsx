import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, Bicycle } from '@phosphor-icons/react';
import CyclingEntry from './CyclingEntry';
import { step } from './engine';
import type { Action, GameState } from './engine';
import type { CyclingDifficulty } from './cycling';
import { loadGame, saveGame } from './storage';
import { loadAudioPreferences } from './audio-preferences';

/** Shares the existing local save and reward rules without creating the village. */
export default function CyclingStandalone() {
  const [initial] = useState(loadGame);
  const [state, setState] = useState(initial.state);
  const current = useRef(state);
  const session = useRef<string | null>(null);
  const [storageError, setStorageError] = useState(initial.error);
  const [preferences] = useState(loadAudioPreferences);
  function persist(next: GameState) {
    current.current = next; setState(next);
    if (initial.error) return;
    try { saveGame(next); setStorageError(''); }
    catch { setStorageError('本机暂时不能保存进度；离开当前骑行页面后，未保存的奖励可能丢失。'); }
  }
  function dispatch(action: Action) { const next = step(current.current, action); persist(next); return next; }
  const dispatchRef = useRef(dispatch); dispatchRef.current = dispatch;
  useEffect(() => {
    const title = document.title; document.title = '难鱼骑自行车 · 独立骑行';
    const timer = setInterval(() => dispatchRef.current({ type: 'tick' }), 30000);
    const cancel = () => {
      const id = session.current; session.current = null;
      if (id && current.current.activeGame?.id === id) dispatchRef.current({ type: 'cancelGame', sessionId: id });
    };
    window.addEventListener('hardfish:before-route', cancel);
    return () => { clearInterval(timer); window.removeEventListener('hardfish:before-route', cancel); cancel(); document.title = title; };
  }, []);
  function start(difficulty?: CyclingDifficulty) {
    if (initial.error || current.current.energy < 8) return false;
    const next = dispatch({ type: 'startGame', value: 'cycling', difficulty });
    session.current = next.activeGame?.id ?? null;
    return !!session.current;
  }
  return <main className="cycling-standalone" data-testid="cycling-standalone">
    <header className="cycling-page-head"><h1><Bicycle size={20} />难鱼骑自行车</h1>
      <span className="cycling-save-summary">精力 {Math.floor(state.energy)} · 贝壳 {state.shells}</span>
      <a href="#" className="cycling-return"><ArrowLeft size={16} />回到小镇</a></header>
    {storageError && <p role="alert" className="cycling-storage-error">{storageError}</p>}
    <div className="cycling-page-body"><CyclingEntry lowQuality={state.settings.lowQuality} outfit={state.outfit}
      voiceEnabled={state.settings.voice} voiceVolume={state.settings.volume} effectsEnabled={preferences.effects}
      onExit={() => { location.hash = ''; }} onStart={start} onFinish={score => {
        const id = session.current; session.current = null;
        if (id) dispatch({ type: 'finishGame', value: 'cycling', score, sessionId: id });
      }} /></div>
  </main>;
}
