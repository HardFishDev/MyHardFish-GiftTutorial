import { useState } from 'react';
import { ArrowRight, BookBookmark, Check, CheckCircle, Compass, Flag, LockKey, MapPin, Package, Sparkle, UsersThree } from '@phosphor-icons/react';
import type { Action, GameKind, GameState } from './engine';
import { getAdventureView } from './engine';
import { adventureItems, discoveries } from './adventure-content';
import { friends, places } from './content';
import type { QuestView } from './adventure-types';
import type { Place } from './scene';
import { EXPLORATION_SPOTS } from './world-layout';

type Props = {
  state: GameState;
  dispatch: (action: Action) => GameState;
  navigate: (place: Place, hotspot: string) => void;
  play: (kind: GameKind, place: Place) => void;
  story: (id: string) => void;
};
const placeName = (id: Place) => places.find(p => p.id === id)?.name || id;
const gameNames: Record<GameKind, string> = { bottle: '漂流瓶记忆', cook: '火候刚刚好', math: '五题就下课', words: '词卡接力', harvest: '浆果回收', cycling: '难鱼骑自行车' };
const statusText = { locked: '还没轮到', available: '可以接下', active: '进行中', completed: '已完成' };
export function QuestObjectives({ view, navigate, play, story }: Pick<Props, 'navigate' | 'play' | 'story'> & { view: QuestView }) {
  if (!view.stage || !view.requirements.length) return null;
  return <div className="quest-objectives" aria-label="本步要做的事">{view.requirements.map(({ requirement: r, met, current, target }) => <div key={r.id} className={met ? 'met' : ''}><span>{met ? <CheckCircle size={17} /> : <span className="objective-dot" />}</span><div><b>{r.label}</b><small>{met ? '已完成' : `${current} / ${target}`}</small></div>{!met && <button className="text-button" onClick={() => {
    if (r.kind === 'game') play(r.game, view.stage!.place);
    else if (r.kind === 'story') story(r.storyId);
    else { const d = discoveries.find(d => d.id === r.discoveryId); if (d) navigate(d.place, d.hotspot); }
  }}>{r.kind === 'game' ? `玩${gameNames[r.game]}` : r.kind === 'story' ? '去体验' : '去看看'}<ArrowRight size={14} /></button>}</div>)}</div>;
}
export function AdventurePanel(props: Props) {
  const { state, dispatch, navigate } = props;
  const view = getAdventureView(state);
  const [tab, setTab] = useState<'quests' | 'discoveries' | 'bag' | 'memories'>('quests');
  const completed = view.quests.filter(q => q.status === 'completed');
  const underway = view.quests.filter(q => q.status !== 'completed' && q.status !== 'locked');
  const locked = view.quests.filter(q => q.status === 'locked');
  const [showCompleted, setShowCompleted] = useState(false);
  return <div className="adventure-book">
    <header className="notebook-cover"><div><small>老母猪村 · 共同生活手帐</small><h3>慢慢把村子<br />过成自己的地方。</h3><p>有事一起做，没事一起晃。嘴上互损，活儿也得有人干。</p></div><div className="notebook-stamp"><span>村民</span><b>已登记</b><small>难鱼 & {state.name}</small></div></header>
    <div className="adventure-summary"><span><Flag size={16} />委托 {view.completedCount} / {view.quests.length}</span><span><Compass size={16} />发现 {view.discoveredCount} / {discoveries.length}</span><span><UsersThree size={16} />{Object.values(state.adventure.relations).reduce((a, b) => a + b, 0)} 次默契积累</span></div>
    <div className="notebook-tabs" role="tablist" aria-label="村民手帐分类">{([['quests', '委托'], ['discoveries', '探索册'], ['bag', '随身物件'], ['memories', '村中记事']] as const).map(([id, label]) => <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}>{label}</button>)}</div>
    {tab === 'quests' && <div className="quest-page">
      <p className="notebook-intro">从一个小忙开始。地图随时能逛，委托也不催你赶时间。</p>
      {underway.map(q => <article className={`quest-card ${state.adventure.trackedQuest === q.quest.id ? 'tracked' : ''}`} key={q.quest.id}>
        <div className="quest-card-top"><small>{statusText[q.status]} · {q.quest.friendIds.map(id => friends.find(f => f.id === id)?.name).filter(Boolean).join(' / ')}</small>{state.adventure.trackedQuest === q.quest.id && <span><Flag size={12} />正在追踪</span>}</div>
        <h3>{q.quest.title}</h3><p>{q.quest.intro}</p>
        <div className="quest-stage-strip">{q.quest.stages.map((stage, i) => <span key={stage.id} className={i < q.completedStages ? 'done' : i === q.completedStages ? 'current' : ''} title={stage.title}>{i < q.completedStages ? <Check size={12} /> : i + 1}</span>)}<small>{q.completedStages} / {q.quest.stages.length} 步</small></div>
        {q.stage && <div className="quest-next"><span><MapPin size={15} />{placeName(q.stage.place)}</span><b>{q.stage.title}</b><p>{q.stage.text}</p><QuestObjectives {...props} view={q} /></div>}
        <div className="quest-card-actions">{q.status === 'available' ? <button className="primary" onClick={() => dispatch({ type: 'startQuest', value: q.quest.id })}>接下这件事<ArrowRight size={17} /></button> : <><button className="primary" onClick={() => { dispatch({ type: 'trackQuest', value: q.quest.id }); if (q.stage) navigate(q.stage.place, q.stage.hotspot); }}><Compass size={17} />去下一站</button><button className="text-button" onClick={() => dispatch({ type: 'trackQuest', value: q.quest.id })}>{state.adventure.trackedQuest === q.quest.id ? '已追踪' : '追踪这件事'}</button></>}<small>{q.quest.reward.shells || 0} 贝壳 · 留下一段共同记忆</small></div>
        <details className="source-note"><summary>这件事从哪儿来</summary><p>{q.quest.source}</p></details>
      </article>)}
      {!underway.length && <div className="notebook-empty"><Sparkle size={30} /><h3>大家的事都办妥了。</h3><p>还可以找齐村里的小发现，换个装扮、走走别的路，或者和难鱼聊聊后来的事。</p></div>}
      {locked.length > 0 && <div className="future-quests"><h4>后面还有这些小事</h4>{locked.map(q => <div key={q.quest.id}><LockKey size={16} /><span><b>{q.quest.title}</b><small>{q.reason}</small></span></div>)}</div>}
      {completed.length > 0 && <><button className="completed-toggle" onClick={() => setShowCompleted(!showCompleted)}><CheckCircle size={17} />{showCompleted ? '收起' : '展开'}已完成的 {completed.length} 件事</button>{showCompleted && completed.map(q => <article key={q.quest.id} className="completed-quest"><h4><CheckCircle size={18} />{q.quest.title}</h4><p>{q.quest.ending}</p><small>{q.progress?.completedAt ? new Date(q.progress.completedAt).toLocaleDateString('zh-CN') : ''} · 这段经历已经记下</small></article>)}</>}
    </div>}
    {tab === 'discoveries' && <><p className="notebook-intro">每个地方都有三处能细看的角落。靠近发光标记，和难鱼一起读读上面的故事。</p><div className="discovery-groups">{places.map(place => { const local = discoveries.filter(d => d.place === place.id); return <section key={place.id}><h3>{place.name}<small>{local.filter(d => state.adventure.discoveries.includes(d.id)).length} / {local.length}</small></h3>{local.map(d => { const found = state.adventure.discoveries.includes(d.id); return <button key={d.id} onClick={() => navigate(d.place, d.hotspot)} className={found ? 'found' : ''}><span>{found ? <CheckCircle size={19} /> : <Compass size={19} />}</span><div><b>{d.title}</b><p>{found ? d.text : '还没一起细看，去这里转转。'}</p></div><ArrowRight size={17} /></button>; })}</section>; })}</div></>}
    {tab === 'bag' && <><p className="notebook-intro">这些是一起做事留下的物件，交付时会按委托扣除。零食仍放在「给她投喂」里。</p><div className="quest-bag">{adventureItems.filter(item => (state.adventure.items[item.id] || 0) > 0).map(item => <article key={item.id}><span><Package size={26} /></span><div><h4>{item.name}<b>× {state.adventure.items[item.id]}</b></h4><p>{item.description}</p></div></article>)}</div>{!Object.values(state.adventure.items).some(n => n > 0) && <div className="notebook-empty"><Package size={32} /><h3>先空着也没关系。</h3><p>完成委托步骤后，信笺、词卡和筹备物件会放在这里。</p></div>}<div className="relation-ledger"><h3>群友默契</h3>{friends.map(friend => <div key={friend.id}><span style={{ background: friend.color }}>{friend.name.slice(0, 1)}</span><b>{friend.name}</b><small>共同做事 {state.adventure.relations[friend.id] || 0}</small></div>)}</div></>}
    {tab === 'memories' && <div className="village-log">{[...state.adventure.log].reverse().map((entry, i) => <article key={`${entry.at}-${i}`}><span><BookBookmark size={17} /></span><div><small>{new Date(entry.at).toLocaleString('zh-CN', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</small><h4>{entry.title}</h4><p>{entry.text}</p></div></article>)}{!state.adventure.log.length && <p className="notebook-intro">第一页还空着，去村口看看吧。</p>}</div>}
  </div>;
}

export function SpotPanel(props: Props & { spotId: string }) {
  const { state, dispatch, spotId, navigate } = props;
  const [feedback, setFeedback] = useState('');
  const spot = EXPLORATION_SPOTS.find(s => s.id === spotId);
  const discovery = discoveries.find(d => d.hotspot === spotId);
  const found = discovery && state.adventure.discoveries.includes(discovery.id);
  const all = getAdventureView(state);
  const here = all.quests.filter(q => q.status === 'active' && q.stage?.hotspot === spotId && q.stage.place === state.place);
  const available = all.quests.filter(q => q.status === 'available' && q.quest.stages[0]?.hotspot === spotId);
  if (!spot) return <p>先去地图上找个地方看看。</p>;
  return <div className="spot-panel">
    <div className="spot-heading"><span><MapPin size={27} /></span><div><small>{placeName(spot.place)} · 走到这里，才看得清</small><h3>{spot.label}</h3></div></div>
    {discovery && <article className="discovery-note"><div><small>路边的小发现</small>{found && <span><CheckCircle size={14} />已记入探索册</span>}</div><h4>{discovery.title}</h4><p>{discovery.text}</p>{!found && <button className="secondary" onClick={() => dispatch({ type: 'discover', value: discovery.id, hotspot: spotId })}><BookBookmark size={17} />记下这处发现</button>}</article>}
    {feedback && <div className="spot-feedback" role="status"><span>难鱼</span><p>{feedback}</p></div>}
    {here.map(q => <article className="spot-quest" key={`${q.quest.id}-${q.stage!.id}`}><small>委托 · {q.quest.title} · 第 {q.completedStages + 1} 步</small><h3>{q.stage!.title}</h3><p>{q.stage!.text}</p><QuestObjectives {...props} view={q} /><div className="quest-choices">{q.choices.map(({ choice, enabled, reason }) => <div key={choice.id}><button disabled={!enabled} onClick={() => { const next = dispatch({ type: 'questAction', questId: q.quest.id, stageId: q.stage!.id, choiceId: choice.id, hotspot: spotId }); if (next.adventure.quests[q.quest.id]?.stage !== q.progress?.stage) setFeedback(choice.text); }}><span>{choice.label}</span><ArrowRight size={17} /></button>{!enabled && <small>{reason}</small>}</div>)}</div></article>)}
    {available.map(q => <article className="spot-quest" key={q.quest.id}><small>这里有件事想拜托你</small><h3>{q.quest.title}</h3><p>{q.quest.intro}</p><button className="primary" onClick={() => dispatch({ type: 'startQuest', value: q.quest.id })}>接下这件事<ArrowRight size={17} /></button></article>)}
    {!here.length && all.tracked?.stage && <button className="next-destination" onClick={() => navigate(all.tracked!.stage!.place, all.tracked!.stage!.hotspot)}><Compass size={22} /><span><small>下一站 · {placeName(all.tracked.stage.place)}</small><b>{all.tracked.stage.title}</b></span><ArrowRight size={18} /></button>}
  </div>;
}
