import * as THREE from 'three';
import type { EnvironmentBuilder } from './environment';
import type { Place } from './scene';

/** Ordinary, directly clickable objects supplement the commission markers. */
export function addWorldInteractions(b: EnvironmentBuilder, place: Place) {
  const add = (id: string, label: string, at: [number, number, number], approach: [number, number], surface = at[1]) => {
    const h = b.hotspot(id, label, at, [1.35, 1.3, 1.1]);
    h.userData.approach = approach; h.userData.activityTarget = at; h.userData.surfaceHeight = surface;
    return h;
  };
  switch (place) {
    case 'home':
      add('water', '给露台的香草浇水', [12.4, 1.25, 7.2], [12.2, 5.4]);
      add('write', '坐到书桌前写两笔', [6.6, 1.6, -5], [4.5, -3.55], 1.49);
      add('inspect', '看看今天的唱片', [3.2, 1.25, 7.2], [3.2, 5.5]); break;
    case 'kitchen':
      add('read', '翻翻备菜手记', [-4.1, 1.85, -3.2], [-.5, -3.2], 1.4);
      add('inspect', '读冰箱上的便利贴', [-9.2, 2.2, -5.5], [-7.45, -5.65]); break;
    case 'park': {
      const toy = new THREE.Group(); b.root.add(toy);
      b.sphere([.25, .25, .25], [1.15, .29, 8.7], '#c59169', toy).userData.keep = true;
      for (let i = 0; i < 3; i++) {
        const stripe = b.torus(.25, .012, [1.15, .29, 8.7], '#78624d', toy);
        stripe.rotation.set(i === 0 ? Math.PI / 2 : 0, i === 2 ? Math.PI / 2 : 0, 0); stripe.userData.keep = true;
      }
      const h = add('play', '和难鱼玩一会儿球', [1.15, .5, 8.7], [2.5, 9]); h.userData.propSource = toy;
      add('read', '在树荫下读一页', [8.3, 1.6, -13.35], [8.3, -11.05]);
      add('water', '照料路边的小花', [12.7, .7, 4.5], [11, 4.5]); break;
    }
    case 'shop':
      add('read', '核对今天的采购单', [-5.4, 1.85, 4.7], [-5.4, 6.7]);
      add('inspect', '看看货架上的新包装', [0, 1.65, -9.4], [0, -7.6]); break;
    case 'school':
      add('write', '坐好写两行草稿', [-2.55, 1.75, -1.5], [0, -1.5], 1.42);
      add('read', '翻开课间的书', [6.35, 1.85, -9], [4.1, -8.8]); break;
    case 'village':
      add('water', '给共同花园浇水', [18, 1.35, -18], [18, -14.5]);
      add('read', '读一读村务公告', [-16, 2, 1], [-16, 3.5]); break;
    case 'workshop':
      add('write', '坐下记联机笔记', [-12, 1.85, -10], [-12, -5.9], 1.62);
      add('inspect', '检查共同作品', [0, 1.9, -15], [0, -11.5], 1.6); break;
    case 'river':
      add('read', '读一封河岸来信', [-7, 1.75, 9], [-7, 12], 1.12);
      add('write', '在码头记一笔', [1, 1.25, 0], [-2, 0]);
      add('inspect', '看看观景台的望远镜', [-10.5, 2.23, -13.5], [-9.35, -12.7]); break;
    case 'market':
      add('shop', '到摊前挑一件小物', [-10, 1.7, -4], [-6.5, -4], 1.46);
      add('cook', '帮小摊翻一翻锅', [21, 1.7, 1], [21, 3.6], 1.46);
      add('read', '看看旧书和唱片', [10, 1.9, -15], [10, -12.6], 1.46); break;
  }
}
