import * as THREE from 'three';
import { canvasTexture, ellipsoid, mesh, point, smoothUvSeamNormals } from './dbh-geometry';

// [height, half width, front Z, back Z]. Front and back are interpolated
// separately: nose/lip/chin relief must never become a ridge around a full ring.
const profiles = [
  [.142,.002,.149,.145], [.148,.038,.157,.107], [.157,.066,.168,.013],
  [.174,.096,.173,-.066], [.192,.126,.182,-.135], [.205,.144,.186,-.154],
  [.235,.177,.190,-.188], [.26,.193,.192,-.208], [.29,.207,.197,-.243],
  [.32,.222,.200,-.254], [.36,.231,.202,-.278], [.42,.237,.204,-.310],
  [.52,.245,.195,-.365], [.65,.265,.195,-.370], [.76,.214,.150,-.327],
  [.835,.104,.057,-.213], [.865,.002,-.064,-.068],
];
const eyeX=.128,eyeY=.421,eyeZ=.134,eyeAngle=.285;
const mouthY=.235;
function globeFront(x:number,y:number,side:number):number {
  const c=Math.cos(eyeAngle),s=side*Math.sin(eyeAngle),dx=x-side*eyeX,dy=y-eyeY;
  const a=s*s/(.084*.084)+c*c/(.033*.033);
  const b=2*dx*s*c*(1/(.033*.033)-1/(.084*.084));
  const d=dx*dx*(c*c/(.084*.084)+s*s/(.033*.033))+(dy/.07)**2-1;
  const discriminant=b*b-4*a*d;
  return discriminant<0?-Infinity:eyeZ+(-b+Math.sqrt(discriminant))/(2*a);
}
const gaussian = (x: number, y: number, cx: number, cy: number, wx: number, wy: number) => Math.exp(-(((x - cx) / wx) ** 2 + ((y - cy) / wy) ** 2));
function rawSection(y: number, axis: number): number {
  let i = 0; while (i < profiles.length - 2 && y > profiles[i + 1][0]) i++;
  const a = profiles[i], b = profiles[i + 1], h = b[0] - a[0], t = THREE.MathUtils.clamp((y - a[0]) / h, 0, 1);
  const slope = (j: number) => {
    if (!j) return (profiles[1][axis] - profiles[0][axis]) / (profiles[1][0] - profiles[0][0]);
    if (j === profiles.length - 1) return (profiles[j][axis] - profiles[j - 1][axis]) / (profiles[j][0] - profiles[j - 1][0]);
    const before = (profiles[j][axis] - profiles[j - 1][axis]) / (profiles[j][0] - profiles[j - 1][0]);
    const after = (profiles[j + 1][axis] - profiles[j][axis]) / (profiles[j + 1][0] - profiles[j][0]);
    return before * after <= 0 ? 0 : 2 * before * after / (before + after);
  };
  return (2 * t ** 3 - 3 * t * t + 1) * a[axis] + (t ** 3 - 2 * t * t + t) * h * slope(i) + (-2 * t ** 3 + 3 * t * t) * b[axis] + (t ** 3 - t * t) * h * slope(i + 1);
}
// Low-frequency cranial form: soften changes of curvature between authored
// sections without spreading local nose/lip details around a horizontal ring.
const sectionStart=profiles[0][0],sectionEnd=profiles[profiles.length-1][0],sectionSteps=1024;
const sectionTable=Array.from({length:sectionSteps+1},(_,i)=>{
  const y=sectionStart+(sectionEnd-sectionStart)*i/sectionSteps;
  const fade=(value:number)=>{const t=THREE.MathUtils.clamp(value,0,1);return t*t*t*(t*(t*6-15)+10);};
  const blend=fade((y-sectionStart)/.040)*fade((sectionEnd-y)/.032);
  return [1,2,3].map(axis=>{
    let total=0,weight=0;
    for(let sample=-6;sample<=6;sample++){
      const w=Math.exp(-.5*(sample*.0075/.017)**2);
      total+=rawSection(y+sample*.0075,axis)*w;weight+=w;
    }
    return THREE.MathUtils.lerp(rawSection(y,axis),total/weight,blend);
  });
});
function section(y:number,axis:number):number {
  const position=THREE.MathUtils.clamp((y-sectionStart)/(sectionEnd-sectionStart),0,1)*sectionSteps;
  const index=Math.min(sectionSteps-1,Math.floor(position));
  return THREE.MathUtils.lerp(sectionTable[index][axis-1],sectionTable[index+1][axis-1],position-index);
}
function profile(y:number,axis:number):number {
  if(axis===1)return section(y,1);
  const front=section(y,2),back=section(y,3);
  return axis===2?(front-back)/2:(front+back)/2;
}
export function getDbhSkullSection(y:number):{halfWidth:number;front:number;back:number} {
  return {halfWidth:section(y,1),front:section(y,2),back:section(y,3)};
}
function relief(x: number, y: number): number {
  const nose=.016*gaussian(x,y,0,.359,.032,.060)+.038*gaussian(x,y,0,.317,.036,.036)
    +.0055*gaussian(x,y,-.020,.299,.016,.019)+.0055*gaussian(x,y,.020,.299,.016,.019)
    +.004*gaussian(x,y,0,.290,.013,.019);
  const cheeks=.008*gaussian(x,y,-.145,.343,.074,.061)+.008*gaussian(x,y,.145,.343,.074,.061);
  const orbital=-.008*gaussian(Math.abs(x),y,.133,.426,.078,.067);
  const outerOrbit=.033*gaussian(Math.abs(x),y,.190,.422,.065,.125);
  const muzzle=.022*gaussian(x,y,0,mouthY,.095,.055);
  const chin=.003*gaussian(x,y,0,.186,.080,.034);
  return nose+cheeks+orbital+outerOrbit+muzzle+chin;
}
function surface(x: number, y: number): number {
  return profile(y,3)+profile(y,2)*Math.pow(Math.max(0,1-(x/profile(y,1))**2),.39)+relief(x,y);
}
const baseSkin = new THREE.Color('#f7cbbb'), cheekSkin = new THREE.Color('#ea9f94'), lipSkin = new THREE.Color('#c48b83');
function skinColor(x: number, y: number, front = 1): THREE.Color {
  const warmth = front * (.40 * gaussian(Math.abs(x),y,.150,.345,.086,.057) + .26 * gaussian(x,y,0,.308,.038,.038));
  return baseSkin.clone().lerp(cheekSkin,warmth);
}

// A linear blink can cut through a convex globe halfway between two safe poses.
// This small additional target restores the spherical clearance at mid-blink.
function addBlinkClearance(geometry: THREE.BufferGeometry, side: number): void {
  const base=geometry.getAttribute('position'),closed=geometry.morphAttributes.position![0];
  const corrected=new Float32Array(base.count*3);
  for(let i=0;i<base.count;i++){
    let clearance=0;
    for(let sample=1;sample<32;sample++){
      const t=sample/32,x=THREE.MathUtils.lerp(base.getX(i),closed.getX(i),t),y=THREE.MathUtils.lerp(base.getY(i),closed.getY(i),t),z=THREE.MathUtils.lerp(base.getZ(i),closed.getZ(i),t);
      clearance=Math.max(clearance,(globeFront(x,y,side)+.0012-z)/(4*t*(1-t)));
    }
    clearance*=1.08;
    corrected[i*3]=base.getX(i);corrected[i*3+1]=base.getY(i);corrected[i*3+2]=base.getZ(i)+clearance;
  }
  const sculpt=geometry.clone();sculpt.morphAttributes={};
  sculpt.setAttribute('position',new THREE.Float32BufferAttribute(corrected,3));sculpt.computeVertexNormals();
  geometry.morphAttributes.position!.push(sculpt.getAttribute('position').clone());
  geometry.morphAttributes.normal!.push(sculpt.getAttribute('normal').clone());sculpt.dispose();
}

/** Sculpted skin plus separate curved eye surfaces and anatomical eyelid apertures. */
export function createDbhFace() {
  const root = new THREE.Group(); root.name = 'dbh-anatomical-face';
  const skinMaterial = new THREE.MeshStandardMaterial({ color: '#ffffff', vertexColors: true, roughness: .74, emissive: '#f7cbbb', emissiveIntensity: .035 });
  const rows = 164, cols = 192, positions: number[] = [], colors: number[] = [], uv: number[] = [], indices: number[] = [], blinkPositions: number[] = [], speechPositions: number[] = [];
  const inAperture = (x: number, y: number, z: number) => {
    if (z < .07) return false;
    for (const side of [-1,1]) {
      const dx = (x-side*(eyeX+.025*Math.sin(eyeAngle)))/(.096*Math.cos(eyeAngle));
      const ey=y-eyeY-side*dx*.0025,dy=ey/(ey>0?.066:.056);
      if (dx * dx + dy * dy < .87) return true;
    }
    return (x / .059) ** 2 + ((y-mouthY)/.014) ** 2 < 1;
  };
  for (let row = 0; row <= rows; row++) {
    const y = .142 + (.865 - .142) * row / rows;
    for (let col = 0; col <= cols; col++) {
      const angle = col / cols * Math.PI * 2, front = Math.cos(angle), x = Math.sin(angle) * profile(y,1), facing = THREE.MathUtils.smoothstep(front,.1,.7);
      const depth=front>0?Math.pow(front,.78):front;
      const z=profile(y,3)+depth*profile(y,2)+relief(x,y)*facing;
      const sculptY=y+.035*THREE.MathUtils.smoothstep(y,.146,.21)*(1-THREE.MathUtils.smoothstep(y,.17,.35))*THREE.MathUtils.smoothstep(-front,-.2,.75);
      positions.push(x,sculptY,z); uv.push(col / cols,row / rows);
      const color = skinColor(x,y,facing); colors.push(color.r,color.g,color.b);
      const eyeMotion = facing * gaussian(Math.abs(x),y,eyeX,eyeY+.005,.088,.081);
      blinkPositions.push(x,sculptY + (y > eyeY ? -.0015 : .001) * eyeMotion,z);
      const speech = facing * gaussian(x,y,0,.194,.08,.044);
      speechPositions.push(x,sculptY - .003 * speech,z + .0007 * speech);
      if (row && col) {
        const a = row * (cols + 1) + col, b = a - cols - 1;
        for (const tri of [[a-1,b,a],[b-1,b,a-1]]) {
          const tx = tri.reduce((n,i)=>n+positions[i*3],0)/3, ty = tri.reduce((n,i)=>n+positions[i*3+1],0)/3, tz = tri.reduce((n,i)=>n+positions[i*3+2],0)/3;
          if (!inAperture(tx,ty,tz)) indices.push(...tri);
        }
      }
    }
  }
  // Close the tiny chin and crown rings; leaving the chin open reveals a pale
  // sliver of the differently lit neck when viewed from slightly below.
  for(let i=1;i<cols-1;i++){
    indices.push(0,i+1,i);
    const top=rows*(cols+1);indices.push(top,top+i,top+i+1);
  }
  const geometry = new THREE.BufferGeometry(); geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3)); geometry.setAttribute('color',new THREE.Float32BufferAttribute(colors,3)); geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2)); geometry.setIndex(indices); geometry.computeVertexNormals(); smoothUvSeamNormals(geometry,cols+1);
  // A small diffuse-normal blend under the sculpted nose softens its crease;
  // the nasal silhouette, projection, and all side-view geometry remain intact.
  const faceNormals=geometry.getAttribute('normal'),normal=new THREE.Vector3(),smoothNormal=new THREE.Vector3();
  const baseSurface=(x:number,y:number)=>profile(y,3)+profile(y,2)*Math.pow(Math.max(.001,1-(x/profile(y,1))**2),.39);
  for(let i=0;i<positions.length/3;i++){
    const x=positions[i*3],y=positions[i*3+1],z=positions[i*3+2],blend=.40*gaussian(x,y,0,.297,.039,.025);
    if(z<.12||blend<.002)continue;
    const h=.0003,dx=(baseSurface(x+h,y)-baseSurface(x-h,y))/(2*h),dy=(baseSurface(x,y+h)-baseSurface(x,y-h))/(2*h);
    smoothNormal.set(-dx,-dy,1).normalize();normal.fromBufferAttribute(faceNormals,i).lerp(smoothNormal,blend).normalize();
    faceNormals.setXYZ(i,normal.x,normal.y,normal.z);
  }
  geometry.morphAttributes.position = [new THREE.Float32BufferAttribute(blinkPositions,3),new THREE.Float32BufferAttribute(speechPositions,3)];
  const face = mesh(root,geometry,skinMaterial); face.name = 'dbh-continuous-skin-sculpt'; face.userData.unbatched = true;
  const lids: THREE.Mesh[] = [], speechMeshes: THREE.Mesh[] = [], gazes: THREE.Group[] = [];
  const irisTexture = canvasTexture(512,512,ctx => {
    ctx.clearRect(0,0,512,512);
    const color = ctx.createRadialGradient(256,256,75,256,256,249);
    color.addColorStop(0,'#39251d'); color.addColorStop(.24,'#64442f'); color.addColorStop(.63,'#9c7954'); color.addColorStop(.89,'#765239'); color.addColorStop(1,'#34271f');
    ctx.fillStyle=color; ctx.beginPath();ctx.arc(256,256,250,0,Math.PI*2);ctx.fill();
    for(let i=0;i<280;i++) { const a=i/280*Math.PI*2,r=87+Math.sin(i*2.73)*12;ctx.strokeStyle=i%3?'rgba(46,28,18,.26)':'rgba(220,181,123,.22)';ctx.lineWidth=i%3?1:1.8;ctx.beginPath();ctx.moveTo(256+Math.cos(a)*r,256+Math.sin(a)*r);ctx.lineTo(256+Math.cos(a+.009)*239,256+Math.sin(a+.009)*239);ctx.stroke(); }
    ctx.fillStyle='#251c17';ctx.beginPath();ctx.ellipse(256,246,91,112,0,0,Math.PI*2);ctx.fill();
    const shade=ctx.createLinearGradient(0,0,0,512);shade.addColorStop(0,'rgba(29,21,18,.72)');shade.addColorStop(.55,'rgba(29,21,18,0)');ctx.fillStyle=shade;ctx.beginPath();ctx.arc(256,256,250,0,Math.PI*2);ctx.fill();
  });
  const irisMaterial = new THREE.MeshStandardMaterial({ map: irisTexture, transparent: true, roughness: .60 });
  const scleraMaterial = new THREE.MeshStandardMaterial({ color: '#e9d8cc', roughness: .65 });
  const lashMaterial = new THREE.MeshStandardMaterial({ color: '#493029', roughness: .83 });
  const highlightMaterial = new THREE.MeshBasicMaterial({ color: '#fff9ed', transparent: true, opacity: .70 });

  for (const side of [-1,1]) {
    const eye = new THREE.Group(); eye.position.set(side*eyeX,eyeY,eyeZ); eye.rotation.y=side*eyeAngle; root.add(eye);
    const globe=ellipsoid(eye,scleraMaterial,point(0,0,0),point(.084,.07,.033),48); globe.name=`dbh-real-eyeball-${side}`;
    const gaze=new THREE.Group();eye.add(gaze);gazes.push(gaze);
    const eyeDepth=(x:number,y:number)=>.033*Math.sqrt(Math.max(.025,1-(x/.084)**2-(y/.07)**2));
    const world=(x:number,y:number,z:number)=>point(side*eyeX+x*Math.cos(eyeAngle)+z*side*Math.sin(eyeAngle),eyeY+y,eyeZ-x*side*Math.sin(eyeAngle)+z*Math.cos(eyeAngle));
    const irisPos:number[]=[],irisUv:number[]=[],irisIndex:number[]=[],radial=14,sectors=80;
    for(let ring=0;ring<=radial;ring++)for(let s=0;s<=sectors;s++){
      const r=ring/radial,a=s/sectors*Math.PI*2,lx=-side*.008+r*Math.cos(a)*.046,ly=.001+r*Math.sin(a)*.052;
      irisPos.push(lx,ly,eyeDepth(lx,ly)+.001);irisUv.push(.5+r*Math.cos(a)*.5,.5+r*Math.sin(a)*.5);
      if(ring&&s){const a=ring*(sectors+1)+s,b=a-sectors-1;irisIndex.push(a-1,a,b,b-1,a-1,b);}
    }
    const irisGeometry=new THREE.BufferGeometry();irisGeometry.setAttribute('position',new THREE.Float32BufferAttribute(irisPos,3));irisGeometry.setAttribute('uv',new THREE.Float32BufferAttribute(irisUv,2));irisGeometry.setIndex(irisIndex);irisGeometry.computeVertexNormals();
    mesh(gaze,irisGeometry,irisMaterial).name=`dbh-curved-brown-iris-${side}`;
    const hx=-side*.008-.012,hy=.02;
    ellipsoid(gaze,highlightMaterial,point(hx,hy,eyeDepth(hx,hy)+.003),point(.0048,.0066,.0013),20);
    ellipsoid(gaze,highlightMaterial,point(-side*.008+.014,-.018,eyeDepth(-side*.008+.014,-.018)+.002),point(.0018,.0025,.0008),16);

    const lidPos:number[]=[],lidClosed:number[]=[],lidColors:number[]=[],lidIndices:number[]=[],lidUv:number[]=[],rings=8,steps=112;
    const opening=(angle:number,closed=false)=>{
      const x=.073*Math.cos(angle),s=Math.sin(angle),h=s>=0?.050:.040;
      const arc=Math.sign(s)*Math.abs(s)**1.25;
      const y=closed?-.003+.0015*(1-(x/.073)**2):arc*h+side*(x/.073)*.003;
      return world(x,y,eyeDepth(x,y)+.0012);
    };
    for(let ring=0;ring<=rings;ring++)for(let step=0;step<=steps;step++){
      const t=ring/rings,a=step/steps*Math.PI*2,s=Math.sin(a),lx=.096*Math.cos(a),ly=s*(s>=0?.066:.056)+side*Math.cos(a)*.0025;
      const outer=world(lx,ly,.025);outer.z=surface(outer.x,outer.y)+.0007;
      const inner=opening(a),closedInner=opening(a,true);
      const open=inner.clone().lerp(outer,t),shut=closedInner.clone().lerp(outer,t);
      const blend=1-THREE.MathUtils.smoothstep(t,0,.74);
      open.z=surface(open.x,open.y)+.0007+(inner.z-surface(inner.x,inner.y)) * blend;
      shut.z=surface(shut.x,shut.y)+.0007+(closedInner.z-surface(closedInner.x,closedInner.y)) * blend;
      open.z=Math.max(open.z,globeFront(open.x,open.y,side)+.0012);
      shut.z=Math.max(shut.z,globeFront(shut.x,shut.y,side)+.0012);
      lidPos.push(open.x,open.y,open.z);lidClosed.push(shut.x,shut.y,shut.z);lidUv.push(step/steps,t);
      const color=skinColor(open.x,open.y);color.lerp(cheekSkin,(1-t)*.015);lidColors.push(color.r,color.g,color.b);
      if(ring&&step){const q=ring*(steps+1)+step,p=q-steps-1;lidIndices.push(q-1,q,p,p-1,q-1,p);}
    }
    const lidGeometry=new THREE.BufferGeometry();lidGeometry.setAttribute('position',new THREE.Float32BufferAttribute(lidPos,3));lidGeometry.setAttribute('color',new THREE.Float32BufferAttribute(lidColors,3));lidGeometry.setAttribute('uv',new THREE.Float32BufferAttribute(lidUv,2));lidGeometry.setIndex(lidIndices);lidGeometry.computeVertexNormals();
    const closedGeometry=lidGeometry.clone();closedGeometry.setAttribute('position',new THREE.Float32BufferAttribute(lidClosed,3));closedGeometry.computeVertexNormals();
    lidGeometry.morphAttributes.position=[closedGeometry.getAttribute('position').clone()];lidGeometry.morphAttributes.normal=[closedGeometry.getAttribute('normal').clone()];closedGeometry.dispose();
    addBlinkClearance(lidGeometry,side);
    const lid=mesh(root,lidGeometry,skinMaterial);lid.name=`dbh-continuous-eyelid-${side}`;lid.userData.unbatched=true;lids.push(lid);
    for(const upper of [true,false]){
      const path=(closed:boolean)=>Array.from({length:49},(_,i)=>{const a=(upper?0:Math.PI)+i/48*Math.PI,p=opening(a,closed);p.z+=.0017;return p;});
      const lashGeometry=new THREE.TubeGeometry(new THREE.CatmullRomCurve3(path(false)),64,upper?.0029:.00065,6,false);
      const closedLash=new THREE.TubeGeometry(new THREE.CatmullRomCurve3(path(true)),64,upper?.0029:.00065,6,false);
      lashGeometry.morphAttributes.position=[closedLash.getAttribute('position').clone()];lashGeometry.morphAttributes.normal=[closedLash.getAttribute('normal').clone()];closedLash.dispose();
      addBlinkClearance(lashGeometry,side);
      const lash=mesh(root,lashGeometry,upper?lashMaterial:new THREE.MeshStandardMaterial({color:'#dfb3a1',roughness:.83}));lash.name=`dbh-${upper?'upper':'lower'}-lid-rim-${side}`;lash.userData.unbatched=true;lids.push(lash);
    }
    const browPoints=[point(side*.061,.501,0),point(side*.115,.514,0),point(side*.171,.509,0),point(side*.211,.497,0)];
    const browCurve=new THREE.CatmullRomCurve3(browPoints),browPos:number[]=[],browIndex:number[]=[],browUv:number[]=[];
    for(let i=0;i<=40;i++){
      const t=i/40,p=browCurve.getPoint(t),thickness=.0015+.004*Math.sin(Math.PI*t)**.65;
      for(const edge of [-1,1]){const y=p.y+edge*thickness;browPos.push(p.x,y,surface(p.x,y)+.002);browUv.push(t,(edge+1)/2);}
      if(i){const a=i*2;browIndex.push(a-2,a,a-1,a-1,a,a+1);}
    }
    const browGeometry=new THREE.BufferGeometry();browGeometry.setAttribute('position',new THREE.Float32BufferAttribute(browPos,3));browGeometry.setAttribute('uv',new THREE.Float32BufferAttribute(browUv,2));browGeometry.setIndex(browIndex);browGeometry.computeVertexNormals();
    mesh(root,browGeometry,new THREE.MeshStandardMaterial({color:'#654637',roughness:.9,transparent:true,opacity:.86,side:THREE.DoubleSide}));
  }

  const mouthPos:number[]=[],mouthOpen:number[]=[],mouthColor:number[]=[],mouthIndex:number[]=[],mouthUv:number[]=[],mouthRings=12,mouthSteps=112;
  for(let ring=0;ring<=mouthRings;ring++)for(let step=0;step<=mouthSteps;step++){
    const t=ring/mouthRings,a=step/mouthSteps*Math.PI*2,s=Math.sin(a),c=Math.cos(a);
    const outerX=.068*c,outerY=mouthY+.019*s,innerX=.047*c;
    const line=mouthY+.0014*(1-c*c),innerY=line+s*.0002,openY=line+s*(s>0?.005:.008);
    const x=THREE.MathUtils.lerp(innerX,outerX,t),y=THREE.MathUtils.lerp(innerY,outerY,t),oy=THREE.MathUtils.lerp(openY,outerY,t);
    const lipVolume=.0007*Math.sin((1-t)*Math.PI*.85),z=surface(x,y)+lipVolume+.0003,oz=surface(x,oy)+lipVolume+.0003;
    mouthPos.push(x,y,z);mouthOpen.push(x,oy,oz);mouthUv.push(step/mouthSteps,t);
    const color=skinColor(x,y),pigment=(1-THREE.MathUtils.smoothstep(t,0,.56))*(s>0?.84:.64);color.lerp(lipSkin,pigment);mouthColor.push(color.r,color.g,color.b);
    if(ring&&step){const q=ring*(mouthSteps+1)+step,p=q-mouthSteps-1;mouthIndex.push(q-1,q,p,p-1,q-1,p);}
  }
  const lipsGeometry=new THREE.BufferGeometry();lipsGeometry.setAttribute('position',new THREE.Float32BufferAttribute(mouthPos,3));lipsGeometry.setAttribute('color',new THREE.Float32BufferAttribute(mouthColor,3));lipsGeometry.setAttribute('uv',new THREE.Float32BufferAttribute(mouthUv,2));lipsGeometry.setIndex(mouthIndex);lipsGeometry.computeVertexNormals();
  const opened=lipsGeometry.clone();opened.setAttribute('position',new THREE.Float32BufferAttribute(mouthOpen,3));opened.computeVertexNormals();lipsGeometry.morphAttributes.position=[opened.getAttribute('position').clone()];lipsGeometry.morphAttributes.normal=[opened.getAttribute('normal').clone()];opened.dispose();
  const lips=mesh(root,lipsGeometry,skinMaterial);lips.name='dbh-soft-lips-speaking';lips.userData.unbatched=true;speechMeshes.push(lips);
  const cavityGeometry=new THREE.CircleGeometry(1,80),cavityPositions=cavityGeometry.getAttribute('position');
  for(let i=0;i<cavityPositions.count;i++){
    const x=cavityPositions.getX(i)*.052,y=mouthY+cavityPositions.getY(i)*.014;
    cavityPositions.setXYZ(i,x,y,surface(x,y)-.006);
  }
  cavityGeometry.computeVertexNormals();
  mesh(root,cavityGeometry,new THREE.MeshStandardMaterial({color:'#945f55',roughness:.94})).name='dbh-recessed-mouth';
  for(const side of [-1,1])ellipsoid(root,new THREE.MeshStandardMaterial({color:'#b98876',roughness:.87}),point(side*.017,.299,surface(side*.017,.299)+.0003),point(.0025,.0007,.0003),16);
  function update(t: number, dt: number, action: string, yaw = 0, pitch = 0) {
    const phase = (t+.71)%4.83, blink = phase < .17 ? 1-Math.min(1,Math.abs(phase-.085)/.085) : 0;
    const speaking = action==='talk' ? Math.max(0,Math.sin(t*11.4))*.8 : 0;
    if(face.morphTargetInfluences){face.morphTargetInfluences[0]=blink;face.morphTargetInfluences[1]=speaking;}
    lids.forEach(lid=>{if(lid.morphTargetInfluences){lid.morphTargetInfluences[0]=blink;lid.morphTargetInfluences[1]=4*blink*(1-blink);}});
    speechMeshes.forEach(part=>{if(part.morphTargetInfluences)part.morphTargetInfluences[0]=speaking;});
    const k=1-Math.exp(-Math.min(.1,Math.max(0,dt))*12);
    gazes.forEach(gaze=>{gaze.visible=blink<.93;gaze.position.x=THREE.MathUtils.lerp(gaze.position.x,THREE.MathUtils.clamp(yaw,-.4,.4)*.012,k);gaze.position.y=THREE.MathUtils.lerp(gaze.position.y,-THREE.MathUtils.clamp(pitch,-.2,.2)*.018,k);});
  }
  // These sub-centimeter facial features are smaller than a world shadow-map texel.
  // Keep their continuous PBR normals while avoiding aliased self-shadow bands.
  root.traverse(object => {
    if (object instanceof THREE.Mesh) {
      object.receiveShadow = false;
      object.userData.unbatched = true;
    }
  });
  return { root, update, dispose: () => irisTexture.dispose() };
}
