import type { Place } from './scene';

/** Pure semantic data: importing this catalog does not load Three.js or the model. */
export const ACTIVITY_PRESETS = {
  sit: { kind: 'sit', prop: 'none', seated: true },
  read: { kind: 'read', prop: 'book' },
  cook: { kind: 'cook', prop: 'spatula' },
  water: { kind: 'water', prop: 'wateringCan' },
  shop: { kind: 'shop', prop: 'bag' },
  play: { kind: 'play', prop: 'ball' },
  write: { kind: 'write', prop: 'pencil' },
  inspect: { kind: 'inspect', prop: 'magnifier' },
  talk: { kind: 'talk', prop: 'none' },
  celebrate: { kind: 'celebrate', prop: 'lantern' },
  eat: { kind: 'eat', prop: 'food' },
} as const;
export type WorldActivityKind = keyof typeof ACTIVITY_PRESETS;
export type WorldActivityProp = typeof ACTIVITY_PRESETS[WorldActivityKind]['prop'] | 'cup';
export interface ActivityPreset { kind: WorldActivityKind; prop: WorldActivityProp; seated?: boolean; }

export const EXPLORATION_ACTIVITIES = {
  home_notice: { kind: 'read', prop: 'book' },
  home_record: { kind: 'read', prop: 'book' },
  home_terrace: { kind: 'water', prop: 'wateringCan' },
  kitchen_recipe: { kind: 'read', prop: 'book' },
  kitchen_fridge: { kind: 'inspect', prop: 'magnifier' },
  kitchen_table: { kind: 'sit', prop: 'cup', seated: true },
  park_bottle: { kind: 'inspect', prop: 'magnifier' },
  park_picnic: { kind: 'read', prop: 'book', seated: true },
  park_pavilion: { kind: 'sit', prop: 'cup', seated: true },
  shop_list: { kind: 'read', prop: 'book' },
  shop_fruit: { kind: 'shop', prop: 'bag' },
  shop_bulletin: { kind: 'read', prop: 'book' },
  school_blackboard: { kind: 'write', prop: 'pencil' },
  school_desk: { kind: 'read', prop: 'book', seated: true },
  school_club: { kind: 'read', prop: 'book' },
  village_square: { kind: 'talk', prop: 'none' },
  village_board: { kind: 'write', prop: 'pencil' },
  village_garden: { kind: 'water', prop: 'wateringCan' },
  workshop_server: { kind: 'inspect', prop: 'magnifier' },
  workshop_recycle: { kind: 'shop', prop: 'bag' },
  workshop_project: { kind: 'inspect', prop: 'lantern' },
  river_bottle: { kind: 'read', prop: 'book' },
  river_dock: { kind: 'write', prop: 'pencil' },
  river_observatory: { kind: 'inspect', prop: 'lantern' },
  market_stall: { kind: 'shop', prop: 'bag' },
  market_table: { kind: 'sit', prop: 'cup', seated: true },
  market_stage: { kind: 'talk', prop: 'lantern' },
} as const satisfies Record<string, ActivityPreset>;

/** Viewing a place does not imply eating, receiving goods, or a successful reward. */
export function activityForHotspot(place: Place, id: string): ActivityPreset | null {
  if (id.startsWith('travel:')) return null;
  const spot = id.startsWith('adventure:') ? id.slice(10) : id;
  if (spot in EXPLORATION_ACTIVITIES) return EXPLORATION_ACTIVITIES[spot as keyof typeof EXPLORATION_ACTIVITIES];
  switch (id) {
    case 'rest': return ACTIVITY_PRESETS.sit;
    case 'cook': return ACTIVITY_PRESETS.cook;
    case 'math': case 'words': return { kind: 'write', prop: 'pencil', seated: place === 'school' };
    case 'bottle': return ACTIVITY_PRESETS.inspect;
    case 'harvest': return ACTIVITY_PRESETS.water;
    case 'shop': return ACTIVITY_PRESETS.shop;
    case 'closet': return { kind: 'inspect', prop: 'none' };
    case 'friends': case 'pet': return ACTIVITY_PRESETS.talk;
    case 'play': return ACTIVITY_PRESETS.play;
    case 'read': return { ...ACTIVITY_PRESETS.read, seated: place === 'home' || place === 'park' };
    case 'water': return ACTIVITY_PRESETS.water;
    case 'write': return { ...ACTIVITY_PRESETS.write, seated: place === 'home' || place === 'school' || place === 'workshop' };
    case 'inspect': return ACTIVITY_PRESETS.inspect;
    case 'story': return place === 'home' ? ACTIVITY_PRESETS.read : ACTIVITY_PRESETS.talk;
    default: return id.startsWith('story:') ? ACTIVITY_PRESETS.read : null;
  }
}
export const getHotspotActivity = (id: string, place: Place) => activityForHotspot(place, id);
