import { useEffect, useState } from 'react';
import type { ComponentType } from 'react';
import type { CyclingGameProps } from './CyclingGame';
import LoadingScreen from './LoadingScreen';
import { preloadResources } from './resources';
import type { ResourceProgress } from './resources';
import { CYCLING_ASSET_URLS } from './cycling-assets';
import './cycling.css';

const initial: ResourceProgress = { percent: 0, completed: 0, total: CYCLING_ASSET_URLS.length, loadedBytes: 0, label: '正在准备难鱼的骑行装备' };

/** Opening the activity is the only point at which its code and audio are fetched. */
export default function CyclingEntry(props: CyclingGameProps) {
  const [Game, setGame] = useState<ComponentType<CyclingGameProps> | null>(null);
  const [progress, setProgress] = useState(initial);
  const [failed, setFailed] = useState<string[]>([]);
  const [error, setError] = useState('');
  const [moduleFailed, setModuleFailed] = useState(false);
  const [ready, setReady] = useState(false);
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    const controller = new AbortController();
    setProgress(initial); setFailed([]); setError(''); setReady(false); setGame(null);
    Promise.all([
      import('./CyclingGame'),
      preloadResources(setProgress, controller.signal, { urls: CYCLING_ASSET_URLS, retry: attempt > 0, label: '正在准备骑行音效和语音' }),
    ]).then(([module, result]) => {
      if (controller.signal.aborted || result.aborted) return;
      setFailed(result.failed);
      if (result.failed.length) setError('骑行素材没有加载完整，请重试。');
      else setGame(() => module.default);
    }).catch(() => { if (!controller.signal.aborted) { setModuleFailed(true); setError('骑行页面未能加载，请检查网络后重试。'); } });
    return () => controller.abort();
  }, [attempt]);
  return <div className="cycling-entry" data-testid="cycling-entry" data-ready={ready}>
    {Game && <Game {...props} onReady={() => { setReady(true); props.onReady?.(); }} />}
    {!ready && props.onExit && <button className="cycling-load-cancel" onClick={props.onExit}>取消加载</button>}
    {!ready && <LoadingScreen variant="cycling" progress={progress} worldReady={ready} failed={failed} error={error}
      onRetry={() => { if (moduleFailed) { location.hash = 'cycling'; location.reload(); } else setAttempt(value => value + 1); }} />}
  </div>;
}
