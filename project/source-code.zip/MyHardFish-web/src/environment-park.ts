import * as THREE from 'three';
import type { EnvironmentBuilder } from './environment';

/** A walkable village park. All scenery is generated locally; no network assets. */
export function buildPark(b: EnvironmentBuilder): void {
  const wood = '#a98b63', dark = '#526253';
  const path = (size: [number, number, number], pos: [number, number, number]) => {
    const p = b.surface(size, pos, '#d9d2b6', 'stone', .025);
    const uv = p.geometry.getAttribute('uv');
    for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * size[0] / 2, uv.getY(i) * size[2] / 2);
    uv.needsUpdate = true;
    p.castShadow = false;
    return p;
  };
  // The spawn opens onto a broad promenade with side paths, rather than a tiny display platform.
  path([5.2, .065, 32], [2.5, .017, -.5]);
  path([31, .06, 3.4], [0, .016, 3.7]);
  path([29, .06, 2.8], [0, .016, -11]);
  path([2.6, .06, 18], [-12.5, .016, -1]);
  for (let i = -7; i <= 7; i++) {
    b.surface([.045, .007, 3.3], [i * 1.95, .052, 3.7], '#babda3', 'stone', 0).castShadow = false;
    b.surface([5.1, .007, .035], [2.5, .053, i * 1.95], '#c0bea4', 'stone', 0).castShadow = false;
  }
  // Oval pond: two collision rectangles leave a 2.5 m bridge corridor clear.
  const basin = b.cylinder(1, 1, .16, [-5, -.09, -5], '#8c9d88');
  basin.scale.set(5.7, 1, 4.05); basin.castShadow = false;
  const waterMaterial = new THREE.MeshPhysicalMaterial({ color: '#83b7ac', roughness: .23, metalness: .12, clearcoat: .55, transparent: true, opacity: .94 });
  const water = new THREE.Mesh(new THREE.CircleGeometry(1, 72), waterMaterial);
  water.rotation.x = -Math.PI / 2; water.scale.set(5.4, 3.8, 1); water.position.set(-5, .055, -5); water.receiveShadow = true; b.root.add(water);
  b.obstacle(-5, -7.65, 10.9, 2.8); b.obstacle(-5, -2.35, 10.9, 2.8);
  for (let i = 0; i < 54; i++) {
    const a = i / 54 * Math.PI * 2;
    const x = -5 + Math.cos(a) * 5.62, z = -5 + Math.sin(a) * 3.98;
    if (Math.abs(z + 5) < 1.35) continue;
    const rock = b.sphere([.37 + (i % 3) * .06, .18 + (i % 2) * .08, .29], [x, .14, z], i % 3 ? '#b7bda8' : '#d2ceaf');
    rock.rotation.y = a; rock.castShadow = false;
  }
  // A level timber crossing is actually walkable by the ground-based character.
  for (let i = 0; i < 32; i++) b.surface([.35, .09, 2.48], [-10.66 + i * .365, .095, -5], i % 4 ? wood : '#ba9d77', 'wood', .018);
  for (const side of [-1, 1]) {
    for (let i = 0; i < 9; i++) {
      const x = -10.7 + i * 1.44, z = -5 + side * 1.31;
      b.surface([.13, 1.08, .13], [x, .59, z], '#897556', 'wood', .025);
      b.sphere([.105, .075, .105], [x, 1.17, z], '#bd9f73');
    }
    b.surface([11.7, .105, .12], [-4.92, 1.03, -5 + side * 1.31], '#a88a63', 'wood', .025);
    b.surface([11.7, .07, .085], [-4.92, .63, -5 + side * 1.31], '#b29a74', 'wood', .015);
  }
  // Lily pads, reeds and fine rings make the water legible at the normal play distance.
  for (const [x, z, scale] of [[-8.5, -7, .48], [-7.3, -2.9, .42], [-4.2, -7.5, .5], [-2.8, -2.9, .34], [-8.9, -2.8, .37]] as const) {
    const leaf = b.cylinder(scale, scale, .017, [x, .075, z], '#78976b'); leaf.scale.z = .76; leaf.castShadow = false;
    const flower = b.sphere([.115, .055, .115], [x + .06, .122, z], '#f4ddc4'); flower.castShadow = false;
    for (let n = 0; n < 5; n++) { const a = n * Math.PI * 2 / 5; b.sphere([.11, .034, .075], [x + Math.cos(a) * .115, .106, z + Math.sin(a) * .115], '#e6b6a4').castShadow = false; }
  }
  for (let i = 0; i < 9; i++) {
    const ring = b.torus(.24 + (i % 3) * .13, .009, [-7.9 + (i % 3) * 2.25, .078, -7.45 + Math.floor(i / 3) * .4], '#bad4c2');
    ring.rotation.x = -Math.PI / 2; ring.scale.y = .63; ring.castShadow = false;
  }
  for (let i = 0; i < 24; i++) {
    const a = i * 2.39, x = -9 + Math.sin(a) * .75, z = -2.2 + Math.cos(a) * .52;
    const reed = b.cylinder(.019, .027, .55 + (i % 4) * .17, [x, .48 + (i % 4) * .085, z], '#798c53'); reed.rotation.z = Math.sin(a) * .18; reed.castShadow = false;
    if (i % 3 === 0) b.cylinder(.049, .049, .22, [x, .9 + (i % 4) * .17, z], '#8c7751').castShadow = false;
  }
  // The playable bottle station is close to the arrival point and on dry ground.
  b.surface([2.35, .12, 1.05], [-2, .76, .25], '#b7976e', 'wood', .035);
  for (const x of [-2.9, -1.1]) b.surface([.12, .7, .12], [x, .36, .25], '#86795c', 'wood', .02);
  b.obstacle(-2, .25, 2.6, 1.15);
  for (let i = 0; i < 4; i++) {
    const x = -2.65 + i * .42;
    const bottle = b.cylinder(.095, .13, .36, [x, 1.01, .25], ['#95bcb0', '#adc6b2', '#d2ba88', '#86aa9b'][i]); bottle.castShadow = false;
    b.cylinder(.054, .06, .15, [x, 1.25, .25], '#91b4a3').castShadow = false;
    b.cylinder(.058, .058, .07, [x, 1.36, .25], '#b8956a').castShadow = false;
    b.box([.13, .17, .01], [x, 1.025, .379], '#f3e7c9', .012).castShadow = false;
  }
  b.surface([2.14, 1.08, .09], [-2, 1.75, .16], '#a9916d', 'wood', .025);
  b.label('捡一封瓶中信', [-2, 1.75, .23], 2.0, '#486858', '#f0ead4');
  b.hotspot('bottle', '捡一封瓶中信', [-2, 1.05, .3], [2.6, 2.1, 1.25]);
  // Near-field lawn seating and picnic details create somewhere to stay.
  b.bench(7.7,9.4,Math.PI);
  b.bench(6.8, -.65, -.32); b.bench(-6.8, 5.4, .15); b.bench(8.8, -8.8, -.55);
  const blanket = b.surface([3.6, .025, 2.65], [7.7, .03, 5.6], '#dcc7a7', 'fabric', .02); blanket.rotation.y = -.16; blanket.castShadow = false;
  for (let i = 0; i < 8; i++) { const stripe = b.surface([3.55, .008, .038], [7.7, .049, 4.45 + i * .31], '#c39b7e', 'fabric', 0); stripe.rotation.y = -.16; stripe.castShadow = false; }
  b.surface([.76, .52, .51], [8.4, .29, 5.6], '#b6976b', 'wood', .1);
  const basketHandle = b.torus(.31, .035, [8.4, .8, 5.6], '#9f8159'); basketHandle.scale.y = 1.2;
  b.cup(7.05, .045, 5.2, '#e8e0bd'); b.cup(7.65, .045, 5.5, '#bec5a0');
  b.cylinder(.31, .31, .025, [6.95, .067, 5.9], '#eee2c2');
  for (let i = 0; i < 3; i++) b.sphere([.11, .12, .11], [6.77 + i * .18, .18, 5.9], i % 2 ? '#c49465' : '#d1ad70');
  b.surface([.63, .065, .48], [7.5, .11, 6.3], '#829687', 'fabric', .025).rotation.y = .3;
  b.obstacle(7.7, 5.6, 3.6, 2.8); b.hotspot('story:soup_photo', '胡辣汤喊你一起拍合影', [7.7, .5, 5.6], [3.6, 1.3, 2.8]);
  // Flower pavilion: open-sided timber construction, shingles and climbing vines.
  const pavilion = new THREE.Group(); pavilion.position.set(8.3, 0, -12.2); b.root.add(pavilion);
  b.surface([5.5, .13, 4.6], [0, .08, 0], '#c7bea0', 'stone', .06, pavilion);
  for (const x of [-2.3, 2.3]) for (const z of [-1.8, 1.8]) {
    const column=b.occluder(`pavilion-column:${x}:${z}`,pavilion);
    b.surface([.2, 3.3, .2], [x, 1.72, z], '#9a8660', 'wood', .035, column);
    b.obstacle(8.3 + x, -12.2 + z, .38, .38);
    for (let i = 0; i < 4; i++) b.sphere([.25, .16, .17], [x + Math.sin(i) * .12, 1 + i * .52, z + .08], i % 2 ? '#899c70' : '#a4ad7c', column).castShadow = false;
  }
  const canopy=b.occluder('pavilion-roof-and-eaves',pavilion);
  for (const z of [-1.9, 1.9]) b.surface([5.4, .19, .22], [0, 3.34, z], '#9f8b67', 'wood', .025, canopy);
  for (let i = 0; i < 11; i++) b.surface([.14, .16, 4.6], [-2.5 + i * .5, 3.49, 0], '#af9973', 'wood', .025, canopy);
  for (const side of [-1, 1]) {
    const roof = b.surface([2.95, .12, 5.1], [side * 1.25, 3.86, 0], '#81927a', 'wood', .025, canopy); roof.rotation.z = side * -.23;
    for (let i = 0; i < 8; i++) { const slat = b.surface([2.93, .035, .045], [side * 1.25, 3.94, -2.3 + i * .66], '#a8b198', 'wood', .008, canopy); slat.rotation.z = side * -.23; }
  }
  b.bench(8.3, -13.35); const sign=b.occluder('pavilion-front-sign');b.label('今天有空，就坐一会儿', [8.3, 2.63, -10.37], 3.4, '#52644c', '#e7dfbf',sign);
  // A village noticeboard carries stylised emblems rather than real-person portraits.
  for (const x of [5.65, 8.25]) b.surface([.12, 2.65, .13], [x, 1.34, 1.95], '#8b795b', 'wood', .025);
  b.surface([3.1, 1.48, .13], [6.95, 2.13, 1.95], '#ad9270', 'wood', .055);
  b.label('老母猪村 · 今日有空\n猴的招牌 / 狐狸的纸瓶', [6.95, 2.15, 2.025], 2.78, '#53654e', '#efe5c9');
  b.surface([3.5, .11, .45], [6.95, 2.96, 1.95], '#6e8668', 'wood', .03).rotation.x = -.16;
  b.obstacle(6.95, 1.95, 3.25, .6); b.hotspot('friends', '读读群友留言', [6.95, 2, 2], [3.5, 2.6, .8]);
  // Layered trees frame the setting; the middle promenade always remains unobstructed.
  for (const [x, z, scale] of [[-14, -12, 1.3], [-8, -14, 1.5], [-2, -14, 1.15], [4, -16, 1.3], [13.6, -12, 1.25], [14.8, -5.5, 1.45], [14, 2.3, 1.3], [13.4, 10, 1.5], [7, 13, 1.3], [-3.8, 13.4, 1.6], [-11.5, 10.8, 1.5], [-15, 3, 1.25], [-15, -4.3, 1.4], [-11, 7.8, .9]] as const) b.tree(x, z, scale);
  // Planter borders, flowering shrubs and grasses repeat a restrained shared palette.
  const beds = [[-8, 8, 3.2, 1.45], [7.5, -4.7, 3.4, 1.3], [12.2, 5.1, 1.4, 4.2], [-4.3, -11, 3.6, 1.05]];
  for (const [x, z, w, d] of beds) {
    b.surface([w, .25, d], [x, .14, z], '#b1b596', 'stone', .12); b.surface([w - .22, .08, d - .22], [x, .29, z], '#857e58', 'plaster', .08); b.obstacle(x, z, w, d);
    for (let i = 0; i < 18; i++) {
      const px = x + Math.sin(i * 2.39) * (w - .35) * .43, pz = z + Math.cos(i * 2.39) * (d - .3) * .4;
      b.sphere([.18, .26, .18], [px, .52, pz], i % 2 ? '#91a278' : '#758d64').castShadow = false;
      b.sphere([.13, .075, .13], [px, .78 + (i % 3) * .035, pz], ['#e6c594', '#d6a68f', '#ece4bc'][i % 3]).castShadow = false;
    }
  }
  for (let i = 0; i < 65; i++) {
    const a = i * 2.399, radius = 11.5 + (i % 5) * 1.15, x = Math.cos(a) * radius, z = Math.sin(a) * radius;
    if (Math.abs(x - 2.5) < 3 || Math.abs(z - 3.7) < 2 || Math.abs(z + 11) < 1.7) continue;
    for (let n = 0; n < 3; n++) { const blade = b.box([.055, .18 + n * .05, .02], [x + n * .055, .13 + n * .02, z], n % 2 ? '#8e9e72' : '#a2ac7a', 0); blade.rotation.z = (n - 1) * .28; blade.castShadow = false; }
  }
  // One shared dapple map keeps soft foliage shadows visible on low shadow settings too.
  const shadowCanvas = document.createElement('canvas'); shadowCanvas.width = shadowCanvas.height = 256;
  const context = shadowCanvas.getContext('2d')!;
  const fade = context.createRadialGradient(128, 128, 20, 128, 128, 120);
  fade.addColorStop(0, 'rgba(44,64,34,.13)'); fade.addColorStop(1, 'rgba(44,64,34,0)');
  context.fillStyle = fade; context.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 42; i++) {
    const a = i * 2.399, radius = 15 + (i % 9) * 9;
    context.beginPath(); context.ellipse(128 + Math.cos(a) * radius, 128 + Math.sin(a) * radius * .76, 9 + i % 7, 6 + i % 5, a, 0, Math.PI * 2);
    context.fillStyle = 'rgba(45,62,36,.055)'; context.fill();
  }
  const shadowMap = new THREE.CanvasTexture(shadowCanvas);
  const shadowMaterial = new THREE.MeshBasicMaterial({ map: shadowMap, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1 });
  for (const [x, z] of [[-13.1, 3.5], [-9.7, 8.1], [12.9, 3.1], [6.2, 12.2], [-3.4, 12.2], [13.9, -4.3], [-12.6, -11.3]]) {
    const shadow = new THREE.Mesh(new THREE.PlaneGeometry(6.4, 5.1), shadowMaterial);
    shadow.position.set(x, .057, z); shadow.rotation.x = -Math.PI / 2; shadow.rotation.z = .22; b.root.add(shadow);
  }
  // Lamps, bins and entrance details make this feel like a real inhabited public garden.
  for (const [x, z] of [[-10.8, 2.2], [4.95, -8.5], [4.95, 8.6], [-11, -10.2], [12.5, -1.3]]) {
    b.cylinder(.16, .22, .17, [x, .09, z], '#727f68'); b.cylinder(.045, .08, 3.1, [x, 1.64, z], dark);
    b.box([.45, .52, .45], [x, 3.17, z], '#efe4b7', .07); b.cylinder(.35, .28, .14, [x, 3.5, z], '#68765e'); b.sphere([.08, .12, .08], [x, 3.64, z], '#68765e'); b.obstacle(x, z, .4, .4);
  }
  b.cylinder(.34, .28, .88, [4.9, .45, .35], '#83917a'); b.cylinder(.39, .39, .07, [4.9, .93, .35], '#60735c'); b.obstacle(4.9, .35, .75, .75);
  b.elevation(-4.92, -5, 11.75, 2.5, .14);
  b.elevation(8.3, -12.2, 5.5, 4.6, .145);
  b.elevation(2.5, -.5, 5.2, 32, .0495);
  b.elevation(0, 3.7, 31, 3.4, .046);
  b.elevation(0, -11, 29, 2.8, .046);
  b.elevation(-12.5, -1, 2.6, 18, .046);
  b.label('有伞再出门', [-7.2, 1.4, 5.82], 1.45, '#61704f', '#eee3c1');
}
