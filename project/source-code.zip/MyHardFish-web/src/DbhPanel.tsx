import { useEffect, useRef, useState } from 'react';
import { ArrowRight, BookOpenText, Camera, Check, Compass, HandWaving, Heart, MapPin, MusicNotes, Sparkle, X } from '@phosphor-icons/react';
import { DBH_CLUES, DBH_DESTINATIONS, DBH_GIFTS, DBH_MEMORIES, DBH_TOPICS } from './dbh-content';
import type { DbhAction } from './dbh-content';
import { applyDbhInteraction, dbhFriendship, normalizeDbhState } from './dbh-state';
import type { DbhEvent, DbhState } from './dbh-state';
import type { Place } from './scene';
import './dbh.css';

export type DbhPanelProps = {
  state: DbhState;
  onChange: (next: DbhState) => void;
  onClose: () => void;
  onAction: (action: DbhAction) => void;
  onTravel?: (place: Place, hotspot?: string) => void;
  /** The owner handles the camera, file download, and photo failure feedback. */
  onPhoto?: () => void | Promise<void>;
};

type Tab = 'chat' | 'activity' | 'notes';

export function DbhPanel({ state: input, onChange, onClose, onAction, onTravel, onPhoto }: DbhPanelProps) {
  const state = normalizeDbhState(input);
  const friendship = dbhFriendship(state);
  const [tab, setTab] = useState<Tab>('chat');
  const [topicId, setTopicId] = useState<string | null>(null);
  const [spoken, setSpoken] = useState(() => state.credited.includes('greet') ? '又见面啦。今天想去哪儿，还是在这里陪我待一会儿？' : '嗨，我是 dbh。刚好有点风，一起在广场待一会儿吧。');
  const [replyDone, setReplyDone] = useState(false);
  const [danceBeat, setDanceBeat] = useState(0);
  const [photoBusy, setPhotoBusy] = useState(false);
  const photoPending = useRef(false);
  const mounted = useRef(true);
  const closeRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLElement>(null);
  const latest = useRef(state);
  latest.current = state;
  const topic = DBH_TOPICS.find(item => item.id === topicId);
  const correctAnswers = DBH_CLUES.filter(clue => state.quest.answers[clue.id] === clue.answer).length;

  useEffect(() => {
    mounted.current = true;
    const previous = document.activeElement;
    closeRef.current?.focus({ preventScroll: true });
    return () => { mounted.current = false; if (previous instanceof HTMLElement && previous.isConnected) previous.focus({ preventScroll: true }); };
  }, []);

  const event = (event: DbhEvent) => {
    const next = applyDbhInteraction(latest.current, event);
    latest.current = next;
    onChange(next);
    return next;
  };
  const say = (text: string, action: DbhAction) => { setSpoken(text); onAction(action); };
  const close = () => { onAction('bye'); onClose(); };
  const chooseTab = (next: Tab) => { setTab(next); panelRef.current?.querySelector('.dbh-panel-body')?.scrollTo({ top: 0 }); };
  const travel = (place: Place, hotspot: string) => { onAction('wave'); onTravel?.(place, hotspot); };
  const answer = (clueId: string, option: string) => {
    event({ type: 'answer', clue: clueId, answer: option });
    const clue = DBH_CLUES.find(item => item.id === clueId)!;
    say(option === clue.answer ? '对，就是这个小细节。给这一格画个勾。' : `这格好像还差一点。${clue.hint}可以再选一次。`, option === clue.answer ? 'nod' : 'think');
  };
  const photo = async () => {
    if (photoPending.current) return;
    photoPending.current = true;
    setPhotoBusy(true);
    onAction('photo');
    setSpoken(onPhoto ? '我准备好了。把今天的广场和我们一起装进照片里吧。' : '找好角度，我先摆个姿势。这个瞬间也记在我们的手记里。');
    try {
      await onPhoto?.();
      if (mounted.current) event({ type: 'action', action: 'photo' });
    } catch {
      if (mounted.current) setSpoken('刚才的照片没有保存好。等一会儿再拍一次吧，我还在这里。');
    } finally {
      photoPending.current = false;
      if (mounted.current) setPhotoBusy(false);
    }
  };

  return <aside ref={panelRef} className="dbh-panel" role="dialog" aria-modal="false" aria-label="与 dbh 聊天" onKeyDown={e => {
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); }
  }}>
    <header className="dbh-panel-header">
      <div className="dbh-name-tag" aria-hidden="true">DBH<span>村中心</span></div>
      <div className="dbh-identity"><h2>dbh <span>在广场等你</span></h2><p>QQ 80117801</p></div>
      <button ref={closeRef} className="dbh-close" onClick={close} aria-label="结束与 dbh 的交谈"><X size={20} /></button>
    </header>
    <div className="dbh-friendship"><span><Heart size={14} weight={friendship.points >= 8 ? 'fill' : 'regular'} />{friendship.label}</span><span>共同经历 {friendship.points}<i aria-hidden="true"><b style={{ width: `${Math.min(friendship.points / friendship.next, 1) * 100}%` }} /></i></span></div>
    <nav className="dbh-tabs" aria-label="dbh 互动分类">{([['chat', '聊聊天'], ['activity', '一起做点事'], ['notes', '村中手记']] as const).map(([id, label]) => <button key={id} aria-pressed={tab === id} onClick={() => chooseTab(id)}>{label}{id === 'notes' && state.quest.status === 'active' && <span className="dbh-tab-dot" aria-label="散步约定进行中" />}</button>)}</nav>
    <div className="dbh-panel-body">
      <div className="dbh-speech" role="status" aria-live="polite" aria-atomic="true"><small>dbh</small><p>{spoken}</p></div>
      {tab === 'chat' && <div className="dbh-chat">
        <button className="dbh-greeting" onClick={() => { event({ type: 'greet' }); say(state.credited.includes('greet') ? '看见你啦！手挥这么高，是怕我认不出来吗？' : '收到你的招呼了。以后路过这里，我们就算老熟人啦。', 'wave'); }}><HandWaving size={19} /><span>挥手打招呼</span>{state.credited.includes('greet') && <Check size={15} />}</button>
        {!topic ? <><h3 className="dbh-section-title">从一句话开始</h3><div className="dbh-topic-list">{DBH_TOPICS.map(item => <button key={item.id} onClick={() => { setTopicId(item.id); setReplyDone(false); say(item.opening, item.action); }}><span>{item.label}</span>{state.credited.includes(`talk:${item.id}`) ? <Check size={16} /> : <ArrowRight size={16} />}</button>)}</div></> : <div className="dbh-conversation"><h3 className="dbh-section-title">{topic.label}</h3>{!replyDone ? <div className="dbh-replies">{topic.replies.map(reply => <button key={reply.label} onClick={() => { event({ type: 'talk', topic: topic.id }); setReplyDone(true); say(reply.text, reply.action); }}><span>{reply.label}</span><ArrowRight size={15} /></button>)}</div> : <p className="dbh-quiet-note"><Check size={13} />这段闲聊已经记住了。</p>}<button className="dbh-text-button" onClick={() => { setTopicId(null); setReplyDone(false); }}>换个话题</button></div>}
        {onTravel && <details className="dbh-directions"><summary><Compass size={16} />请 dbh 指个路</summary><div>{DBH_DESTINATIONS.map(destination => <button key={destination.hotspot} onClick={() => travel(destination.place, destination.hotspot)}><MapPin size={16} /><span><b>{destination.label}</b><small>{destination.note}</small></span><ArrowRight size={15} /></button>)}</div></details>}
      </div>}
      {tab === 'activity' && <div className="dbh-activities">
        <h3 className="dbh-section-title">让今天多一点小动作</h3>
        <div className="dbh-action-grid">
          <button onClick={() => { setDanceBeat(1); say('来，先跟着我左右晃一下。不用数准，开心就算踩到节拍。', 'dance'); }}><MusicNotes size={22} /><span>一起跳一小段</span><small>跟着三拍，随意就好</small></button>
          <button onClick={() => { event({ type: 'action', action: 'stretch' }); say('肩膀抬起来——慢慢放下。嗯，现在可以继续理直气壮地休息了。', 'stretch'); }}><Sparkle size={22} /><span>伸个懒腰</span><small>把肩膀交给微风</small></button>
          <button onClick={() => { event({ type: 'action', action: 'cheer' }); say('下一小步，也值得庆祝。来，一、二、三——今天的你做得不错！', 'cheer'); }}><Heart size={22} /><span>给彼此打打气</span><small>为一点点进展庆祝</small></button>
          <button onClick={() => { void photo(); }} disabled={photoBusy} aria-busy={photoBusy}><Camera size={22} /><span>{photoBusy ? '正在准备合影…' : '拍张合影'}</span><small>{onPhoto ? '摆好姿势并保存照片' : '定格一个广场姿势'}</small></button>
        </div>
        {danceBeat > 0 && <div className="dbh-dance"><span aria-label={`跟拍进度 ${danceBeat} / 3`}>{[1, 2, 3].map(beat => <i key={beat} className={beat <= danceBeat ? 'done' : ''} />)}</span><p>{danceBeat === 1 ? '第一拍，轻轻向左。' : danceBeat === 2 ? '第二拍，跟着向右。' : '第三拍，给今天一个收尾！'}</p><button onClick={() => {
          if (danceBeat < 3) { setDanceBeat(danceBeat + 1); onAction('dance'); }
          else { setDanceBeat(0); event({ type: 'action', action: 'dance' }); say('最后一拍刚好！就算没踩准，我们也是全广场最认真晃的两个人。', 'cheer'); }
        }}>{danceBeat < 3 ? '跟上下一拍' : '一起完成收尾'}<ArrowRight size={15} /></button></div>}
        <h3 className="dbh-section-title">亲手做一份小纪念</h3>
        <p className="dbh-hint">dbh 准备了纸条和落叶，可以一起制作。</p>
        <div className="dbh-crafts">{DBH_GIFTS.map(gift => { const made = state.credited.includes(`craft:${gift.id}`); return <button key={gift.id} onClick={() => { event({ type: 'craft', gift: gift.id }); say(made ? `还记得「${gift.memory}」吗？我们再做一个，把上次没压平的边角也整理好。` : gift.reply, 'gift'); }}><span className="dbh-paper" aria-hidden="true">{gift.id === 'paper_star' ? '☆' : '❧'}</span><span><b>{gift.label}</b><small>{gift.material}</small>{made && <em><Check size={12} />已留下「{gift.memory}」</em>}</span><ArrowRight size={15} /></button>; })}</div>
        <p className="dbh-hint dbh-credit-note">每种新经历会增加一次熟悉度，喜欢的动作可以反复做。</p>
      </div>}
      {tab === 'notes' && <div className="dbh-notes">
        <section className="dbh-walk"><div className="dbh-walk-heading"><BookOpenText size={22} /><div><small>dbh 的散步小约定</small><h3>把村子看仔细一点</h3></div>{state.quest.status === 'completed' && <Check size={21} />}</div>
          {state.quest.status === 'available' ? <><p>到公告栏、共同花园和集合钟看看，带回三个小发现。回来一起填好手记，我把这一页留给你。</p><span className="dbh-reward">纪念：村中散步手记 · 熟悉度 +3</span><button className="dbh-primary" onClick={() => { event({ type: 'startQuest' }); say('约好了。我在这里等你，先去哪里都可以。到地方后，点开标记读一读，再带着发现回来。', 'nod'); }}>接下散步小约定<ArrowRight size={16} /></button></> : state.quest.status === 'completed' ? <p className="dbh-complete">三个小发现已经一起写好。这一页会跟着存档留下，下次见面，我们还有新的话可以聊。</p> : <>
            <p>去点开三处地点的探索标记，读完再回来填写。<b>已到访 {state.quest.visited.length}/3 · 答对 {correctAnswers}/3</b></p>
            <div className="dbh-clues">{DBH_CLUES.map(clue => { const visited = state.quest.visited.includes(clue.hotspot); const correct = state.quest.answers[clue.id] === clue.answer; return <div key={clue.id} className={correct ? 'dbh-clue is-correct' : 'dbh-clue'}><div><b>{clue.label}</b><span>{correct ? '已记下' : visited ? '已到访' : '待到访'}</span></div>{visited ? <label htmlFor={`dbh-clue-${clue.id}`}>{clue.question}<select aria-label={clue.question} id={`dbh-clue-${clue.id}`} value={state.quest.answers[clue.id] || ''} onChange={e => answer(clue.id, e.target.value)}><option value="" disabled>选出你看到的细节</option>{clue.options.map(option => <option key={option.id} value={option.id}>{option.label}</option>)}</select></label> : <p>到这里读一读，回来就能填写。</p>}{onTravel && <button className="dbh-text-button" onClick={() => travel('village', clue.hotspot)}>{visited ? '再去看看' : '带我过去'}<ArrowRight size={13} /></button>}</div>; })}</div>
            <button className="dbh-primary" disabled={correctAnswers !== DBH_CLUES.length} onClick={() => { const next = event({ type: 'finishQuest' }); if (next.quest.status === 'completed') say('一页写好了！原来熟悉一个地方，就是慢慢记住这些小事。这份散步手记，送给我们。', 'gift'); }}>交上这页手记<Check size={16} /></button>
          </>}
        </section>
        <h3 className="dbh-section-title">我们的共同记忆 <span>{state.memories.length}</span></h3>
        {state.memories.length ? <div className="dbh-memories">{[...state.memories].reverse().map(id => <article key={id}><span aria-hidden="true">✧</span><div><h4>{DBH_MEMORIES[id].title}</h4><p>{DBH_MEMORIES[id].text}</p></div></article>)}</div> : <p className="dbh-hint">这一页还空着。从挥手问好、折一颗纸星开始吧。</p>}
      </div>}
      <footer className="dbh-footnote">角色对白为游戏创作 · 互动进度随游戏存档保存</footer>
    </div>
  </aside>;
}
