/** Let a pending loading message paint before synchronous scene/GPU work begins.
 * A single animation frame still runs before paint. The second frame leaves one
 * complete paint opportunity between the caller and its expensive work.
 * Hidden tabs naturally wait for animation frames, and disposal cancels both.
 */
export function waitForScenePaint(signal?: AbortSignal): Promise<boolean> {
  if (signal?.aborted) return Promise.resolve(false);
  return new Promise(resolve => {
    let frame = 0;
    let settled = false;
    const finish = (painted: boolean) => {
      if (settled) return;
      settled = true;
      cancelAnimationFrame(frame);
      signal?.removeEventListener('abort', abort);
      resolve(painted);
    };
    const abort = () => finish(false);
    signal?.addEventListener('abort', abort, { once: true });
    frame = requestAnimationFrame(() => {
      if (settled) return;
      frame = requestAnimationFrame(() => finish(true));
    });
  });
}
