import * as THREE from 'three';
import { mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';
import { createDbhHead } from './dbh-head';
import { createDbhShirt } from './dbh-clothing';
import { createDbhLimb, createDbhShorts, createDbhFoot } from './dbh-body';
import { batchJointMeshes, canvasTexture, ellipsePoints, ellipsoid, line, loft, mesh, point, smoothUvSeamNormals } from './dbh-geometry';

export type DbhAction = 'idle' | 'wave' | 'talk' | 'nod' | 'think' | 'cheer' | 'dance' | 'stretch' | 'photo' | 'gift' | 'bye';

/** A self-contained articulated NPC. Authoring units: 4.2 high, feet at zero, front +Z. */
export function createDbhCharacter() {
  const root = new THREE.Group(); root.name = 'DBH • 80117801';
  root.userData = { npc: 'dbh', action: 'idle', ready: true, qq: '80117801' };
  const contactTexture = canvasTexture(128, 128, ctx => {
    const gradient = ctx.createRadialGradient(64, 64, 8, 64, 64, 62);
    gradient.addColorStop(0, 'rgba(43,31,20,0.31)'); gradient.addColorStop(.4, 'rgba(43,31,20,0.2)'); gradient.addColorStop(1, 'rgba(43,31,20,0)');
    ctx.fillStyle = gradient; ctx.fillRect(0, 0, 128, 128);
  });
  const contact = new THREE.Mesh(new THREE.PlaneGeometry(1.04, .58), new THREE.MeshBasicMaterial({ map: contactTexture, transparent: true, depthWrite: false }));
  contact.rotation.x = -Math.PI / 2; contact.position.set(0, .005, .055); contact.renderOrder = 1; root.add(contact);
  const rig = new THREE.Group(); root.add(rig);
  const mat = (color: THREE.ColorRepresentation, roughness = .67) => new THREE.MeshStandardMaterial({ color, roughness });
  const skin = mat('#f7cbbb', .74), skinLight = mat('#eabfab', .76);
  const seam = mat('#606168', .98), sole = mat('#202022', .9), strap = mat('#333131', .76);
  const knit = canvasTexture(512, 512, ctx => {
    const pixels = ctx.createImageData(512, 512); let seed = 810117;
    for (let i = 0; i < 512 * 512; i++) {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
      const fiber = (seed / 4294967296 - .5) * 22;
      pixels.data[i * 4] = 96 + fiber; pixels.data[i * 4 + 1] = 98 + fiber; pixels.data[i * 4 + 2] = 102 + fiber; pixels.data[i * 4 + 3] = 255;
    }
    ctx.putImageData(pixels, 0, 0); ctx.lineWidth = .45;
    for (let i = 0; i < 14000; i++) {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; const x = (seed & 65535) / 128, y = (seed >>> 16) / 128;
      ctx.strokeStyle = i % 3 ? 'rgba(20,23,26,.045)' : 'rgba(236,238,239,.065)';
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + .35, y + .9 + (i % 3) * .4); ctx.stroke();
    }
  });
  knit.wrapS = knit.wrapT = THREE.RepeatWrapping; knit.repeat.set(3, 3);
  const knitBump = knit.clone(); knitBump.colorSpace = THREE.NoColorSpace; knitBump.needsUpdate = true;
  const cloth = new THREE.MeshStandardMaterial({ color: '#e5e5e8', map: knit, bumpMap: knitBump, bumpScale: .00065, roughness: .97, side: THREE.DoubleSide });
  const torso = new THREE.Group(); torso.position.set(0, 2.22, .06); rig.add(torso);
  createDbhShirt(torso, cloth, seam);
  // The throat narrows under the jaw and opens into the shoulder girdle; a
  // straight cylinder here made the reference's short neck look elongated.
  mesh(torso, loft([
    { y: .94, x: .15, z: .098 }, { y: 1.02, x: .15, z: .098 },
    { y: 1.09, x: .145, z: .099, cz: -.012 }, { y: 1.13, x: .13, z: .095, cz: -.018 }, { y: 1.17, x: .105, z: .085, cz: -.02 },
    { y: 1.25, x: .095, z: .083, cz: -.029 }, { y: 1.34, x: .105, z: .105, cz: -.045 },
  ], 64, false, 8), skin).name = 'dbh-tapered-neck';

  const legs: THREE.Bone[] = [], knees: THREE.Object3D[] = [], feet: THREE.Group[] = [], arms: THREE.Group[] = [], elbows: THREE.Object3D[] = [], hands: THREE.Object3D[] = [];
  const fingerJoints: THREE.Group[][] = [];
  for (const side of [-1, 1]) {
    const leg = new THREE.Bone(); leg.position.set(side * .19, 2.12, 0); rig.add(leg); legs.push(leg);
    const legSkin = createDbhLimb(leg, skin, [
      // The covered upper thigh is omitted so the garment never competes with hidden skin.
      { y: -.18, x: .155, z: .176, cx: -side * .005, cz: .064 }, { y: -.34, x: .146, z: .177, cx: -side * .016, cz: .066 },
      { y: -.57, x: .128, z: .147, cx: -side * .035, cz: .055 }, { y: -.72, x: .118, z: .121, cx: -side * .045, cz: .039 },
      { y: -.845, x: .109, z: .115, cx: -side * .045, cz: .025 }, { y: -.96, x: .11, z: .112, cx: -side * .035, cz: -.002 },
      { y: -1.12, x: .121, z: .130, cx: -side * .025, cz: -.027 }, { y: -1.30, x: .112, z: .122, cx: -side * .03, cz: -.032 },
      { y: -1.55, x: .077, z: .088, cx: -side * .037, cz: -.029 }, { y: -1.77, x: .063, z: .071, cx: -side * .037, cz: -.011 },
      { y: -1.91, x: .065, z: .077, cx: -side * .038, cz: -.002 }, { y: -1.98, x: .072, z: .09, cx: -side * .038 },
    ], -.85, -1.86, .17);
    knees.push(legSkin.middle);
    const foot = new THREE.Group(); foot.position.set(-side * .038, -.26, 0); legSkin.end.add(foot); feet.push(foot);
    createDbhFoot(foot, skin, skinLight, sole, strap, side);
    batchJointMeshes(foot);
    // Reference profile has a longer forefoot, with the same narrow front width.
    foot.traverse(object => { if (!(object instanceof THREE.Mesh)) return;
      object.updateMatrix(); object.geometry.applyMatrix4(object.matrix);
      object.position.set(0,0,0); object.quaternion.identity(); object.scale.set(1,1,1); object.updateMatrix();
      const p = object.geometry.getAttribute('position');
      for (let i=0;i<p.count;i++) { const z=p.getZ(i); if(z>.015)p.setZ(i,.015+(z-.015)*1.42); }
      object.geometry.deleteAttribute('normal');
      const smooth = mergeVertices(object.geometry, .000001); object.geometry.dispose(); object.geometry = smooth;
      object.geometry.computeVertexNormals();
    });
    const arm = new THREE.Group(); arm.position.set(side * .395, .98, -.008); torso.add(arm); arms.push(arm);
    const sleeveGeometry = loft([{ y: .046, x: .001, z: .001, cx: -side * .082 }, { y: .024, x: .068, z: .086, cx: -side * .047 }, { y: -.044, x: .113, z: .136, cx: -side * .021 }, { y: -.16, x: .143, z: .146 }, { y: -.29, x: .150, z: .14, cx: side * .005 }, { y: -.40, x: .149, z: .135, cx: side * .008 }], 48, true, 8);
    const sleevePositions = sleeveGeometry.getAttribute('position');
    for (let i = 0; i < sleevePositions.count; i++) {
      const x = sleevePositions.getX(i), y = sleevePositions.getY(i), z = sleevePositions.getZ(i);
      sleevePositions.setY(i, y + side * (x / .154) * .057 * THREE.MathUtils.clamp((-y - .23) / .18, 0, 1));
      sleevePositions.setZ(i, z + Math.sign(z) * .009 * Math.sin(y * 25 + x * 17) * Math.exp(-(((y + .18) / .11) ** 2)));
    }
    sleeveGeometry.computeVertexNormals(); smoothUvSeamNormals(sleeveGeometry, 49); mesh(arm, sleeveGeometry, cloth);
    line(arm, seam, ellipsePoints(.149, .135, -.394).map(p => { p.x += side*.008; p.y += side * (p.x / .154) * .057 * THREE.MathUtils.clamp((.394-.23)/.18,0,1); return p; }), .0028, 48, true);
    const armSkin = createDbhLimb(arm, skin, [
      { y: -.12, x: .001, z: .001 }, { y: -.16, x: .103, z: .108 },
      { y: -.31, x: .098, z: .103, cz: -.005 }, { y: -.49, x: .085, z: .089, cz: -.008 },
      { y: -.61, x: .076, z: .079, cz: -.005 }, { y: -.66, x: .077, z: .08 },
      { y: -.76, x: .084, z: .085, cz: .007 }, { y: -.9, x: .077, z: .076, cz: .008 },
      { y: -1.04, x: .06, z: .06, cz: .006 }, { y: -1.16, x: .047, z: .041, cz: .005 },
      { y: -1.203, x: .05, z: .033, cz: .006 }, { y: -1.257, x: .056, z: .034, cz: .009 },
      { y: -1.300, x: .057, z: .032, cz: .013 }, { y: -1.337, x: .053, z: .028, cz: .014 },
      { y: -1.357, x: .043, z: .021, cz: .008 }, { y: -1.37, x: .001, z: .001, cz: .005 },
    ], -.66, -1.16, .13, .065);
    elbows.push(armSkin.middle);
    const hand = new THREE.Group(); hand.scale.set(1.04,1.09,1.04); armSkin.end.add(hand); hands.push(armSkin.end);
    const handFingers: THREE.Group[] = []; fingerJoints.push(handFingers);
    for (let finger = 0; finger < 4; finger++) {
      const x = -.041 + finger * .027, length = [.102, .123, .117, .092][finger];
      const digit = new THREE.Group(); digit.position.set(x, [-.15, -.164, -.161, -.141][finger], .01); hand.add(digit); handFingers.push(digit);
      mesh(digit, loft([
        { y: .018, x: .011, z: .011 }, { y: 0, x: .016, z: .013 }, { y: -length * .38, x: .0145, z: .013, cz: .003 },
        { y: -length * .7, x: .013, z: .012, cz: .008 }, { y: -length + .014, x: .012, z: .011, cz: .012 }, { y: -length + .007, x: .0105, z: .0095, cz: .012 }, { y: -length + .0025, x: .0065, z: .006, cz: .012 }, { y: -length, x: .0005, z: .0005, cz: .012 },
      ], 18), skin);
      ellipsoid(digit, skinLight, point(0, -length + .018, .022), point(.0075, .012, .0015), 16);
    }
    mesh(hand, loft([
      { y: -.052, x: .006, z: .006, cx: -side * .042, cz: .011 }, { y: -.072, x: .027, z: .024, cx: -side * .039, cz: .015 },
      { y: -.111, x: .025, z: .022, cx: -side * .059, cz: .024 }, { y: -.148, x: .018, z: .017, cx: -side * .068, cz: .033 },
      { y: -.17, x: .013, z: .014, cx: -side * .066, cz: .037 }, { y: -.178, x: .009, z: .009, cx: -side * .064, cz: .037 },
      { y: -.183, x: .001, z: .001, cx: -side * .063, cz: .037 },
    ], 22), skin);
    ellipsoid(hand, skinLight, point(-side * .066, -.163, .049), point(.009, .012, .0015), 16);
    batchJointMeshes(hand);
  }

  createDbhShorts(rig, cloth, legs);

  const headModel = createDbhHead(skin);
  const head = headModel.root; head.position.y = 1.08; torso.add(head);

  const gift = new THREE.Group(); hands[1].add(gift); gift.position.set(0, -.21, .1);
  const starShape = new THREE.Shape();
  for (let i = 0; i < 10; i++) { const a = Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? .065 : .14; if (!i) starShape.moveTo(Math.cos(a) * r, Math.sin(a) * r); else starShape.lineTo(Math.cos(a) * r, Math.sin(a) * r); } starShape.closePath();
  mesh(gift, new THREE.ExtrudeGeometry(starShape, { depth: .038, bevelEnabled: true, bevelSize: .011, bevelThickness: .01, bevelSegments: 2, steps: 1 }), mat('#f1bd68', .74));
  gift.visible = false;
  batchJointMeshes(rig);

  let currentAction: DbhAction = 'idle';
  const motionPreference = typeof window.matchMedia === 'function' ? window.matchMedia('(prefers-reduced-motion: reduce)') : undefined;
  const localLook = new THREE.Vector3();
  const rootOrientation = new THREE.Quaternion(), parentOrientation = new THREE.Quaternion(), photoOrientation = new THREE.Quaternion().setFromAxisAngle(point(0, 0, 1), Math.PI);
  const approach = (object: THREE.Object3D, x: number, y: number, z: number, k: number) => { object.rotation.x = THREE.MathUtils.lerp(object.rotation.x, x, k); object.rotation.y = THREE.MathUtils.lerp(object.rotation.y, y, k); object.rotation.z = THREE.MathUtils.lerp(object.rotation.z, z, k); };
  const setAction = (action: DbhAction) => { currentAction = action; root.userData.action = action; };
  const update = (elapsed: number, dt: number, action: DbhAction = currentAction, lookAt?: THREE.Vector3, reducedMotion = motionPreference?.matches ?? false) => {
    if (action !== currentAction) setAction(action);
    const t = reducedMotion ? .85 : elapsed, k = reducedMotion ? 1 : 1 - Math.exp(-Math.max(.001, Math.min(dt, .1)) * 9);
    let bodyX = 0, bodyY = 0, bodyZ = .009 * Math.sin(t * 1.15), headX = 0, headY = 0, headZ = -.012 * Math.sin(t * .8);
    let leftX = -.035, leftZ = -.067, rightX = -.035, rightZ = .067, leftElbow = -.055, rightElbow = -.055, leftWrist = 0, rightWrist = 0;
    let leftLeg = 0, rightLeg = 0, leftKnee = 0, rightKnee = 0, bounce = 0;
    if (lookAt) { root.updateWorldMatrix(true, false); localLook.copy(lookAt); root.worldToLocal(localLook); headY = THREE.MathUtils.clamp(Math.atan2(localLook.x, localLook.z), -.48, .48); headX = THREE.MathUtils.clamp(-Math.atan2(localLook.y - 3.75, Math.hypot(localLook.x, localLook.z)), -.16, .19); }
    if (action === 'wave' || action === 'bye') { rightZ = 2.35; rightX = -.12; rightElbow = -.75; rightWrist = Math.sin(t * 7) * .3; headZ = -.075; }
    if (action === 'talk') { rightX = -.42; rightZ = .27; rightElbow = -1.0 + .12 * Math.sin(t * 3); leftElbow = -.25; headX += Math.sin(t * 2.4) * .035; }
    if (action === 'nod') { headX += .16 + Math.sin(t * 3.8) * .14; rightElbow = -.25; }
    if (action === 'think') { rightX = -.66; rightZ = -.31; rightElbow = -1.75; headZ = .1; headX += .08; leftElbow = -.22; }
    if (action === 'cheer') { leftZ = -2.48; rightZ = 2.48; leftElbow = rightElbow = -.56; bounce = Math.abs(Math.sin(t * 5.2)) * .085; headX = -.07; }
    if (action === 'dance') { const b = Math.sin(t * 4.2); leftZ = -.8 + b * .35; rightZ = .8 + b * .35; leftX = -.5 + b * .4; rightX = -.5 - b * .4; leftElbow = rightElbow = -.75; bodyZ = b * .075; bodyY = b * .12; leftLeg = .15 * b; rightLeg = -.15 * b; leftKnee = Math.max(0, b) * .18; rightKnee = Math.max(0, -b) * .18; bounce = Math.abs(b) * .045; }
    if (action === 'stretch') { leftZ = -2.65; rightZ = 2.65; leftElbow = rightElbow = -.14; bodyZ = Math.sin(t * .8) * .075; headX = -.07; }
    if (action === 'photo') { rightZ = 2.2; rightElbow = -1.0; rightX = -.36; headZ = -.095; leftElbow = -.21; }
    if (action === 'gift') { rightX = -.93; rightZ = -.16; rightElbow = -.86; leftX = -.48; leftZ = .21; leftElbow = -.85; headX = .06; }
    if (reducedMotion) { bounce = 0; bodyZ = action === 'dance' ? .04 : 0; }
    rig.position.y = THREE.MathUtils.lerp(rig.position.y, bounce, k);
    approach(torso, bodyX, bodyY, bodyZ, k); torso.scale.y = reducedMotion ? 1 : 1 + Math.sin(t * 1.9) * .0018;
    approach(head, headX, headY, headZ, k);
    approach(arms[0], leftX, .05, leftZ, k); approach(arms[1], rightX, -.05, rightZ, k);
    approach(elbows[0], leftElbow, 0, 0, k); approach(elbows[1], rightElbow, 0, 0, k);
    approach(hands[0], -.03, .27, leftWrist, k);
    if (action === 'photo') {
      root.getWorldQuaternion(rootOrientation); rootOrientation.multiply(photoOrientation);
      elbows[1].getWorldQuaternion(parentOrientation); parentOrientation.invert().multiply(rootOrientation);
      hands[1].quaternion.slerp(parentOrientation, k);
    } else approach(hands[1], -.03, -.27, rightWrist, k);
    fingerJoints.forEach((digits, handIndex) => digits.forEach((digit, index) => {
      const right = handIndex === 1;
      let curl = [-.24,-.32,-.41,-.52][index], spread = (index - 1.5) * .042;
      if ((action === 'wave' || action === 'bye' || action === 'cheer') && right) { curl = 0; spread = (index - 1.5) * .082; }
      if (action === 'photo' && right) { curl = index > 1 ? -1.45 : -.02; spread = index === 0 ? -.14 : index === 1 ? .11 : 0; }
      if (action === 'think' && right) curl = index === 0 ? -.12 : -1.1;
      if (action === 'gift') curl = -.38;
      approach(digit, curl, 0, spread, k);
    }));
    approach(legs[0], leftLeg, 0, 0, k); approach(legs[1], rightLeg, 0, 0, k); approach(knees[0], leftKnee, 0, 0, k); approach(knees[1], rightKnee, 0, 0, k);
    // Keep the sandal soles level while the hips and knees articulate.
    feet.forEach((foot,index)=>{foot.rotation.x=-(legs[index].rotation.x+knees[index].rotation.x);});
    headModel.update(t, dt, action, headY, headX);
    gift.visible = action === 'gift'; gift.rotation.y = reducedMotion ? 0 : Math.sin(t * 1.5) * .18;
  };
  update(0, .1);
  const dispose = () => {
    headModel.dispose();
    const materials = new Set<THREE.Material>(), textures = new Set<THREE.Texture>();
    root.traverse(object => { if (object instanceof THREE.Mesh) { object.geometry.dispose(); if (object instanceof THREE.SkinnedMesh) object.skeleton.dispose(); for (const material of Array.isArray(object.material) ? object.material : [object.material]) materials.add(material); } });
    materials.forEach(material => { for (const value of Object.values(material)) if (value instanceof THREE.Texture) textures.add(value); material.dispose(); });
    textures.forEach(texture => texture.dispose());
  };
  return { root, update, setAction, dispose };
}
