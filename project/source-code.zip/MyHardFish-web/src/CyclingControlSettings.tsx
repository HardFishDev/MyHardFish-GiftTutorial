import { useEffect, useRef, useState } from 'react';
import { X, Hand, Keyboard, ArrowsOutCardinal, SpeakerHigh, Microphone } from '@phosphor-icons/react';
import { CYCLING_CONTROL_ACTIONS, CYCLING_TOUCH_MAX_VERTICAL_OFFSET, createDefaultCyclingControls, cyclingKeyChord, cyclingKeyLabel, updateCyclingBinding } from './cycling-controls';
import type { CyclingControlAction, CyclingControlPreferences } from './cycling-controls';
import './cycling-control-settings.css';

interface Props {
  draft: CyclingControlPreferences;
  onChange: (value: CyclingControlPreferences) => void;
  onSave: () => void;
  onClose: () => void;
  onEditLayout: () => void;
  effects: boolean;
  voice: boolean;
  onEffects: () => void;
  onVoice: () => void;
}

export default function CyclingControlSettings(props: Props) {
  const { draft, onChange, onClose } = props;
  const [tab, setTab] = useState<'touch' | 'keys'>(() => matchMedia('(pointer: coarse)').matches ? 'touch' : 'keys');
  const [capture, setCapture] = useState<{ action: CyclingControlAction; slot: 0 | 1 } | null>(null);
  const [error, setError] = useState('');
  const panel = useRef<HTMLDivElement>(null);
  const latest = useRef(props); latest.current = props;
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    panel.current?.querySelector<HTMLButtonElement>('[data-close]')?.focus();
    return () => { if (previous?.isConnected) previous.focus({ preventScroll: true }); };
  }, []);
  useEffect(() => {
    const keydown = (event: KeyboardEvent) => {
      if (capture) {
        event.preventDefault(); event.stopImmediatePropagation();
        if (event.key === 'Escape') { setCapture(null); setError(''); return; }
        if (event.repeat || ['Shift', 'Control', 'Meta', 'Alt'].includes(event.key)) return;
        const chord = cyclingKeyChord(event);
        if (!chord) { setError('这个按键需要留给浏览器或输入框，请换一个按键。'); return; }
        const result = updateCyclingBinding(latest.current.draft.bindings, capture.action, capture.slot, chord);
        if (!result.ok) { setError(result.error); return; }
        latest.current.onChange({ ...latest.current.draft, bindings: result.bindings });
        setCapture(null); setError(''); return;
      }
      if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); latest.current.onClose(); }
      if (event.key === 'Tab') {
        const focusable = [...(panel.current?.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),[tabindex="0"]') ?? [])];
        const first = focusable[0], last = focusable.at(-1);
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
    };
    window.addEventListener('keydown', keydown, true);
    return () => window.removeEventListener('keydown', keydown, true);
  }, [capture]);
  const touch = draft.touch;
  const setTouch = (value: Partial<typeof touch>) => onChange({ ...draft, touch: { ...touch, ...value } });
  return <div className="cycling-settings-backdrop" onPointerDown={event => event.stopPropagation()}>
    <div className="cycling-settings-panel" role="dialog" aria-modal="true" aria-labelledby="cycling-settings-title" ref={panel}>
      <header><div><small>找到顺手的骑法</small><h2 id="cycling-settings-title">骑行操作设置</h2></div><button data-close aria-label="关闭操作设置" onClick={onClose}><X size={22} /></button></header>
      <div className="cycling-settings-tabs" role="tablist" aria-label="操作设置类别">
        <button role="tab" aria-selected={tab === 'touch'} onClick={() => { setTab('touch'); setCapture(null); setError(''); }}><Hand size={18} />触屏布局</button>
        <button role="tab" aria-selected={tab === 'keys'} onClick={() => { setTab('keys'); setCapture(null); setError(''); }}><Keyboard size={18} />键盘键位</button>
      </div>
      <div className="cycling-settings-content">
        {tab === 'touch' ? <>
          <p className="cycling-settings-note">左右变道，长按减速。松开减速键即可恢复车速。横屏和竖屏分别记住按钮位置。</p>
          <fieldset><legend>惯用手</legend><div className="cycling-setting-options">{(['right', 'left'] as const).map(hand => <label key={hand}><input type="radio" name="cycling-hand" checked={touch.handedness === hand} onChange={() => setTouch({ handedness: hand })} />{hand === 'right' ? '右手减速' : '左手减速'}</label>)}</div></fieldset>
          <fieldset><legend>按钮大小</legend><div className="cycling-setting-options">{(['normal', 'large'] as const).map(size => <label key={size}><input type="radio" name="cycling-size" checked={touch.size === size} onChange={() => setTouch({ size })} />{size === 'normal' ? '标准按钮' : '大号按钮'}</label>)}</div></fieldset>
          <label className="cycling-lift-setting"><span>按钮上移 <output>{Math.round(touch.verticalOffset)} px</output></span><input aria-label="按钮上移" type="range" min="0" max={CYCLING_TOUCH_MAX_VERTICAL_OFFSET} step="4" value={touch.verticalOffset} onChange={event => setTouch({ verticalOffset: Number(event.target.value) })} /></label>
          <button className="cycling-layout-edit" onClick={props.onEditLayout}><ArrowsOutCardinal size={21} /><span>拖动调整位置<small>把方向、减速和工具按钮移到顺手的位置</small></span></button>
        </> : <>
          <p className="cycling-settings-note">点选主键或备用键，再按下新按键。支持 Shift 组合；同一按键只能对应一个操作。</p>
          <div className="cycling-key-head"><span>操作</span><span>主键</span><span>备用键</span></div>
          <div className="cycling-key-list">{CYCLING_CONTROL_ACTIONS.map(action => <div className="cycling-key-row" key={action.id}><span>{action.label}</span>{([0, 1] as const).map(slot => <button key={slot} aria-label={`修改${action.label}${slot === 0 ? '主键' : '备用键'}`} className={capture?.action === action.id && capture.slot === slot ? 'is-capturing' : ''} onClick={() => { setCapture({ action: action.id, slot }); setError(''); }}>{capture?.action === action.id && capture.slot === slot ? '请按键…' : cyclingKeyLabel(draft.bindings[action.id][slot])}</button>)}</div>)}</div>
          {capture && <p className="cycling-capture-status" role="status">按下新的按键，Esc 取消<button onClick={() => { setCapture(null); setError(''); }}>取消录入</button></p>}
        </>}
        {error && <p className="cycling-setting-error" role="alert">{error}</p>}
        <fieldset className="cycling-setting-sounds"><legend>声音 <small>开关立即生效</small></legend><button aria-label="骑行音效" aria-pressed={props.effects} onClick={props.onEffects}><SpeakerHigh size={18} />音效 {props.effects ? '开' : '关'}</button><button aria-label="骑行语音" aria-pressed={props.voice} onClick={props.onVoice}><Microphone size={18} />语音 {props.voice ? '开' : '关'}</button></fieldset>
      </div>
      <footer><button className="cycling-settings-reset" onClick={() => { onChange(createDefaultCyclingControls()); setCapture(null); setError(''); }}>恢复默认</button><button onClick={onClose}>取消</button><button className="primary" disabled={!!capture} onClick={props.onSave}>保存设置</button></footer>
    </div>
  </div>;
}
