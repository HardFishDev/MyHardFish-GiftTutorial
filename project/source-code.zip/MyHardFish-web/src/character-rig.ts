import * as THREE from 'three';
import { ACTIVITY_KINDS } from './character-activity';
import type { CharacterActivityKind } from './character-activity';

/** A cubic limb with fixed buffers. Posing changes vertex values, never geometry. */
export class CurvedLimb extends THREE.Mesh<THREE.BufferGeometry,THREE.Material> {
  readonly controls=[new THREE.Vector3(),new THREE.Vector3(),new THREE.Vector3(),new THREE.Vector3()];
  private readonly points:Float32Array;
  private readonly normals:Float32Array;
  private readonly segments:number;
  private readonly sides:number;
  private readonly tangent=new THREE.Vector3();
  private readonly normal=new THREE.Vector3();
  private readonly binormal=new THREE.Vector3();
  private readonly axis=new THREE.Vector3();
  constructor(material:THREE.Material,segments=26,sides=10) {
    const g=new THREE.BufferGeometry();super(g,material);
    this.segments=segments;this.sides=sides;
    this.points=new Float32Array((segments+1)*(sides+1)*3);this.normals=new Float32Array(this.points.length);
    g.setAttribute('position',new THREE.BufferAttribute(this.points,3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('normal',new THREE.BufferAttribute(this.normals,3).setUsage(THREE.DynamicDrawUsage));
    const indices:number[]=[];
    for(let j=0;j<segments;j++)for(let i=0;i<sides;i++) {
      const a=j*(sides+1)+i,b=a+sides+1;
      indices.push(a,a+1,b,a+1,b+1,b);
    }
    g.setIndex(indices);g.boundingSphere=new THREE.Sphere(new THREE.Vector3(),4);
    this.frustumCulled=false;this.castShadow=this.receiveShadow=true;
  }
  pose(radiusStart:number,radiusEnd:number) {
    const [a,b,c,d]=this.controls;
    for(let j=0;j<=this.segments;j++) {
      const t=j/this.segments,q=1-t,aa=q*q*q,bb=3*q*q*t,cc=3*q*t*t,dd=t*t*t;
      const x=a.x*aa+b.x*bb+c.x*cc+d.x*dd,y=a.y*aa+b.y*bb+c.y*cc+d.y*dd,z=a.z*aa+b.z*bb+c.z*cc+d.z*dd;
      this.tangent.set(3*q*q*(b.x-a.x)+6*q*t*(c.x-b.x)+3*t*t*(d.x-c.x),3*q*q*(b.y-a.y)+6*q*t*(c.y-b.y)+3*t*t*(d.y-c.y),3*q*q*(b.z-a.z)+6*q*t*(c.z-b.z)+3*t*t*(d.z-c.z)).normalize();
      this.axis.set(0,Math.abs(this.tangent.z)>.94?1:0,Math.abs(this.tangent.z)>.94?0:1);
      this.normal.crossVectors(this.tangent,this.axis).normalize();this.binormal.crossVectors(this.tangent,this.normal).normalize();
      const radius=THREE.MathUtils.lerp(radiusStart,radiusEnd,t)*(.97+.03*Math.sin(Math.PI*t));
      for(let i=0;i<=this.sides;i++) {
        const angle=i/this.sides*Math.PI*2,cs=Math.cos(angle),sn=Math.sin(angle),k=(j*(this.sides+1)+i)*3;
        const nx=this.normal.x*cs+this.binormal.x*sn,ny=this.normal.y*cs+this.binormal.y*sn,nz=this.normal.z*cs+this.binormal.z*sn;
        this.points[k]=x+nx*radius;this.points[k+1]=y+ny*radius;this.points[k+2]=z+nz*radius;
        this.normals[k]=nx;this.normals[k+1]=ny;this.normals[k+2]=nz;
      }
    }
    this.geometry.getAttribute('position').needsUpdate=true;this.geometry.getAttribute('normal').needsUpdate=true;
  }
}

export type CharacterMotion='idle'|'walk'|'happy'|'angry'|'eat'|'sleep'|'dance'|CharacterActivityKind;
export const MOTIONS:CharacterMotion[]=['idle','walk','happy','angry','eat','sleep','dance',...ACTIVITY_KINDS.filter(kind=>kind!=='eat')];
export function characterMotion(value:string):CharacterMotion {return MOTIONS.includes(value as CharacterMotion)?value as CharacterMotion:'idle';}

/** Smooth clip weights and a locomotion clock independent of absolute elapsed time. */
export class MotionBlend {
  readonly weights=Object.fromEntries(MOTIONS.map(name=>[name,name==='idle'?1:0])) as Record<CharacterMotion,number>;
  motion:CharacterMotion='idle';
  localTime=0;
  readonly times=Object.fromEntries(MOTIONS.map(name=>[name,0])) as Record<CharacterMotion,number>;
  walkPhase=0;
  breathingTime=0;
  private pending:CharacterMotion|null=null;
  start(value:string){this.pending=characterMotion(value);}
  update(delta:number,value:string,walking:boolean) {
    const dt=THREE.MathUtils.clamp(Number.isFinite(delta)?delta:0,0,.25);
    const next=walking?'walk':characterMotion(value);
    if(next!==this.motion||this.pending===next){this.motion=next;this.times[next]=0;}
    this.pending=null;this.breathingTime+=dt;
    const ease=1-Math.exp(-dt*8.5);
    for(const key of MOTIONS){
      this.weights[key]+=((key===next?1:0)-this.weights[key])*ease;
      // Outgoing clips keep their phase during the cross-fade; only a restarted
      // incoming clip resets. A new mood cannot snap the previous hand pose.
      if(this.weights[key]>.0001||key===next)this.times[key]+=dt;
    }
    this.localTime=this.times[next];
    this.walkPhase+=dt*9.2*this.weights.walk;
    return dt;
  }
}
