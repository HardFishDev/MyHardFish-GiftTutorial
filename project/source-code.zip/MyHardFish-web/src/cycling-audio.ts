import { cyclingAudioUrl, type CyclingAudioId } from './cycling-assets';

export interface CyclingAudioSettings {
  effects: boolean;
  voice: boolean;
  volume: number;
}

type PickupKind = 'cover' | 'bottle' | 'parcel';
type ObstacleKind = 'hole' | 'barrier';
type ActiveClip = { id: CyclingAudioId; gain: GainNode };
const VOICE_CHANCE = 0.38;
const VOICE_GAP_MS = 8500;
const EFFECT_GAP_MS = 55;
const volume = (value: number) => Number.isFinite(value) ? Math.max(0, Math.min(1, value)) : 0.7;

/** A small, isolated file-based sound bank. It never imports the town's sounds,
 * speech synthesis, music, quote catalog or save engine. Browser gesture unlock
 * resumes one context; later pickups play decoded MP3 buffers on that context.
 */
export class CyclingAudio {
  readonly ready: Promise<void>;
  private settings: CyclingAudioSettings;
  private context: AudioContext | null = null;
  private readonly buffers = new Map<CyclingAudioId, AudioBuffer>();
  private readonly active = new Map<AudioBufferSourceNode, ActiveClip>();
  private readonly requests = new AbortController();
  private voiceSource: AudioBufferSourceNode | null = null;
  private disposed = false;
  private paused = true;
  private lastVoice = -Infinity;
  private lastEffect = -Infinity;

  constructor(settings: CyclingAudioSettings) {
    this.settings = { ...settings, volume: volume(settings.volume) };
    document.addEventListener('visibilitychange', this.onVisibility);
    window.addEventListener('pagehide', this.pause);
    this.ready = this.prepare();
  }

  private async prepare(): Promise<void> {
    const Constructor = window.AudioContext ||
      (window as Window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Constructor) return;
    try { this.context = new Constructor(); } catch { return; }
    const context = this.context;
    const ids: CyclingAudioId[] = ['pickupMetal', 'pickupChime', 'hit', 'pickupVoice'];
    await Promise.all(ids.map(async id => {
      try {
        const response = await fetch(cyclingAudioUrl(id), {
          cache: 'force-cache', signal: this.requests.signal,
        });
        if (!response.ok) return;
        const buffer = await context.decodeAudioData(await response.arrayBuffer());
        if (!this.disposed && buffer.duration > 0) this.buffers.set(id, buffer);
      } catch {
        // Missing/unsupported audio must never block steering or a completed ride.
      }
    }));
  }

  /** Call synchronously inside start/continue or another explicit user gesture. */
  unlock(): void {
    if (this.disposed || document.hidden) return;
    this.paused = false;
    const context = this.context;
    if (context && context.state !== 'running' && context.state !== 'closed') {
      void context.resume().catch(() => {});
    }
  }

  setEnabled(settings: CyclingAudioSettings): void {
    this.settings = { ...settings, volume: volume(settings.volume) };
    for (const [source, clip] of this.active) {
      if (!(clip.id === 'pickupVoice' ? settings.voice : settings.effects) || !this.settings.volume) {
        this.stop(source);
      } else clip.gain.gain.value = this.level(clip.id);
    }
  }

  pickup(kind: PickupKind): void {
    this.effect(kind === 'cover' ? 'pickupMetal' : 'pickupChime');
    const now = performance.now();
    if (kind !== 'cover' || !this.settings.voice || this.voiceSource || now - this.lastVoice < VOICE_GAP_MS
        || !this.canPlay('pickupVoice') || Math.random() >= VOICE_CHANCE) return;
    // There is one voice slot and no queue: rapid covers never stack phrases.
    const source = this.play('pickupVoice');
    if (source) {
      this.voiceSource = source;
      this.lastVoice = now;
    }
  }

  hit(_kind: ObstacleKind): void {
    this.effect('hit');
  }

  private effect(id: Exclude<CyclingAudioId, 'pickupVoice'>): void {
    if (!this.settings.effects || !this.canPlay(id)) return;
    const now = performance.now();
    if (id !== 'hit' && now - this.lastEffect < EFFECT_GAP_MS) return;
    // A hit stays audible even in a dense pickup row, without a large sound pile.
    if (id === 'hit') {
      for (const [source, clip] of this.active) if (clip.id !== 'pickupVoice') this.stop(source);
    } else if ([...this.active.values()].filter(clip => clip.id !== 'pickupVoice').length >= 4) return;
    if (this.play(id)) this.lastEffect = now;
  }

  private canPlay(id: CyclingAudioId): boolean {
    return !this.disposed && !this.paused && !document.hidden && this.settings.volume > 0
      && this.context?.state === 'running' && this.buffers.has(id);
  }

  private level(id: CyclingAudioId): number {
    return this.settings.volume * (id === 'pickupVoice' ? 0.94 : 0.58);
  }

  private play(id: CyclingAudioId): AudioBufferSourceNode | null {
    if (!this.canPlay(id) || !this.context) return null;
    const source = this.context.createBufferSource();
    const gain = this.context.createGain();
    source.buffer = this.buffers.get(id)!;
    gain.gain.value = this.level(id);
    source.connect(gain);
    gain.connect(this.context.destination);
    this.active.set(source, { id, gain });
    source.onended = () => this.release(source);
    try {
      source.start();
      return source;
    } catch {
      this.release(source);
      return null;
    }
  }

  private release(source: AudioBufferSourceNode): void {
    const clip = this.active.get(source);
    if (!clip) return;
    source.onended = null;
    source.disconnect();
    clip.gain.disconnect();
    this.active.delete(source);
    if (this.voiceSource === source) this.voiceSource = null;
  }

  private stop(source: AudioBufferSourceNode): void {
    try { source.stop(); } catch { /* Already stopped or never started. */ }
    this.release(source);
  }

  pause = (): void => {
    this.paused = true;
    for (const source of this.active.keys()) this.stop(source);
    if (this.context?.state === 'running') void this.context.suspend().catch(() => {});
  };

  private onVisibility = (): void => {
    if (document.hidden) this.pause();
  };

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.requests.abort();
    this.pause();
    document.removeEventListener('visibilitychange', this.onVisibility);
    window.removeEventListener('pagehide', this.pause);
    const context = this.context;
    this.context = null;
    this.buffers.clear();
    if (context && context.state !== 'closed') void context.close().catch(() => {});
  }
}
