import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { createBodyGeometry, createFootGeometry, FORM, frontSurface, sectionPoint } from './character-form';
import { CurvedLimb, MotionBlend } from './character-rig';
import { ACTIVITY_KINDS, DEFAULT_ACTIVITY_PROP, SEAT_CONTACT, addSeatedMorph, seatedLegPoint } from './character-activity';
import type { CharacterActivityContext, CharacterActivityProp } from './character-activity';
import { ActivityArmPose } from './character-poses';
import { CharacterProps } from './character-props';
export type { CharacterActivity, CharacterActivityContext, CharacterActivityKind, CharacterActivityProp, CharacterFood } from './character-activity';

export type NanyuOutfit='classic'|'mint'|'chef'|'student'|'night';
/** Bicycle contacts in character-root metres; shared by the bike and its rider. */
export const CYCLING_RIG={saddle:[0,1.54,-.42],gripX:.58,gripY:2.28,gripZ:.96,crankY:.78,crankZ:.03,crankRadius:.29,pedalX:.50} as const;
const TAU=Math.PI*2,SKIN='#f8f7ef',INK='#101313';
const vec=(x:number,y:number,z:number)=>new THREE.Vector3(x,y,z);
// Garment patterns retain their original drafting coordinates; only this
// conversion and their group scale change. Their depth is freshly projected.
const frontZ=(x:number,y:number)=>frontSurface(x*.76,y);
function tube(points:THREE.Vector3[],radius:number,material:THREE.Material,closed=false,segments=36) {
  return new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points,closed,'centripetal'),segments,radius,7,closed),material);
}
function textileTexture() {
  const canvas=document.createElement('canvas');canvas.width=canvas.height=64;
  const ctx=canvas.getContext('2d')!;ctx.fillStyle='#aaa';ctx.fillRect(0,0,64,64);
  for(let i=0;i<64;i+=2){ctx.fillStyle=i%4?'#b7b7b7':'#c7c7c7';ctx.fillRect(i,0,1,64);ctx.fillRect(0,i,64,1);}
  const t=new THREE.CanvasTexture(canvas);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(5,5);return t;
}
type Arm={side:number;limb:CurvedLimb;shoulder:THREE.Group;wrist:THREE.Group;hand:THREE.Mesh};
type Leg={side:number;foot:THREE.Group;shin:CurvedLimb;hip:THREE.Group;ankle:THREE.Group};
type Eye={group:THREE.Group;black:THREE.Mesh;upper:THREE.Mesh;lower:THREE.Mesh};

export class NanyuCharacter {
  readonly root=new THREE.Group();
  private readonly body=new THREE.Group();
  private readonly costume=new THREE.Group();
  private readonly geometries=new Set<THREE.BufferGeometry>();
  private readonly materials=new Set<THREE.Material>();
  private readonly materialCache=new Map<string,THREE.MeshStandardMaterial>();
  private readonly costumeCache=new Map<NanyuOutfit,THREE.Object3D[]>();
  private readonly clothTexture=textileTexture();
  private readonly sphere=new THREE.SphereGeometry(1,28,20);
  private readonly blend=new MotionBlend();
  private readonly skinMaterial=new THREE.MeshPhysicalMaterial({color:SKIN,roughness:.29,metalness:0,clearcoat:.42,clearcoatRoughness:.24});
  private readonly blackMaterial=new THREE.MeshPhysicalMaterial({color:INK,roughness:.27,metalness:0,clearcoat:.5,clearcoatRoughness:.21});
  private readonly eyeMaterial=new THREE.MeshPhysicalMaterial({color:'#060909',roughness:.12,clearcoat:1,clearcoatRoughness:.08});
  private readonly skin:THREE.Mesh;
  private readonly bodyHigh:THREE.BufferGeometry;
  private bodyLow?:THREE.BufferGeometry;
  private readonly footGeometry=createFootGeometry();
  private readonly arms:Arm[]=[];
  private readonly legs:Leg[]=[];
  private readonly eyes:Eye[]=[];
  private readonly chewing=new THREE.Group();
  private readonly particles=new THREE.Group();
  private readonly scratch=new THREE.Vector3();
  private readonly cyclingInverse=new THREE.Matrix4();
  private readonly activityPose=new ActivityArmPose();
  private readonly activityProps:CharacterProps;
  private readonly seatContact=new THREE.Group();
  private readonly eatContact=new THREE.Group();
  private readonly foodGrip=new THREE.Group();
  private activity:CharacterActivityContext|null=null;
  private poseContext:CharacterActivityContext={kind:'sit'};
  private seated=0;
  private seatHeight=1.05;
  private disposed=false;
  private low=false;
  private outfit:NanyuOutfit='classic';
  private blink=0;
  private blinkAt=2.3;
  private blinkStart=-10;
  private readonly reduced=typeof matchMedia==='function'&&matchMedia('(prefers-reduced-motion: reduce)').matches;

  constructor() {
    this.root.name='难鱼 · 白瓷三视图角色';
    Object.assign(this.root.userData,{character:'nanyu',characterVersion:4,action:'pet',ready:true,reference:'three-view-porcelain',motionWeights:this.blend.weights});
    this.body.name='连续白瓷身体与四肢';this.root.add(this.body);this.body.add(this.costume,this.chewing,this.particles);this.costume.scale.x=.76;
    this.bodyHigh=addSeatedMorph(createBodyGeometry());
    this.skin=new THREE.Mesh(this.bodyHigh,this.skinMaterial);this.skin.name='连续头腹鼻唇 · 无纹理';this.skin.userData.qaRole='body';this.skin.castShadow=this.skin.receiveShadow=true;this.body.add(this.skin);
    this.geometries.add(this.bodyHigh);this.geometries.add(this.footGeometry);this.geometries.add(this.sphere);
    for(const m of [this.skinMaterial,this.blackMaterial,this.eyeMaterial])this.materials.add(m);
    this.makeFace();this.makeLimbs();this.makeParticles();
    this.seatContact.name='seat-contact';this.seatContact.userData.qaRole='seat-contact';this.seatContact.position.set(...SEAT_CONTACT);this.body.add(this.seatContact);
    this.eatContact.name='eat-contact';this.eatContact.userData.qaRole='eat-contact';this.eatContact.position.copy(this.chewing.position);this.body.add(this.eatContact);
    this.foodGrip.name='food-grip';this.foodGrip.userData.qaRole='food-grip';this.foodGrip.position.set(0,0,.055);this.arms[0].wrist.add(this.foodGrip);
    this.activityProps=new CharacterProps(this.sphere,color=>this.material(color),this.geometries);this.body.add(this.activityProps.root);
    this.root.userData.animationVersion=7;
    this.update(0,0,'idle',false);
  }
  private material(color:string,textile=false) {
    const key=`${color}/${textile}`;let m=this.materialCache.get(key);
    if(!m){m=new THREE.MeshStandardMaterial({color,roughness:textile?.92:.5,...(textile?{bumpMap:this.clothTexture,bumpScale:.007}: {})});this.materialCache.set(key,m);this.materials.add(m);}
    return m;
  }
  private ellipsoid(parent:THREE.Object3D,scale:number[],position:number[],material:THREE.Material,_segments=28) {
    const m=new THREE.Mesh(this.sphere,material);m.scale.set(scale[0],scale[1],scale[2]);m.position.set(position[0],position[1],position[2]);m.castShadow=m.receiveShadow=true;parent.add(m);this.materials.add(material);return m;
  }
  private anchor(parent:THREE.Object3D,name:string,x=0,y=0,z=0) {
    const a=new THREE.Group();a.name=name;a.userData.qaRole=name;a.position.set(x,y,z);parent.add(a);return a;
  }
  private makeFace() {
    const glint=new THREE.MeshBasicMaterial({color:'#fffdf2'});this.materials.add(glint);
    for(const side of [-1,1]) {
      const group=new THREE.Group();group.position.set(side*FORM.eyeX,FORM.eyeY,0);group.name=side<0?'right-eye':'left-eye';this.body.add(group);
      const black=this.ellipsoid(group,[.103,.063,.057],[0,0,.304],this.eyeMaterial);
      const upper=this.ellipsoid(group,[.129,.018,.037],[0,.060,.309],this.skinMaterial);
      const lower=this.ellipsoid(group,[.113,.012,.032],[0,-.054,.307],this.skinMaterial);
      this.ellipsoid(black,[.108,.15,.045],[-.27,.32,.86],glint);
      this.eyes.push({group,black,upper,lower});
    }
    const smile:THREE.Vector3[]=[];
    for(let i=0;i<=26;i++){const x=(i/26-.5)*.408,y=FORM.mouthY+.040*(x/.205)**2;smile.push(vec(x,y,frontSurface(x,y)+.012));}
    const crease=tube(smile,.0075,this.material('#827b70'),false,36);crease.name='浅笑唇线';crease.castShadow=false;this.body.add(crease);this.geometries.add(crease.geometry);
    this.chewing.name='mouth-expression';this.chewing.userData.qaRole='mouth-expression';
    this.chewing.position.set(0,FORM.mouthY,frontSurface(0,FORM.mouthY)+.003);
    this.ellipsoid(this.chewing,[.039,.018,.009],[0,0,0],this.material('#514b45'));
    this.chewing.visible=false;
  }
  private makeLimbs() {
    for(const side of [-1,1]) {
      const label=side<0?'right':'left';
      const shoulder=this.anchor(this.body,`${label}-shoulder`,side*.615,2.20,-.018);
      const cap=this.ellipsoid(shoulder,[.059,.075,.058],[0,0,0],this.blackMaterial);
      cap.name=`${label}-shoulder-cap`;
      const wrist=this.anchor(this.body,`${label}-wrist`,side*.873,1.075,.04);
      const limb=new CurvedLimb(this.blackMaterial);limb.name=`${label}-arm`;limb.userData.qaRole=limb.name;this.body.add(limb);this.geometries.add(limb.geometry);
      const hand=this.ellipsoid(wrist,[.103,.11,.102],[0,0,0],this.blackMaterial);hand.name=`${label}-hand`;hand.userData.qaRole=hand.name;
      this.arms.push({side,limb,shoulder,wrist,hand});
      const foot=new THREE.Group();foot.name=`${label}-foot`;foot.userData.qaRole=foot.name;foot.position.x=side*FORM.hipX;
      const boot=new THREE.Mesh(this.footGeometry,this.blackMaterial);boot.castShadow=boot.receiveShadow=true;boot.userData.qaRole=`${label}-boot`;foot.add(boot);this.root.add(foot);
      const ankle=this.anchor(foot,`${label}-ankle`,0,.298,-.013);
      const hip=this.anchor(this.body,`${label}-white-leg`,side*FORM.hipX,FORM.hipY,-.015);
      const shin=new CurvedLimb(this.blackMaterial,16,10);shin.name=`${label}-shin`;shin.userData.qaRole=shin.name;this.root.add(shin);this.geometries.add(shin.geometry);
      this.legs.push({side,foot,shin,hip,ankle});
    }
  }
  private makeParticles() {
    const g=new THREE.OctahedronGeometry(.045,0);this.geometries.add(g);
    const m=new THREE.MeshStandardMaterial({color:'#deb66f',emissive:'#8a692c',emissiveIntensity:.15,roughness:.65});this.materials.add(m);
    for(let i=0;i<4;i++){const p=new THREE.Mesh(g,m);p.scale.set(.6,1,.6);this.particles.add(p);}this.particles.visible=false;
  }
  private band(y0:number,y1:number,material:THREE.Material,offset=.035,wavy=0) {
    const pos:number[]=[],uv:number[]=[],index:number[]=[],cols=72,rows=8,p=new THREE.Vector3();
    for(let j=0;j<=rows;j++)for(let i=0;i<=cols;i++){
      const a=i/cols*TAU,f=j/rows,y=THREE.MathUtils.lerp(y0,y1,f)+Math.sin(a*3+f*2)*wavy;
      sectionPoint(y,a,offset,p);pos.push(p.x/.76,p.y,p.z);uv.push(i/cols*3,f);
      if(j<rows&&i<cols){const k=j*(cols+1)+i;index.push(k,k+1,k+cols+1,k+1,k+cols+2,k+cols+1);}
    }
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(index);g.computeVertexNormals();
    const m=new THREE.Mesh(g,material);m.castShadow=m.receiveShadow=true;this.costume.add(m);return m;
  }
  private frontCloth(x0: number, x1: number, y0: number, y1: number, material: THREE.Material, offset = 0.04, folds = 0.008) {
    const pos: number[] = [], uv: number[] = [], index: number[] = [];
    const cols = 24, rows = 24;
    for (let j = 0; j <= rows; j++) for (let i = 0; i <= cols; i++) {
      const u = i / cols, v = j / rows;
      const x = THREE.MathUtils.lerp(x0, x1, u), y = THREE.MathUtils.lerp(y0, y1, v);
      const z = frontZ(x, y) + offset + Math.sin(u * Math.PI * 6 + v) * folds;
      pos.push(x, y, z); uv.push(u, v);
      if (i < cols && j < rows) { const k = j * (cols + 1) + i; index.push(k, k + 1, k + cols + 1, k + 1, k + cols + 2, k + cols + 1); }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    geo.setIndex(index); geo.computeVertexNormals();
    const mesh = new THREE.Mesh(geo, material); mesh.castShadow = mesh.receiveShadow = true;
    this.costume.add(mesh); return mesh;
  }

  private stitch(points: [number, number][], color = '#e2ddbf', radius = 0.006, offset = 0.056) {
    const mesh = tube(points.map(([x, y]) => vec(x, y, frontZ(x, y) + offset)), radius, this.material(color));
    this.costume.add(mesh); return mesh;
  }

  private frontPolygon(points: [number, number][], material: THREE.Material, offset = 0.085) {
    const contour = points.map(p => new THREE.Vector2(...p));
    const triangles = THREE.ShapeUtils.triangulateShape(contour, []);
    const positions: number[] = [], uv: number[] = [];
    const steps = 12;
    const project = (a: THREE.Vector2, b: THREE.Vector2, c: THREE.Vector2, u: number, v: number) => {
      const x = a.x * (1 - u - v) + b.x * u + c.x * v;
      const y = a.y * (1 - u - v) + b.y * u + c.y * v;
      positions.push(x, y, frontZ(x, y) + offset); uv.push(x, y);
    };
    for (const tri of triangles) {
      const [a, b, c] = tri.map(i => contour[i]);
      for (let j = 0; j < steps; j++) for (let i = 0; i < steps - j; i++) {
        project(a, b, c, i / steps, j / steps);
        project(a, b, c, (i + 1) / steps, j / steps);
        project(a, b, c, i / steps, (j + 1) / steps);
        if (i + j < steps - 1) {
          project(a, b, c, (i + 1) / steps, j / steps);
          project(a, b, c, (i + 1) / steps, (j + 1) / steps);
          project(a, b, c, i / steps, (j + 1) / steps);
        }
      }
    }
    const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3)); geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); geo.computeVertexNormals();
    const mesh = new THREE.Mesh(geo, material); material.side = THREE.DoubleSide;
    this.costume.add(mesh); return mesh;
  }

  private badge(x: number, y: number, color: string, radius = 0.07, z?: number) {
    const material = new THREE.MeshStandardMaterial({ color, roughness: 0.44, metalness: 0.25 });
    return this.ellipsoid(this.costume, [radius, radius, 0.016], [x, y, z ?? frontZ(x, y) + 0.075], material, 24);
  }

  setOutfit(id: NanyuOutfit) {
    if (id === this.outfit && this.costume.children.length) return;
    this.costume.clear(); this.outfit = id;
    this.root.userData.outfit = id;
    if (this.costumeCache.has(id)) { this.costume.add(...this.costumeCache.get(id)!); return; }
    if (id === 'classic') return;
    const wrapPoint=(y:number,angle:number,offset=.04)=>{
      const point=sectionPoint(y,angle,offset);point.x/=.76;return point;
    };

    if (id === 'mint') {
      const knit = this.material('#527b6c', true), edge = this.material('#91aaa0', true);
      this.band(1.67, 1.91, knit, 0.05, 0.012);
      this.band(1.68, 1.705, edge, 0.062);
      this.band(1.885, 1.91, edge, 0.062);
      this.frontCloth(0.35, 0.61, 1.28, 1.91, knit, 0.097, 0.018);
      for (let i = 0; i < 7; i++) {
        const x = 0.37 + i * 0.036;
        const fringe = tube([vec(x, 1.29, frontZ(x, 1.29) + 0.09), vec(x + 0.006, 1.18, frontZ(x, 1.29) + 0.07)], 0.009, edge, false, 6);
        this.costume.add(fringe);
      }
      this.badge(-0.53, 1.81, '#d9b566', 0.08);
      this.stitch([[-0.553, 1.83], [-0.53, 1.785], [-0.508, 1.83]], '#5b765d', 0.009, 0.099);
    }

    if (id === 'chef') {
      const cream = this.material('#efe4c7', true), trim = this.material('#bba479', true);
      this.frontCloth(-0.59, 0.59, 1.18, 1.94, cream, 0.052, 0.012);
      this.stitch([[-0.57, 1.84], [-0.57, 1.45], [-0.57, 1.20], [0, 1.185], [0.57, 1.20], [0.57, 1.45], [0.57, 1.84]], '#ad9673', 0.008, 0.071);
      this.band(1.52, 1.60, trim, 0.025);
      this.frontCloth(-0.29, 0.29, 1.37, 1.63, cream, 0.087, 0.007);
      this.stitch([[-0.285, 1.62], [-0.285, 1.39], [0, 1.37], [0.285, 1.39], [0.285, 1.62]], '#c4b28e', 0.006, 0.109);
      this.stitch([[-0.285, 1.625], [0, 1.62], [0.285, 1.625]], '#b29d77', 0.009, 0.112);
      for (const sign of [-1, 1]) this.stitch([[sign * 0.5, 1.8], [sign * 0.65, 2.1], [sign * 0.665, 2.52]], '#cfbb94', 0.025, 0.036);
      this.costume.add(tube([
        vec(-.665,2.52,frontZ(-.665,2.52)+.036),wrapPoint(2.53,-Math.PI/2,.032),
        wrapPoint(2.51,-2.4,.032),wrapPoint(2.49,Math.PI,.032),wrapPoint(2.51,2.4,.032),
        wrapPoint(2.53,Math.PI/2,.032),vec(.665,2.52,frontZ(.665,2.52)+.036),
      ],.025,this.material('#cfbb94'),false,56));
      const hat = new THREE.Group(); hat.position.set(0.01, 3.53, -0.025); hat.rotation.z = -0.10;
      const hatMat = this.material('#f3efe4', true);
      const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.49, 0.53, 0.20, 48, 2), hatMat);
      brim.scale.z = 0.72; brim.position.y = 0.055; brim.castShadow = true; hat.add(brim);
      for (let i = 0; i < 7; i++) {
        const a = i / 7 * TAU;
        this.ellipsoid(hat, [0.235, 0.24, 0.205], [Math.cos(a) * 0.33, 0.25 + Math.sin(a) * 0.022, Math.sin(a) * 0.18], hatMat);
      }
      this.ellipsoid(hat, [0.34, 0.20, 0.22], [0, 0.34, 0], hatMat);
      this.costume.add(hat);
      this.badge(-0.37, 1.70, '#b08046', 0.045);
      // Bow is on the back, so a turn reveals a complete costume.
      for (const sign of [-1, 1]) {
        const bow = this.ellipsoid(this.costume, [0.19, 0.085, 0.04], [sign * 0.145, 1.56, sectionPoint(1.56,Math.PI,.042).z], cream);
        bow.rotation.z = sign * 0.3;
      }
    }

    if (id === 'student') {
      const navy = this.material('#394f67', true), ivory = this.material('#e8e5d7', true);
      this.band(1.33, 1.82, navy, 0.045, 0.012);
      this.band(1.32, 1.365, this.material('#61778d', true), 0.056);
      for (const sign of [-1, 1]) {
        this.frontPolygon([[sign * 0.045, 1.83], [sign * 0.49, 1.95], [sign * 0.32, 1.57]], ivory);
        this.stitch([[sign * 0.48, 1.92], [sign * 0.32, 1.59], [sign * 0.1, 1.8]], '#c2c4ba', 0.007, 0.09);
      }
      const tieMat = this.material('#a95748', true);
      this.ellipsoid(this.costume, [0.082, 0.067, 0.036], [0, 1.79, frontZ(0, 1.79) + 0.105], tieMat);
      this.frontPolygon([[-0.05, 1.77], [-0.086, 1.42], [0, 1.33], [0.086, 1.42], [0.05, 1.77]], tieMat, 0.11);
      const bagMat = this.material('#a78966', true);
      const bag = new THREE.Mesh(new RoundedBoxGeometry(1.07, 0.99, 0.43, 5, 0.13), bagMat);
      bag.position.set(0, 1.83, -0.505); bag.rotation.x = -0.06; bag.castShadow = true; this.costume.add(bag);
      const pocket = new THREE.Mesh(new RoundedBoxGeometry(0.72, 0.37, 0.065, 3, 0.075), this.material('#b89c78', true));
      pocket.position.set(0, 1.62, -0.75); this.costume.add(pocket);
      const thread = this.material('#d2ba94', true);
      this.costume.add(tube([
        vec(-0.44, 1.49, -0.735), vec(-0.44, 2.17, -0.735), vec(-0.33, 2.23, -0.745),
        vec(0.33, 2.23, -0.745), vec(0.44, 2.17, -0.735), vec(0.44, 1.49, -0.735),
      ], 0.008, thread, false, 56));
      this.costume.add(tube([vec(-0.31, 1.73, -0.792), vec(0, 1.74, -0.798), vec(0.31, 1.73, -0.792)], 0.009, this.material('#766953'), false, 28));
      const zipper = new THREE.Mesh(new THREE.TorusGeometry(0.024, 0.006, 6, 12), this.material('#d4c18c'));
      zipper.position.set(0.21, 1.708, -0.798); zipper.scale.y = 1.45; this.costume.add(zipper);
      const label = new THREE.Mesh(new RoundedBoxGeometry(0.19, 0.075, 0.012, 2, 0.012), this.material('#75624b'));
      label.position.set(0, 1.57, -0.790); this.costume.add(label);
      for (const sign of [-1, 1]) {
        const strap = tube([
          vec(sign*.38,2.24,-.36),wrapPoint(2.39,sign*2.35,.045),wrapPoint(2.47,sign*Math.PI/2,.038),
          wrapPoint(2.41,sign*.96,.048),vec(sign*.63,2.10,frontZ(sign*.63,2.10)+.044),
          vec(sign*.69,1.47,frontZ(sign*.69,1.47)+.044),vec(sign*.39,1.36,-.53),
        ], 0.029, bagMat, false, 64);
        strap.castShadow = true; this.costume.add(strap);
        this.badge(sign * 0.63, 1.65, '#c6b581', 0.035);
      }
      this.badge(-0.37, 1.59, '#acb9bd', 0.050);
    }

    if (id === 'night') {
      const lavender = this.material('#88849e', true), pale = this.material('#bfbbd0', true);
      this.band(1.26, 1.83, lavender, 0.052, 0.009);
      this.band(1.26, 1.29, pale, 0.068);
      this.stitch([[0, 1.81], [0.015, 1.53], [0.03, 1.29]], '#c7c3d8', 0.009, 0.083);
      for (const y of [1.72, 1.55, 1.38]) this.badge(0.05, y, '#d5d0d9', 0.028);
      this.frontCloth(-0.55, -0.27, 1.40, 1.59, lavender, 0.083, 0.004);
      this.stitch([[-0.54, 1.58], [-0.28, 1.58]], '#c9c3d9', 0.01, 0.095);
      const points: number[] = [], uv: number[] = [], ind: number[] = [];
      const rings = 22, sides = 48;
      for (let j = 0; j <= rings; j++) {
        const t = j / rings, r = Math.max(0.012, 0.54 * Math.pow(1 - t, 0.8));
        const x = 0.09 + 0.61 * t * t, y = 3.53 + Math.sin(t * Math.PI * 0.74) * 0.67;
        for (let i = 0; i <= sides; i++) {
          const a = i / sides * TAU;
          points.push(x + Math.cos(a) * r, y + Math.cos(a) * r * t * -0.48, -0.025 + Math.sin(a) * r * 0.69);
          uv.push(i / sides * 2, t);
          if (i < sides && j < rings) { const k = j * (sides + 1) + i; ind.push(k, k + sides + 1, k + 1, k + 1, k + sides + 1, k + sides + 2); }
        }
      }
      const geometry = new THREE.BufferGeometry(); geometry.setAttribute('position', new THREE.Float32BufferAttribute(points, 3)); geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); geometry.setIndex(ind); geometry.computeVertexNormals();
      const cap = new THREE.Mesh(geometry, lavender); cap.castShadow = true; this.costume.add(cap);
      const brim = new THREE.Mesh(new THREE.TorusGeometry(0.51, 0.055, 10, 64), pale); brim.rotation.x = Math.PI / 2; brim.scale.y = 0.69; brim.position.set(0.09, 3.55, -0.025); this.costume.add(brim);
      this.ellipsoid(this.costume, [0.105, 0.115, 0.10], [0.71, 4.00, -0.025], this.material('#eae4ce'));
      // Small sewn stars, deliberately quiet rather than a printed flat costume.
      for (const [x, y] of [[-0.38, 1.72], [0.36, 1.56], [0.46, 1.74]]) {
        const star = new THREE.Shape();
        for (let i = 0; i < 10; i++) {
          const a = Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? 0.019 : 0.040;
          const px = x + Math.cos(a) * r, py = y + Math.sin(a) * r;
          if (i === 0) star.moveTo(px, py); else star.lineTo(px, py);
        }
        star.closePath(); const sg = new THREE.ShapeGeometry(star); const sp = sg.getAttribute('position');
        for (let i = 0; i < sp.count; i++) sp.setZ(i, frontZ(sp.getX(i), sp.getY(i)) + 0.082);
        sg.computeVertexNormals(); this.costume.add(new THREE.Mesh(sg, this.material('#d7ccae')));
      }
    }
    this.costumeCache.set(id, [...this.costume.children]);
    this.costume.traverse(o => { if (o instanceof THREE.Mesh) { o.castShadow = true; o.receiveShadow = true; this.geometries.add(o.geometry); (Array.isArray(o.material)?o.material:[o.material]).forEach(m=>this.materials.add(m)); } });
  }


  setQuality(low:boolean) {
    if(this.disposed||this.low===low)return;this.low=low;
    if(low&&!this.bodyLow){this.bodyLow=addSeatedMorph(createBodyGeometry(true));this.geometries.add(this.bodyLow);}
    const stride=this.skin.morphTargetInfluences?.[0]??0;
    this.skin.geometry=low?this.bodyLow!:this.bodyHigh;this.skin.updateMorphTargets();
    this.skin.morphTargetInfluences![0]=stride;this.skin.morphTargetInfluences![1]=-stride;this.skin.morphTargetInfluences![2]=this.seated;
    this.skinMaterial.clearcoat=low?0:.42;this.blackMaterial.clearcoat=low?0:.5;
    this.skinMaterial.needsUpdate=this.blackMaterial.needsUpdate=true;
    this.activityProps.setQuality(low);this.root.userData.quality=low?'low':'high';
  }
  setActivity(context:CharacterActivityContext|null) {
    if(this.disposed)return;
    if(context&&!ACTIVITY_KINDS.includes(context.kind))return;
    this.activity=context?{...context,target:context.target?[...context.target]:undefined}:null;
    if(this.activity?.target&&!this.activity.target.every(Number.isFinite))this.activity.target=undefined;
    if(this.activity){this.poseContext=this.activity;this.blend.start(this.activity.kind);}
    else {this.blend.start('idle');this.activityProps.clear();}
    this.root.userData.activity=this.activity?.kind??null;
  }
  getActivitySnapshot() {
    this.root.updateMatrixWorld(true);
    const seat=this.seatContact.getWorldPosition(new THREE.Vector3()),mouth=this.eatContact.getWorldPosition(new THREE.Vector3());
    const right=this.arms[0].wrist.getWorldPosition(new THREE.Vector3()),left=this.arms[1].wrist.getWorldPosition(new THREE.Vector3());
    const grip=this.foodGrip.getWorldPosition(new THREE.Vector3());
    const propObject=this.activityProps.activeObject,propPosition=propObject?.getWorldPosition(new THREE.Vector3());
    const visibleProps=this.activityProps.root.children.filter(p=>p.visible&&p.userData.qaRole==='activity-prop').map(p=>({name:p.name,prop:p.userData.prop,position:p.getWorldPosition(new THREE.Vector3()).toArray()}));
    return {kind:this.activity?.kind??null,seated:this.seated,seatHeight:this.seatHeight,seatContact:seat.toArray(),mouth:mouth.toArray(),rightHand:right.toArray(),leftHand:left.toArray(),foodGrip:grip.toArray(),handToMouth:right.distanceTo(mouth),gripToMouth:grip.distanceTo(mouth),prop:this.activityProps.activeProp,propPosition:propPosition?.toArray()??null,propOriginToMouth:propPosition?.distanceTo(mouth)??null,visibleProps};
  }
  startMotion(motion:string){if(!this.activity)this.blend.start(motion);}
  /** A contact-driven seated pose: both soles track the crank, hands stay on the bar. */
  updateCycling(elapsed:number,crankPhase:number,steering=0,reaction?:{impact:number;reach:number;reachSide:number}) {
    if(this.disposed)return;
    const rig=CYCLING_RIG;
    this.activity=null;this.activityProps.clear();this.seated=1;this.seatHeight=rig.saddle[1];
    this.body.scale.setScalar(1);
    const impact=reaction?.impact??0,reach=reaction?.reach??0,reachSide=reaction?.reachSide??-1;
    this.body.rotation.set(.17-impact*.15,reach*reachSide*.055,Math.sin(crankPhase)*.008+impact*.025);
    this.scratch.set(...SEAT_CONTACT).applyEuler(this.body.rotation);
    this.body.position.set(rig.saddle[0]-this.scratch.x,rig.saddle[1]-this.scratch.y,rig.saddle[2]-this.scratch.z);
    this.body.position.y+=impact*.09;
    this.body.updateMatrix();this.cyclingInverse.copy(this.body.matrix).invert();
    this.skin.morphTargetInfluences![0]=0;this.skin.morphTargetInfluences![1]=0;this.skin.morphTargetInfluences![2]=1;
    this.chewing.visible=false;this.particles.visible=false;
    const blinkTime=elapsed%4.7,blink=blinkTime<.16?Math.sin(blinkTime/.16*Math.PI):0;
    for(const eye of this.eyes){eye.black.scale.y=.063*(1-blink*.95)*(1+impact*.18);eye.upper.position.y=.060-blink*.053+impact*.015;eye.lower.position.y=-.054+blink*.047-impact*.006;eye.group.rotation.z=0;}
    for(const arm of this.arms){
      const side=arm.side,p=arm.limb.controls;
      // The little steer angle turns both grips around the stem, exactly as the bike does.
      const turn=steering*.10,gx=side*rig.gripX*Math.cos(turn),gz=rig.gripZ-side*rig.gripX*Math.sin(turn);
      const handReach=side===reachSide?reach:0;
      p[0].copy(arm.shoulder.position);p[3].set(gx+side*handReach*.37,rig.gripY+handReach*.23+impact*.06,gz+handReach*.2).applyMatrix4(this.cyclingInverse);
      p[1].copy(p[0]).lerp(p[3],.34);p[1].x+=side*.08;
      p[2].copy(p[0]).lerp(p[3],.7);p[2].y-=.12+impact*.16;p[2].x+=side*(.09+impact*.1);
      arm.wrist.position.copy(p[3]);arm.hand.scale.set(.085,.09,.09);arm.limb.pose(.058,.034);
    }
    for(const leg of this.legs){
      const side=leg.side,angle=crankPhase+(side<0?Math.PI:0),foot=leg.foot;
      const pedalY=rig.crankY+Math.cos(angle)*rig.crankRadius,pedalZ=rig.crankZ+Math.sin(angle)*rig.crankRadius;
      foot.position.set(side*rig.pedalX,pedalY+.055,pedalZ-.12);foot.rotation.set(0,0,0);foot.updateMatrix();
      seatedLegPoint(side*FORM.hipX,FORM.hipY,-.015,leg.hip.position);
      const p=leg.shin.controls;p[0].copy(leg.hip.position).applyMatrix4(this.body.matrix);p[3].copy(leg.ankle.position).applyMatrix4(foot.matrix);
      p[1].copy(p[0]).lerp(p[3],.28);p[1].z+=.24;p[1].x+=side*.04;
      p[2].copy(p[0]).lerp(p[3],.70);p[2].z+=.18;leg.shin.pose(.084,.071);
    }
    Object.assign(this.root.userData,{motion:'cycling',action:'cycling',seated:1,cyclingPedalPhase:crankPhase,cyclingSteering:steering,cyclingImpact:impact,cyclingReach:reach,activityProp:'none'});
  }
  update(_elapsed:number,delta:number,motion:string,walking:boolean) {
    if(this.disposed)return;
    if(walking&&this.activity)this.setActivity(null);
    const dt=this.blend.update(delta,this.activity?.kind??motion,walking),w=this.blend.weights,t=this.blend.breathingTime,phase=this.blend.walkPhase;
    const h=this.blend.times.happy,a=this.blend.times.angry,e=this.blend.times.eat,d=this.blend.times.dance;
    const ease=dt>0?1-Math.exp(-dt*13):1;
    const intensity=this.reduced?.4:1;
    const breath=Math.sin(t*1.7),stride=Math.sin(phase)*w.walk*intensity;
    const wave=Math.sin(h*8.6),dance=Math.sin(d*5.8);
    this.root.userData.motion=this.blend.motion;
    const seatedTarget=!walking&&(this.activity?(this.activity.seated||this.activity.kind==='sit'):motion==='sit')?1:0;
    this.seated+=(seatedTarget-this.seated)*(dt>0?1-Math.exp(-dt*8.5):1);
    const requestedSeat=this.poseContext.seatHeight;
    const seatGoal=typeof requestedSeat==='number'&&Number.isFinite(requestedSeat)?THREE.MathUtils.clamp(requestedSeat,.4,1.6):1.05;
    this.seatHeight+=(seatGoal-this.seatHeight)*ease;
    this.body.position.set(0,.012*breath*intensity+.035*Math.abs(stride)+w.happy*.025*(1+Math.sin(h*5))+w.dance*.052*(1-Math.cos(d*5.8)),0);
    this.body.rotation.set(w.sleep*.055+w.eat*.025*Math.sin(e*6)+w.angry*.07,w.dance*.09*dance,w.walk*.023*Math.sin(phase)+w.happy*.022*Math.sin(h*4)-w.sleep*.075+w.angry*.018*Math.sin(a*19)+w.dance*.055*dance);
    this.body.scale.set(1+.003*breath+w.sleep*.018,1+.002*breath-w.sleep*.022,1+.004*breath+w.eat*.007*Math.sin(e*9));
    const activityTime=this.blend.localTime;
    this.body.rotation.x+=w.read*.055+w.write*.06+w.cook*.028+w.inspect*.035-this.seated*.026;
    this.body.rotation.y+=w.talk*Math.sin(this.blend.times.talk*1.5)*.045*intensity;
    this.body.rotation.z+=w.celebrate*Math.sin(this.blend.times.celebrate*3.8)*.035*intensity;
    this.body.position.y+=w.celebrate*.065*(1-Math.cos(this.blend.times.celebrate*4.8))*intensity;
    this.body.position.z=-this.seated*.035;
    this.body.updateMatrix();this.scratch.copy(this.seatContact.position).multiply(this.body.scale).applyEuler(this.body.rotation);
    this.body.position.y=this.body.position.y*(1-this.seated)+this.seated*(this.seatHeight-this.scratch.y);
    this.body.position.x=this.seated*(SEAT_CONTACT[0]-this.scratch.x);this.body.position.z=this.seated*(SEAT_CONTACT[2]-this.scratch.z);
    const height=this.poseContext.target?.[1]??this.poseContext.surfaceHeight??1.42;
    const workY=THREE.MathUtils.clamp((Number.isFinite(height)?height:1.42)-this.body.position.y+.18,1.12,2.25);
    const workZ=THREE.MathUtils.clamp(this.poseContext.target?.[2]??.85,.68,1.30),reachX=THREE.MathUtils.clamp(this.poseContext.target?.[0]??0,-.25,.25);
    if(t>this.blinkAt){this.blinkStart=t;this.blinkAt=t+3.1+(Math.sin(t*4.1)+1)*1.25;}
    const b=t-this.blinkStart,automatic=b>=0&&b<.19?Math.sin(b/.19*Math.PI):0;
    const blinkTarget=Math.max(w.sleep,automatic);this.blink+=(blinkTarget-this.blink)*(1-Math.exp(-dt*48));
    this.eyes.forEach((eye,index)=>{
      eye.black.scale.y=.063*(1-this.blink*.95);
      eye.upper.position.y=.060-this.blink*.053-w.angry*.007;
      eye.lower.position.y=-.054+this.blink*.047+w.happy*.004;
      eye.upper.scale.y=.018+this.blink*.010;
      eye.lower.scale.y=.012+this.blink*.009;
      eye.group.rotation.z=(index?1:-1)*w.angry*.17;
    });
    this.chewing.visible=w.eat>.03;this.chewing.scale.y=.25+w.eat*(.55+.35*Math.sin(e*11));
    for(const arm of this.arms){
      const s=arm.side,p=arm.limb.controls;const right=s<0;
      p[0].copy(arm.shoulder.position);
      let hx=s*.873,hy=1.075+w.idle*.008*Math.sin(t*1.7+s),hz=.04+stride*s*.27+w.idle*.018*Math.sin(t*1.3+s);
      let ex=s*.82,ey=1.56,ez=-.015-stride*s*.13;
      const happy=w.happy*(right?1:.24);
      hx+=happy*s*(.15+.055*wave);hy+=happy*(1.75+.11*Math.cos(h*8.6));hz+=happy*.10;
      ex+=happy*s*.25;ey+=happy*.81;ez+=happy*.06;
      hx+=w.angry*s*.10;hy+=w.angry*.72;hz+=w.angry*.15;ex+=w.angry*s*.23;ey+=w.angry*.17;
      if(right){hx+=w.eat*(.873-.18);hy+=w.eat*(1.14+.025*Math.sin(e*9));hz+=w.eat*.51;ex+=w.eat*s*.16;ey+=w.eat*.29;ez+=w.eat*.34;}
      hx-=w.sleep*s*.573;hy+=w.sleep*.245;hz+=w.sleep*.51;ex-=w.sleep*s*.15;ey-=w.sleep*.06;ez+=w.sleep*.29;
      hx+=w.dance*s*(.25+.12*Math.sin(d*5.8+s));hy+=w.dance*(.72+.44*Math.sin(d*5.8+s*.9));hz+=w.dance*.18;
      ex+=w.dance*s*.23;ey+=w.dance*.42;ez+=w.dance*.13;
      let ux=s*(.70+w.happy*(right?.12:.025)+w.angry*.12+w.dance*.13),uy=1.96+w.happy*(right?.30:.04)+w.angry*.09+w.dance*.18,uz=.005+w.eat*(right?.27:0)+w.sleep*.08;
      if(!right)ux+=s*w.eat*.08;
      for(const kind of ACTIVITY_KINDS) {
        if(kind==='eat'||w[kind]<.0001)continue;
        const weight=w[kind],pose=this.activityPose;pose.set(kind,this.blend.times[kind],s,workY,workZ,reachX,intensity);
        hx+=weight*(pose.hx-s*.873);hy+=weight*(pose.hy-1.075);hz+=weight*(pose.hz-.04);
        ex+=weight*(pose.ex-s*.82);ey+=weight*(pose.ey-1.56);ez+=weight*(pose.ez+.015);
        ux+=weight*(pose.ux-s*.70);uy+=weight*(pose.uy-1.96);uz+=weight*(pose.uz-.005);
      }
      if(right){const chew=Math.max(0,Math.sin(e*2.3));hy-=w.eat*(.22*(1-chew));hz+=w.eat*.06*(1-chew);}
      this.scratch.set(ux,uy,uz);p[1].lerp(this.scratch,ease);
      this.scratch.set(ex,ey,ez);p[2].lerp(this.scratch,ease);this.scratch.set(hx,hy,hz);p[3].lerp(this.scratch,ease);arm.wrist.position.copy(p[3]);arm.limb.pose(.058,.029);
      arm.hand.scale.setScalar(1);arm.hand.scale.set(.103*(1+w.angry*.12),.11*(1+w.angry*.12),.102);
    }
    this.skin.morphTargetInfluences![0]=stride*(1-this.seated);this.skin.morphTargetInfluences![1]=-stride*(1-this.seated);this.skin.morphTargetInfluences![2]=this.seated;
    const prop:CharacterActivityProp=this.activity?.prop??(this.activity?DEFAULT_ACTIVITY_PROP[this.activity.kind]:w.eat>.03&&this.blend.motion==='eat'?'food':'none');
    const propAmount=this.activity?w[this.activity.kind]:w.eat;
    this.activityProps.update(prop,this.activity?.food??'bun',activityTime,this.arms[0].wrist.position,this.arms[1].wrist.position,propAmount,this.reduced);
    const held=this.activityProps.activeObject;
    if(held&&(prop==='food'||prop==='cup'))this.foodGrip.position.copy(held.position).sub(this.arms[0].wrist.position);
    else this.foodGrip.position.set(0,0,.055);
    this.root.userData.activityProp=this.activityProps.activeProp;this.root.userData.seated=this.seated;
    this.body.updateMatrix();
    for(const leg of this.legs){
      const s=leg.side,legStride=stride*s,foot=leg.foot;
      foot.position.set(s*FORM.hipX+w.dance*s*.07*(1+Math.sin(d*5.8)),0,legStride*.24+this.seated*.77);
      foot.rotation.set(-legStride*.20, s*.10+w.dance*.09*Math.sin(d*5.8+s),w.dance*s*.07*Math.sin(d*5.8+s));
      foot.updateMatrix();
      let minY=Infinity;const points=this.footGeometry.getAttribute('position');
      for(let i=0;i<points.count;i++){this.scratch.fromBufferAttribute(points,i).applyMatrix4(foot.matrix);minY=Math.min(minY,this.scratch.y);}
      const lift=(Math.max(0,Math.sin(phase+s*Math.PI/2))*.13*w.walk*intensity+w.dance*Math.max(0,Math.sin(d*5.8+s*Math.PI/2))*.095+w.celebrate*Math.max(0,Math.sin(this.blend.times.celebrate*4.8))*.11*intensity)*(1-this.seated);
      foot.position.y=lift-minY;foot.updateMatrix();
      leg.hip.position.set(s*FORM.hipX,FORM.hipY,-.015+legStride*.245);
      seatedLegPoint(s*FORM.hipX,FORM.hipY,-.015,this.scratch);leg.hip.position.lerp(this.scratch,this.seated);
      const p=leg.shin.controls;p[0].copy(leg.hip.position).applyMatrix4(this.body.matrix);p[3].copy(leg.ankle.position).applyMatrix4(foot.matrix);
      p[1].copy(p[0]).lerp(p[3],.35);p[2].copy(p[0]).lerp(p[3],.75);p[1].x+=s*.013;p[1].z+=this.seated*.17;p[2].z-=.015+this.seated*.055;leg.shin.pose(.084,.071);
    }
    this.particles.visible=!this.low&&!this.reduced&&(w.dance>.2||w.celebrate>.2);
    this.particles.children.forEach((p,i)=>{const a=t*.7+i*TAU/4;p.position.set(Math.cos(a)*1.02,2.8+Math.sin(t*2+i)*.2,Math.sin(a)*.4);p.rotation.set(t*.5,t+i,0);});
  }
  dispose() {
    if(this.disposed)return;this.disposed=true;
    this.activity=null;this.activityProps.clear();
    this.root.traverse(o=>{if(o instanceof THREE.Mesh){this.geometries.add(o.geometry);(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>this.materials.add(m));}});
    for(const g of this.geometries)g.dispose();for(const m of this.materials)m.dispose();this.clothTexture.dispose();this.costumeCache.clear();this.root.clear();
  }
}
