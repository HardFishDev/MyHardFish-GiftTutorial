import { useEffect, useRef, useState } from "react";
import {
  ArrowClockwise,
  Check,
  FishSimple,
  Flame,
  Waves,
} from "@phosphor-icons/react";
import type { GameKind } from "./engine";
import FieldGames from "./FieldGames";
import CyclingEntry from './CyclingEntry';
import type { CyclingDifficulty } from './cycling';
import type { NanyuOutfit } from './character';

const shuffle = <T,>(a: T[]) => {
  const r = [...a];
  for (let i = r.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [r[i], r[j]] = [r[j], r[i]];
  }
  return r;
};
const titles = { bottle: "漂流瓶记忆", cook: "火候刚刚好", math: "五题就下课" };
const descriptions = {
  bottle:
    "12 个漂流瓶，藏着 6 对难鱼原话。翻开两个相同的瓶子即可配对，12 次机会，看你能找到几对。",
  cook: "指针会来回移动。在绿色区域按下「出锅」，三轮中每成功一次就多赚贝壳，还能带走蛋炒饭。支持空格键。",
  math: "五道口算，没有倒计时。答错也可以继续，难鱼会陪你一起看答案。满分会解锁特别成就。",
};
function questions() {
  return Array.from({ length: 5 }, (_, i) => {
    const a = 2 + Math.floor(Math.random() * 8),
      b = 2 + Math.floor(Math.random() * 8);
    const answer = i % 3 === 0 ? a + b : i % 3 === 1 ? a * b : a + b - b;
    return {
      text:
        i % 3 === 0
          ? `${a} + ${b}`
          : i % 3 === 1
            ? `${a} × ${b}`
            : `${a + b} − ${b}`,
      answer,
      options: shuffle([
        answer,
        answer + 2,
        answer + 1,
        Math.max(0, answer - 2),
      ]),
    };
  });
}
export default function MiniGame(props: {
  kind: GameKind;
  onStart: (difficulty?: CyclingDifficulty) => boolean;
  onFinish: (score: number) => void;
  onInteraction?: () => void;
  lowQuality?: boolean;
  outfit?: NanyuOutfit;
  voiceEnabled?: boolean;
  voiceVolume?: number;
  effectsEnabled?: boolean;
  onExit?: () => void;
}) {
  if (props.kind === 'cycling') return <CyclingEntry {...props} />;
  if (props.kind === "words" || props.kind === "harvest")
    return <FieldGames {...props} kind={props.kind} />;
  return <ClassicMiniGame {...props} kind={props.kind} />;
}

function ClassicMiniGame({
  kind,
  onStart,
  onFinish,
  onInteraction,
}: {
  kind: "bottle" | "cook" | "math";
  onStart: () => boolean;
  onFinish: (score: number) => void;
  onInteraction?: () => void;
}) {
  const [phase, setPhase] = useState<"intro" | "play" | "done">("intro");
  const [score, setScore] = useState(0);
  const [round, setRound] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [cards, setCards] = useState<string[]>([]);
  const [open, setOpen] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [turns, setTurns] = useState(0);
  const [quiz, setQuiz] = useState(questions);
  const [answered, setAnswered] = useState<number | null>(null);
  const claimed = useRef(false),
    locked = useRef(false);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const needle = useRef<HTMLDivElement>(null),
    position = useRef(0),
    cookStart = useRef(0);
  const finishRef = useRef(onFinish);
  finishRef.current = onFinish;
  useEffect(() => () => clearTimeout(timer.current), []);
  function finish(result: number) {
    if (claimed.current) return;
    claimed.current = true;
    setScore(result);
    setPhase("done");
    finishRef.current(result);
  }
  function start() {
    if (!onStart()) return;
    claimed.current = false;
    locked.current = false;
    setScore(0);
    setRound(0);
    setFeedback("");
    setOpen([]);
    setMatched([]);
    setTurns(0);
    setCards(
      shuffle(
        ["6", "喵", "已阅", "寒心", "多谢", "好好好"].flatMap((t) => [t, t]),
      ),
    );
    setQuiz(questions());
    setAnswered(null);
    cookStart.current = performance.now();
    setPhase("play");
  }
  useEffect(() => {
    if (phase !== "play" || kind !== "cook") return;
    let frame = 0;
    const move = (time: number) => {
      position.current = (1 - Math.cos((time - cookStart.current) / 520)) * 50;
      if (needle.current) needle.current.style.left = `${position.current}%`;
      frame = requestAnimationFrame(move);
    };
    frame = requestAnimationFrame(move);
    return () => cancelAnimationFrame(frame);
  }, [phase, kind]);
  const cookRef = useRef<() => void>(() => {});
  cookRef.current = () => {
    if (phase !== "play" || kind !== "cook" || locked.current) return;
    onInteraction?.();
    locked.current = true;
    const hit = position.current >= 36 && position.current <= 64;
    const nextScore = score + (hit ? 1 : 0);
    setScore(nextScore);
    setFeedback(
      hit
        ? "火候刚刚好！这锅香了。"
        : position.current < 36
          ? "早了点，再等它热一会儿。"
          : "火有点大，下次早点出锅。",
    );
    setRound(round + 1);
    timer.current = setTimeout(() => {
      if (round >= 2) finish(nextScore);
      else {
        locked.current = false;
        setFeedback("");
        cookStart.current = performance.now();
      }
    }, 1000);
  };
  useEffect(() => {
    if (kind !== "cook" || phase !== "play") return;
    const key = (e: KeyboardEvent) => {
      if (e.code === "Space" && e.target === document.body) {
        e.preventDefault();
        cookRef.current();
      }
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [kind, phase]);
  function flip(index: number) {
    if (locked.current || open.includes(index) || matched.includes(index))
      return;
    onInteraction?.();
    if (open.length === 0) {
      setOpen([index]);
      return;
    }
    locked.current = true;
    const first = open[0];
    setOpen([first, index]);
    const match = cards[first] === cards[index];
    const nextScore = score + (match ? 1 : 0);
    const moves = turns + 1;
    setTurns(moves);
    timer.current = setTimeout(
      () => {
        if (match) {
          setMatched((m) => [...m, first, index]);
          setScore(nextScore);
        }
        setOpen([]);
        locked.current = false;
        if (nextScore === 6 || moves >= 12) finish(nextScore);
      },
      match ? 360 : 850,
    );
  }
  return (
    <div className={`mini-game mini-${kind}`}>
      <div className="mini-emblem">
        {kind === "bottle" ? (
          <Waves size={36} />
        ) : kind === "cook" ? (
          <Flame size={36} />
        ) : (
          <span>½</span>
        )}
      </div>
      <h3>{titles[kind]}</h3>
      {phase === "intro" && (
        <>
          <p>{descriptions[kind]}</p>
          <div className="game-facts">
            <span>消耗 8 精力</span>
            <span>保底 8 贝壳</span>
            <span>完成增加熟悉度</span>
          </div>
          <button className="primary wide" onClick={start}>
            和难鱼一起开始
          </button>
        </>
      )}
      {phase === "play" && kind === "bottle" && (
        <>
          <div className="game-progress">
            <span>找到 {score} / 6 对</span>
            <span>剩余 {12 - turns} 次</span>
          </div>
          <div className="bottle-grid">
            {cards.map((text, i) => (
              <button
                key={i}
                className={`bottle ${open.includes(i) ? "flipped" : ""} ${matched.includes(i) ? "matched" : ""}`}
                aria-label={`漂流瓶 ${i + 1}${open.includes(i) || matched.includes(i) ? ` ${text}` : ""}`}
                aria-pressed={open.includes(i) || matched.includes(i)}
                disabled={matched.includes(i)}
                onClick={() => flip(i)}
              >
                {open.includes(i) || matched.includes(i) ? (
                  text
                ) : (
                  <>
                    <FishSimple size={25} />
                    <small>{String(i + 1).padStart(2, "0")}</small>
                  </>
                )}
              </button>
            ))}
          </div>
        </>
      )}
      {phase === "play" && kind === "cook" && (
        <>
          <div className="game-progress">
            <span>第 {Math.min(round + 1, 3)} / 3 锅</span>
            <span>成功 {score} 次</span>
          </div>
          <div className="pot-art">
            <Flame size={64} weight="duotone" />
          </div>
          <div className="heat-track">
            <div className="heat-zone" />
            <div className="heat-needle" ref={needle} />
          </div>
          <div className="heat-labels">
            <span>还没熟</span>
            <b>刚刚好</b>
            <span>要糊了</span>
          </div>
          <button
            className="primary wide"
            onClick={() => cookRef.current()}
            disabled={!!feedback}
          >
            出锅！
          </button>
          <p className="game-feedback" aria-live="polite">
            {feedback || "绿色区域出锅 · 点击按钮或按空格"}
          </p>
        </>
      )}
      {phase === "play" && kind === "math" && (
        <>
          <div className="game-progress">
            <span>第 {round + 1} / 5 题</span>
            <span>答对 {score} 题</span>
          </div>
          <div className="math-board">{quiz[round].text} = ?</div>
          <div className="math-options">
            {quiz[round].options.map((answer) => (
              <button
                key={answer}
                disabled={answered !== null}
                className={
                  answered !== null && answer === quiz[round].answer
                    ? "correct"
                    : answered === answer
                      ? "incorrect"
                      : ""
                }
                onClick={() => {
                  if (answered !== null) return;
                  onInteraction?.();
                  setAnswered(answer);
                  if (answer === quiz[round].answer) setScore((s) => s + 1);
                }}
              >
                {answer}
                {answered !== null && answer === quiz[round].answer && (
                  <Check size={20} />
                )}
              </button>
            ))}
          </div>
          {answered !== null && (
            <>
              <p className="game-feedback" aria-live="polite">
                {answered === quiz[round].answer
                  ? "赢了！下一题也不过如此。"
                  : `这题等于 ${quiz[round].answer}。没事，接着来。`}
              </p>
              <button
                className="primary wide"
                onClick={() => {
                  if (round === 4) finish(score);
                  else {
                    setRound((r) => r + 1);
                    setAnswered(null);
                  }
                }}
              >
                {round === 4 ? "交卷，下课！" : "下一题"}
              </button>
            </>
          )}
        </>
      )}
      {phase === "done" && (
        <div className="game-result">
          <span className="result-number">
            {score}
            <small> / {kind === "bottle" ? 6 : kind === "cook" ? 3 : 5}</small>
          </span>
          <h4>
            {score === 0
              ? "先熟悉一下，下次赢回来"
              : score === (kind === "bottle" ? 6 : kind === "cook" ? 3 : 5)
                ? "赢了。难鱼宣布是她带飞的。"
                : "还不错，下次再一起玩。"}
          </h4>
          <p>
            +{8 + score * 5} 贝壳 · +{3 + score} 熟悉度
            {kind === "cook" ? ` · 蛋炒饭 ×${score >= 2 ? 2 : 1}` : ""}
          </p>
          <button className="secondary" onClick={start}>
            <ArrowClockwise size={18} />
            再玩一局 · 8 精力
          </button>
          <small>奖励已放进背包，可以关闭窗口继续逛逛。</small>
        </div>
      )}
    </div>
  );
}
