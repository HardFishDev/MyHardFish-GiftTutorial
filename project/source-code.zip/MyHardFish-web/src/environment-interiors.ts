import * as THREE from 'three';
import type { EnvironmentBuilder } from './environment';

function bottle(b:EnvironmentBuilder,x:number,y:number,z:number,color:string,scale=1,parent:THREE.Object3D=b.root) {
  b.cylinder(.095*scale,.10*scale,.38*scale,[x,y+.19*scale,z],color,parent);
  b.cylinder(.037*scale,.063*scale,.16*scale,[x,y+.45*scale,z],color,parent);
  b.cylinder(.043*scale,.043*scale,.05*scale,[x,y+.55*scale,z],'#ddd4b8',parent);
  b.cylinder(.1005*scale,.1005*scale,.15*scale,[x,y+.21*scale,z],'#efe2bd',parent);
}
function pendant(b:EnvironmentBuilder,x:number,z:number,y=4.4) {
  const fixture=b.occluder(`pendant:${x}:${z}`);
  b.cylinder(.022,.022,1.1,[x,y+.7,z],'#776953',fixture);
  b.cylinder(.20,.51,.48,[x,y,z],'#b79a6e',fixture);
  const glow=b.cylinder(.46,.46,.025,[x,y-.25,z],'#ffdfac',fixture);
  glow.material=new THREE.MeshBasicMaterial({color:'#ffe4b3'});
}
function chair(b:EnvironmentBuilder,x:number,z:number,rotation=0) {
  const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=rotation;b.root.add(g);
  b.surface([.82,.11,.82],[0,.77,0],'#b79973','wood',.05,g);
  for(const xx of [-.3,.3])for(const zz of [-.3,.3])b.surface([.07,.76,.07],[xx,.39,zz],'#8b7657','wood',.015,g);
  b.surface([.79,.52,.10],[0,1.20,-.34],'#c4a47c','wood',.04,g);
  b.obstacle(x,z,.9,.9);
  const side=x<5.3?-1:1;b.seat(`kitchen-chair:${x}:${z}`,[0,.825,.12],[side*Math.cos(rotation)*1.7,0,-.65],{parent:g,width:.82,depth:.82,surface:[0,1.34,1.55],target:[0,1.42,1.55]});
}

export function buildKitchen(b:EnvironmentBuilder) {
  // The counters occupy the rear wall; a broad central route stays clear.
  b.window(-1.1,-10.76,6.2,3.4,3.85);
  b.surface([16.9,1.02,.055],[-.7,1.95,-10.72],'#dde1cd','tile',0);
  b.surface([17,1.22,1.6],[-.65,.64,-9.65],'#879980','wood',.06);
  b.surface([17.2,.14,1.82],[-.65,1.33,-9.62],'#f3e9d3','stone',.04);
  b.surface([17.05,.12,.07],[-.65,.12,-8.82],'#62755e','wood',.015);
  for(let i=0;i<12;i++) {
    const x=-8.36+i*1.40;
    b.surface([1.30,1.06,.055],[x,.71,-8.825],'#a4b296','wood',.035);
    b.surface([1.10,.06,.033],[x,1.06,-8.782],'#7f9076','wood',.015);
    b.surface([.36,.034,.065],[x,.97,-8.746],'#bbaa80','metal',.01);
  }
  b.obstacle(-.65,-9.65,17.25,1.95);
  // Sink, curved tap, draining board, dishes and a small herb garden.
  b.surface([2.1,.05,1.14],[-1.45,1.415,-9.63],'#9daaa0','metal',.10);
  b.surface([1.42,.055,.85],[-1.66,1.443,-9.63],'#657971','metal',.13);
  b.surface([1.18,.055,.66],[-1.66,1.46,-9.63],'#c1ccc1','metal',.10);
  const tap=b.torus(.25,.026,[-1.65,1.90,-10.19],'#9ba89c');tap.rotation.y=Math.PI/2;
  b.cylinder(.034,.034,.32,[-1.65,1.59,-10.44],'#aab4a8');
  for(let i=0;i<6;i++)b.surface([.025,.035,.65],[-.71+i*.105,1.46,-9.64],'#d3d8c8','metal',.009);
  for(let i=0;i<4;i++){const p=b.cylinder(.21,.19,.038,[.55,1.43+i*.037,-9.51],'#ece5d0');p.material=b.material('#ece5d0','stone');}
  b.cup(.96,1.42,-9.58,'#ba9277');b.plant(-2.8,-10.24,.37).position.y=1.41;
  bottle(b,-.18,1.40,-10.11,'#8eb09e',.75);
  // A real stove and oven: four separate trivets, knobs and a lit oven window.
  b.surface([2.85,.08,1.3],[-6.60,1.44,-9.57],'#4b5750','metal',.04);
  for(const dx of [-.66,.66])for(const dz of [-.31,.31]){
    b.cylinder(.28,.28,.026,[-6.60+dx,1.49,-9.57+dz],'#242c28');
    const ring=b.torus(.19,.022,[-6.60+dx,1.515,-9.57+dz],'#78897b');ring.rotation.x=Math.PI/2;
    for(const a of [0,Math.PI/2]){const bar=b.surface([.63,.033,.037],[-6.60+dx,1.54,-9.57+dz],'#313d34','metal',.008);bar.rotation.y=a;}
  }
  b.surface([2.55,1.11,.08],[-6.6,.73,-8.74],'#c7cbb7','metal',.04);
  b.surface([2.07,.62,.055],[-6.6,.62,-8.674],'#344238','metal',.07);
  b.surface([1.80,.40,.021],[-6.6,.59,-8.637],'#746649','plaster',.04);
  b.surface([1.86,.056,.10],[-6.6,.985,-8.58],'#a1a794','metal',.02);
  for(let i=0;i<5;i++)b.cylinder(.066,.066,.047,[-7.42+i*.41,1.17,-8.64],'#e7e0cb').rotation.x=Math.PI/2;
  b.surface([3.2,.20,1.55],[-6.6,3.33,-9.91],'#b7c1b0','metal',.08);
  b.mesh(new THREE.ConeGeometry(1,1.0,4),[-6.6,3.83,-10.0],'#c7cebc','metal').scale.set(1.5,1,.72);
  b.surface([.72,1.21,.65],[-6.6,4.64,-10.05],'#c9d0bf','metal',.035);
  for(let i=0;i<9;i++)b.surface([.11,.012,.63],[-7.2+i*.15,3.218,-9.75],'#657567','metal',.002);
  b.cylinder(.42,.35,.41,[-7.26,1.77,-9.28],'#b77755');
  b.cylinder(.45,.45,.065,[-7.26,2.00,-9.28],'#d3b184');b.sphere([.065,.045,.065],[-7.26,2.06,-9.28],'#77634a');
  for(const x of [-7.81,-6.71])b.surface([.27,.08,.13],[x,1.86,-9.28],'#655744','wood',.035);
  b.cylinder(.31,.24,.065,[-5.94,1.61,-9.25],'#3c4d3f');b.surface([.65,.055,.11],[-5.43,1.63,-9.25],'#856e52','wood',.03);
  b.hotspot('cook','和难鱼一起掌勺',[-6.6,1.5,-9.3],[3,2.5,1.8]);
  // Tall fridge has two inset doors, handles, magnets and a note from RainNight.
  b.surface([2.10,3.43,1.68],[-9.35,1.73,-6.50],'#e7e4d1','metal',.15);
  for(const [cy,h] of [[2.49,1.73],[.85,1.45]]){
    b.surface([1.97,h,.10],[-9.35,cy,-5.61],'#eee9d9','metal',.095);
    b.surface([.062,.52,.13],[-10.09,cy+.06,-5.50],'#b4bba6','metal',.025);
  }
  b.label('雨夜的便利贴\nMILK 在第二层',[-9.08,2.56,-5.532],1.03,'#587261','#f1dfaf');
  for(const [x,y,c] of [[-9.61,2.96,'#c48e74'],[-8.67,2.99,'#86a08c'],[-8.73,2.16,'#d8b874']] as const)b.sphere([.052,.052,.018],[x,y,-5.51],c);
  b.obstacle(-9.35,-6.5,2.25,1.9);b.hotspot('story:belated_cake','雨夜留了一张字条',[-9.35,2.2,-5.62],[2.2,2,1]);
  // Open wall shelves mix ceramics, cookbooks and pantry jars.
  for(const y of [2.92,4.13]){
    b.surface([5.1,.10,.65],[6.1,y,-10.4],'#c3a27c','wood',.025);
    for(const x of [3.82,8.37])b.surface([.08,.45,.50],[x,y-.23,-10.42],'#7e8e76','metal',.015);
    for(let i=0;i<7;i++){
      const x=3.95+i*.65;b.cylinder(.15,.14,.35,[x,y+.225,-10.29],['#cbb98e','#8b9f88','#ca987c','#d8caab'][i%4]);
      b.cylinder(.167,.167,.055,[x,y+.425,-10.29],'#ae936d');
    }
  }
  for(let i=0;i<4;i++)b.book(2.38+i*.18,1.41,-10.2,['#b8916f','#6c8872','#e0c17e','#8caaa1'][i],.14,.49+i*.04,.33);
  bottle(b,5.55,1.41,-10.11,'#768a5b',1.1);bottle(b,5.95,1.41,-10.1,'#9b8460');
  b.surface([1.15,.07,.68],[6.82,1.425,-9.41],'#b99468','wood',.06);
  for(let i=0;i<4;i++)b.sphere([.13,.115,.13],[6.45+i*.2,1.57,-9.43],i%2?'#ce9f55':'#b96f53');
  // Island: drawers, wicker baskets, a cutting board and vegetable prep.
  b.surface([4.6,1.14,2.20],[-4.1,.61,-3.2],'#748b76','wood',.07);
  b.surface([4.9,.16,2.46],[-4.1,1.27,-3.2],'#e7d6b7','stone',.06);
  for(let i=0;i<3;i++)for(let j=0;j<2;j++){
    const x=-5.61+i*1.5,y=.35+j*.51;b.surface([1.40,.44,.06],[x,y,-2.05],'#9cac92','wood',.035);
    b.surface([.35,.035,.07],[x,y+.10,-1.998],'#bbaa7a','metal',.01);
  }
  b.obstacle(-4.1,-3.2,5,2.5);
  b.surface([1.6,.08,.93],[-4.05,1.39,-3.12],'#ba9162','wood',.055);
  for(let i=0;i<6;i++){const slice=b.cylinder(.09,.09,.10,[-4.6+i*.15,1.485,-3.06],'#da9b59');slice.rotation.z=Math.PI/2;}
  b.surface([.63,.028,.12],[-3.63,1.465,-3.31],'#bec8bb','metal',.006);b.surface([.32,.04,.115],[-3.16,1.465,-3.31],'#755f47','wood',.02);
  for(let i=0;i<5;i++)b.sphere([.17,.15,.16],[-5.73+(i%3)*.19,1.52+Math.floor(i/3)*.11,-3.47],i%2?'#aabe72':'#9ca960');
  b.cylinder(.31,.25,.33,[-2.26,1.49,-3.63],'#d2b08a');for(let i=0;i<5;i++){const u=b.cylinder(.018,.018,.61,[-2.35+i*.04,1.84,-3.62],'#9a7b50');u.rotation.z=(i-2)*.09;}
  b.hotspot('cook','切好菜，再试试火候',[-4.1,1.4,-3.1],[4.7,1.6,2.5]);
  for(const x of [-5.3,-3.0]){b.cylinder(.37,.35,.14,[x,.83,-.98],'#c6a477');for(const dz of [-.21,.21])for(const dx of [-.21,.21])b.surface([.055,.78,.055],[x+dx,.39,-.98+dz],'#7e7f64','metal',.01);b.obstacle(x,-.98,.83,.83);b.seat(`kitchen-stool:${x}`,[x,.9,-1.06],[x,0,.5],{facing:Math.PI,width:.7,depth:.7,surface:[x,1.38,-2.2],target:[x,1.5,-2.2]});}
  pendant(b,-5.2,-3.2);pendant(b,-2.9,-3.2);
  // Dining area: a shared place setting and the option to decline birthday cake.
  b.table(5.3,1.7,4.25,2.75,1.27);
  for(const x of [4.2,6.4]){chair(b,x,-.18);chair(b,x,3.59,Math.PI);}
  for(const [x,z] of [[4.3,.93],[6.3,.93],[4.3,2.47],[6.3,2.47]]){
    b.surface([1.17,.018,.85],[x,1.355,z],'#b2bba1','fabric',.03);
    b.cylinder(.29,.28,.045,[x,1.39,z],'#f1e7cf');const rim=b.torus(.24,.013,[x,1.417,z],'#c1b493');rim.rotation.x=Math.PI/2;
    b.cup(x+.40,1.38,z-.20,'#d5bd97');b.surface([.025,.024,.47],[x-.4,1.395,z],'#b4bcaa','metal',.004);
  }
  b.cylinder(.16,.12,.37,[5.3,1.56,1.7],'#b0bba1');for(let i=0;i<5;i++){b.cylinder(.008,.008,.5,[5.3+(i-2)*.04,1.9,1.7],'#83905f');b.sphere([.085,.065,.075],[5.3+(i-2)*.065,2.12+(i%2)*.09,1.7],'#d5b680');}
  pendant(b,5.3,1.7,4.15);
  b.hotspot('story:english_kitchen','雨夜的中英厨房',[5.3,1.45,1.7],[4.3,1.8,2.8]);
  b.label('今天由主厨决定\n吃饭可以，催饭不行',[4.68,5.31,-10.72],3.5,'#657459','#e6ddc2');
  b.plant(8.8,-6,1.45);b.obstacle(8.8,-6,1.45,1.45);
  b.surface([2.05,.90,1.10],[-8.8,.57,3.7],'#baa582','wood',.04);b.surface([2.20,.11,1.20],[-8.8,1.08,3.7],'#deceb0','wood',.035);
  b.obstacle(-8.8,3.7,2.3,1.35);b.cup(-9.28,1.15,3.7);b.plant(-8.35,3.7,.38).position.y=1.15;
  b.label('一起吃饭\n也可以只聊聊天',[-8.8,1.73,3.15],1.5,'#58715d','#e9dfc6');b.hotspot('friends','谁又在催开饭',[-8.8,1.3,3.7],[2.2,2,1.3]);
}

export function buildShop(b:EnvironmentBuilder) {
  const colors=['#c49772','#879e8a','#dcc389','#94afac','#c38b74','#a5ad83'];
  function packet(x:number,y:number,z:number,color:string,index:number,parent:THREE.Object3D=b.root) {
    const h=.42+(index%3)*.07;
    b.surface([.28,h,.23],[x,y+h/2,z],color,'fabric',.04,parent);
    b.surface([.22,.13,.012],[x,y+h*.58,z+.123],'#f2e2bd','plaster',.012,parent);
    b.surface([.27,.034,.24],[x,y+h-.02,z],'#d5c5a4','plaster',.008,parent);
  }
  // Continuous merchant wall: timber frames, adjustable metal shelving and goods.
  b.surface([18.9,.18,.32],[.1,4.59,-10.49],'#b69a72','wood',.03);
  b.surface([18.9,.07,.08],[.1,4.49,-10.3],'#e0c08e','metal',.01);
  b.label('老母猪村 · 便利店',[.3,5.33,-10.70],6.2,'#4b6757','#eee0bb');
  b.label('慢慢挑，别跟钱包吵架',[7.4,5.25,-10.70],2.4,'#7c8669','#eee0bb');
  for(let bay=0;bay<4;bay++) {
    const x=-7.25+bay*4.8;
    b.surface([4.45,3.82,.22],[x,2.02,-10.41],'#a8b69b','wood',.025);
    for(const side of [-1,1])b.surface([.10,3.89,.97],[x+side*2.23,1.98,-10.01],'#bfa987','wood',.025);
    for(let shelf=0;shelf<4;shelf++) {
      const y=.35+shelf*.94;
      b.surface([4.45,.12,1.08],[x,y,-9.98],'#d6bf99','wood',.025);
      b.surface([4.44,.13,.05],[x,y+.012,-9.412],'#f1e3bf','plaster',.006);
      for(let col=0;col<10;col++) {
        const xx=x-1.91+col*.42,color=colors[(bay+shelf+col)%colors.length];
        if((bay+shelf)%3===0)bottle(b,xx,y+.07,-9.90,color,.90);
        else if((bay+shelf)%3===1){b.cylinder(.13,.13,.42,[xx,y+.285,-9.92],color);b.cylinder(.134,.134,.025,[xx,y+.508,-9.92],'#d4d8c3');b.cylinder(.136,.136,.16,[xx,y+.29,-9.92],'#eee0b9');}
        else packet(xx,y+.07,-9.89,color,col);
      }
      if(shelf===1||shelf===3)b.label(shelf===1?['温牛奶 10 贝壳','脆甜桃子 12 贝壳','蛋炒饭 18 贝壳','苦咖啡 14 贝壳'][bay]:['认真吃早饭','今天也有好心情','三餐不要糊弄','夜猫子补给'][bay],[x,y-.01,-9.374],1.64,'#6a785d','#f0e2bd');
    }
    b.label(['奶香日常','零食有理','便当时间','精神续杯'][bay],[x,4.20,-10.23],2.04,'#526e59','#e5d7b4');
  }
  b.obstacle(.0,-9.92,19.2,1.8);
  b.hotspot('shop','挑点零食再回家',[0,1.6,-9.5],[18.8,3.5,1.8]);
  // Cold cabinet with shelves visible through slightly tinted glazing.
  b.surface([2.24,3.75,2.06],[-9.38,1.91,-5.85],'#d9dfcc','metal',.11);
  b.surface([2.03,3.19,.08],[-9.38,1.90,-4.762],'#5f796f','metal',.03);
  for(let j=0;j<4;j++) {
    const y=.52+j*.73;b.surface([1.84,.06,.70],[-9.38,y,-4.87],'#c4d2c5','metal',.02);
    for(let i=0;i<5;i++)bottle(b,-10.08+i*.35,y+.05,-4.75,colors[(i+j)%colors.length],.72);
  }
  for(const dx of [-.50,.50]) {
    const glass=b.surface([.95,3.11,.023],[-9.38+dx,1.91,-4.50],'#d8e7db','metal',.01);
    glass.material=new THREE.MeshStandardMaterial({color:'#c4e0d4',roughness:.25,transparent:true,opacity:.17,depthWrite:false});
    b.surface([.04,3.16,.075],[-9.38+dx-.48,1.9,-4.47],'#b7c8b6','metal',.01);
    b.surface([.042,.66,.10],[-9.38+dx+.31,1.89,-4.41],'#dee4d1','metal',.012);
  }
  b.label('冷藏柜 · 鲜奶和汽水',[-9.38,3.52,-4.49],1.94,'#58776a','#e8e9d6');
  for(let i=0;i<12;i++)b.surface([.10,.032,.02],[-10.05+i*.12,.25,-4.45],'#869a86','metal',.003);
  b.obstacle(-9.38,-5.85,2.45,2.25);b.hotspot('shop','冰柜里有什么',[-9.38,1.8,-4.65],[2.5,3.6,1.4]);
  // Freestanding center shelves sit to the left of the central walking aisle.
  for(const z of [-4.5,-1.3]) {
    const x=-4.75;
    b.surface([3.8,2.43,.18],[x,1.28,z],'#a8b097','wood',.03);
    for(const dx of [-1.83,1.83])b.surface([.09,2.6,1.18],[x+dx,1.3,z],'#b6a182','wood',.025);
    for(let j=0;j<3;j++) {
      const y=.27+j*.78;b.surface([3.78,.10,1.34],[x,y,z],'#d4be98','wood',.025);
      for(let i=0;i<8;i++) {
        packet(x-1.56+i*.445,y+.06,z+.40,colors[(i+j)%6],i+j);
        packet(x-1.56+i*.445,y+.06,z-.40,colors[(i+j+2)%6],i+j);
      }
      b.surface([3.73,.075,.04],[x,y+.01,z+.69],'#ebe0bf','plaster',.008);
    }
    b.label(z< -3?'囤一点快乐':'先看价格，再看口袋',[x,2.5,z+.105],2.17,'#536951','#e3d6b1');
    b.obstacle(x,z,4.05,1.65);
  }
  b.hotspot('shop','零食货架',[-4.75,1.5,-1.3],[4.1,2.9,1.8]);
  // A low produce island keeps the right side open to long views across the shop.
  const produceX=5.20,produceZ=-3.15;
  b.surface([5.4,1.0,2.6],[produceX,.53,produceZ],'#ac9470','wood',.06);
  b.surface([5.65,.13,2.84],[produceX,1.10,produceZ],'#d1b58b','wood',.035);
  for(let i=0;i<3;i++)for(let j=0;j<2;j++) {
    const x=3.39+i*1.8,z=-3.82+j*1.40;
    b.surface([1.57,.075,1.12],[x,1.23,z],'#967d58','wood',.02);
    for(const dz of [-.57,.57])b.surface([1.64,.24,.055],[x,1.34,z+dz],'#b3946c','wood',.016);
    for(const dx of [-.82,.82])b.surface([.055,.24,1.17],[x+dx,1.34,z],'#b3946c','wood',.016);
    for(let row=0;row<3;row++)for(let col=0;col<4;col++){
      const xx=x-.50+col*.33,zz=z-.34+row*.32,fruitColor=['#d8a478','#bdc17c','#e2b58a','#bac283','#c68e71','#d5be78'][(i+j*3)%6];
      b.sphere([.17,.16,.17],[xx,1.43,zz],fruitColor);
      if(i===0){const leaf=b.sphere([.073,.011,.027],[xx+.03,1.593,zz],'#6e8b55');leaf.rotation.y=.45;}
      else b.cylinder(.009,.012,.06,[xx,1.60,zz],'#907752');
    }
  }
  b.label('脆甜桃子 · 12 贝壳',[4.5,.71,-1.79],2.65,'#657851','#e9ddbc');
  b.label('果然有点甜',[6.60,.71,-1.79],1.20,'#6f7b57','#e9ddbc');
  b.obstacle(produceX,produceZ,5.8,3.0);b.hotspot('shop','新鲜水果摊',[produceX,1.3,produceZ],[5.7,1.8,3]);
  // Ice cream chest: angled glass, frozen tubs and baskets of wafer cones.
  b.surface([3.60,1.26,1.96],[6.7,.67,1.0],'#b2c7bd','metal',.15);
  b.surface([3.47,.09,1.84],[6.7,1.37,1.0],'#e4e7d3','metal',.055);
  b.surface([3.07,.08,1.49],[6.7,1.40,1.0],'#75938b','metal',.065);
  for(let i=0;i<4;i++)for(let j=0;j<2;j++)b.cylinder(.21,.19,.055,[5.49+i*.79,1.462,.63+j*.72],['#e4c7a0','#bbd1ac','#dcb1a2','#c4b6a2'][i]);
  const chestGlass=b.surface([3.21,.022,1.66],[6.7,1.50,1.0],'#c4dfd4','metal',.035);
  chestGlass.material=new THREE.MeshStandardMaterial({color:'#dcece0',transparent:true,opacity:.2,roughness:.2,depthWrite:false});
  b.surface([.045,.055,1.65],[6.7,1.53,1.0],'#d9e4d3','metal',.01);b.surface([.42,.058,.055],[6.24,1.56,1.5],'#eff0de','metal',.015);
  b.label('冰淇淋\n今天可以甜一点',[6.7,.80,2.013],2.13,'#577e6c','#d8e4cf');
  b.obstacle(6.7,1.0,3.85,2.25);b.hotspot('shop','冰柜补给',[6.7,1.0,1.0],[3.9,2,2.3]);
  // Cash desk and a paper shopping list place the village stories in the room.
  b.surface([5.2,1.35,1.85],[-5.4,.71,4.7],'#7c9880','wood',.065);
  b.surface([5.46,.15,2.03],[-5.4,1.46,4.7],'#ead9b6','stone',.05);
  for(let i=0;i<14;i++)b.surface([.043,1.19,.035],[-7.73+i*.36,.72,5.649],'#a6b697','wood',.008);
  b.surface([1.23,.11,.91],[-5.8,1.60,4.63],'#626f61','metal',.035);
  b.surface([.13,.62,.12],[-5.8,1.91,4.39],'#768572','metal',.025);
  b.surface([1.15,.77,.095],[-5.8,2.16,4.39],'#4b6356','metal',.055);
  b.label('欢迎回村\n今日快乐营业',[-5.8,2.16,4.453],1.03,'#e5e8c6','#456454');
  b.surface([.66,.065,.36],[-4.67,1.63,4.8],'#687c68','metal',.025);
  for(let row=0;row<3;row++)for(let col=0;col<5;col++)b.surface([.064,.018,.056],[-4.89+col*.104,1.673,4.69+row*.093],col===4?'#d3ad77':'#c3cdb6','plaster',.008);
  b.cup(-3.48,1.55,4.54,'#b39370');
  b.surface([1.1,.04,.78],[-6.99,1.57,4.79],'#9b8765','wood',.025);
  const list=b.label('全村野餐采购单\n猴：先买吃的',[-6.99,1.597,4.79],.97,'#637451','#f1e8c9');list.rotation.x=-Math.PI/2;
  for(let i=0;i<3;i++)packet(-3.60+i*.25,1.55,5.15,colors[i],i);
  b.obstacle(-5.4,4.7,5.65,2.2);b.hotspot('shop','结账和补货',[-4.6,1.4,4.8],[3.65,2.8,2.3]);
  b.hotspot('story:group_picnic','全村野餐采购单',[-7.05,1.75,4.8],[1.1,.8,1.1]);
  // Shopping baskets, reusable bags and a small welcome area.
  for(let level=0;level<5;level++) {
    const y=.16+level*.115;
    b.surface([.91,.065,.70],[-1.76,y,5.07],'#b19a71','wood',.02);
    for(const z of [4.70,5.44])b.surface([1.0,.19,.048],[-1.76,y+.12,z],'#bfa780','wood',.014);
    for(const x of [-2.26,-1.26])b.surface([.045,.19,.76],[x,y+.12,5.07],'#bfa780','wood',.012);
  }
  b.obstacle(-1.76,5.07,1.1,.88);
  b.surface([3.12,.028,1.76],[6.8,.024,6.9],'#b4b9a0','fabric',.04);
  const welcome=b.label('欢迎回来',[6.8,.045,6.9],2.30,'#61745a','#b4b9a0');welcome.rotation.x=-Math.PI/2;
  b.bench(7.5,7.7,Math.PI);
  b.plant(9.3,5.45,1.7);b.obstacle(9.3,5.45,1.7,1.7);
  b.surface([1.91,2.45,.12],[8.86,1.39,-6.25],'#b59b71','wood',.04).rotation.y=-.27;
  const board=b.label('村口留言板\n今天谁有空？',[8.85,1.60,-6.16],1.73,'#5b725c','#e7d7ae');board.rotation.y=-.27;
  b.hotspot('friends','看看群友留言',[8.85,1.55,-6.15],[2.1,2.7,.75]);b.obstacle(8.9,-6.25,2.1,.6);
  for(const [x,z] of [[-4.6,-3.1],[4.9,-3.1],[-5.6,4.4],[5.8,4.4]])pendant(b,x,z,4.45);
  b.label('营业中 · 日子慢慢过',[-5.4,.95,5.704],2.42,'#f0e1b9','#7d987e');
}
