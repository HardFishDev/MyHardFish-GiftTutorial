import { useEffect, useRef, useState } from "react";
import type { CSSProperties, ReactNode } from "react";
import {
  ArrowCounterClockwise,
  Compass,
  Flag,
  Binoculars,
  Basket,
  Bicycle,
  List,
  UsersThree,
  MapTrifold,
  CornersOut,
  CornersIn,
  BookOpen,
  Camera,
  CaretRight,
  ChatCircleDots,
  Check,
  CheckCircle,
  CoatHanger,
  CookingPot,
  DownloadSimple,
  FishSimple,
  FloppyDisk,
  ForkKnife,
  GameController,
  GearSix,
  GraduationCap,
  Hand,
  Heart,
  Info,
  Lightning,
  ListChecks,
  LockKey,
  MapPin,
  Moon,
  MusicNotes,
  PaperPlaneRight,
  Plus,
  Smiley,
  Sparkle,
  SpeakerHigh,
  SpeakerSlash,
  Storefront,
  Trophy,
  UploadSimple,
  Waves,
  X,
} from "@phosphor-icons/react";
import { FishWorld } from "./scene";
import type { Place } from "./scene";
import { AdventurePanel, SpotPanel } from "./AdventurePanel";
import VillageAtlas, { placeIcons } from "./VillageAtlas";
import WorldControls from "./WorldControls";
import './dbh-entry.css';
import { DbhPanel } from './DbhPanel';
import { recordDbhVisit } from './dbh-state';
import { EXPLORATION_SPOTS } from "./world-layout";
import {
  achievementInfo,
  dailyTasks,
  foods,
  friends,
  outfits,
  places,
  stories,
} from "./content";
import type { FoodId } from "./content";
import { getAdventureView, quoteMap, quotes, relationship, step } from "./engine";
import type { Action, GameKind, GameState } from "./engine";
import {
  downloadFile,
  loadBackup,
  loadGame,
  loadSlots,
  makeArchive,
  readArchive,
  restoreStored,
  saveGame,
  saveSlots,
} from "./storage";
import type { Archive, Slot } from "./storage";
import { speak, stopVoice, loadAudioPreferences, saveAudioPreferences, configureAudio, unlockAudio, playEffect, disposeAudio, setMusicScene } from "./audio";
import type { AudioPreferences, AudioEffectKind } from "./audio";
import LoadingScreen from "./LoadingScreen";
import SceneTransitionIndicator from "./SceneTransitionIndicator";
import { INITIAL_PROGRESS, preloadResources } from "./resources";
import MiniGame from "./MiniGame";
import "./world.css";
import "./expansion.css";
import musicCatalog from "./music-catalog.json" with { type: "json" };
import { activityForAction, GAME_ACTIVITIES, STORY_NODE_ACTIVITIES } from './interaction-feedback';
import type { ActivityFeedback } from './interaction-feedback';

const asset = (name: string) => `${import.meta.env.BASE_URL}assets/${name}`;
const timestamp = (n: number) =>
  new Date(n).toLocaleString("zh-CN", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
type Panel =
  | ""
  | "closet"
  | "album"
  | "saves"
  | "settings"
  | "help"
  | "games"
  | "story"
  | "shop"
  | "tasks"
  | "mini"
  | "menu"
  | "map"
  | "interact"
  | "friends"
  | "adventure"
  | "spot"
  | "dbh";
type Tab = "chat" | "food" | "stories";

function Modal({
  title,
  onClose,
  children,
  wide = false,
  activity = false,
  cycling = false,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  wide?: boolean;
  activity?: boolean;
  cycling?: boolean;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const close = useRef(onClose);
  close.current = onClose;
  useEffect(() => {
    const el = ref.current!,
      previous = document.activeElement as HTMLElement | null;
    el.showModal();
    return () => {
      el.close();
      if (previous?.isConnected) previous.focus();
    };
  }, []);
  useEffect(() => {
    const body = ref.current?.querySelector(".modal-body");
    if (body) body.scrollTop = 0;
  }, [title]);
  return (
    <dialog
      ref={ref}
      className={`modal ${wide ? "modal-wide" : ""} ${activity ? "modal-activity" : ""} ${cycling ? 'modal-cycling' : ''}`}
      aria-labelledby="modal-title"
      onCancel={(e) => {
        e.preventDefault();
        close.current();
      }}
      onClick={(e) => {
        if (e.target === ref.current) {
          const b = ref.current!.getBoundingClientRect();
          if (
            e.clientX < b.left ||
            e.clientX > b.right ||
            e.clientY < b.top ||
            e.clientY > b.bottom
          )
            close.current();
        }
      }}
    >
      <div className="modal-head">
        <h2 id="modal-title">{title}</h2>
        <button
          className="icon-button"
          aria-label="关闭窗口"
          onClick={onClose}
          autoFocus
        >
          <X size={23} />
        </button>
      </div>
      <div className="modal-body">{children}</div>
    </dialog>
  );
}

function FoodArt({ id }: { id: FoodId }) {
  return (
    <span className={`food-art food-${id}`} aria-hidden="true">
      <span />
      <i />
      <b />
    </span>
  );
}

function SaveManager({
  state,
  restore,
  notify,
  allowSave,
}: {
  state: GameState;
  restore: (state: GameState) => void;
  notify: (s: string) => void;
  allowSave: () => void;
}) {
  const [error, setError] = useState("");
  const [slots, setSlots] = useState<Slot[]>(() => {
    try {
      return loadSlots();
    } catch {
      return [null, null, null];
    }
  });
  const [pending, setPending] = useState<Archive | null>(null);
  const [confirm, setConfirm] = useState<{
    state: GameState;
    label: string;
  } | null>(null);
  const [backup, setBackup] = useState<GameState | null>(() => {
    try {
      return loadBackup();
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  function restoreState(next: GameState, incomingSlots?: Slot[]) {
    try {
      restoreStored(state, next, incomingSlots);
      setBackup(state);
      if (incomingSlots) setSlots(incomingSlots);
      restore(next);
      setPending(null);
      setConfirm(null);
      setError("");
      notify("进度已恢复，恢复前的进度也已备份");
    } catch {
      setError("浏览器无法写入存档。请先导出当前进度，再检查浏览器存储空间。");
    }
  }
  async function importFile(file?: File) {
    if (!file) return;
    setLoading(true);
    setError("");
    try {
      if (file.size > 2 * 1024 * 1024)
        throw Error("文件超过 2 MB，请选择本游戏导出的存档 ZIP");
      setPending(readArchive(new Uint8Array(await file.arrayBuffer())));
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "无法读取此 ZIP，当前进度没有更改",
      );
    } finally {
      setLoading(false);
      if (input.current) input.current.value = "";
    }
  }
  return (
    <div className="save-manager">
      <p className="muted">
        进度保存在当前浏览器。换设备前，带走一份
        ZIP。恢复存档前会自动备份当前进度。
      </p>
      <div className="current-save">
        <FloppyDisk size={26} />
        <div>
          <b>当前生活 · {state.name}</b>
          <small>
            熟悉度 {Math.floor(state.bond)} · {state.shells} 贝壳 ·{" "}
            {state.endings.length} 个结局
          </small>
        </div>
        <button
          className="text-button"
          onClick={() => {
            try {
              saveGame(state);
              allowSave();
              notify("当前进度已保存");
              setError("");
            } catch {
              setError("保存失败，请导出 ZIP 备份");
            }
          }}
        >
          立即保存
        </button>
      </div>
      <div className="save-actions">
        <button
          className="primary"
          onClick={() => {
            try {
              const bytes = makeArchive(state, slots);
              downloadFile(
                bytes as BlobPart,
                `我的群友难鱼_${new Date().toISOString().slice(0, 10)}.zip`,
                "application/zip",
              );
              notify("存档 ZIP 已导出");
            } catch {
              setError("导出失败，请重试");
            }
          }}
        >
          <DownloadSimple size={19} />
          导出 ZIP
        </button>
        <button
          className="secondary"
          onClick={() => input.current?.click()}
          disabled={loading}
        >
          <UploadSimple size={19} />
          {loading ? "正在检查…" : "导入 ZIP"}
        </button>
        <input
          ref={input}
          className="visually-hidden"
          type="file"
          accept=".zip,application/zip"
          aria-label="选择存档 ZIP"
          onChange={(e) => void importFile(e.target.files?.[0])}
        />
      </div>
      {error && (
        <p role="alert" className="error-message">
          {error}
        </p>
      )}
      {pending && (
        <div className="confirm-box">
          <h3>已检查这份存档</h3>
          <p>
            {pending.state.name} · {pending.state.shells} 贝壳 · 熟悉度{" "}
            {Math.floor(pending.state.bond)}
            <br />
            最后更新于 {timestamp(pending.state.updatedAt)}，包含{" "}
            {pending.slots.filter(Boolean).length} 个手动存档。
          </p>
          <div className="button-row">
            <button
              className="primary"
              onClick={() => restoreState(pending.state, pending.slots)}
            >
              确认导入并替换
            </button>
            <button className="secondary" onClick={() => setPending(null)}>
              取消导入
            </button>
          </div>
        </div>
      )}
      {confirm && (
        <div className="confirm-box">
          <h3>读取{confirm.label}？</h3>
          <p>
            将回到 {timestamp(confirm.state.updatedAt)}{" "}
            的进度，当前进度会先备份。
          </p>
          <div className="button-row">
            <button
              className="primary"
              onClick={() => restoreState(confirm.state)}
            >
              确认读取
            </button>
            <button className="secondary" onClick={() => setConfirm(null)}>
              取消
            </button>
          </div>
        </div>
      )}
      <h3 className="subheading">给这一刻留个位置</h3>
      <div className="slot-list">
        {slots.map((slot, i) => (
          <div className="save-slot" key={i}>
            <span className="slot-number">0{i + 1}</span>
            <div>
              <b>{slot ? slot.label : "还空着"}</b>
              <small>
                {slot
                  ? `${timestamp(slot.savedAt)} · ${slot.state.shells} 贝壳`
                  : "把今天存下来，以后还可以回来。"}
              </small>
            </div>
            <div className="slot-actions">
              <button
                className="text-button"
                onClick={() => {
                  const save = () => {
                    try {
                      const next = [...slots];
                      next[i] = {
                        label: `${places.find((p) => p.id === state.place)!.name}的日常`,
                        savedAt: Date.now(),
                        state: structuredClone(state),
                      };
                      saveSlots(next);
                      setSlots(next);
                      notify(`已保存到位置 ${i + 1}`);
                      setError("");
                    } catch {
                      setError("保存失败，请检查浏览器存储空间");
                    }
                  };
                  if (
                    slot &&
                    !window.confirm(
                      `覆盖位置 ${i + 1} 的旧存档？当前游戏进度不会改变。`,
                    )
                  )
                    return;
                  save();
                }}
              >
                保存
              </button>
              <button
                className="text-button"
                disabled={!slot}
                onClick={() =>
                  slot &&
                  setConfirm({ state: slot.state, label: `位置 ${i + 1}` })
                }
              >
                读取
              </button>
            </div>
          </div>
        ))}
      </div>
      {backup && (
        <button
          className="text-button restore-backup"
          onClick={() => setConfirm({ state: backup, label: "恢复前备份" })}
        >
          <ArrowCounterClockwise size={17} />
          回到上次恢复之前
        </button>
      )}
    </div>
  );
}

export default function App() {
  const [initial] = useState(loadGame);
  const [state, setState] = useState(initial.state);
  const stateRef = useRef(state);
  stateRef.current = state;
  const [storageError, setStorageError] = useState(initial.error);
  const blockedSave = useRef(!!initial.error);
  const [saved, setSaved] = useState(true);
  const [panel, setPanel] = useState<Panel>("");
  const [cinematic, setCinematic] = useState(false);
  const [overview, setOverview] = useState(false);
  const [spotId, setSpotId] = useState("");
  const pendingNavigation = useRef<{ place: Place; target: string } | null>(null);
  const pendingArrival = useRef<Place | null>(null);
  const pendingActivity = useRef<ActivityFeedback | null>(null);
  const miniSession = useRef<string | null>(null);
  const [tab, setTab] = useState<Tab>("chat");
  const [albumTab, setAlbumTab] = useState<
    "quotes" | "journal" | "achievements"
  >("quotes");
  const [selectedQuote, setSelectedQuote] = useState<string | null>(null);
  const [mini, setMini] = useState<GameKind>("bottle");
  const cyclingOpen = panel === 'mini' && mini === 'cycling';
  const [storyEnd, setStoryEnd] = useState<{
    title: string;
    text: string;
    quote?: string;
  } | null>(null);
  const [text, setText] = useState("");
  const [toast, setToast] = useState("");
  const [worldError, setWorldError] = useState(false);
  const [worldReady, setWorldReady] = useState(false);
  const [worldTransitioning, setWorldTransitioning] = useState(false);
  const [worldSceneError, setWorldSceneError] = useState("");
  const [travelAttempt, setTravelAttempt] = useState(0);
  const worldInputsBlocked = worldTransitioning || Boolean(worldSceneError);
  const [audioPreferences, setAudioPreferences] = useState(loadAudioPreferences);
  const [resourceProgress, setResourceProgress] = useState(INITIAL_PROGRESS);
  const [resourceFailures, setResourceFailures] = useState<string[]>([]);
  const [resourcesReady, setResourcesReady] = useState(false);
  const [loadAttempt, setLoadAttempt] = useState(0);
  const isLoading = !resourcesReady || (!worldReady && !worldError);
  const [worldHover, setWorldHover] = useState("");
  const [guide, setGuide] = useState(
    state.counts.pet + state.counts.chat === 0,
  );
  const [nameDraft, setNameDraft] = useState(state.name);
  const sceneHost = useRef<HTMLDivElement>(null),
    world = useRef<FishWorld | null>(null);
  const messages = useRef<HTMLDivElement>(null),
    interacted = useRef(false);
  const interruptPathForReaction = useRef(false);
  const sceneAction = useRef<(id: string) => void>(() => {});
  const dbhSession = useRef(0);
  useEffect(() => { dbhSession.current++; }, [panel]);
  const place = places.find((p) => p.id === state.place)!;
  const adventure = getAdventureView(state);
  const suggestedStory = stories.find(s => s.place === state.place && s.minBond <= state.bond && !state.endings.some(e => e.startsWith(s.id+":"))) || stories.find(s => s.place === state.place && s.minBond <= state.bond);
  const totalInteractions =
    state.counts.chat +
    state.counts.pet +
    state.counts.feed +
    state.counts.tease;
  const day = Math.max(
    1,
    Math.floor((Date.now() - state.createdAt) / 86400000) + 1,
  );
  function notify(message: string) {
    setToast(message);
  }
  function changeAudioPreferences(value: Partial<AudioPreferences>) {
    const next = { ...audioPreferences, ...value };
    configureAudio(next);
    setAudioPreferences(next);
    try { saveAudioPreferences(next); }
    catch { notify("声音设置暂时无法保存，下次打开时可能恢复默认设置。"); }
  }
  function dispatch(action: Action) {
    interacted.current = action.type !== "tick";
    const previous = stateRef.current;
    const next = step(previous, action);
    const feedback = activityForAction(previous, next, action);
    if (next.place !== previous.place) { pendingActivity.current = null; world.current?.cancelActivity(); }
    else if (feedback) pendingActivity.current = feedback;
    else if (action.type === 'interact' && action.value !== 'rest') world.current?.cancelActivity();
    if (next.place !== previous.place) setMusicScene(next.place);
    let effect: AudioEffectKind | undefined;
    if (action.type === "interact") {
      if (action.value === "pet" || action.value === "tease" || action.value === "dance") effect = action.value;
      else if (action.value !== "rest") effect = "pet";
    } else if (action.type === "feed" && next.counts.feed > previous.counts.feed) effect = "feed";
    else if (action.type === "place" && next.place !== previous.place) effect = "travel";
    else if (action.type === "outfit" && next.outfit !== previous.outfit) effect = "outfit";
    else if (action.type !== "tick" && next.shells > previous.shells) effect = "reward";
    if (effect) playEffect(effect);
    if (next.reaction.id !== previous.reaction.id)
      interruptPathForReaction.current = action.type === "interact" || action.type === "feed";
    stateRef.current = next;
    setState(next);
    // Selecting the same destination can replace a pending switch or retry a
    // failed one even when the game's place value has not changed.
    if (action.type === 'place' && next.place === previous.place &&
      (world.current?.transitioning || world.current?.getSnapshot().place !== next.place || worldSceneError))
      setTravelAttempt(attempt => attempt + 1);
    if (next.notice) notify(next.notice);
    return next;
  }
  const dispatchRef = useRef(dispatch);
  dispatchRef.current = dispatch;
  sceneAction.current = (id) => {
    if (isLoading || worldInputsBlocked || world.current?.transitioning) return;
    if (panel && (id.startsWith("travel:") || id.startsWith("adventure:"))) {
      notify("已经走到目标附近，收起当前窗口后可以继续互动。");
      return;
    }
    if (id === 'npc:dbh') {
      if (!panel && world.current?.setDbhConversation(true)) {setPanel('dbh');setGuide(false);setOverview(false);}
      return;
    }
    if (id.startsWith("travel:")) {
      const destination = id.slice(7) as Place;
      if (places.some(place => place.id === destination)) { pendingNavigation.current = null; pendingArrival.current = stateRef.current.place; dispatch({ type: "place", value: destination }); setGuide(false); }
      return;
    }
    if (id.startsWith("adventure:")) {
      const target = id.slice(10);
      if (EXPLORATION_SPOTS.some(spot => spot.id === target && spot.place === stateRef.current.place)) {
        const dbh = recordDbhVisit(stateRef.current.dbh, stateRef.current.place, target);
        if (JSON.stringify(dbh) !== JSON.stringify(stateRef.current.dbh)) dispatch({type:'dbh',value:dbh});
        setSpotId(target); setPanel("spot"); setGuide(false); }
      return;
    }
    if (id === "words" || id === "harvest") openMini(id);
    if (id === "pet" || id === "rest")
      dispatch({ type: "interact", value: id });
    if (id === "cook" || id === "math" || id === "bottle") openMini(id);
    if (id === "story") { if (suggestedStory) startStory(suggestedStory.id); else { setTab("stories"); setPanel("interact"); } }
    if (id.startsWith("story:")) startStory(id.slice(6));
    if (id === "closet") setPanel("closet");
    if (id === "friends") setPanel("friends");
    if (id === "shop") setPanel("shop");
    if (id === 'play') notify('难鱼把球抛起来又接住了。移动可以收起球。');
    if (id === 'water') notify('难鱼提起水壶，给眼前的花草浇点水。');
    if (id === 'read') notify('难鱼翻开书：已阅。再翻一页看看。');
    if (id === 'write') notify('难鱼拿起笔，把刚才的小事记下来。');
    if (id === 'inspect') notify('难鱼凑近看了看：这个我得亲自检查。');
  };
  useEffect(() => {
    const controller = new AbortController();
    setResourcesReady(false);
    setResourceFailures([]);
    setResourceProgress(INITIAL_PROGRESS);
    preloadResources(setResourceProgress, controller.signal, { retry: loadAttempt > 0 }).then(result => {
      if (controller.signal.aborted || result.aborted) return;
      setResourceFailures(result.failed);
      if (!result.failed.length) setResourcesReady(true);
    }).catch(() => {
      if (!controller.signal.aborted) setResourceFailures(["资源下载中断"]);
    });
    return () => controller.abort();
  }, [loadAttempt]);
  useEffect(() => {
    if (!isLoading) return;
    // Scene keyboard listeners are global; inert alone only blocks DOM targets.
    const blockGameKeys = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.closest?.("button,input,textarea")) return;
      if (["Enter", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "m", "j", "e", "w", "a", "s", "d"].includes(e.key.length === 1 ? e.key.toLowerCase() : e.key)) {
        e.preventDefault(); e.stopImmediatePropagation();
      }
    };
    window.addEventListener("keydown", blockGameKeys, true);
    return () => window.removeEventListener("keydown", blockGameKeys, true);
  }, [isLoading]);
  useEffect(() => {
    setMusicScene(stateRef.current.place);
    configureAudio(audioPreferences);
    return () => disposeAudio();
  }, []);
  useEffect(() => {
    let w: FishWorld | undefined;
    const host = sceneHost.current!;
    const syncSceneStatus = () => {
      if (host.dataset.ready === "true") setWorldReady(true);
      const busy = host.dataset.sceneLoading === "true";
      setWorldTransitioning(busy);
      setWorldSceneError(host.dataset.sceneError || "");
      setWorldHover(busy ? "" : host.dataset.hover || "");
    };
    const observer = new MutationObserver(syncSceneStatus);
    observer.observe(host, { attributes: true, attributeFilter: ["data-ready", "data-hover", "data-scene-loading", "data-scene-error"] });
    try {
      w = new FishWorld(sceneHost.current!, (id) => sceneAction.current(id));
      world.current = w;
      w.outfit(stateRef.current.outfit);
      w.setQuality(stateRef.current.settings.lowQuality);
      syncSceneStatus();
    } catch (error) {
      console.error("3D 世界初始化失败", error);
      setWorldError(true);
    }
    return () => {
      observer.disconnect();
      w?.dispose();
      world.current = null;
      stopVoice();
    };
  }, []);
  useEffect(() => {
    world.current?.setSuspended(cyclingOpen || Boolean(worldSceneError));
  }, [cyclingOpen, worldSceneError]);
  useEffect(() => {
    if (cyclingOpen) {
      pendingActivity.current = null;
      stopVoice();
    }
    return () => {
      if (cyclingOpen) {
        const id = miniSession.current;
        miniSession.current = null;
        if (id && stateRef.current.activeGame?.id === id)
          dispatchRef.current({ type: 'cancelGame', sessionId: id });
        world.current?.setSuspended(false);
      }
    };
  }, [cyclingOpen]);
  useEffect(() => {
    world.current?.setDbhConversation(panel === 'dbh');
    const activePanel = ['spot', 'mini', 'story', 'shop', 'closet', 'interact', 'friends'].includes(panel);
    world.current?.setActivityView(activePanel);
    if (!pendingActivity.current && panel === 'shop') pendingActivity.current = { kind: 'shop', prop: 'bag' };
    if (!pendingActivity.current && panel === 'closet') pendingActivity.current = { kind: 'inspect', prop: 'none' };
    if (!pendingActivity.current && panel === 'friends') pendingActivity.current = { kind: 'read', prop: 'book' };
    if (!pendingActivity.current && panel === 'interact') pendingActivity.current = tab === 'chat' ? { kind: 'talk', prop: 'none' } : { kind: 'inspect', prop: 'none' };
    if (!pendingActivity.current && panel === 'story' && stateRef.current.story) {
      const story = stateRef.current.story;
      const activity = STORY_NODE_ACTIVITIES[story.id]?.[story.node];
      if (activity) pendingActivity.current = { ...activity, hotspotId: `story:${story.id}` };
    }
    // Closing a panel ends reading/inspection, but lets eating and completed actions finish.
    if (!activePanel) world.current?.cancelActivity({ retainTimed: true });
  }, [panel, tab]);
  useEffect(() => {
    setMusicScene(state.place);
    const owner = world.current;
    const destination = state.place;
    const arrival = pendingArrival.current;
    pendingArrival.current = null;
    const navigation = pendingNavigation.current;
    pendingNavigation.current = null;
    let cancelled = false;
    setWorldHover("");
    if (!owner) return;
    const arrive = (ready: boolean) => {
      if (cancelled || world.current !== owner || stateRef.current.place !== destination) return;
      if (!ready) {
        if (navigation?.place === destination && !pendingNavigation.current) pendingNavigation.current = navigation;
        return;
      }
      owner.setWorldFlags(stateRef.current.adventure.flags);
      if (navigation?.place === destination) {
        owner.focusHotspot(navigation.target);
        if (!owner.walkToHotspot(navigation.target, { interactOnArrival: true })) notify("这条路暂时没找到，试着走近发光标记。");
        setOverview(false);
      }
    };
    // The pending destination may differ while the visible world still matches,
    // as in A → B → A before B finishes. Always replace that pending switch.
    if (owner.transitioning || owner.getSnapshot().place !== destination || worldSceneError) {
      setWorldTransitioning(true);
      void owner.changePlace(destination, arrival ? { from: arrival } : { entry: "spawn" }).then(arrive);
    } else arrive(true);
    return () => { cancelled = true; };
  }, [state.place, travelAttempt]);
  useEffect(() => {
    world.current?.setWorldFlags(state.adventure.flags);
  }, [state.adventure.flags.join("|")]);
  useEffect(() => {
    world.current?.outfit(state.outfit);
  }, [state.outfit]);
  useEffect(() => {
    world.current?.setQuality(state.settings.lowQuality);
  }, [state.settings.lowQuality]);
  useEffect(() => {
    world.current?.act(
      state.reaction.motion,
      state.reaction.motion === "sleep" ? 7 : state.reaction.motion === "dance" ? 4.8 : 3.6,
      interruptPathForReaction.current,
    );
    interruptPathForReaction.current = false;
    if (interacted.current && state.settings.voice && !cyclingOpen)
      speak(
        state.reaction.text,
        state.reaction.quoteId,
        state.settings.volume,
        () => notify("这台设备暂时无法播放语音，文字对话仍可继续"),
      );
  }, [state.reaction.id]); // Only a new reply triggers voice; settings/ticks do not replay it.
  useEffect(() => {
    if (world.current?.transitioning || worldInputsBlocked) return;
    const activity = pendingActivity.current;
    pendingActivity.current = null;
    if (activity) world.current?.beginActivity(activity.kind, activity);
  }, [state.revision, panel, mini, tab, worldInputsBlocked]);
  useEffect(() => {
    if (!state.settings.voice) stopVoice();
  }, [state.settings.voice]);
  useEffect(() => {
    if (blockedSave.current) return;
    setSaved(false);
    const timer = setTimeout(() => {
      try {
        saveGame(state);
        setSaved(true);
        setStorageError("");
      } catch {
        setStorageError("自动保存失败。请在存档管理中导出 ZIP，避免进度丢失。");
      }
    }, 250);
    return () => clearTimeout(timer);
  }, [state]);
  useEffect(() => {
    const timer = setInterval(
      () => dispatchRef.current({ type: "tick" }),
      30000,
    );
    const flush = () => {
      if (!blockedSave.current) {
        try {
          saveGame(stateRef.current);
        } catch {
          /* The visible save error is reported on the next tick. */
        }
      }
    };
    const visibility = () => {
      if (document.hidden) {
        flush();
        stopVoice();
      }
    };
    window.addEventListener("pagehide", flush);
    window.addEventListener("hardfish:before-route", flush);
    document.addEventListener("visibilitychange", visibility);
    return () => {
      clearInterval(timer);
      flush();
      window.removeEventListener("pagehide", flush);
      window.removeEventListener("hardfish:before-route", flush);
      document.removeEventListener("visibilitychange", visibility);
    };
  }, []);
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(""), 4200);
    return () => clearTimeout(timer);
  }, [toast]);
  useEffect(() => {
    const el = messages.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [state.messages.length, state.reaction.id, tab, panel]);
  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if (isLoading) return;
      if (e.key === "Escape") { setCinematic(false); if(panel === "dbh")setPanel(""); return; }
      if (e.target instanceof HTMLElement && (e.target.closest("input,textarea,select,dialog") || e.target.isContentEditable)) return;
      if (e.key === "Enter" && !panel && !(e.target instanceof HTMLElement && e.target.closest("button,a,summary"))) { e.preventDefault(); setTab("chat"); setPanel("interact"); }
      if (e.key.toLowerCase() === "m" && !panel) setPanel("map");
      if (e.key.toLowerCase() === "j" && !panel) setPanel("adventure");
    };
    window.addEventListener("keydown",key);
    return () => window.removeEventListener("keydown",key);
  }, [panel, isLoading]);
  function startStory(id: string) {
    const story = stories.find(s => s.id === id);
    if (!story) return;
    if (!stateRef.current.story && stateRef.current.bond < story.minBond) {
      notify(`和难鱼的熟悉度达到 ${story.minBond} 后，就能开始这段故事。`);
      setTab("stories"); setPanel("interact"); return;
    }
    if (stateRef.current.story && stateRef.current.story.id !== id) { notify("先完成正在进行的故事，再开新的一篇"); }
    else { dispatch({type:"place",value:story.place}); if (!stateRef.current.story) dispatch({type:"startStory",value:id}); }
    setStoryEnd(null); setPanel("story");
  }
  function navigate(place: Place, hotspot: string) {
    const target = hotspot.startsWith('npc:') ? hotspot : `adventure:${hotspot}`;
    world.current?.setDbhConversation(false);
    setPanel(""); setGuide(false); setOverview(false);
    if (stateRef.current.place !== place || world.current?.transitioning || world.current?.getSnapshot().place !== place || worldSceneError) {
      pendingNavigation.current = { place, target };
      dispatch({ type: "place", value: place });
    } else {
      world.current?.focusHotspot(target);
      if (!world.current?.walkToHotspot(target, { interactOnArrival: true })) notify("这条路暂时没找到，试着走近发光标记。");
    }
  }
  async function photographWithDbh() {
    const owner=world.current,session=dbhSession.current;
    if(!owner?.getSnapshot().npc?.conversation)throw Error('请先回到 dbh 身边。');
    owner.playDbhAction('photo');
    await new Promise(resolve => setTimeout(resolve,900));
    if(world.current!==owner||dbhSession.current!==session||!owner.getSnapshot().npc?.conversation)throw Error('合影已取消。');
    const photo=owner.photographDbh();
    if(!photo)throw Error('合影暂时未能保存，请再试一次。');
    const link=document.createElement('a');
    link.download=`难鱼与dbh_${new Date().toISOString().slice(0,10)}.png`;
    link.href=photo;link.click();notify('合影已生成，可在下载中查看。');
  }
  function playAt(kind: GameKind, place: Place) {
    dispatch({ type: "place", value: place });
    openMini(kind);
  }
  function openMini(kind: GameKind) {
    miniSession.current = null;
    setMini(kind);
    setPanel("mini");
    if (kind === 'cycling') { pendingActivity.current = null; return; }
    const activity = GAME_ACTIVITIES[kind];
    // Before paying for a round she can look over the materials, without claiming a result.
    pendingActivity.current = { ...activity, kind: activity.kind === 'cook' ? 'inspect' : activity.kind, prop: activity.kind === 'cook' ? 'magnifier' : activity.prop };
  }
  function submit(message: string) {
    if (!message.trim()) return;
    dispatch({ type: "chat", text: message });
    setText("");
    setGuide(false);
  }
  function restore(next: GameState) {
    stopVoice();
    world.current?.cancelActivity();
    pendingActivity.current = null;
    interacted.current = false;
    blockedSave.current = false;
    setStorageError("");
    const restored = step(next, { type: "tick" });
    stateRef.current = restored;
    setState(restored);
    setNameDraft(restored.name);
  }
  function photo() {
    if (!world.current || world.current.transitioning || worldSceneError) {
      notify("3D 场景尚未准备好");
      return;
    }
    world.current.act('happy', 2.4, true);
    const link = document.createElement("a");
    link.href = world.current.photograph();
    link.download = `难鱼在${place.name}.png`;
    link.click();
    notify("合照已保存，今天也算来过了");
  }
  async function sticker(id: string) {
    const q = quoteMap[id],
      img = new Image();
    img.src = asset("avatar.png");
    try {
      await img.decode();
      const c = document.createElement("canvas");
      c.width = 600;
      c.height = 720;
      const ctx = c.getContext("2d")!;
      ctx.fillStyle = "#e9efeb";
      ctx.fillRect(0, 0, c.width, c.height);
      const width = (img.width / img.height) * 430;
      ctx.drawImage(img, (600 - width) / 2, 58, width, 430);
      ctx.fillStyle = "#294a3e";
      ctx.font = "bold 32px sans-serif";
      ctx.textAlign = "center";
      const lines = q.text.match(/.{1,14}/g) || [q.text];
      lines.forEach((line, i) => ctx.fillText(line, 300, 558 + i * 44));
      ctx.font = "16px sans-serif";
      ctx.fillText("我的群友难鱼 · 游戏原创语录贴纸", 300, 684);
      const a = document.createElement("a");
      a.href = c.toDataURL();
      a.download = `难鱼_${q.id}.png`;
      a.click();
      notify("语录贴纸已保存");
    } catch {
      notify("贴纸暂时生成失败，请重试");
    }
  }
  const currentStory =
    state.story && stories.find((s) => s.id === state.story!.id);
  const currentNode =
    currentStory && state.story ? currentStory.nodes[state.story.node] : null;
  const panelTitles: Record<Exclude<Panel, "">, string> = {
    dbh: "与 dbh 聊天",
    closet: "难鱼的衣柜",
    album: "我们的收藏册",
    saves: "存档管理",
    settings: "生活设置",
    help: "和难鱼相处指南",
    games: "今天玩点什么",
    story: storyEnd
      ? "这一段故事，记住了"
      : currentStory
        ? currentStory.title
        : "今天的故事",
    shop: "村口便利店",
    tasks: "今日小事",
    mini: "和难鱼玩一局",
    menu: "在难鱼的世界里",
    map: "今天，去哪儿？",
    interact: "和难鱼待一会儿",
    friends: "老母猪村 · 群友圈",
    adventure: "村民手帐",
    spot: EXPLORATION_SPOTS.find(spot => spot.id === spotId)?.label || "停下来看看",
  };

  function taskList() {
    return (
      <div className="task-list">
        {dailyTasks.map((t) => {
          const count = Math.min(state.daily.counts[t.id], t.target),
            complete = count >= t.target,
            claimed = state.daily.claimed.includes(t.id);
          return (
            <div className={`task ${claimed ? "claimed" : ""}`} key={t.id}>
              <span className="task-check">
                {claimed ? <Check size={19} /> : <ListChecks size={20} />}
              </span>
              <div>
                <b>{t.label}</b>
                <small>
                  {count} / {t.target} · 奖励 {t.reward} 贝壳
                </small>
              </div>
              <button
                className={
                  complete && !claimed ? "primary small" : "text-button"
                }
                disabled={!complete || claimed}
                onClick={() => dispatch({ type: "claim", value: t.id })}
              >
                {claimed ? "已领取" : complete ? "领取" : "进行中"}
              </button>
            </div>
          );
        })}
        <p className="fine-print">
          每日按设备本地日期刷新。离开游戏不会失去熟悉度。
        </p>
      </div>
    );
  }

  return (
    <div className={`app-shell immersive ${panel === "dbh" ? "dbh-open" : ""} ${cinematic ? "cinematic" : ""} ${state.settings.lowQuality ? "low-quality" : ""}`} aria-busy={isLoading} onClickCapture={(e) => {
      unlockAudio();
      if ((e.target as HTMLElement).closest("button:not(:disabled)")) playEffect("click");
    }}>
      <main className="world-stage" aria-label="难鱼的日常" aria-busy={worldTransitioning}>
        <div className="scene-host" ref={sceneHost} data-testid="scene" inert={isLoading || worldInputsBlocked} data-loading={isLoading} />
        {worldError && <div className="world-fallback">
          <img src={asset("avatar.png")} alt="难鱼的原始形象" />
          <p>3D 世界暂时未能打开，请启用浏览器硬件加速。<br />聊天、剧情和存档仍然可以使用。</p>
        </div>}
        <div className="world-vignette" />
      </main>
      {!isLoading && !cyclingOpen && worldTransitioning && <SceneTransitionIndicator label={`正在前往${place.name}…`} className="world-scene-transition" />}
      {!isLoading && !cyclingOpen && worldSceneError && !worldTransitioning && <div className="world-scene-error" role="alert">
        <span>{worldSceneError}</span>
        <button onClick={() => setTravelAttempt(attempt => attempt + 1)}>重试</button>
        <button onClick={() => setPanel("map")}>换个地点</button>
      </div>}
      {isLoading && <LoadingScreen progress={resourceProgress} worldReady={worldReady || worldError} failed={resourceFailures} onRetry={() => setLoadAttempt(n => n + 1)} onContinue={() => { setResourcesReady(true); notify("部分声音或图片没能加载，仍可游玩；重新打开可再试一次。"); }} />}
      <div className="game-hud" inert={isLoading || panel === "dbh"} style={isLoading ? { visibility: "hidden" } : undefined}>
        <header className="hud-top">
          <div className="hud-identity">
            <h1>我的群友<span>难鱼</span><i>。</i></h1>
            <button className="location-chip" onClick={() => setPanel("map")} aria-label="打开地图">
              <MapPin size={15} weight="fill" />{place.name}<span>在一起的第 {day} 天</span><CaretRight size={14} />
            </button>
          </div>
          <div className="hud-utilities">
            <button className="hud-wallet" onClick={() => setPanel("shop")} aria-label={`贝壳余额 ${state.shells}，打开便利店`}>
              <Waves size={20} /><b data-testid="shells">{state.shells}</b><Plus size={13} />
            </button>
            <button className="hud-icon voice-toggle" aria-label={state.settings.voice ? "关闭语音" : "开启语音"} onClick={() => dispatch({type:"settings",value:{voice:!state.settings.voice}})}>
              {state.settings.voice ? <SpeakerHigh size={21} /> : <SpeakerSlash size={21} />}
            </button>
            <button className={`hud-icon music-toggle ${audioPreferences.music ? "" : "music-off"}`} aria-label={audioPreferences.music ? "关闭背景音乐" : "开启背景音乐"} title={`${place.name} · ${musicCatalog[state.place].title}`} aria-pressed={audioPreferences.music} onClick={() => changeAudioPreferences({ music: !audioPreferences.music })}><MusicNotes size={21} /></button>
            <button className="hud-icon" aria-label="打开生活菜单" onClick={() => setPanel("menu")}><List size={23} /></button>
          </div>
        </header>
        <section className="fish-status" aria-label="难鱼状态">
          <img src={asset("avatar.png")} alt="" />
          <div className="status-content">
            <div className="status-name"><b>难鱼</b><span>{relationship(state.bond)}</span></div>
            <div className="compact-needs">
              {([
                ["hunger", "饱腹", ForkKnife, "#d1a15d"],
                ["mood", "心情", Smiley, "#be8068"],
                ["energy", "精力", Lightning, "#74957b"],
                ["bond", "熟悉度", Heart, "#be838e"],
              ] as const).map(([key,label,Icon,color]) => <div key={key} className="compact-need" title={`${label} ${Math.round(state[key])}/100`}>
                <Icon size={13} /><div className="compact-meter" role="meter" aria-label={label} aria-valuenow={Math.round(state[key])} aria-valuemin={0} aria-valuemax={100}><i style={{width:`${state[key]}%`,background:color}} /></div>
                <span data-testid={key}>{Math.round(state[key])}</span>
              </div>)}
            </div>
          </div>
        </section>
        {storageError && <div className="storage-alert" role="alert">{storageError}<button onClick={() => setPanel("saves")}>打开存档管理</button></div>}
        <button className="world-invitation quest-tracker" aria-label="打开村民手帐" onClick={() => setPanel("adventure")}>
          <span className="invitation-icon"><Flag size={21} /></span><span><small>{adventure.tracked ? `正在一起做 · ${adventure.tracked.completedStages + 1}/${adventure.tracked.quest.stages.length}` : "村里今天，慢慢逛"}</small><b>{adventure.tracked?.quest.title || "都办妥了，看看共同回忆"}</b>{adventure.tracked?.stage && <span className="tracker-next">{places.find(place => place.id === adventure.tracked!.stage!.place)?.name} · {adventure.tracked.stage.title}</span>}</span><CaretRight size={17} />
        </button>
        {worldReady && !panel && <div inert={worldInputsBlocked}><WorldControls world={world} enabled={!cinematic && !worldInputsBlocked} /></div>}
        {worldReady && !panel && !cinematic && state.place === 'village' && <button className="dbh-find" onClick={() => navigate('village','npc:dbh')}><ChatCircleDots size={18}/><span>去找 dbh<small>钟楼旁 · 村中友人</small></span><CaretRight size={16}/></button>}
        {worldHover && !worldInputsBlocked && <div className="world-hover"><Hand size={14}/>{worldHover}<span>点击互动</span></div>}
        <div className="world-tools">
          <button className="hud-icon" aria-label="拍张难鱼的照片" disabled={worldInputsBlocked} onClick={photo}><Camera size={21} /></button>
          <button className="hud-icon" aria-label="重置视角" disabled={worldInputsBlocked} onClick={() => world.current?.resetCamera()}><ArrowCounterClockwise size={20} /></button>
          <button className="hud-icon overview-switch" aria-label={overview ? "跟随难鱼" : "俯瞰这片区域"} disabled={worldInputsBlocked} onClick={() => { const next = !overview; setOverview(next); world.current?.setCameraMode(next ? "overview" : "follow"); }}><Binoculars size={20} /></button>
          <button className="hud-icon" aria-label="隐藏界面欣赏风景" onClick={() => setCinematic(true)}><CornersOut size={20} /></button>
        </div>
        {guide && <div className="explore-guide"><Hand size={16}/><span>点地面，她会走过去。拖动画面，看看这个家。</span><button aria-label="收起新手提示" onClick={() => setGuide(false)}><X size={15}/></button></div>}
        <div className="bottom-hud">
          <div className="world-dialogue" key={state.reaction.id} aria-live="polite">
            <div className="dialogue-speaker"><span>难鱼</span><small>{state.reaction.motion === "angry" ? "攻击性上线" : state.reaction.motion === "sleep" ? "暂时休战" : "本人在线"}</small></div>
            <p>{state.reaction.text}</p>
            <button className="dialogue-voice" aria-label="重播这句语音" onClick={() => speak(state.reaction.text,state.reaction.quoteId,state.settings.volume,() => notify("语音暂时无法播放"))}><SpeakerHigh size={18}/></button>
          </div>
          <nav className="action-dock" aria-label="陪伴操作">
            <button onClick={() => {setTab("chat");setPanel("interact");}}><ChatCircleDots size={23}/><span>聊聊天</span><kbd>Enter</kbd></button>
            <button onClick={() => {dispatch({type:"interact",value:"pet"});setGuide(false);}}><Hand size={23}/><span>摸摸脑袋</span></button>
            <button onClick={() => {setTab("food");setPanel("interact");}}><ForkKnife size={23}/><span>给她投喂</span></button>
            <button onClick={() => setPanel("friends")}><UsersThree size={23}/><span>群友圈</span></button>
          </nav>
        </div>
        <div className="world-bottom-left"><button className="map-button" onClick={() => setPanel("map")}><MapTrifold size={23}/><span>去逛逛</span></button><span className="movement-hint">W A S D 走动 · E 互动 · J 手帐 · M 地图</span></div>
        <button className="world-save" onClick={() => setPanel("saves")}><CheckCircle size={13}/>{storageError ? "保存待处理" : saved ? "进度已保存" : "保存中…"}</button>
      </div>
      {cinematic && <button className="return-hud" onClick={() => setCinematic(false)}><CornersIn size={19}/>返回游戏</button>}
      {toast && (
        <div className="toast" role="status">
          <CheckCircle size={19} />
          <span>{toast}</span>
        </div>
      )}
      {panel === 'dbh' && <DbhPanel
        state={state.dbh}
        onChange={value => dispatch({type:'dbh',value})}
        onClose={() => setPanel('')}
        onAction={action => {
          world.current?.playDbhAction(action);
          if(action === 'dance')world.current?.act('dance',8);
          else if(action === 'cheer')world.current?.act('happy',4);
        }}
        onTravel={(place,hotspot) => {
          if(hotspot)navigate(place,hotspot);
          else {setPanel('');world.current?.setDbhConversation(false);dispatch({type:'place',value:place});}
        }}
        onPhoto={photographWithDbh}
      />}
      {panel && panel !== "dbh" && (
        <Modal
          title={cyclingOpen ? '难鱼骑自行车' : panelTitles[panel]}
          onClose={() => setPanel("")}
          wide={panel === "album" || panel === "closet" || panel === "map" || panel === "friends" || panel === "adventure"}
          activity={!cyclingOpen && ['spot', 'mini', 'story', 'shop', 'closet', 'interact', 'friends'].includes(panel)}
          cycling={cyclingOpen}
        >
          {panel === "interact" && (
          <section
            className="companion-panel"
            id="interaction-panel"
            aria-label="和难鱼互动"
          >
            <div className="companion-heading">
              <div className="portrait">
                <img src={asset("avatar.png")} alt="难鱼" />
              </div>
              <div>
                <h2>
                  难鱼 <span>本人在线</span>
                </h2>
                <p>{relationship(state.bond)}</p>
              </div>
              <Heart className="heading-heart" size={25} weight="duotone" />
            </div>
            <div className="panel-tabs" role="tablist" aria-label="互动类型">
              {(
                [
                  ["chat", "聊聊天", ChatCircleDots],
                  ["food", "零食袋", ForkKnife],
                  ["stories", "小故事", BookOpen],
                ] as const
              ).map(([id, label, Icon]) => (
                <button
                  key={id}
                  role="tab"
                  id={`tab-${id}`}
                  aria-controls={`pane-${id}`}
                  aria-selected={tab === id}
                  tabIndex={tab === id ? 0 : -1}
                  onKeyDown={(e) => {
                    if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
                      e.preventDefault();
                      const keys: Tab[] = ["chat", "food", "stories"];
                      const next =
                        keys[
                          (keys.indexOf(tab) +
                            (e.key === "ArrowRight" ? 1 : 2)) %
                            3
                        ];
                      setTab(next);
                      document.getElementById(`tab-${next}`)?.focus();
                    }
                  }}
                  onClick={() => setTab(id)}
                >
                  <Icon size={17} />
                  {label}
                </button>
              ))}
            </div>
            {tab === "chat" && (
              <div
                role="tabpanel"
                aria-labelledby="tab-chat"
                id="pane-chat"
                className="chat-pane"
              >
                <div
                  className="chat-history"
                  ref={messages}
                  role="log"
                  aria-label="聊天记录"
                >
                  <div className="chat-date">今天 · 有空就来唠两句</div>
                  {state.messages.slice(-30).map((m, i) => (
                    <div className={`message ${m.who}`} key={`${m.at}-${i}`}>
                      {m.who === "fish" && (
                        <img
                          className="message-avatar"
                          src={asset("avatar.png")}
                          alt=""
                        />
                      )}
                      <div>
                        <span className="message-name">
                          {m.who === "fish" ? "难鱼" : state.name}
                        </span>
                        <div className="message-bubble">{m.text}</div>
                        {m.who === "fish" && (
                          <div className="message-tools">
                            <button
                              aria-label={`播放语音：${m.text}`}
                              onClick={() =>
                                speak(m.text, m.quoteId, state.settings.volume)
                              }
                            >
                              <SpeakerHigh size={14} />
                            </button>
                            {m.quoteId && (
                              <button
                                onClick={() => {
                                  setSelectedQuote(m.quoteId!);
                                  setPanel("album");
                                  setAlbumTab("quotes");
                                }}
                              >
                                原话小记
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="chat-bottom">
                  <div className="quick-talk">
                    {["今天想玩什么", "夸你一句", "你好可爱", "放假好无聊"].map(
                      (s, i) => (
                        <button
                          key={s}
                          onClick={() =>
                            i === 1
                              ? dispatch({ type: "interact", value: "praise" })
                              : submit(s)
                          }
                        >
                          {s}
                        </button>
                      ),
                    )}
                  </div>
                  <form
                    className="chat-form"
                    onSubmit={(e) => {
                      e.preventDefault();
                      submit(text);
                    }}
                  >
                    <input
                      aria-label="给难鱼发消息"
                      value={text}
                      maxLength={200}
                      onChange={(e) => setText(e.target.value)}
                      placeholder="跟难鱼说点什么…"
                      autoComplete="off"
                    />
                    <button
                      type="submit"
                      aria-label="发送消息"
                      disabled={!text.trim()}
                    >
                      <PaperPlaneRight size={21} weight="fill" />
                    </button>
                  </form>
                  <div className="chat-footer">
                    <span>她会接梗，也会嘴硬。</span>
                    <button
                      onClick={() => { dispatch({ type: "interact", value: "tease" }); setPanel(""); }}
                    >
                      故意逗她一下 <Sparkle size={12} />
                    </button>
                  </div>
                </div>
              </div>
            )}
            {tab === "food" && (
              <div
                role="tabpanel"
                aria-labelledby="tab-food"
                id="pane-food"
                className="food-pane"
              >
                <p className="panel-intro">
                  吃饱了，才有力气跟你斗嘴。
                  <br />
                  <span>饱腹低于 98 时可以投喂。</span>
                </p>
                <div className="food-list">
                  {foods.map((f) => (
                    <div className="food-row" key={f.id}>
                      <FoodArt id={f.id} />
                      <div>
                        <b>
                          {f.name}
                          <small>×{state.inventory[f.id]}</small>
                        </b>
                        <p>
                          饱腹 +{f.hunger} · 精力 +{f.energy}
                        </p>
                      </div>
                      <button
                        className="feed-button"
                        aria-label={`投喂${f.name}`}
                        disabled={!state.inventory[f.id] || state.hunger >= 98}
                        onClick={() => { dispatch({ type: "feed", value: f.id }); setPanel(""); }}
                      >
                        投喂
                      </button>
                    </div>
                  ))}
                </div>
                <button
                  className="secondary wide"
                  onClick={() => {
                    dispatch({ type: "place", value: "shop" });
                    setPanel("shop");
                  }}
                >
                  <Storefront size={18} />
                  去便利店补货
                  <CaretRight size={16} />
                </button>
                <button
                  className="text-button wide"
                  onClick={() => {
                    dispatch({ type: "place", value: "kitchen" });
                    openMini("cook");
                  }}
                >
                  自己做饭也可以，去厨房试试
                </button>
              </div>
            )}
            {tab === "stories" && (
              <div
                role="tabpanel"
                aria-labelledby="tab-stories"
                id="pane-stories"
                className="stories-pane"
              >
                <p className="panel-intro">
                  一起发生的小事，后来都成了故事。
                  <br />
                  <span>
                    已发现 {state.endings.length} 个结局 · 不同选择有不同走向
                  </span>
                </p>
                {state.story && (
                  <button
                    className="resume-story"
                    onClick={() => {
                      setStoryEnd(null);
                      setPanel("story");
                    }}
                  >
                    <BookOpen size={20} />
                    继续上次的故事
                    <CaretRight size={18} />
                  </button>
                )}
                <div className="story-list">
                  {stories.map((story) => {
                    const locked = state.bond < story.minBond,
                      Icon = placeIcons[story.place],
                      ends = state.endings.filter((e) =>
                        e.startsWith(story.id + ":"),
                      ).length;
                    return (
                      <button
                        key={story.id}
                        className={`story-preview ${locked ? "locked" : ""}`}
                        disabled={locked}
                        onClick={() => {
                          if (state.story && state.story.id !== story.id) {
                            notify("先完成正在进行的故事，再开新的一篇");
                            setStoryEnd(null);
                            setPanel("story");
                            return;
                          }
                          dispatch({ type: "place", value: story.place });
                          if (!state.story)
                            dispatch({ type: "startStory", value: story.id });
                          setStoryEnd(null);
                          setPanel("story");
                        }}
                      >
                        <span className="story-icon">
                          <Icon size={23} />
                        </span>
                        <div>
                          <small>
                            {story.tag} ·{" "}
                            {places.find((p) => p.id === story.place)!.name}
                          </small>
                          <h3>{story.title}</h3>
                          <p>
                            {locked
                              ? `熟悉度 ${story.minBond} 解锁`
                              : ends
                                ? `已发现 ${ends} 个结局，再走另一条路`
                                : story.intro}
                          </p>
                        </div>
                        {locked ? (
                          <LockKey size={18} />
                        ) : (
                          <CaretRight size={18} />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
            <div className="panel-footnote">
              <FishSimple size={17} />
              <span>难鱼在这儿，你也在这儿。</span>
              <span>{totalInteractions} 次陪伴</span>
            </div>
          </section>
          )}
          {panel === "menu" && <>
            <p className="menu-greeting">今天也一起，理直气壮地摸鱼。</p>
            <div className="life-menu">
              {([
                ["adventure","村民手帐","委托、发现和村中记事",Flag],
                ["map","去逛逛","九片街区，沿路去看看",MapTrifold],
                ["closet","衣柜","换个心情出门",CoatHanger],
                ["games","一起玩吧","词卡、回收，还有老三样",GameController],
                ["friends","群友圈","老母猪村的熟面孔",UsersThree],
                ["album","收藏","原话、日记与小成就",BookOpen],
                ["tasks","今日小事","领走今天的贝壳",ListChecks],
                ["saves","存档","把今天好好存下来",FloppyDisk],
                ["settings","设置","声音与画面，随你喜欢",GearSix],
              ] as const).map(([id,label,note,Icon]) => <button key={id} onClick={() => setPanel(id)} aria-label={label}><Icon size={25}/><b>{label}</b><small>{note}</small></button>)}
            </div>
            <div className="menu-actions">
              <button className="secondary" onClick={() => {dispatch({type:"interact",value:"wave"});setPanel("");}}><Hand size={19}/>打个招呼</button>
              <button className="secondary" onClick={() => {dispatch({type:"interact",value:"rest"});setPanel("");}}><Moon size={19}/>歇一会儿</button>
              <button className="secondary" onClick={() => {dispatch({type:"interact",value:"dance"});setPanel("");}}><Sparkle size={19}/>叫她摇一个</button>
              <button className="text-button" onClick={() => setPanel("help")}><Info size={18}/>相处指南</button>
            </div>
          </>}
          {panel === "map" && <><button className="dbh-map-meet" onClick={() => navigate("village", "npc:dbh")}><ChatCircleDots size={24}/><span><b>dbh 在村中心等你</b><small>去钟楼旁聊聊天、做手工，或接下散步小约定。</small></span><CaretRight size={20}/></button><VillageAtlas state={state} targetPlace={adventure.tracked?.stage?.place} travel={place => {pendingNavigation.current = null; dispatch({type:"place",value:place});setPanel("");setGuide(false);}} /></>}
          {panel === "adventure" && <AdventurePanel state={state} dispatch={dispatch} navigate={navigate} play={playAt} story={startStory} />}
          {panel === "spot" && <SpotPanel key={spotId} spotId={spotId} state={state} dispatch={dispatch} navigate={navigate} play={playAt} story={startStory} />}
          {panel === "friends" && <>
            <div className="friends-intro"><UsersThree size={34}/><div><h3>熟人局，嘴上可不客气。</h3><p>群里的老称呼，生活里的新故事。</p></div></div>
            <div className="friend-list">{friends.map(friend => {
              const related=stories.filter(s=>friend.storyIds.includes(s.id));
              const count=state.endings.filter(e=>friend.storyIds.some(id=>e.startsWith(id+":"))).length;
              return <article className="friend-card" key={friend.id}>
                <div className="friend-heading"><span className="friend-avatar" style={{background:friend.color}}>{friend.name.slice(0,1)}</span><div><h3>{friend.name}</h3><span>{friend.role}</span></div><small>{count ? `${count} 段共同回忆` : "老母猪村群友"}</small></div>
                <p>{friend.summary}</p>
                <div className="friend-quote"><ChatCircleDots size={17}/><span>难鱼：{friend.quote}</span></div>
                <div className="friend-stories">{related.map(story => <button key={story.id} disabled={state.bond<story.minBond} onClick={()=>startStory(story.id)}><BookOpen size={16}/>{story.title}{state.bond<story.minBond ? <small>熟悉度 {story.minBond}</small> : <CaretRight size={14}/>}</button>)}</div>
                <button className="text-button" onClick={()=>{submit(`聊聊${friend.name}`);setTab("chat");setPanel("interact");}}>跟难鱼聊聊{friend.name}<ChatCircleDots size={16}/></button>
                <details className="source-note"><summary>称呼与互动来历</summary><p>{friend.source}</p><p>取自群聊的互动原型；游戏中的场景、邀约和后续为改编。</p></details>
              </article>;
            })}</div>
          </>}
          {panel === "closet" && (
            <>
              <p className="muted">
                轮廓还是那条鱼，今天换个心情。购买后会直接穿上。
              </p>
              <div className="closet-grid">
                {outfits.map((o) => (
                  <div
                    className={`outfit-card ${state.outfit === o.id ? "equipped" : ""}`}
                    key={o.id}
                  >
                    <div
                      className={`outfit-art outfit-${o.id}`}
                      style={{ "--outfit-color": o.color } as CSSProperties}
                    >
                      <img src={asset("avatar.png")} alt="" />
                      <span className="outfit-accessory" />
                      {state.outfit === o.id && (
                        <span className="equipped-label">
                          <Check size={13} />
                          穿着呢
                        </span>
                      )}
                    </div>
                    <div className="outfit-info">
                      <h3>{o.name}</h3>
                      <p>{o.note}</p>
                      <button
                        className={
                          state.owned.includes(o.id)
                            ? "secondary wide"
                            : "primary wide"
                        }
                        disabled={
                          state.outfit === o.id ||
                          (!state.owned.includes(o.id) &&
                            state.shells < o.price)
                        }
                        onClick={() =>
                          dispatch({ type: "outfit", value: o.id })
                        }
                      >
                        {state.outfit === o.id
                          ? "当前装扮"
                          : state.owned.includes(o.id)
                            ? "换上这件"
                            : `${o.price} 贝壳 · 买下并换上`}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              <p className="fine-print">
                装扮会直接显示在场景里的 3D 难鱼身上。
              </p>
            </>
          )}
          {panel === "shop" && (
            <>
              <div className="shop-banner">
                <Storefront size={38} />
                <div>
                  <h3>村口小店，熟人也不赊账。</h3>
                  <p>
                    口袋里还有 <b>{state.shells}</b> 贝壳
                  </p>
                </div>
              </div>
              <div className="shop-list">
                {foods.map((f) => (
                  <div className="shop-row" key={f.id}>
                    <FoodArt id={f.id} />
                    <div>
                      <h3>{f.name}</h3>
                      <p>{f.note}</p>
                      <small>袋子里还有 {state.inventory[f.id]} 份</small>
                    </div>
                    <button
                      className="secondary"
                      aria-label={`购买${f.name} ${f.price}贝壳`}
                      disabled={
                        state.shells < f.price || state.inventory[f.id] >= 99
                      }
                      onClick={() => dispatch({ type: "buyFood", value: f.id })}
                    >
                      <Plus size={15} />
                      {f.price} 贝壳
                    </button>
                  </div>
                ))}
              </div>
              <button
                className="text-button wide"
                onClick={() => setPanel("closet")}
              >
                再去看看衣柜 <CoatHanger size={18} />
              </button>
            </>
          )}
          {panel === "games" && (
            <>
              <p className="muted">
                玩得怎么样都能赚贝壳。精力不够就歇一会儿，再一起出发。
              </p>
              <div className="game-menu">
                {(
                  [
                    ['cycling', '难鱼骑自行车', '独立村外环线', Bicycle, '骑上自行车捡井盖，绕开空井，多视角兜风拿奖励。', 'park'],
                    ["words", "词卡接力", "联机工坊", BookOpen, "看村里的东西学单词，答错也可以一起学会。", "workshop"],
                    ["harvest", "浆果回收", "联机工坊", Basket, "照订单分装浆果和种子，不限时，装错可退。", "workshop"],
                    [
                      "bottle",
                      "漂流瓶记忆",
                      "公园",
                      Waves,
                      "找到 6 对难鱼原话，考考你的记性。",
                      "park",
                    ],
                    [
                      "cook",
                      "火候刚刚好",
                      "厨房",
                      CookingPot,
                      "盯紧绿色区域，带两份炒饭回家。",
                      "kitchen",
                    ],
                    [
                      "math",
                      "五题就下课",
                      "教室",
                      GraduationCap,
                      "不用赶时间，五道口算陪她慢慢做。",
                      "school",
                    ],
                  ] as const
                ).map(([id, title, location, Icon, desc, p]) => (
                  <button
                    className="game-menu-item"
                    key={id}
                    onClick={() => {
                      if (id !== 'cycling') dispatch({ type: "place", value: p });
                      openMini(id);
                    }}
                  >
                    <span>
                      <Icon size={32} />
                    </span>
                    <div>
                      <small>
                        {location} · 最高 {state.records[id]} 分
                      </small>
                      <h3>{title}</h3>
                      <p>{desc}</p>
                    </div>
                    <CaretRight size={20} />
                  </button>
                ))}
              </div>
              <button
                className="text-button wide"
                onClick={() => { dispatch({ type: "interact", value: "dance" }); setPanel(""); }}
              >
                <Sparkle size={18} />
                不想动脑？叫难鱼摇一个
              </button>
            </>
          )}
          {panel === "mini" && <>
            <MiniGame
              kind={mini}
              key={mini}
              lowQuality={state.settings.lowQuality}
              outfit={state.outfit}
              onExit={() => setPanel('')}
              voiceEnabled={state.settings.voice}
              voiceVolume={state.settings.volume}
              effectsEnabled={audioPreferences.effects}
              onStart={(difficulty) => {
                if (stateRef.current.energy < 8) {
                  notify("精力不足，先歇一会儿");
                  return false;
                }
                const next = dispatch({ type: "startGame", value: mini, difficulty });
                miniSession.current = next.activeGame?.id || null;
                return !!miniSession.current;
              }}
              onFinish={(score) =>
                dispatch({ type: "finishGame", value: mini, score, sessionId: miniSession.current || "" })
              }
              onInteraction={() => {
                if (stateRef.current.activeGame?.id !== miniSession.current || stateRef.current.activeGame?.kind !== mini) return;
                const activity = GAME_ACTIVITIES[mini];
                world.current?.beginActivity(activity.kind, activity);
              }}
            />
            {!cyclingOpen && adventure.tracked?.stage && <button className="text-button wide" onClick={() => navigate(adventure.tracked!.stage!.place, adventure.tracked!.stage!.hotspot)}><Compass size={17} />回到委托现场</button>}
          </>}
          {panel === "story" && (
            <>
              {storyEnd ? (
                <div className="story-ending">
                  <Sparkle size={38} />
                  <span className="eyebrow">已记进我们的日记</span>
                  <h3>{storyEnd.title}</h3>
                  <p>{storyEnd.text}</p>
                  {storyEnd.quote && (
                    <blockquote>“{quoteMap[storyEnd.quote].text}”</blockquote>
                  )}
                  <button
                    className="primary wide"
                    onClick={() => {
                      setPanel("interact");
                      setTab("stories");
                      setStoryEnd(null);
                    }}
                  >
                    继续一起过日子
                  </button>
                </div>
              ) : currentStory && currentNode ? (
                <div className="story-reader">
                  <div className="story-scene-label">
                    <MapPin size={15} />
                    {
                      places.find((p) => p.id === currentStory.place)!.name
                    } · {currentStory.tag}
                  </div>
                  <img
                    className="story-portrait"
                    src={asset("avatar.png")}
                    alt="难鱼正在等你的回答"
                  />
                  <p className="story-narration">{currentNode.text}</p>
                  {currentNode.quote && (
                    <blockquote>
                      “{quoteMap[currentNode.quote].text}”
                      <button
                        aria-label="播放剧情原话"
                        onClick={() =>
                          speak(
                            quoteMap[currentNode.quote!].text,
                            currentNode.quote,
                            state.settings.volume,
                          )
                        }
                      >
                        <SpeakerHigh size={18} />
                      </button>
                    </blockquote>
                  )}
                  <div className="story-choices">
                    {currentNode.choices?.map((c) => (
                      <button
                        className="story-choice"
                        key={c.next}
                        onClick={() => {
                          const end = currentStory.nodes[c.next];
                          dispatch({ type: "choice", value: c.next });
                          if (end.ending)
                            setStoryEnd({
                              title: end.ending,
                              text: end.text,
                              quote: end.quote,
                            });
                        }}
                      >
                        {c.label}
                        <CaretRight size={18} />
                      </button>
                    ))}
                  </div>
                  <details className="source-note">
                    <summary>这一篇从哪里来</summary>
                    <p>{currentStory.source} 场景与后续发展为游戏创作。</p>
                  </details>
                  <p className="fine-print">
                    可以随时关掉窗口，当前选择已自动保存。
                  </p>
                </div>
              ) : (
                <div className="empty-state">
                  <BookOpen size={40} />
                  <p>在「小故事」里选一篇，和难鱼一起开始。</p>
                  <button
                    className="primary"
                    onClick={() => {
                      setPanel("interact");
                      setTab("stories");
                    }}
                  >
                    去挑一个故事
                  </button>
                </div>
              )}
            </>
          )}
          {panel === "tasks" && taskList()}
          {panel === "album" && (
            <>
              <div className="segmented">
                {(
                  [
                    ["quotes", "语录贴纸"],
                    ["journal", "一起的日记"],
                    ["achievements", "小小成就"],
                  ] as const
                ).map(([id, label]) => (
                  <button
                    key={id}
                    aria-pressed={albumTab === id}
                    className={albumTab === id ? "active" : ""}
                    onClick={() => setAlbumTab(id)}
                  >
                    {label}
                  </button>
                ))}
              </div>
              {albumTab === "quotes" && (
                <>
                  <div className="album-intro">
                    <div>
                      <h3>她说过的话，都留着。</h3>
                      <p>
                        已遇见 {state.collected.length} / {quotes.length}{" "}
                        句。继续聊天、探索、逗她，遇见更多原话。
                      </p>
                    </div>
                    <button
                      className="secondary small"
                      onClick={() => {
                        const next = dispatch({ type: "recall" });
                        setSelectedQuote(next.reaction.quoteId || null);
                      }}
                    >
                      翻一页旧日常
                    </button>
                  </div>
                  {selectedQuote && (
                    <div className="quote-detail">
                      <button
                        className="quote-detail-close icon-button"
                        aria-label="收起原话小记"
                        onClick={() => setSelectedQuote(null)}
                      >
                        <X size={17} />
                      </button>
                      <span className="eyebrow">
                        原话小记 · {quoteMap[selectedQuote].date}
                      </span>
                      <h3>“{quoteMap[selectedQuote].text}”</h3>
                      <p>{quoteMap[selectedQuote].context}</p>
                      <small>
                        完整记录中，纯文字相同的发言共{" "}
                        {quoteMap[selectedQuote].count} 条。
                      </small>
                      <div className="button-row">
                        <button
                          className="text-button"
                          onClick={() =>
                            speak(
                              quoteMap[selectedQuote].text,
                              selectedQuote,
                              state.settings.volume,
                            )
                          }
                        >
                          <SpeakerHigh size={18} />
                          听听这句
                        </button>
                        <button
                          className="text-button"
                          onClick={() => void sticker(selectedQuote)}
                        >
                          <DownloadSimple size={18} />
                          保存语录贴纸
                        </button>
                      </div>
                    </div>
                  )}
                  <div className="quote-grid">
                    {quotes.map((q, i) => {
                      const got = state.collected.includes(q.id);
                      return (
                        <button
                          className={`quote-card ${got ? "unlocked" : ""}`}
                          key={q.id}
                          disabled={!got}
                          onClick={() => setSelectedQuote(q.id)}
                        >
                          {got ? (
                            <>
                              <img src={asset("avatar.png")} alt="" />
                              <b>{q.text}</b>
                              <span>
                                查看原话小记 <CaretRight size={12} />
                              </span>
                            </>
                          ) : (
                            <>
                              <LockKey size={21} />
                              <span>未遇见的第 {i + 1} 句话</span>
                            </>
                          )}
                        </button>
                      );
                    })}
                  </div>
                  <p className="fine-print">
                    贴纸由参考形象与原话制作，是游戏原创作品。没有把未恢复的 QQ
                    表情伪称为原始附件。
                  </p>
                </>
              )}
              {albumTab === "journal" && (
                <div className="journal-list">
                  {[...state.journal].reverse().map((j, i) => (
                    <article key={`${j.at}-${i}`}>
                      <span>{timestamp(j.at)}</span>
                      <p>{j.text}</p>
                    </article>
                  ))}
                </div>
              )}
              {albumTab === "achievements" && (
                <div className="achievement-list">
                  {achievementInfo.map((a) => (
                    <div
                      className={`achievement ${state.achievements.includes(a.id) ? "earned" : ""}`}
                      key={a.id}
                    >
                      <Trophy
                        size={30}
                        weight={
                          state.achievements.includes(a.id) ? "fill" : "regular"
                        }
                      />
                      <div>
                        <h3>{a.title}</h3>
                        <p>{a.text}</p>
                      </div>
                      <span>
                        {state.achievements.includes(a.id)
                          ? "已达成"
                          : `+${a.reward} 贝壳`}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
          {panel === "saves" && (
            <SaveManager
              state={state}
              restore={restore}
              notify={notify}
              allowSave={() => {
                blockedSave.current = false;
                setStorageError("");
                setSaved(true);
              }}
            />
          )}
          {panel === "settings" && (
            <div className="settings-list">
              <label className="setting-row">
                <div><b>背景音乐</b><p>每个地方，一首纯音乐。说话时轻一点，开关会记住。</p></div>
                <input type="checkbox" checked={audioPreferences.music} onChange={e => changeAudioPreferences({ music: e.target.checked })} />
              </label>
              <label className="volume-setting">
                <span>音乐音量 <b>{Math.round(audioPreferences.musicVolume * 100)}%</b></span>
                <input aria-label="音乐音量" type="range" min="0" max="1" step="0.05" value={audioPreferences.musicVolume} onChange={e => changeAudioPreferences({ musicVolume: Number(e.target.value) })} />
              </label>
              <div className="scene-music-info">
                <MusicNotes size={22} aria-hidden="true" />
                <div><small>{place.name}的背景音乐</small><b data-testid="current-music-title">{musicCatalog[state.place].title}</b><p>{musicCatalog[state.place].description}</p></div>
              </div>
              <details className="music-credits">
                <summary>音乐名单与署名 · {places.length} 首</summary>
                <p>场景音乐由 Kevin MacLeod 创作，取自 incompetech.com，采用 <a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noopener noreferrer">CC BY 4.0</a> 许可。游戏版本做了片段裁剪、音量调整与首尾淡化。</p>
                <ul>{places.map(p => {
                  const track = musicCatalog[p.id];
                  return <li key={p.id}><span>{p.name}</span><div><a href={track.source} target="_blank" rel="noopener noreferrer">{track.title}</a><small>{track.author} · <a href={track.licenseUrl} target="_blank" rel="noopener noreferrer">{track.license}</a></small></div></li>;
                })}</ul>
              </details>
              <label className="setting-row">
                <div><b>互动音效</b><p>摸头、喂食、换装与领奖，各有一点动静。开关会记住。</p></div>
                <input type="checkbox" checked={audioPreferences.effects} onChange={e => changeAudioPreferences({ effects: e.target.checked })} />
              </label>
              <form
                className="name-setting"
                onSubmit={(e) => {
                  e.preventDefault();
                  dispatch({ type: "name", value: nameDraft });
                }}
              >
                <label htmlFor="player-name">难鱼怎么称呼你</label>
                <div>
                  <input
                    id="player-name"
                    value={nameDraft}
                    onChange={(e) => setNameDraft(e.target.value)}
                    maxLength={16}
                  />
                  <button className="secondary" type="submit">
                    保存称呼
                  </button>
                </div>
              </form>
              <label className="setting-row">
                <div>
                  <b>难鱼开麦</b>
                  <p>原话配有快速、俏皮的合成语音</p>
                </div>
                <input
                  type="checkbox"
                  checked={state.settings.voice}
                  onChange={(e) =>
                    dispatch({
                      type: "settings",
                      value: { voice: e.target.checked },
                    })
                  }
                />
              </label>
              <label className="volume-setting">
                <span>
                  语音音量 <b>{Math.round(state.settings.volume * 100)}%</b>
                </span>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={state.settings.volume}
                  onChange={(e) =>
                    dispatch({
                      type: "settings",
                      value: { volume: Number(e.target.value) },
                    })
                  }
                />
              </label>
              <button
                className="text-button"
                onClick={() =>
                  speak(
                    quoteMap.greeting.text,
                    "greeting",
                    state.settings.volume,
                  )
                }
              >
                <SpeakerHigh size={18} />
                试听难鱼的声音
              </button>
              <label className="setting-row">
                <div>
                  <b>今天温柔一点</b>
                  <p>部分激烈的互损换成轻一点的吐槽</p>
                </div>
                <input
                  type="checkbox"
                  checked={state.settings.gentle}
                  onChange={(e) =>
                    dispatch({
                      type: "settings",
                      value: { gentle: e.target.checked },
                    })
                  }
                />
              </label>
              <label className="setting-row">
                <div>
                  <b>轻量画面</b>
                  <p>降低分辨率与模型细分、关闭阴影，适合发热的手机</p>
                </div>
                <input
                  type="checkbox"
                  checked={state.settings.lowQuality}
                  onChange={(e) =>
                    dispatch({
                      type: "settings",
                      value: { lowQuality: e.target.checked },
                    })
                  }
                />
              </label>
              <div className="about-note">
                <FishSimple size={28} />
                <div>
                  <b>我的群友难鱼</b>
                  <p>
                    把吵吵闹闹的群友，装进一座能一起生活的小村。
                    <br />
                    本地游玩，无需账号。
                  </p>
                </div>
              </div>
              <button
                className="secondary wide"
                onClick={() => setPanel("help")}
              >
                打开相处指南
              </button>
            </div>
          )}
          {panel === "help" && (
            <div className="help-content">
              <div className="help-hero">
                <img src={asset("avatar.png")} alt="参考图中的难鱼" />
                <div>
                  <h3>
                    先别研究攻略，
                    <br />
                    打个招呼就行。
                  </h3>
                  <p>她有点嘴硬，有点无聊，也有点想有人陪。</p>
                </div>
              </div>
              <ol>
                <li>
                  <b>陪她过日子。</b>
                  点击难鱼或「摸摸脑袋」互动。点地面走动，拖动旋转视角；手机可用摇杆。键盘 W A S D 移动、E 互动、J 手帐、M 地图。
                  生活菜单里可以打招呼，看她挥挥手；滚轮或双指缩放能凑近看看。
                </li>
                <li>
                  <b>吃饭，休息，出门。</b>
                  在零食袋投喂，在便利店补货。精力不足时免费休息。切换地点能发现新的故事。
                </li>
                <li>
                  <b>一起玩，攒贝壳。</b>
                  公园配对漂流瓶、厨房控制火候、教室完成五道题；工坊还能接力词卡、分拣浆果。完成一局就有奖励，相关委托也会记下成果。
                </li>
                <li>
                  <b>帮群友做点事。</b>
                  右上角的目标打开村民手帐。接下委托后选择「去下一站」，她会走到对应物件；先细看发现，再完成本步。委托物件放在手帐的随身物件里，交付不会误吃掉。
                </li>
                <li>
                  <b>把日常收起来。</b>
                  聊过的原话会进入收藏册；故事的不同选择会发现不同结局。买新衣服会改变
                  3D 装扮。
                </li>
                <li>
                  <b>记得备份。</b>
                  浏览器会自动保存。需要换设备，先去存档管理导出
                  ZIP，在新设备导入。
                </li>
              </ol>
              <details className="source-note">
                <summary>关于原话、声音和这个游戏</summary>
                <p>
                  角色取材于用户授权的老母猪村 QQ 记录，参考范围为 2022 至 2026
                  年，包含难鱼 52,980
                  条消息。精选原话保留语境小记；游戏世界、食物效果和剧情是创作。
                </p>
                <p>
                  原话使用俏皮风格合成语音，并非本人声音克隆。追加对白由浏览器朗读，中文语音可用性取决于设备。聊天是本地话题与上下文规则，暂时不能回答所有开放问题。
                </p>
                <p>
                  原始聊天、QQ
                  账号与完整群聊不会加载到游戏里。新对话保存在你的设备。收藏册的图片是原创语录贴纸。
                </p>
              </details>
            </div>
          )}
        </Modal>
      )}
    </div>
  );
}
