import type { Outfit, Place } from "./scene";

/** Shared data contracts only. This module has no runtime engine/content imports. */
export type GameKind = "bottle" | "cook" | "math" | "words" | "harvest" | "cycling";

export type AdventureItem = {
  id: string;
  name: string;
  description: string;
  icon?: string;
};

export type AdventureReward = {
  shells?: number;
  bond?: number;
  items?: Record<string, number>;
  foods?: Record<string, number>;
  relations?: Record<string, number>;
  flags?: string[];
  outfits?: Outfit[];
};

export type QuestRequirement =
  | { id: string; kind: "game"; game: GameKind; label: string; minScore?: number; count?: number }
  | { id: string; kind: "story"; storyId: string; label: string }
  | { id: string; kind: "discovery"; discoveryId: string; label: string };

export type QuestChoice = {
  id: string;
  label: string;
  /** Authored response, not presented as a verbatim chat quotation. */
  text: string;
  quoteId?: string;
  costItems?: Record<string, number>;
  costFoods?: Record<string, number>;
  costShells?: number;
  reward?: AdventureReward;
};

export type QuestStage = {
  id: string;
  title: string;
  text: string;
  place: Place;
  /** Semantic world hotspot ID shared with the scene/UI. */
  hotspot: string;
  quoteId?: string;
  /** All objectives must be met. Game/story events count after this stage starts. */
  requirements?: QuestRequirement[];
  /** Each option completes this stage; alternatives never erase earlier progress. */
  choices: QuestChoice[];
};

export type QuestDefinition = {
  id: string;
  title: string;
  intro: string;
  friendIds: string[];
  /** Compact public adaptation note; private message IDs remain in research. */
  source: string;
  prerequisites: string[];
  /** Automatically activates once prerequisites finish (one introductory chain). */
  autoStart?: boolean;
  stages: QuestStage[];
  reward: AdventureReward;
  ending: string;
};

export type DiscoveryDefinition = {
  id: string;
  title: string;
  text: string;
  place: Place;
  hotspot: string;
  quoteId?: string;
  reward?: AdventureReward;
};

export type QuestProgress = {
  status: "active" | "completed";
  /** Zero based; completed quests use stages.length. */
  stage: number;
  startedAt: number;
  stageStartedAt: number;
  /** Revision guard disambiguates a game begun before a stage at the same ms. */
  stageStartedRevision: number;
  completedAt?: number;
  /** Counts belong only to the current stage and reset on an atomic transition. */
  objectives: Record<string, number>;
  /** stageId -> chosen optionId; persisted independently of the rolling journal. */
  choices: Record<string, string>;
};

export type AdventureLogEntry = {
  at: number;
  kind: "quest" | "stage" | "discovery";
  title: string;
  text: string;
  questId?: string;
  stageId?: string;
};

export type AdventureState = {
  schema: 1;
  trackedQuest: string | null;
  quests: Record<string, QuestProgress>;
  /** Dedicated quest bag: these items cannot accidentally be fed as snacks. */
  items: Record<string, number>;
  relations: Record<string, number>;
  flags: string[];
  discoveries: string[];
  log: AdventureLogEntry[];
};

export type ActiveGame = {
  id: string;
  kind: GameKind;
  place: Place;
  startedAt: number;
  startedRevision: number;
};

export type QuestRequirementView = {
  requirement: QuestRequirement;
  current: number;
  target: number;
  met: boolean;
};

export type QuestChoiceView = { choice: QuestChoice; enabled: boolean; reason: string };

export type QuestView = {
  quest: QuestDefinition;
  status: "locked" | "available" | "active" | "completed";
  progress: QuestProgress | null;
  stage: QuestStage | null;
  completedStages: number;
  requirements: QuestRequirementView[];
  choices: QuestChoiceView[];
  ready: boolean;
  reason: string;
};

export type AdventureView = {
  quests: QuestView[];
  tracked: QuestView | null;
  completedCount: number;
  activeCount: number;
  availableCount: number;
  discoveredCount: number;
};

export type AdventureAction =
  | { type: "startQuest"; value: string }
  | { type: "trackQuest"; value: string }
  | { type: "questAction"; questId: string; stageId: string; choiceId: string; hotspot: string }
  | { type: "discover"; value: string; hotspot: string };
