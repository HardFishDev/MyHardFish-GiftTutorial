import type { Action, GameKind, GameState } from './engine';
import type { CharacterActivityKind, CharacterActivityProp } from './character';
import type { FoodId } from './content';
import { stories } from './content';
import { quests } from './adventure-content';
import { activityForHotspot } from './world-activities';

/** Animation follows the accepted result, never a requested reward or item. */
export interface ActivityFeedback {
  kind: CharacterActivityKind;
  prop?: CharacterActivityProp;
  food?: FoodId;
  hotspotId?: string;
  seated?: boolean;
  duration?: number;
}
export const GAME_ACTIVITIES: Record<GameKind, ActivityFeedback> = {
  cook: { kind: 'cook', prop: 'spatula', hotspotId: 'cook' },
  math: { kind: 'write', prop: 'pencil', hotspotId: 'math', seated: true },
  words: { kind: 'read', prop: 'book', hotspotId: 'words', seated: true },
  harvest: { kind: 'shop', prop: 'bag', hotspotId: 'harvest' },
  bottle: { kind: 'inspect', prop: 'magnifier', hotspotId: 'bottle' },
  cycling: { kind: 'play', prop: 'none' },
};

const talk: ActivityFeedback = { kind: 'talk', prop: 'none' };
const read: ActivityFeedback = { kind: 'read', prop: 'book' };
const write: ActivityFeedback = { kind: 'write', prop: 'pencil' };
const sit: ActivityFeedback = { kind: 'sit', prop: 'cup', seated: true };
const inspect: ActivityFeedback = { kind: 'inspect', prop: 'magnifier' };
const lamp: ActivityFeedback = { kind: 'inspect', prop: 'lantern' };
const shop: ActivityFeedback = { kind: 'shop', prop: 'bag' };
const cook: ActivityFeedback = { kind: 'cook', prop: 'spatula' };
const celebrate: ActivityFeedback = { kind: 'celebrate', prop: 'none' };
const meal: ActivityFeedback = { kind: 'eat', prop: 'food', food: 'rice' };
const snack: ActivityFeedback = { kind: 'eat', prop: 'food', food: 'bun' };

/** Each accepted stage does the work in its text, rather than celebrating a reward. */
export const QUEST_STAGE_ACTIVITIES: Record<string, Record<string, ActivityFeedback>> = {
  village_opening: { pick_route: write, name_board: write, walk_garden: inspect, post_route: write },
  berry_orders: { collect_order: read, sort_harvest: shop, check_prices: write, deliver_crate: shop },
  workshop_lights: { parts: lamp, count_lights: write, install: lamp },
  river_letters: { find_labels: write, pair_letters: read, answer: write, hang_lantern: lamp },
  market_words: { word_notes: read, word_round: write, recipe_label: write, post_menu: write },
  shared_table: { list: write, cook, cake_offer: sit, serve: meal },
  memory_exhibit: { collect_memory: write, old_story: read, caption: write, install_exhibit: write },
  opening_night: { rain_plan: inspect, collect_light: lamp, open_stage: lamp, festival: celebrate },
  quiet_corner: { desk_chat: { ...read, seated: true }, terrace_pause: sit, leave_bookmark: write },
  sticker_guestbook: { notice_request: write, test_sheet: write, place_sheet: write },
};

/** Alternatives with different visible actions: agreeing to a task never implies eating. */
export const QUEST_CHOICE_ACTIVITIES: Record<string, Record<string, Record<string, ActivityFeedback>>> = {
  village_opening: { walk_garden: { mark_crates: write }, post_route: { say_route: talk } },
  berry_orders: { collect_order: { copy_order: write }, deliver_crate: { shared_delivery: write } },
  workshop_lights: { parts: { rename_system: write } },
  river_letters: { find_labels: { blank_card: read }, answer: { keep_blank: { kind: 'sit', prop: 'none', seated: true } } },
  market_words: { word_notes: { sound_notes: { kind: 'talk', prop: 'book' } } },
  shared_table: {
    cook: { box_meal: meal },
    cake_offer: { fruit_bite: { kind: 'eat', prop: 'food', food: 'peach' }, card_only: { ...talk, seated: true }, another_day: sit },
  },
  opening_night: { festival: { quiet_seat: { kind: 'sit', prop: 'lantern', seated: true } } },
  quiet_corner: { desk_chat: { pause_mark: { ...read, seated: true } }, terrace_pause: { say_thanks: { ...talk, seated: true } } },
};

/** Story gestures follow the node reached, including quiet and food-refusal endings. */
export const STORY_NODE_ACTIVITIES: Record<string, Record<string, ActivityFeedback>> = {
  fanclub: { start: talk, rename: write, promote: talk, peace: sit, secret: write, chair: talk },
  movie: { start: sit, comedy: sit, trailer: talk, quiet: sit, laugh: celebrate, talk: { ...talk, seated: true } },
  rain: { start: inspect, shelter: sit, run: talk, wait: talk, umbrella: write },
  download: { start: inspect, help: inspect, roast: talk, fixed: { kind: 'talk', prop: 'cup' }, learn: write },
  afterclass: { start: read, steps: write, break: sit, solved: write, confidence: write },
  holiday: { start: sit, bottles: read, slow: sit, future: write, today: sit },
  dinner: { start: cook, team: cook, clap: talk, dinner: meal, chef: meal },
  budget: { start: shop, pick: shop, treat: shop, share: snack, save: shop },
  village_notice: { start: read, edit: write, meeting: talk, notice: write, corner: write },
  berry_coop: { start: shop, list: write, trade: shop, open: shop, receipt: read },
  fox_bottles: { start: read, read, reply: write, useful: write, archive: write },
  fox_dictionary: { start: read, objects: read, cards: read, teacher: talk, pocket: { kind: 'read', prop: 'book' } },
  server_chickens: { start: inspect, observe: inspect, coop: inspect, log: write, village: lamp },
  plugin_parade: { start: inspect, labels: write, rehearsal: talk, simple: { kind: 'sit', prop: 'none', seated: true }, encore: celebrate },
  soup_photo: { start: talk, pose: talk, funny: celebrate, approve: read, behind: talk },
  soup_museum: { start: inspect, caption: write, together: lamp, sketch: read, space: write },
  belated_cake: { start: talk, card: write, choose: talk, wish: write, small: snack, later: sit },
  english_kitchen: { start: read, correct: write, wrong: talk, table: meal, mutual: write },
  grammar_club: { start: { ...read, seated: true }, split: read, listen: { ...talk, seated: true }, finish: talk, relay: read },
  quiet_revision: { start: read, count: read, window: sit, enough: talk, tomorrow: write },
  group_picnic: { start: read, plan: write, wishes: write, photo: talk, letters: shop },
};

function storyActivity(storyId: string, nodeId: string): ActivityFeedback {
  return { ...(STORY_NODE_ACTIVITIES[storyId]?.[nodeId] || talk), duration: 5.2 };
}

export function activityForAction(previous: GameState, next: GameState, action: Action): ActivityFeedback | null {
  switch (action.type) {
    case 'feed':
      return next.counts.feed > previous.counts.feed
        ? { kind: 'eat', prop: action.value === 'milk' || action.value === 'coffee' ? 'cup' : 'food', food: action.value, duration: 5.6 }
        : null;
    case 'buyFood':
      return next.inventory[action.value] > previous.inventory[action.value]
        ? { kind: 'shop', prop: 'bag', duration: 4.2 } : null;
    case 'outfit':
      return next.outfit !== previous.outfit || next.owned.length > previous.owned.length
        ? { kind: 'celebrate', prop: 'none', duration: 3.2 } : null;
    case 'chat':
      return next.counts.chat > previous.counts.chat ? { kind: 'talk', prop: 'none', duration: 4.2 } : null;
    case 'interact':
      if (action.value === 'rest') return { kind: 'sit', prop: 'none', hotspotId: 'rest', seated: true, duration: 9 };
      // Petting, teasing, waving and dancing keep the expressive full-body reaction clips.
      return null;
    case 'startGame':
      return next.activeGame && next.activeGame.id !== previous.activeGame?.id
        ? { ...GAME_ACTIVITIES[action.value] } : null;
    case 'finishGame':
      return next.counts.play > previous.counts.play ? { kind: 'celebrate', prop: 'none', duration: 3.8 } : null;
    case 'startStory':
      return !previous.story && next.story?.id === action.value
        ? { ...storyActivity(next.story.id, next.story.node), hotspotId: `story:${next.story.id}` } : null;
    case 'choice': {
      if (!previous.story) return null;
      const story = stories.find(item => item.id === previous.story!.id);
      const node = story?.nodes[previous.story.node];
      if (!node?.choices?.some(choice => choice.next === action.value)) return null;
      const destination = story?.nodes[action.value];
      if (!destination || (destination.ending ? next.story !== null
        : next.story?.id !== story!.id || next.story?.node !== action.value)) return null;
      return storyActivity(story!.id, action.value);
    }
    case 'discover':
      return next.adventure.discoveries.length > previous.adventure.discoveries.length
        ? { kind: 'write', prop: 'pencil', hotspotId: `adventure:${action.hotspot}`, duration: 4.8 } : null;
    case 'questAction': {
      const before = previous.adventure.quests[action.questId];
      const after = next.adventure.quests[action.questId];
      const stage = before ? quests.find(quest => quest.id === action.questId)?.stages[before.stage] : undefined;
      if (!before || !after || after.stage !== before.stage + 1 || stage?.id !== action.stageId
        || after.choices[action.stageId] !== action.choiceId) return null;
      const activity = QUEST_CHOICE_ACTIVITIES[action.questId]?.[action.stageId]?.[action.choiceId]
        || QUEST_STAGE_ACTIVITIES[action.questId]?.[action.stageId]
        || activityForHotspot(next.place, `adventure:${action.hotspot}`);
      return activity ? { ...activity, hotspotId: `adventure:${action.hotspot}`, duration: 5.4 }
        : { kind: 'talk', prop: 'none', duration: 4.2 };
    }
    case 'startQuest':
      return !previous.adventure.quests[action.value] && next.adventure.quests[action.value]
        ? { kind: 'read', prop: 'book', duration: 3.8 } : null;
    case 'claim':
      return next.daily.claimed.length > previous.daily.claimed.length ? { kind: 'celebrate', prop: 'none', duration: 3.2 } : null;
    case 'recall':
      return next.reaction.id !== previous.reaction.id ? { kind: 'read', prop: 'book', duration: 4.2 } : null;
    default: return null;
  }
}
