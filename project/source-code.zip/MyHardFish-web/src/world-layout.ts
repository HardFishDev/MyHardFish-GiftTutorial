import type { Place } from './scene';

/** Shared geography only. Dialogue, evidence and rewards live in adventure-content. */
export interface ExplorationSpot {
  id: string; place: Place; label: string;
  x: number; z: number; y?: number;
  approach: readonly [number, number];
}
export interface WorldExit {
  to: Place; x: number; z: number;
  approach: readonly [number, number];
  rotation?: number;
}
export const PLACE_LABELS: Record<Place,string> = {
  home:'难鱼的家',kitchen:'共享厨房',park:'村边公园',shop:'村中便利店',school:'自习教室',
  village:'老母猪村',workshop:'联机工坊',river:'瓶信河岸',market:'晚风夜市',
};
export const EXPLORATION_SPOTS: readonly ExplorationSpot[] = [
  {id:'home_notice',place:'home',label:'群聊留言板',x:1,z:-9.7,y:2.3,approach:[1,-7.7]},
  {id:'home_record',place:'home',label:'窗边唱片架',x:3.2,z:7.2,y:1.65,approach:[3.2,5.5]},
  {id:'home_terrace',place:'home',label:'露台盆栽',x:12.4,z:7.2,y:1.5,approach:[12.2,5.4]},
  {id:'kitchen_recipe',place:'kitchen',label:'备菜手记',x:-4.1,z:-3.2,y:1.9,approach:[-.5,-3.2]},
  {id:'kitchen_fridge',place:'kitchen',label:'冰箱便利贴',x:-9.2,z:-5.5,y:2.3,approach:[-7.45,-5.65]},
  {id:'kitchen_table',place:'kitchen',label:'留给群友的餐位',x:5.3,z:1.7,y:1.9,approach:[2,1.7]},
  {id:'park_bottle',place:'park',label:'漂流瓶小站',x:-2,z:.25,y:1.9,approach:[-2,2.3]},
  {id:'park_picnic',place:'park',label:'合影野餐毯',x:7.7,z:5.6,y:1.1,approach:[5,5.6]},
  {id:'park_pavilion',place:'park',label:'树荫长亭',x:8.3,z:-11.5,y:1.9,approach:[8.3,-11.05]},
  {id:'shop_list',place:'shop',label:'收银台采购单',x:-5.4,z:4.7,y:1.9,approach:[-5.4,6.7]},
  {id:'shop_fruit',place:'shop',label:'果篮补给',x:-6.5,z:.2,y:1.8,approach:[-9,.5]},
  {id:'shop_bulletin',place:'shop',label:'店内留言栏',x:8.85,z:-6.15,y:2,approach:[7,-5.6]},
  {id:'school_blackboard',place:'school',label:'黑板角落',x:0,z:-10.25,y:3,approach:[0,-8.5]},
  {id:'school_desk',place:'school',label:'课间草稿本',x:-2.55,z:-1.5,y:1.9,approach:[0,-1.5]},
  {id:'school_club',place:'school',label:'社团留言栏',x:-9.9,z:8.9,y:2.2,approach:[-8.6,8.7]},
  {id:'village_square',place:'village',label:'村口集合钟',x:0,z:-4,y:2.2,approach:[0,-.5]},
  {id:'village_board',place:'village',label:'村务公告栏',x:-16,z:1,y:2.1,approach:[-16,3.5]},
  {id:'village_garden',place:'village',label:'共同种下的小花园',x:18,z:-18,y:1.6,approach:[18,-14.5]},
  {id:'workshop_server',place:'workshop',label:'联机准备台',x:-12,z:-10,y:2,approach:[-12,-5.9]},
  {id:'workshop_recycle',place:'workshop',label:'浆果回收箱',x:12,z:4,y:1.9,approach:[9,4]},
  {id:'workshop_project',place:'workshop',label:'共同作品台',x:0,z:-15,y:2.1,approach:[0,-11.5]},
  {id:'river_bottle',place:'river',label:'河岸收信箱',x:-7,z:9,y:2,approach:[-7,12]},
  {id:'river_dock',place:'river',label:'木码头',x:1,z:0,y:1.4,approach:[-2,0]},
  {id:'river_observatory',place:'river',label:'晚风观景台',x:-13,z:-15,y:2,approach:[-13,-11.5]},
  {id:'market_stall',place:'market',label:'开张的小摊',x:-10,z:-4,y:2,approach:[-6.5,-4]},
  {id:'market_table',place:'market',label:'夜市拼桌',x:9,z:9,y:1.9,approach:[5.5,9]},
  {id:'market_stage',place:'market',label:'街角点歌台',x:0,z:-16,y:2.2,approach:[0,-12]},
];

/** Every edge is bidirectional; approach doubles as the arrival anchor from that neighbour. */
export const WORLD_EXITS: Record<Place,readonly WorldExit[]> = {
  home:[{to:'village',x:.4,z:8.85,approach:[.4,6]},{to:'kitchen',x:-1.6,z:8.85,approach:[-1.6,6]}],
  kitchen:[{to:'home',x:0,z:8.8,approach:[0,6.3]}],
  park:[{to:'village',x:2.5,z:15.1,approach:[2.5,12]},{to:'river',x:-14.7,z:14.7,approach:[-13.3,12.9],rotation:-Math.PI/4}],
  shop:[{to:'village',x:2,z:8.7,approach:[2,6.2]},{to:'market',x:-6,z:8.7,approach:[-6,6.8]}],
  school:[{to:'village',x:0,z:8.8,approach:[0,6.6]},{to:'workshop',x:5.4,z:8.8,approach:[5.4,7.2]}],
  village:[
    {to:'home',x:-32,z:14,approach:[-28.5,14],rotation:Math.PI/2},
    {to:'park',x:-30,z:-26,approach:[-27,-24],rotation:Math.PI/2},
    {to:'shop',x:25,z:18,approach:[21.5,18],rotation:-Math.PI/2},
    {to:'school',x:0,z:-33,approach:[0,-29]},
    {to:'workshop',x:30,z:-21,approach:[26.5,-21],rotation:-Math.PI/2},
    {to:'river',x:34,z:0,approach:[30.5,0],rotation:-Math.PI/2},
    {to:'market',x:0,z:33,approach:[0,29]},
  ],
  workshop:[{to:'village',x:0,z:22,approach:[0,18.5]},{to:'school',x:-22,z:4,approach:[-18.5,4],rotation:Math.PI/2}],
  river:[{to:'village',x:-24,z:12,approach:[-20.5,12],rotation:Math.PI/2},{to:'park',x:-17,z:24,approach:[-17,20.5]}],
  market:[{to:'village',x:0,z:24,approach:[0,20.5]},{to:'shop',x:-24,z:12,approach:[-20.5,12],rotation:Math.PI/2}],
};

export const OUTDOOR_PLACES: readonly Place[]=['park','village','workshop','river','market'];
export const spotsForPlace=(place:Place)=>EXPLORATION_SPOTS.filter(spot=>spot.place===place);
