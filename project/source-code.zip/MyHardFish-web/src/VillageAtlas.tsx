import { BookOpen, Buildings, CaretRight, Check, Compass, CookingPot, GameController, GraduationCap, House, MapPin, Storefront, Tree, Waves } from '@phosphor-icons/react';
import type { Icon } from '@phosphor-icons/react';
import { places } from './content';
import type { GameState } from './engine';
import type { Place } from './scene';
import { discoveries } from './adventure-content';
import { WORLD_EXITS } from './world-layout';

const positions: Record<Place, [number, number]> = { home:[15,28], kitchen:[15,57], park:[43,14], shop:[73,17], school:[86,43], village:[48,44], workshop:[86,73], river:[53,85], market:[16,86] };
export const placeIcons: Record<Place, Icon> = { home:House, kitchen:CookingPot, park:Tree, shop:Storefront, school:GraduationCap, village:Buildings, workshop:GameController, river:Waves, market:Storefront };
export default function VillageAtlas({ state, travel, targetPlace }: { state: GameState; travel:(place:Place)=>void; targetPlace?:Place }) {
  return <div className="village-atlas">
    <header className="atlas-heading"><div><small>老母猪村 / 村中路线图</small><h3>出门就有群友的事。</h3><p>沿路牌步行穿过街区，或点一个地点直接出发。</p></div><span><Compass size={34} /><small>北 ↑</small></span></header>
    <div className="atlas-paper" aria-label="九个相连区域的地图">
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true" className="atlas-terrain">
        <defs><pattern id="atlas-grain" width="3" height="3" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r=".1" fill="#bec9ad" /></pattern></defs>
        <rect width="100" height="100" fill="#e9eedc"/><rect width="100" height="100" fill="url(#atlas-grain)"/>
        <path d="M0 3Q22 18 37 1L63 0Q61 15 39 28T0 19Z" fill="#cad9b9"/>
        <path d="M100 91Q84 79 73 92T44 92Q33 96 35 100H100Z" fill="#afcdca"/><path d="M100 96Q81 84 70 98M91 91Q82 87 75 92M52 97L63 96" fill="none" stroke="#d9e8df" strokeWidth=".4"/>
        <path d="M-2 71Q24 65 37 70T77 62T104 57" fill="none" stroke="#d4dfc3" strokeWidth="13"/>
        <path d="M0 75Q22 69 39 74T79 66T104 61" fill="none" stroke="#c1d1af" strokeWidth=".3"/>
        {Object.entries(WORLD_EXITS).flatMap(([from, exits]) => exits.filter(exit => from.localeCompare(exit.to) < 0).map(exit => { const a=positions[from as Place], b=positions[exit.to]; return <g key={`${from}-${exit.to}`}><path d={`M${a[0]} ${a[1]} Q${(a[0]+b[0])/2+3} ${(a[1]+b[1])/2} ${b[0]} ${b[1]}`} fill="none" stroke="#faf9eb" strokeWidth="2.8"/><path d={`M${a[0]} ${a[1]} Q${(a[0]+b[0])/2+3} ${(a[1]+b[1])/2} ${b[0]} ${b[1]}`} fill="none" stroke="#b5b99a" strokeWidth=".35" strokeDasharray="1 1.5"/></g>; }))}
        {[[4,9],[10,11],[22,8],[29,16],[36,5],[8,42],[6,49],[70,48],[66,54],[94,15],[92,24],[93,88],[30,88]].map(([x,y],i)=><g key={i}><ellipse cx={x} cy={y+1} rx="1.5" ry=".7" fill="#a5ba98" opacity=".5"/><path d={`M${x} ${y-3} l-1.8 3.6 h3.6Z`} fill={i%2?'#92ac84':'#aac19a'}/></g>)}
      </svg>
      <span className="atlas-river-label">瓶信河</span><span className="atlas-district-label">一起折腾，也一起生活</span>
      {places.map(place => { const Icon = placeIcons[place.id]; const [x,y] = positions[place.id]; const count = discoveries.filter(d=>d.place===place.id && state.adventure.discoveries.includes(d.id)).length;return <button key={place.id} style={{left:`${x}%`,top:`${y}%`}} className={`atlas-pin pin-${place.id} ${state.place===place.id?'current':''} ${targetPlace===place.id?'target':''}`} aria-label={place.name} aria-pressed={state.place===place.id} onClick={()=>travel(place.id)}><span className="atlas-building"><Icon size={29} weight="duotone" />{state.place===place.id && <i><MapPin size={11} weight="fill"/></i>}{targetPlace===place.id && state.place!==place.id && <i><BookOpen size={11}/></i>}</span><b>{place.name}</b><small>{count===3?<><Check size={10}/>发现齐了</>:state.visited.includes(place.id)?`${count}/3 小发现`:'还没到过'}</small></button>; })}
    </div>
    <div className="atlas-key"><span><i className="current-dot"/>你在这里</span><span><i className="target-dot"/>委托下一站</span><span>虚构村庄 · 地点自由探索</span></div>
    <div className="atlas-route-note"><Compass size={20}/><p>每个地区有三处小发现，靠近标记后按「互动」。长路可以在手帐里选择「去下一站」，难鱼会沿安全路线走过去。</p><CaretRight size={18}/></div>
  </div>;
}
