import * as THREE from 'three';
import type { EnvironmentBuilder } from './environment';

/** A second, connected living area reached by walking out of the main room. */
export function buildHomeTerrace(b:EnvironmentBuilder) {
  // The near side of the studio is a separate sleeping / listening nook.
  b.surface([6.8,.034,4.6],[-5.85,.025,6.6],'#c7cbb2','fabric',.06).castShadow=false;
  for(let i=0;i<14;i++)b.surface([.024,.006,4.2],[-8.78+i*.45,.046,6.6],'#e0dfc3','fabric',0).castShadow=false;
  b.surface([5.4,.44,3.0],[-5.8,.43,6.45],'#ac9170','wood',.1);
  for(const x of [-8.2,-3.4])for(const z of [5.3,7.6])b.surface([.16,.26,.16],[x,.13,z],'#8f7659','wood',.025);
  b.surface([.18,1.49,3.04],[-8.42,.90,6.45],'#bea887','wood',.06);
  for(let i=0;i<7;i++)b.surface([.05,1.12,.085],[-8.305,.95,5.23+i*.4],'#d4bd98','wood',.02);
  b.surface([5.28,.30,2.91],[-5.78,.80,6.45],'#e6dfc9','fabric',.15);
  b.surface([3.97,.16,2.91],[-5.15,1.015,6.45],'#a8b69e','fabric',.09);
  b.surface([3.99,.53,.095],[-5.15,.78,7.88],'#a8b69e','fabric',.035);
  for(let i=0;i<11;i++)b.surface([3.80,.016,.014],[-5.16,1.107,5.20+i*.245],'#c1cbb0','fabric',.002).castShadow=false;
  for(const z of [5.74,7.13]){const pillow=b.surface([1.01,.29,1.12],[-7.62,1.07,z],'#eee6d0','fabric',.17);pillow.rotation.y=z<6?.06:-.06;}
  const cushion=b.surface([.64,.33,.70],[-6.92,1.13,5.52],'#bd957d','fabric',.14);cushion.rotation.y=.23;
  b.obstacle(-5.80,6.45,5.65,3.2);const bedSpot=b.hotspot('rest','窝进被子里充个电',[-5.8,.9,6.45],[5.6,1.7,3.1]);b.seat('home-bed-edge',[-5.8,1.095,5.25],[-5.1,0,3.9],{facing:Math.PI,width:2,depth:1,hotspot:bedSpot});
  b.table(-9.4,6.3,1.15,1.1,.90);b.cup(-9.32,1.0,6.55,'#cab391');
  b.cylinder(.17,.23,.06,[-9.53,1.01,6.09],'#b3986d');const bedLamp=b.occluder('home-bedside-lamp');b.cylinder(.018,.026,.58,[-9.53,1.31,6.09],'#a68b61',bedLamp);b.cylinder(.18,.33,.34,[-9.53,1.62,6.09],'#e4d4b3',bedLamp);
  b.surface([1.6,1.06,.10],[-10.76,2.90,6.1],'#a99571','wood',.035).rotation.y=Math.PI/2;
  const sleepPrint=b.label('睡饱了\n再跟世界讲道理',[-10.69,2.90,6.1],1.47,'#657760','#e7ddc3');sleepPrint.rotation.y=Math.PI/2;
  b.surface([3.0,.73,.82],[3.2,.54,7.2],'#b89c74','wood',.065);b.surface([3.14,.08,.96],[3.2,.96,7.2],'#cfb38a','wood',.035);
  for(const x of [1.94,4.46])for(const z of [6.91,7.49])b.surface([.075,.24,.075],[x,.13,z],'#897659','wood',.015);
  b.surface([1.11,.11,.70],[2.85,1.075,7.19],'#bd9c73','wood',.035);
  b.cylinder(.27,.27,.029,[2.75,1.15,7.19],'#3e4b43');b.cylinder(.082,.082,.032,[2.75,1.171,7.19],'#bca67d');
  const toneArm=b.cylinder(.012,.012,.43,[3.12,1.19,7.13],'#b2b8a3');toneArm.rotation.z=1.34;toneArm.rotation.y=.35;
  for(const x of [2.02,4.37]){b.surface([.47,.59,.46],[x,1.30,7.19],'#737d68','wood',.03);for(const y of [1.19,1.43]){const speaker=b.cylinder(y>1.3?.07:.13,y>1.3?.07:.13,.016,[x,y,7.43],'#3f4e41');speaker.rotation.x=Math.PI/2;}}
  for(let i=0;i<7;i++)b.book(2.4+i*.19,.25,7.57,['#82927c','#c0a485','#d2bb91'][i%3],.13,.44,.24);
  b.obstacle(3.2,7.2,3.25,1.1);b.hotspot('story','今天的 B 面歌单',[3.2,1.0,7.2],[3.3,1.8,1.1]);
  b.plant(5.6,7.24,.86);b.obstacle(5.6,7.24,.85,.85);
  b.bounds.maxX=15.5;
  // Navigation is the union of the studio and terrace, not its empty bounding rectangle.
  b.obstacle(12.9,-6.0,5.7,9.0);b.obstacle(12.9,9.4,5.7,2.3);
  b.surface([5.3,.14,10.4],[12.6,.03,3.3],'#c5b397','stone',.02);
  b.elevation(12.6,3.3,5.3,10.4,.10);
  for(let i=0;i<14;i++)b.surface([.31,.04,10.0],[10.4+i*.337,.12,3.3],i%3?'#b9a080':'#c6ad8c','wood',.012).castShadow=false;
  // Flush threshold: no invisible step or wall between the two playable areas.
  b.surface([.16,.025,10.1],[10.10,.13,3.3],'#dec8a8','wood',.015);
  for(const z of [-1.65,8.25]) {
    for(let i=0;i<10;i++)b.surface([.055,1.43,.055],[10.5+i*.47,.83,z],'#84927a','metal',.006);
    b.surface([4.9,.12,.15],[12.7,1.57,z],'#a59777','wood',.025);
    b.surface([4.9,.075,.10],[12.7,.32,z],'#94a088','metal',.015);
    b.obstacle(12.7,z,5.0,.14);
  }
  for(let i=0;i<22;i++)b.surface([.055,1.43,.055],[15.16,.83,-1.65+i*.47],'#84927a','metal',.006);
  b.surface([.15,.12,10.12],[15.16,1.57,3.3],'#a59777','wood',.025);
  b.surface([.10,.075,10.10],[15.16,.32,3.3],'#94a088','metal',.015);
  b.obstacle(15.16,3.3,.14,10.2);
  // The planter screen defines the living room without closing the way out.
  b.surface([.42,.62,3.0],[10.3,.41,-3.55],'#b7a483','wood',.04);
  const writingScreen=b.occluder('home-writing-screen');
  for(let i=0;i<10;i++)b.surface([.10,3.7,.14],[10.3,2.26,-4.9+i*.3],'#baaa8e','wood',.015,writingScreen);
  b.obstacle(10.3,-3.55,.55,3.0);
  for(const z of [-4.4,-3.45,-2.5]){const plant=b.plant(10.3,z,.56);plant.position.y=.71;const leaves=plant.children.slice(2),foliage=b.occluder(`home-writing-foliage:${z}`,plant);leaves.forEach(leaf=>foliage.add(leaf));}
  // Small bistro set: rounded seats, fine tubular legs, a real tea tray.
  b.cylinder(.93,.93,.095,[12.7,1.39,2.0],'#d4c19e');
  b.cylinder(.065,.12,1.21,[12.7,.76,2.0],'#86937b');
  for(let i=0;i<3;i++){
    const a=i*Math.PI*2/3,leg=b.cylinder(.025,.033,.92,[12.7+Math.cos(a)*.24,.48,2+Math.sin(a)*.24],'#6e7f69');
    leg.rotation.z=Math.cos(a)*.5;leg.rotation.x=Math.sin(a)*.5;
  }
  b.obstacle(12.7,2.0,1.9,1.9);
  b.cylinder(.34,.31,.035,[12.7,1.46,2.0],'#c1a27a');b.cup(12.51,1.49,2.03,'#c8d0b6');b.cup(12.91,1.49,1.99,'#e7dcc2');
  b.surface([.56,.045,.42],[12.56,1.47,2.46],'#9aab90','fabric',.025).rotation.y=.23;
  for(const [x,z,rotation] of [[12.6,.30,0],[12.6,3.75,Math.PI]]) {
    const seat=new THREE.Group();seat.position.set(x,.12,z);seat.rotation.y=rotation;b.root.add(seat);
    b.surface([1.04,.13,1.0],[0,.65,0],'#bfa07e','wood',.08,seat);
    for(const xx of [-.37,.37])for(const zz of [-.33,.33])b.surface([.045,.63,.045],[xx,.31,zz],'#6f816d','metal',.008,seat);
    for(const xx of [-.4,.4])b.surface([.04,.88,.04],[xx,1.10,-.42],'#6f816d','metal',.008,seat);
    for(let i=0;i<3;i++)b.surface([1.0,.15,.07],[0,1.03+i*.18,-.43],'#c8af8c','wood',.028,seat);
    b.surface([.82,.12,.76],[0,.78,.035],'#c7cdb0','fabric',.06,seat);
    b.obstacle(x,z,1.15,1.15);
    b.seat(`terrace-chair:${z}`,[0,.84,.13],[-1.32,0,0],{parent:seat,width:.82,depth:.76,surface:[0,1.3175,1.55],target:[0,1.42,1.55]});
  }
  b.hotspot('rest','去露台吹吹风',[12.65,1.0,2.0],[2.9,2.0,4.8]);
  // A pocket garden: herbs, terracotta pots, garden tools and a linen basket.
  for(const [x,z,s] of [[14.3,-.65,.80],[14.4,7.25,1.05],[10.9,7.2,.9]]){b.plant(x,z,s).position.y=.14;b.obstacle(x,z,.7*s,.7*s);}
  b.surface([2.2,.68,.76],[12.4,.48,7.20],'#b0946f','wood',.03);
  for(let i=0;i<4;i++)b.plant(11.65+i*.48,7.2,.36).position.y=.83;
  b.obstacle(12.4,7.2,2.3,.9);
  b.cylinder(.20,.17,.32,[14.13,.30,6.33],'#93a389');
  const handle=b.torus(.19,.025,[14.13,.54,6.33],'#81947b');handle.rotation.y=Math.PI/2;
  const spout=b.cylinder(.045,.065,.43,[13.94,.35,6.33],'#9dae8f');spout.rotation.z=-.95;
  b.cylinder(.36,.30,.50,[11.07,.39,5.5],'#bca77f');
  for(let i=0;i<5;i++)b.torus(.32,.01,[11.07,.21+i*.08,5.5],'#947d5b').rotation.x=Math.PI/2;
  b.surface([.73,.05,.69],[11.07,.66,5.5],'#e7dec2','fabric',.05);
  // A strip of garden below the railing ensures this never reads as a floating platform.
  b.surface([18,.16,29],[22,-.06,1],'#9ca987','plaster',0).castShadow=false;
  for(const [x,z,s] of [[19,-4,1.7],[23,4,2.0],[19.3,12,1.6]])b.tree(x,z,s);
  for(let i=0;i<12;i++)b.sphere([.9,.53,.7],[16.8,.37,-3+i*1.35],i%2?'#9dac83':'#819770');
}
