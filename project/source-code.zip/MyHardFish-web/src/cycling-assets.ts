import catalog from './cycling-audio-catalog.json';

export type CyclingAudioId = keyof typeof catalog;

/** Kept separate from the town's preload list and imported only by cycling. */
export function cyclingAudioUrl(id: CyclingAudioId): string {
  return `${import.meta.env.BASE_URL}audio/${catalog[id].file}`;
}

export const CYCLING_ASSET_URLS: readonly string[] = Object.freeze(
  Object.keys(catalog).map(id => cyclingAudioUrl(id as CyclingAudioId)),
);
