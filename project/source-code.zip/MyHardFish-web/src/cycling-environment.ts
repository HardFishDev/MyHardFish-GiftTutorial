import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { CYCLING_LANE_WIDTH, getCyclingDifficulty } from './cycling';
import type { CyclingDifficulty } from './cycling';

const V=(x:number,y:number,z:number)=>new THREE.Vector3(x,y,z);
type Blocker={object:THREE.Object3D;center:THREE.Vector3;radius:number};
const PALETTES={
  riverside:{sky:'#c3e6ee',fog:'#c3e6ee',sun:'#fff2d1',ground:'#8ba96c',road:'#627379',paving:'#ded2ba',water:'#539ca3',hemi:'#cfeeff',bounce:'#b8bd84',sunPower:2.5,ambient:1.9,exposure:1.08},
  village:{sky:'#cbdcdb',fog:'#cbdcdb',sun:'#ffe9bd',ground:'#a4ac75',road:'#687078',paving:'#d9c3a1',water:'#6d9e98',hemi:'#e4f5ff',bounce:'#b4a479',sunPower:2.8,ambient:1.85,exposure:1.03},
  nightHarbor:{sky:'#142b43',fog:'#203b52',sun:'#a7d2ff',ground:'#495d67',road:'#3d5668',paving:'#78909b',water:'#224c68',hemi:'#b7dafb',bounce:'#697482',sunPower:1.65,ambient:1.5,exposure:1.14},
} as const;

/** Procedural, bounded scenery for three different places, sharing no world assets. */
export class CyclingEnvironment {
  readonly root=new THREE.Group();
  readonly blockers:Blocker[]=[];
  readonly roadTrees:THREE.Group[]=[];
  readonly theme;
  readonly palette;
  private readonly chunks:THREE.Group[]=[];
  private readonly geometryCache=new Map<string,THREE.BufferGeometry>();
  private readonly materials=new Map<string,THREE.MeshStandardMaterial>();
  private readonly textures=new Set<THREE.Texture>();
  private readonly scrollingTextures:{texture:THREE.Texture;period:number}[]=[];
  private readonly markings=new THREE.Group();
  private readonly waterHighlights=new THREE.Group();
  private readonly beaconGroups:THREE.Group[]=[];
  private readonly low:boolean;
  private seed=86173;

  constructor(low:boolean,difficulty:CyclingDifficulty) {
    this.low=low;this.theme=getCyclingDifficulty(difficulty).theme;this.palette=PALETTES[this.theme];
    this.root.name=`cycling-map-${this.theme}`;this.root.userData.theme=this.theme;
    try {
    this.buildGround();
    for(let i=0;i<12;i++){
      const chunk=new THREE.Group();chunk.name=`${this.theme}-block-${i}`;this.root.add(chunk);this.chunks.push(chunk);
      if(this.theme==='riverside')this.riversideBlock(chunk,i);
      else if(this.theme==='village')this.villageBlock(chunk,i);
      else this.harborBlock(chunk,i);
    }
    this.buildHorizon();
    } catch(error) {this.dispose();throw error;}
  }

  private random() {this.seed=(Math.imul(this.seed,1664525)+1013904223)>>>0;return this.seed/4294967296;}
  private geo(key:string,create:()=>THREE.BufferGeometry) {let g=this.geometryCache.get(key);if(!g){g=create();this.geometryCache.set(key,g);}return g;}
  private mat(color:string,metal=0,glow=0) {const key=`${color}/${metal}/${glow}`;let m=this.materials.get(key);if(!m){m=new THREE.MeshStandardMaterial({color,roughness:metal?.43:.9,metalness:metal,emissive:glow?color:'#000',emissiveIntensity:glow});this.materials.set(key,m);}return m;}
  private mesh(parent:THREE.Object3D,g:THREE.BufferGeometry,m:THREE.Material,p:number[],s:number[]) {const mesh=new THREE.Mesh(g,m);mesh.position.set(p[0],p[1],p[2]);mesh.scale.set(s[0],s[1],s[2]);mesh.castShadow=!this.low;mesh.receiveShadow=true;parent.add(mesh);return mesh;}
  private box(parent:THREE.Object3D,p:number[],s:number[],color:string,metal=0,glow=0) {return this.mesh(parent,this.geo('box',()=>new THREE.BoxGeometry()),this.mat(color,metal,glow),p,s);}
  private cylinder(parent:THREE.Object3D,p:number[],radius:number,height:number,color:string,metal=0,sides=12,top=1) {return this.mesh(parent,this.geo(`cylinder-${sides}-${top}`,()=>new THREE.CylinderGeometry(top,1,1,sides)),this.mat(color,metal),p,[radius,height,radius]);}
  private sphere(parent:THREE.Object3D,p:number[],s:number[],color:string,detail=1) {return this.mesh(parent,this.geo(`crown-${detail}`,()=>new THREE.IcosahedronGeometry(1,detail)),this.mat(color),p,s);}
  private rod(parent:THREE.Object3D,a:number[],b:number[],radius:number,color:string,metal=0) {const from=V(...a as [number,number,number]),to=V(...b as [number,number,number]);const mesh=this.cylinder(parent,[0,0,0],radius,from.distanceTo(to),color,metal,8);mesh.position.copy(from).add(to).multiplyScalar(.5);mesh.quaternion.setFromUnitVectors(V(0,1,0),to.sub(from).normalize());return mesh;}
  private model(parent:THREE.Object3D,x:number,z:number,name:string,radius=0,height=2) {const group=new THREE.Group();group.name=name;group.position.set(x,0,z);parent.add(group);if(radius)this.blockers.push({object:group,center:V(0,height,0),radius});return group;}
  /** Merge each model by material so extra architectural detail costs few draws. */
  private batch(group:THREE.Group) {
    const batches=new Map<THREE.Material,{geometry:THREE.BufferGeometry;mesh:THREE.Mesh}[]>();
    group.updateMatrixWorld(true);
    for(const child of [...group.children])if(child instanceof THREE.Mesh&&!Array.isArray(child.material)){
      let geometry=child.geometry.clone();if(geometry.index){const flat=geometry.toNonIndexed();geometry.dispose();geometry=flat;}geometry.applyMatrix4(child.matrix);
      if(!geometry.getAttribute('uv'))geometry.setAttribute('uv',new THREE.BufferAttribute(new Float32Array(geometry.getAttribute('position').count*2),2));
      const entries=batches.get(child.material)??[];entries.push({geometry,mesh:child});batches.set(child.material,entries);
    }
    for(const [material,entries] of batches){if(entries.length<2){entries[0].geometry.dispose();continue;}const merged=mergeGeometries(entries.map(e=>e.geometry),false);for(const e of entries){e.geometry.dispose();group.remove(e.mesh);}if(merged){this.geometryCache.set(`merged-${this.geometryCache.size}`,merged);const mesh=new THREE.Mesh(merged,material);mesh.castShadow=!this.low;mesh.receiveShadow=true;group.add(mesh);}}
  }

  private surface(kind:'road'|'paving'|'grass'|'water',color:string) {
    const canvas=document.createElement('canvas');canvas.width=canvas.height=256;const ctx=canvas.getContext('2d')!;ctx.fillStyle=color;ctx.fillRect(0,0,256,256);
    const count=kind==='road'?6500:kind==='grass'?2800:800;
    for(let i=0;i<count;i++){const alpha=(kind==='road'?.035:.055)+this.random()*.075;ctx.fillStyle=this.random()>.5?`rgba(255,255,255,${alpha})`:`rgba(0,0,0,${alpha})`;const size=this.random()*1.8+.5;ctx.fillRect(this.random()*256,this.random()*256,size,size);}
    if(kind==='paving'){ctx.strokeStyle='rgba(74,66,55,.16)';ctx.lineWidth=1;for(let y=0;y<256;y+=32){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(256,y);ctx.stroke();for(let x=(y%64?16:0);x<256;x+=64){ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x,y+32);ctx.stroke();}}}
    if(kind==='water'){ctx.strokeStyle='rgba(201,232,239,.13)';ctx.lineWidth=1.8;for(let i=0;i<50;i++){const x=this.random()*256,y=this.random()*256;ctx.beginPath();ctx.moveTo(x,y);ctx.bezierCurveTo(x+10,y+2,x+22,y-2,x+35,y);ctx.stroke();}}
    const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.anisotropy=this.low?1:4;this.textures.add(texture);return texture;
  }
  private plane(parent:THREE.Object3D,x:number,z:number,width:number,length:number,y:number,color:string,kind:'road'|'paving'|'grass'|'water',tileX:number,tileZ:number) {
    const texture=this.surface(kind,color);texture.repeat.set(tileX,tileZ);const material=new THREE.MeshStandardMaterial({map:texture,roughness:kind==='water'?.38:kind==='road'?.87:.94,metalness:kind==='water'?.22:0,color:'#ffffff'});this.materials.set(`surface-${this.materials.size}`,material);
    const plane=this.mesh(parent,this.geo('plane',()=>new THREE.PlaneGeometry()),material,[x,y,z],[width,length,1]);plane.rotation.x=-Math.PI/2;plane.castShadow=false;
    if(kind!=='grass')this.scrollingTextures.push({texture,period:length/tileZ});return plane;
  }
  private buildGround() {
    const p=this.palette,night=this.theme==='nightHarbor';
    this.plane(this.root,0,0,380,400,-.18,p.ground,'grass',35,35);
    this.plane(this.root,0,0,9.4,400,-.006,p.road,'road',2.4,90);
    for(const side of [-1,1]){
      this.plane(this.root,side*5.45,0,1.5,400,.01,p.paving,'paving',1.5,160);
      this.box(this.root,[side*4.75,-.025,0],[.18,.11,400],night?'#a2b9c4':'#d4c5af');
      this.box(this.root,[side*6.2,.045,0],[.16,.16,400],night?'#778f9b':'#c1b28b');
      this.box(this.root,[side*4.38,.015,0],[.08,.012,400],night?'#cde5de':'#e9e2cd',0,night?.3:0);
    }
    const waterX=this.theme==='riverside'?-22:this.theme==='nightHarbor'?-33:-11,waterWidth=this.theme==='riverside'?28:this.theme==='nightHarbor'?48:5.6;
    this.plane(this.root,waterX,0,waterWidth,400,-.15,p.water,'water',waterWidth/4,70);
    this.box(this.root,[this.theme==='village'?-8.1:-8,-.08,0],[.3,.35,400],night?'#7d949d':'#9b9a76');
    this.root.add(this.markings,this.waterHighlights);
    const dashes=new THREE.InstancedMesh(this.geo('dash',()=>new THREE.BoxGeometry(.08,.012,3.8)),this.mat(night?'#cce2d8':'#f2e7cb',0,night?.2:0),112),matrix=new THREE.Matrix4();
    for(let i=0;i<56;i++)for(let lane=0;lane<2;lane++){matrix.makeTranslation((lane-.5)*CYCLING_LANE_WIDTH,.018,164-i*6);dashes.setMatrixAt(i*2+lane,matrix);}this.markings.add(dashes);
    const studs=new THREE.InstancedMesh(this.geo('stud',()=>new THREE.BoxGeometry(.09,.025,.22)),this.mat(night?'#90dccb':'#e8c77f',.3,night?.8:0),88);
    for(let i=0;i<44;i++)for(let side=0;side<2;side++){matrix.makeTranslation((side?1:-1)*4.42,.04,172-i*8);studs.setMatrixAt(i*2+side,matrix);}this.markings.add(studs);
    const ripples=new THREE.InstancedMesh(this.geo('glint',()=>new THREE.BoxGeometry(1.4,.01,.035)),this.mat(night?'#5d9aac':'#a5d4cf',0,night?.15:0),65);
    for(let i=0;i<65;i++){matrix.makeTranslation(waterX+Math.sin(i*7)*waterWidth*.4,-.135,174-i*5.7);ripples.setMatrixAt(i,matrix);}this.waterHighlights.add(ripples);
  }

  private railing(parent:THREE.Group,x:number,z:number,style:'wood'|'metal') {
    const rail=this.model(parent,x,z,'promenade-railing'),color=style==='wood'?'#bea17b':'#7b9caa';
    for(let i=0;i<5;i++){this.box(rail,[0,.52,-i*5.5],[.12,1.04,.13],color,style==='metal'?.4:0);this.box(rail,[0,1.08,-i*5.5],[.18,.09,.19],style==='wood'?'#e0c79b':'#bcd8df');}
    for(const y of [.37,.85])this.box(rail,[0,y,-11],[.07,.07,22],color,style==='metal'?.4:0);
    if(style==='metal')for(let i=0;i<20;i++)this.box(rail,[0,.55,-i*1.12],[.045,.66,.045],color,.4);
    this.batch(rail);
  }
  private tree(parent:THREE.Group,x:number,z:number,willow:boolean,variant:number) {
    const height=willow?4.1:3.5+variant*.25,tree=this.model(parent,x,z,willow?'weeping-willow':'village-plane-tree',height*.8,height*.6);if(x>0)this.roadTrees.push(tree);
    this.cylinder(tree,[0,height*.46,0],willow?.16:.22,height*.92,'#82705a',0,10,.65);
    for(let i=0;i<4;i++){const a=i*Math.PI/2+.4;this.rod(tree,[0,height*.55,0],[Math.cos(a)*.85,height*.85,Math.sin(a)*.85],.07,'#82705a');}
    const greens=willow?['#729968','#86a773','#a1b983']:['#647f53','#82995c','#a3ad6e'];
    this.sphere(tree,[0,height,0],[1.42,1.22,1.4],greens[0],this.low?1:2);
    for(let i=0;i<(this.low?3:5);i++){const a=i*TAU/5;this.sphere(tree,[Math.cos(a)*1.02,height-(willow?.68:.17),Math.sin(a)*1.02],[willow?.60:.88,willow?1.38:1.1,willow?.60:.8],greens[1+i%2],this.low?1:2);}
    this.batch(tree);
  }
  private lamp(parent:THREE.Group,x:number,z:number,harbor=false) {
    const lamp=this.model(parent,x,z,harbor?'harbor-light':'lantern-post',.65,2.7),color=harbor?'#6f8595':'#5b7167';
    this.cylinder(lamp,[0,.2,0],.2,.4,color,.45);this.cylinder(lamp,[0,2,0],.065,3.8,color,.5);
    if(harbor){this.rod(lamp,[0,3.8,0],[-Math.sign(x)*.75,4.05,0],.045,color,.5);this.box(lamp,[-Math.sign(x)*.74,4.03,0],[.70,.12,.27],'#aebfc7',.4);this.box(lamp,[-Math.sign(x)*.74,3.96,0],[.53,.025,.2],'#f9d29a',0,1.7);}
    else {this.box(lamp,[0,3.85,0],[.36,.46,.36],'#efdaad',0,.32);for(const dx of [-.19,.19])for(const dz of [-.19,.19])this.box(lamp,[dx,3.85,dz],[.03,.48,.03],color,.3);this.cylinder(lamp,[0,4.15,0],.32,.22,color,.35,4,0);}
    this.batch(lamp);
    if(harbor&&!this.low){const glow=this.mesh(lamp,this.geo('lamp-pool',()=>new THREE.CircleGeometry(1,24)),new THREE.MeshBasicMaterial({color:'#a5c7bf',transparent:true,opacity:.1,depthWrite:false}),[-Math.sign(x)*1.6,.02,0],[2.0,3.8,1]);glow.rotation.x=-Math.PI/2;glow.castShadow=false;this.extraMaterials.add(glow.material);}
  }
  private readonly extraMaterials=new Set<THREE.Material>();
  private bench(parent:THREE.Group,x:number,z:number,rotation=0) {
    const bench=this.model(parent,x,z,'slatted-bench');bench.rotation.y=rotation;
    for(let i=0;i<4;i++)this.box(bench,[0,.50,(i-1.5)*.13],[1.65,.07,.105],'#ae8c64');
    for(let i=0;i<3;i++)this.box(bench,[0,.74+i*.14,-.29],[1.65,.1,.055],'#ae8c64');
    for(const side of [-1,1]){this.box(bench,[side*.61,.28,0],[.075,.55,.55],'#5c7067',.4);this.box(bench,[side*.61,.8,-.29],[.07,.67,.065],'#5c7067',.4);}this.batch(bench);
  }
  private flowers(parent:THREE.Group,x:number,z:number,color:string) {
    const planter=this.model(parent,x,z,'flower-planter');this.box(planter,[0,.22,0],[1.5,.42,.62],'#ab8365');this.box(planter,[0,.44,0],[1.38,.025,.53],'#756c50');
    for(let i=0;i<5;i++){this.sphere(planter,[(i-2)*.27,.6,Math.sin(i)*.12],[.24,.24,.24],'#5e8e61');this.sphere(planter,[(i-2)*.27,.79,Math.sin(i)*.12],[.105,.09,.105],color);}this.batch(planter);
  }

  private gazebo(parent:THREE.Group,x:number,z:number) {
    const g=this.model(parent,x,z,'riverside-pavilion',3,2.8);
    this.cylinder(g,[0,.16,0],2.35,.32,'#cbb38d',0,6);this.cylinder(g,[0,.35,0],2.05,.12,'#dbcaac',0,6);
    for(let i=0;i<6;i++){const a=i*TAU/6;this.cylinder(g,[Math.cos(a)*1.78,1.65,Math.sin(a)*1.78],.09,2.65,'#9b8566');}
    this.cylinder(g,[0,3.05,0],2.55,1.05,'#6d907c',.08,6,0);this.cylinder(g,[0,3.63,0],.11,.2,'#d7bf8f',.3);
    this.cylinder(g,[0,.92,0],.62,.13,'#b1946b',0,16);this.cylinder(g,[0,.65,0],.12,.5,'#9c8263');this.batch(g);
  }
  private sailboat(parent:THREE.Group,x:number,z:number) {
    const boat=this.model(parent,x,z,'river-sailboat');boat.rotation.y=.28;
    this.mesh(boat,this.geo('boat-hull',()=>new THREE.CylinderGeometry(1,.75,1,6)),this.mat('#e9ddbd'),[0,.13,0],[.9,.45,2.2]);
    this.box(boat,[0,.37,0],[1.16,.12,3],'#ac8e67');this.cylinder(boat,[0,2.1,0],.035,3.6,'#b6a887',.3);
    const sail=this.geo('sail',()=>{const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute([0,0,0,0,2.9,0,1.4,0,0],3));g.setAttribute('uv',new THREE.Float32BufferAttribute([0,0,0,1,1,0],2));g.computeVertexNormals();return g;});const m=this.mat('#f4e8c9');m.side=THREE.DoubleSide;this.mesh(boat,sail,m,[.06,.68,0],[1,1,1]);
    this.rod(boat,[0,.68,0],[1.48,.68,0],.025,'#a4997c');this.batch(boat);
  }
  private riversideBlock(chunk:THREE.Group,i:number) {
    this.railing(chunk,-7,0,'wood');this.tree(chunk,8.5,-4,true,i%3);this.tree(chunk,17,-17,false,i%3);
    this.box(chunk,[10,.03,-13],[5.9,.1,5.2],'#7fa76f');
    if(i%3===0){this.gazebo(chunk,13,-7);this.flowers(chunk,7,-14,'#d9b4a1');}
    else if(i%3===1){this.bench(chunk,7,-12,-Math.PI/2);this.sailboat(chunk,-17,-10);}
    else {const pier=this.model(chunk,-10,-8,'timber-landing');for(let j=0;j<14;j++)this.box(pier,[0,.1,-j*.34],[4.5,.18,.29],'#b49b76');for(const x of [-2,2])for(const z of [0,-4])this.cylinder(pier,[x,.43,z],.1,.95,'#8c795d');this.batch(pier);this.bench(chunk,7,-13,-Math.PI/2);}
    this.lamp(chunk,5.8,-20);for(let j=0;j<4;j++){const reed=this.model(chunk,-8.5,-j*5,'river-reeds');for(let k=0;k<3;k++)this.rod(reed,[k*.12,0,0],[k*.15,.6+k*.15,.16],.02,'#6d8e62');this.batch(reed);}
  }

  private house(parent:THREE.Group,x:number,z:number,i:number) {
    const h=this.model(parent,x,z,'village-workshop',4.8,2.8);h.rotation.y=x<0?Math.PI/2:-Math.PI/2;
    const plaster=['#d7c7a5','#c6cdb4','#d9b296'][i%3],roof=['#ae6f58','#778576','#8d7c69'][i%3];
    this.box(h,[0,2.05,0],[4.8,4.1,4.9],plaster);this.box(h,[0,.18,0],[5,.36,5.1],'#a19177');
    const roofGeo=this.geo('gable-roof',()=>{const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute([-1,0,-1,1,0,-1,0,1,-1,-1,0,1,0,1,1,1,0,1,-1,0,-1,0,1,-1,-1,0,1,0,1,-1,0,1,1,-1,0,1,1,0,-1,1,0,1,0,1,-1,0,1,-1,1,0,1,0,1,1],3));const indices:number[]=[];for(let n=0;n<geometry.getAttribute('position').count;n+=3)indices.push(n,n+2,n+1);geometry.setIndex(indices);geometry.computeVertexNormals();return geometry;});
    this.mesh(h,roofGeo,this.mat(roof),[0,4.1,0],[2.68,1.45,2.72]);
    for(const side of [-1,1])for(let row=0;row<5;row++)this.rod(h,[side*(.3+row*.50),5.39-row*.27,-2.76],[side*(.3+row*.50),5.39-row*.27,2.76],.023,roof);
    this.box(h,[1.45,5.16,-.95],[.55,1.4,.55],'#aa937b');this.box(h,[1.45,5.9,-.95],[.69,.17,.7],'#8b8070');
    for(const y of [.65,2.7,4.05])this.box(h,[0,y,2.48],[4.83,.12,.12],'#958571');
    for(const x0 of [-2.26,0,2.26])this.box(h,[x0,2.05,2.48],[.10,4.05,.12],'#958571');
    for(const x0 of [-1.28,1.28])for(const y of [1.45,3.28]){
      this.box(h,[x0,y,2.53],[1.13,.94,.1],'#f0e2c2');this.box(h,[x0,y,2.595],[.90,.74,.05],'#668e91',.1);this.box(h,[x0,y,2.63],[.06,.79,.045],'#e9d7b2');this.box(h,[x0,y,2.63],[.94,.055,.045],'#e9d7b2');
      for(const side of [-1,1])this.box(h,[x0+side*.71,y,2.57],[.28,.94,.07],i%2?'#7d957f':'#ad8162');
      this.box(h,[x0,y-.55,2.66],[1.25,.13,.32],'#c1ac89');
    }
    this.box(h,[0,.90,2.57],[.7,1.8,.16],'#877761');this.cylinder(h,[.19,.98,2.68],.035,.025,'#d1b16d',.7).rotation.x=Math.PI/2;
    if(i%2===0){for(let n=0;n<9;n++)this.box(h,[(n-4)*.4,2.19,3.12],[.40,.10,1.1],n%2?'#c6785d':'#eddfbd');for(const side of [-1,1])this.cylinder(h,[side*1.76,1.1,3.64],.035,2.2,'#82755e');}
    this.batch(h);this.flowers(parent,x-Math.sign(x)*3.2,z+1.9,i%2?'#d2b764':'#d59b85');
  }
  private villageBlock(chunk:THREE.Group,i:number) {
    this.house(chunk,11.4,-5,i);if(i%2===0)this.house(chunk,-18,-10,i+1);else this.tree(chunk,-16,-10,false,i%3);
    this.tree(chunk,7.6,-18,false,i%3);this.railing(chunk,-7,0,'wood');this.lamp(chunk,5.8,-9);this.bench(chunk,6.8,-13,-Math.PI/2);
    if(i%3===0){const cart=this.model(chunk,7.3,-2,'market-crate');for(let j=0;j<3;j++)this.box(cart,[(j-1)*.45,.33,0],[.42,.62,.6],'#ad8b5f');for(let j=0;j<6;j++)this.sphere(cart,[(j%3-1)*.4,.70,Math.floor(j/3)*.25-.1],[.14,.14,.14],j%2?'#cf9d61':'#97a261');this.batch(cart);}
    // Gate pillars and paving lead into each workshop courtyard.
    this.box(chunk,[8.1,.035,-5],[3.8,.1,4.6],'#c3b297');for(const z of [-2.5,-7.5]){this.box(chunk,[7,.57,z],[.35,1.13,.35],'#b1a389');this.box(chunk,[7,1.15,z],[.44,.12,.44],'#d2c3a5');}
  }

  private container(parent:THREE.Group,x:number,y:number,z:number,color:string) {
    const c=this.model(parent,x,z,'corrugated-shipping-container');c.position.y=y;
    this.box(c,[0,1.2,0],[2.7,2.4,5.5],color,.35);for(const side of [-1,1])for(let i=0;i<13;i++)this.box(c,[side*1.37,1.2,(i-6)*.41],[.07,2.24,.075],color,.45);
    for(const side of [-1,1]){this.box(c,[side*.66,1.2,2.79],[1.29,2.25,.075],color,.35);this.box(c,[side*.48,1.2,2.85],[.035,2.05,.05],'#9bb5bd',.7);}
    for(const y0 of [.11,2.3])this.box(c,[0,y0,2.87],[2.77,.08,.07],'#8da2ac',.65);this.batch(c);
  }
  private crane(parent:THREE.Group,x:number,z:number) {
    const c=this.model(parent,x,z,'harbor-gantry-crane',5,6),color='#b89858';
    for(const side of [-1,1]){this.box(c,[side*1.3,3,0],[.28,6,.32],color,.55);this.box(c,[side*1.3,.18,0],[.7,.35,2.0],'#526a78',.55);}
    for(let j=0;j<3;j++){this.rod(c,[-1.3,j*1.8,0],[1.3,(j+1)*1.8,0],.08,color,.5);this.rod(c,[1.3,j*1.8,0],[-1.3,(j+1)*1.8,0],.08,color,.5);}
    this.box(c,[0,6,0],[3,.28,.44],color,.6);this.box(c,[-2.4,6.55,0],[7.8,.26,.28],color,.6);this.rod(c,[0,7.4,0],[-6.3,6.55,0],.035,'#9db0b8',.7);this.box(c,[0,7.03,0],[.23,1.0,.23],color,.55);
    this.rod(c,[-5.4,6.52,0],[-5.4,2.1,0],.024,'#7a929e',.7);this.box(c,[-5.4,2,0],[.42,.21,.36],'#b0a16d',.6);
    this.box(c,[.6,5.65,.68],[1.3,1.15,1.3],'#a68d58',.55);this.box(c,[.6,5.78,1.35],[1.05,.68,.035],'#9bc1ce',.4,.15);this.batch(c);
  }
  private ship(parent:THREE.Group,x:number,z:number) {
    const ship=this.model(parent,x,z,'moored-working-boat',7.5,2.8);
    this.mesh(ship,this.geo('ship-hull',()=>new THREE.CylinderGeometry(1,.8,1,8)),this.mat('#355366',.3),[0,.53,0],[2.4,1.4,7]);this.box(ship,[0,1.24,0],[3.85,.16,11.7],'#86948d',.2);
    this.box(ship,[0,2.03,1.8],[2.9,1.5,3.2],'#c1c8bd');this.box(ship,[0,2.84,1.8],[3.17,.14,3.5],'#557789',.5);
    for(const side of [-1,1])this.box(ship,[side*1.47,2.19,1.8],[.045,.61,2.43],'#90c2d0',.25,.3);
    this.box(ship,[0,2.2,3.42],[2.4,.6,.055],'#90c2d0',.3,.25);this.cylinder(ship,[0,4,1.8],.045,2.3,'#879ea6',.5);
    for(const side of [-1,1])for(let j=0;j<5;j++){this.cylinder(ship,[side*2,1.58,-4.8+j*2.2],.025,.65,'#bccbd0',.7);if(j<4)this.rod(ship,[side*2,1.9,-4.8+j*2.2],[side*2,1.9,-2.6+j*2.2],.018,'#bccbd0',.7);}
    this.batch(ship);
  }
  private lighthouse(parent:THREE.Group,x:number,z:number) {
    const tower=this.model(parent,x,z,'harbor-lighthouse',3.5,5.7);
    for(let i=0;i<5;i++)this.cylinder(tower,[0,1+i*1.9,0],1.4-i*.11,1.9,i%2?'#af6c61':'#d8d5bf',.08,20,.96);
    this.cylinder(tower,[0,10,0],1.4,.18,'#738b94',.5);this.cylinder(tower,[0,10.7,0],.98,1.35,'#e8d8a2',.1,12);this.cylinder(tower,[0,11.58,0],1.45,.65,'#526f82',.4,12,0);
    for(let i=0;i<8;i++){const a=i*TAU/8;this.cylinder(tower,[Math.cos(a),10.7,Math.sin(a)],.037,1.3,'#728894',.6);}
    this.batch(tower);const beacon=new THREE.Group();beacon.position.y=10.7;tower.add(beacon);this.beaconGroups.push(beacon);
    const material=new THREE.MeshBasicMaterial({color:'#fff3bf',transparent:true,opacity:.065,side:THREE.DoubleSide,depthWrite:false});this.extraMaterials.add(material);
    const beam=this.mesh(beacon,this.geo('beacon-cone',()=>new THREE.ConeGeometry(2.6,18,20,1,true)),material,[9,0,0],[1,1,1]);beam.rotation.z=Math.PI/2;beam.castShadow=false;
  }
  private harborBlock(chunk:THREE.Group,i:number) {
    this.railing(chunk,-7,0,'metal');this.lamp(chunk,5.8,-4,true);this.lamp(chunk,-5.8,-16,true);
    this.box(chunk,[-10,.05,-10],[4,.30,23],'#6d818a');
    const yard=this.model(chunk,11.5,-9,'container-yard',5,2.5);this.container(yard,0,0,0,i%2?'#497887':'#a17f5a');this.container(yard,3.0,0,-1,'#647d84');if(i%2===0)this.container(yard,1.6,2.4,-.7,'#8b7770');
    if(i%4===0)this.crane(chunk,-12,-10);else if(i%4===1)this.ship(chunk,-20,-9);else if(i%4===2)this.lighthouse(chunk,-24,-8);
    const bollards=this.model(chunk,-8.4,-3,'mooring-bollards');for(let j=0;j<3;j++){this.cylinder(bollards,[0,.32,-j*7],.20,.64,'#324b5b',.6);this.box(bollards,[0,.52,-j*7],[.70,.18,.18],'#c0a75d',.5);}this.batch(bollards);
    const shed=this.model(chunk,21,-6,'port-warehouse',6,3);this.box(shed,[0,2.5,0],[8,5,10],'#637780',.2);this.box(shed,[0,5.12,0],[8.7,.28,10.7],'#435f72',.5);for(let n=0;n<3;n++)this.box(shed,[-4.03,2,-3+n*3],[.06,2.9,2.2],'#375164',.45);this.batch(shed);
  }

  private buildHorizon() {
    if(this.theme==='nightHarbor'){
      const skyline=this.model(this.root,0,0,'harbor-skyline');for(const side of [-1,1])for(let i=0;i<10;i++){const x=side*(45+i*7),height=8+(i%4)*4,z=-65-i%3*22;this.box(skyline,[x,height*.5,z],[6,height,9],i%2?'#2a4559':'#304e63');for(let row=0;row<4;row++)this.box(skyline,[x,row*2.5+2,z+4.55],[4,.13,.04],'#739eaa',0,.7);}this.batch(skyline);
      const moon=this.mesh(this.root,this.geo('moon',()=>new THREE.SphereGeometry(1,24,16)),new THREE.MeshBasicMaterial({color:'#e7edcf'}),[-41,42,-115],[3.1,3.1,3.1]);moon.castShadow=false;this.extraMaterials.add(moon.material);
      const starGeometry=new THREE.BufferGeometry(),positions=[];for(let i=0;i<120;i++)positions.push((this.random()-.5)*300,32+this.random()*70,-70-this.random()*100);starGeometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));this.geometryCache.set('stars',starGeometry);const starMat=new THREE.PointsMaterial({color:'#bed5dd',size:.21,sizeAttenuation:true});this.extraMaterials.add(starMat);this.root.add(new THREE.Points(starGeometry,starMat));
    }else{
      for(const side of [-1,1])for(let i=0;i<4;i++)this.sphere(this.root,[side*(37+i*20),-2,-72-i*25],[26,10+i*2.5,35],this.theme==='riverside'?(i%2?'#9eb69a':'#91aa8a'):(i%2?'#a7b398':'#9faa89'),2);
      for(let i=0;i<7;i++){const cloud=this.model(this.root,(i-3)*20,-92-(i%3)*18,'cloud');cloud.position.y=26+(i%2)*5;for(let j=0;j<3;j++)this.sphere(cloud,[(j-1)*2.5,Math.sin(j)*.4,0],[3.8,1.2,1.7],'#eff0df',2);this.batch(cloud);}
    }
  }
  update(distance:number,time:number) {
    for(let i=0;i<this.chunks.length;i++)this.chunks[i].position.z=((distance+i*24)%288)-163;
    this.markings.position.z=distance%6;this.waterHighlights.position.z=distance%5.7;
    for(const {texture,period} of this.scrollingTextures)texture.offset.y=-(distance/period)%1;
    this.beaconGroups.forEach((beacon,i)=>{beacon.rotation.y=time*.19+i;});
  }
  dispose() {for(const g of this.geometryCache.values())g.dispose();for(const m of this.materials.values())m.dispose();for(const m of this.extraMaterials)m.dispose();for(const t of this.textures)t.dispose();this.root.removeFromParent();this.root.clear();this.geometryCache.clear();this.materials.clear();this.extraMaterials.clear();this.textures.clear();}
}

const TAU=Math.PI*2;
