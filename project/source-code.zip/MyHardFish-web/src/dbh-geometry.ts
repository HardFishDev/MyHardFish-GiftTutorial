import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

export const point = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
export type ProfileRing = { y: number; x: number; z: number; cx?: number; cz?: number };

/** UV endpoints share a position; keep their normals continuous across the wrap. */
export function smoothUvSeamNormals(geometry: THREE.BufferGeometry, rowSize: number): void {
  const normals = geometry.getAttribute('normal');
  for (let first = 0; first < normals.count; first += rowSize) {
    const last = first + rowSize - 1;
    const x = normals.getX(first) + normals.getX(last);
    const y = normals.getY(first) + normals.getY(last);
    const z = normals.getZ(first) + normals.getZ(last);
    const length = Math.hypot(x, y, z);
    if (length > 1e-10) {
      normals.setXYZ(first, x / length, y / length, z / length);
      normals.setXYZ(last, x / length, y / length, z / length);
    }
  }
}

/** Smooth closed ring loft, used for anatomy and sewn garments instead of stacked primitives. */
export function loft(rings: ProfileRing[], segments = 32, cloth = false, subdivisions = 4): THREE.BufferGeometry {
  if (rings[0].y > rings[rings.length - 1].y) rings = [...rings].reverse();
  // Interpolate the authored anatomical sections in height. Straight spans between
  // sparse calf/jaw sections otherwise leave a visibly polygonal silhouette.
  const draft=rings, dense:ProfileRing[]=[];
  const value=(i:number,key:'x'|'z'|'cx'|'cz')=>draft[i][key]??0;
  const slope=(i:number,key:'x'|'z'|'cx'|'cz')=>{
    const before=Math.max(0,i-1),after=Math.min(draft.length-1,i+1);
    if(before===i)return (value(after,key)-value(i,key))/(draft[after].y-draft[i].y);
    if(after===i)return (value(i,key)-value(before,key))/(draft[i].y-draft[before].y);
    const a=(value(i,key)-value(before,key))/(draft[i].y-draft[before].y);
    const b=(value(after,key)-value(i,key))/(draft[after].y-draft[i].y);
    return a*b<=0?0:2*a*b/(a+b);
  };
  for(let i=0;i<draft.length-1;i++)for(let step=0;step<subdivisions;step++){
    const t=step/subdivisions,h=draft[i+1].y-draft[i].y,ring:ProfileRing={y:draft[i].y+h*t,x:0,z:0};
    for(const key of ['x','z','cx','cz'] as const){
      const a=value(i,key),b=value(i+1,key);
      const result=(2*t**3-3*t*t+1)*a+(t**3-2*t*t+t)*h*slope(i,key)+(-2*t**3+3*t*t)*b+(t**3-t*t)*h*slope(i+1,key);
      ring[key]=THREE.MathUtils.clamp(result,Math.min(a,b),Math.max(a,b));
    }
    dense.push(ring);
  }
  dense.push(draft[draft.length-1]);rings=dense;
  const positions: number[] = [], uvs: number[] = [], indices: number[] = [];
  rings.forEach((ring, i) => {
    for (let j = 0; j <= segments; j++) {
      const angle = j / segments * Math.PI * 2;
      const phase=(ring.y-rings[0].y)/(rings[rings.length-1].y-rings[0].y);
      const wrinkle = cloth ? (Math.sin(angle * 7 + phase * 6) * .003 + Math.cos(angle * 11 - phase * 8) * .002) * Math.min(1, Math.min(ring.x, ring.z) / .018) : 0;
      positions.push((ring.cx ?? 0) + Math.sin(angle) * (ring.x + wrinkle), ring.y, (ring.cz ?? 0) + Math.cos(angle) * (ring.z + wrinkle));
      uvs.push(j / segments, phase);
      if (i && j) {
        const a = i * (segments + 1) + j, b = a - segments - 1;
        indices.push(a - 1, b, a, b - 1, b, a - 1);
      }
    }
  });
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  smoothUvSeamNormals(geometry, segments + 1);
  return geometry;
}

export function mesh(group: THREE.Group, geometry: THREE.BufferGeometry, material: THREE.Material, position?: THREE.Vector3, scale?: THREE.Vector3): THREE.Mesh {
  const object = new THREE.Mesh(geometry, material);
  if (position) object.position.copy(position);
  if (scale) object.scale.copy(scale);
  object.castShadow = true;
  object.receiveShadow = true;
  group.add(object);
  return object;
}

export function ellipsoid(group: THREE.Group, material: THREE.Material, position: THREE.Vector3, scale: THREE.Vector3, segments = 24): THREE.Mesh {
  return mesh(group, new THREE.SphereGeometry(1, segments, Math.max(12, segments / 2)), material, position, scale);
}

export function line(group: THREE.Group, material: THREE.Material, points: THREE.Vector3[], radius = .005, tubularSegments = 24, closed = false): THREE.Mesh {
  return mesh(group, new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points, closed), tubularSegments, radius, 5, closed), material);
}

export function ellipsePoints(rx: number, rz: number, y: number, centerZ = 0, segments = 48): THREE.Vector3[] {
  return Array.from({ length: segments }, (_, i) => point(Math.sin(i / segments * Math.PI * 2) * rx, y, Math.cos(i / segments * Math.PI * 2) * rz + centerZ));
}

/** Elliptical swept locks have a real volume, a tapered tip, and UVs running along the hair. */
export function hairLock(points: THREE.Vector3[], width: number, depth: number, normal = point(0, 0, 1), segments = 26): THREE.BufferGeometry {
  const curve = new THREE.CatmullRomCurve3(points);
  const positions: number[] = [], uvs: number[] = [], indices: number[] = [];
  const sides = 10;
  let previousCross: THREE.Vector3 | undefined;
  for (let i = 0; i <= segments; i++) {
    const t = i / segments, center = curve.getPoint(t), tangent = curve.getTangent(t);
    const cross = new THREE.Vector3().crossVectors(tangent, normal);
    // At a crown/side bend the tangent may align with the preferred face normal.
    // Carry the last width axis through that point instead of collapsing the lock.
    if (cross.lengthSq() < 1e-8 && previousCross) cross.copy(previousCross).projectOnPlane(tangent);
    if (cross.lengthSq() < 1e-8) cross.crossVectors(tangent, Math.abs(tangent.y) < .9 ? point(0, 1, 0) : point(1, 0, 0));
    cross.normalize();
    if (previousCross && cross.dot(previousCross) < 0) cross.negate();
    previousCross = cross.clone();
    const out = new THREE.Vector3().crossVectors(cross, tangent).normalize();
    const taper = (.42 + .58 * Math.sin(Math.min(1, t * 1.5) * Math.PI * .5)) * Math.pow(1 - t, .44) + .006;
    for (let j = 0; j <= sides; j++) {
      const angle = j / sides * Math.PI * 2;
      const p = center.clone().addScaledVector(cross, Math.cos(angle) * width * taper).addScaledVector(out, Math.sin(angle) * depth * Math.pow(taper, .7));
      positions.push(p.x, p.y, p.z);
      uvs.push(j / sides, t * 1.7);
      if (i && j) {
        const a = i * (sides + 1) + j, b = a - sides - 1;
        indices.push(a - 1, a, b, a - 1, b, b - 1);
      }
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  smoothUvSeamNormals(geo, sides + 1);
  return geo;
}

/** Batch within each joint only: animations remain independent and static details cost few draws. */
export function batchJointMeshes(group: THREE.Group): void {
  for (const child of [...group.children]) if (child instanceof THREE.Group) batchJointMeshes(child);
  const batches = new Map<THREE.Material, THREE.Mesh[]>();
  for (const child of group.children) {
    if (!(child instanceof THREE.Mesh) || Array.isArray(child.material) || child.userData.unbatched) continue;
    const existing = batches.get(child.material) ?? [];
    existing.push(child);
    batches.set(child.material, existing);
  }
  for (const [material, objects] of batches) {
    if (objects.length < 2) continue;
    const geometries = objects.map(object => {
      object.updateMatrix();
      const geometry = object.geometry.index ? object.geometry.toNonIndexed() : object.geometry.clone();
      geometry.applyMatrix4(object.matrix);
      return geometry;
    });
    const combined = mergeGeometries(geometries);
    if (combined) {
      for (const object of objects) { group.remove(object); object.geometry.dispose(); }
      mesh(group, combined, material);
    }
    geometries.forEach(geometry => geometry.dispose());
  }
}

export function canvasTexture(width: number, height: number, paint: (ctx: CanvasRenderingContext2D) => void): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (ctx) paint(ctx);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;
  return texture;
}
