import * as THREE from 'three';
import type { EnvironmentBuilder } from './environment';
import { path, boundaryForest, building, lamp, flowerBed, crate, noticeboard, pennants } from './world-town-props';

export function buildWorkshop(b:EnvironmentBuilder) {
  b.bounds={minX:-26,maxX:26,minZ:-26,maxZ:26};b.chunkSize=14;b.navigationStep=.5;b.floor('#97a782','plaster',114);boundaryForest(b,28,64);b.spawn.set(0,0,14);
  path(b,0,0,6,49);path(b,-2,4,45,5.5);path(b,0,-9,38,7);path(b,13,-4,4,25);path(b,-14,-5,4,24);path(b,0,-.5,22,23,'#c5c8ab');
  building(b,-13,-20,16,8,5.4,'#c5ceb5','#819a8b');building(b,13,-19,15,9,5.9,'#d2c7a8','#9c977b');
  // Open co-op desks: working monitors, keyboards, cups, server slots and a cable reel.
  b.table(-12,-10,6.7,3,1.55);
  for(const [x,label]of [[-13.5,'联机准备'],[-10.9,'等你加入']] as const){
    b.surface([1.75,1.22,.14],[x,2.66,-10.25],'#536b60','metal',.06);b.label(label,[x,2.66,-10.169],1.5,'#cfe1bc','#435c52');
    b.surface([.15,.49,.12],[x,1.91,-10.25],'#758774','metal',.02);b.surface([.8,.08,.48],[x,1.68,-10.25],'#8e9c87','metal',.03);
    b.surface([1.32,.07,.48],[x,1.7,-9.3],'#b8c4ad','metal',.03);for(let i=0;i<7;i++)b.surface([.12,.015,.3],[x-.5+i*.16,1.75,-9.3],'#809581','metal',.006);b.cup(x+.85,1.64,-9.9,'#ceb88f');
  }
  b.surface([1.45,2.5,1.2],[-16.2,1.3,-10.5],'#60796d','metal',.07);b.obstacle(-16.2,-10.5,1.6,1.35);
  for(let i=0;i<7;i++){b.surface([1.08,.05,.028],[-16.2,.48+i*.27,-9.878],'#9eae97','metal',.005);b.sphere([.042,.042,.025],[-15.8,.61+i*.27,-9.85],i%2?'#d1bf7b':'#9ac7b0');}
  const cable=b.torus(1.12,.037,[-15.3,.095,-8.6],'#62735e');cable.rotation.x=-Math.PI/2;cable.scale.y=.65;
  for(const x of [-14,-11]){b.cylinder(.45,.40,.15,[x,.9,-7.6],'#bda27e');for(const dx of [-.27,.27])b.surface([.08,.86,.6],[x+dx,.43,-7.6],'#6b7f6b','metal');b.obstacle(x,-7.6,1.1,1.1);b.seat(`workshop-stool:${x}`,[x,.975,-7.72],[x+1.25,0,-7.4],{facing:Math.PI,width:.9,depth:.9,surface:[x,1.62,-9.3],target:[x,1.75,-9.3]});}
  // Shared project: model houses, tools, rulers and unfinished pieces.
  b.table(0,-15,6.2,3.2,1.42);b.surface([5.3,.075,2.6],[0,1.54,-15],'#879978','fabric',.03);
  for(let i=0;i<7;i++){const x=-2.1+(i%4)*1.26,z=-15.7+Math.floor(i/4)*1.35;b.surface([.75,.55,.63],[x,1.86,z],i%2?'#d8c6a2':'#c1cbb1','wood',.015);const roof=b.mesh(new THREE.ConeGeometry(.68,.43,4),[x,2.36,z],'#93a286');roof.rotation.y=Math.PI/4;roof.scale.z=.8;}
  b.surface([1.5,.035,.18],[1.7,1.625,-13.8],'#ccb878','wood',.01);b.cup(-2.6,1.52,-14,'#bca379');b.surface([1.2,.015,.9],[-1.5,1.635,-14],'#dfdfc7','fabric',.005).rotation.y=.15;
  b.label('一起做点什么',[0,3.85,-16.9],5.1,'#586c58','#e8dbb7');
  b.label('酒窝 · 联机等候位',[-12,3.72,-10.2],3.1,'#5a705d','#e8dcbf');
  b.label('jin佬的工作笔记',[16,2.55,-10.1],2.85,'#5a705d','#e8dcbf');
  // Reuse station with open berry crates, labelled sorting bins and a hand cart.
  b.surface([4.1,.2,2.7],[12,.14,4],'#c7b68f','wood',.03);b.obstacle(12,4,4.3,2.8);
  for(let i=0;i<3;i++){const x=10.75+i*1.27;crate(b,x,.28,4,1.1);for(let j=0;j<12;j++)b.sphere([.12,.12,.12],[x+Math.sin(j*2.4)*.35,.99+Math.floor(j/6)*.13,4+Math.cos(j*2.4)*.24],j%3?'#ad7c76':'#8f626c');}
  noticeboard(b,14,7,'浆果回收','带回来，也分一点出去',4);
  for(const x of [16.8,18.1])crate(b,x,0,2.7);crate(b,17.45,.67,2.7);b.obstacle(17.45,2.7,2.8,1.25);
  for(const x of [15.8,17.5]){const wheel=b.torus(.37,.07,[x,.39,7.6],'#637363');wheel.rotation.y=Math.PI/2;}b.surface([2.3,.13,1.3],[16.6,.77,7.6],'#a6b291','wood');b.obstacle(16.6,7.6,2.6,1.6);
  b.surface([5.6,2.1,.15],[13,3.1,-13.9],'#aa9470','wood',.03);
  for(let i=0;i<7;i++){const x=10.9+i*.66;b.cylinder(.023,.023,.75,[x,3.13,-13.78],'#778778');b.surface([.39,.14,.12],[x,3.5,-13.75],i%2?'#89947f':'#b79b6d','metal',.02);}
  b.table(16,-9.4,5.2,2.6,1.4);for(let i=0;i<5;i++)b.surface([.65,.26,.48],[14.4+i*.77,1.66,-9.4],i%2?'#aa9775':'#8da080','wood',.025);
  b.bench(-13,12);b.table(-13,15.6,4,2.1,1.2);b.cup(-13.7,1.3,15.6);b.cup(-12.2,1.3,15.4);b.plant(-16.7,15,1.4);b.obstacle(-16.7,15,1.3,1.3);
  for(const [x,z]of [[-5,9],[5,9],[-21,-9],[21,-8],[-7,19],[7,19]])lamp(b,x,z);
  for(const [x,z]of [[-20,17],[19,17],[-21,-16],[22,-20]])b.tree(x,z,1.35);
  flowerBed(b,8,15,2,6);flowerBed(b,-7,16,2,5);pennants(b,[-19,5.8,-5],[19,5.8,-5],28);
  const ready=b.flagGroup('workshop_ready');for(let i=0;i<9;i++){const glow=b.sphere([.14,.17,.14],[-16+i*4,4.6,-5],'#ffe3a6',ready);const m=b.material('#ffe3a6');m.emissive.set('#e7bc6e');m.emissiveIntensity=.8;glow.material=m;}
  const project=b.flagGroup('exhibition_ready');b.surface([6.3,.46,.18],[0,2.9,-16.75],'#c8ad73','wood',.035,project);b.label('共同作品 · 完成',[0,2.95,-16.64],5.8,'#53694f','#ecd6a6',project);
  const harvest=b.flagGroup('harvest_ready');for(let i=0;i<8;i++)b.sphere([.2,.17,.2],[10.65+(i%4)*.8,1.4,4+Math.floor(i/4)*.35],'#b78b73',harvest);
}
