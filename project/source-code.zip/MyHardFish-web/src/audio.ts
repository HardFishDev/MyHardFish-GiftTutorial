import { quoteMap } from "./engine";
import type { Place } from "./scene";
import {
  loadAudioPreferences,
  normalizeAudioPreferences,
  type AudioPreferences,
} from "./audio-preferences";

export { loadAudioPreferences, saveAudioPreferences } from "./audio-preferences";
export type { AudioPreferences } from "./audio-preferences";
export type AudioEffectKind = "click" | "pet" | "feed" | "tease" | "reward" | "travel" | "outfit" | "dance";

let preferences = loadAudioPreferences();
let initialized = false;
let unlocked = false;
let lifecycle = 0;
const musicPlaces: readonly Place[] = ["home", "kitchen", "park", "shop", "school", "village", "workshop", "river", "market"];
const CROSSFADE_MS = 1200;
interface MusicTrack {
  scene: Place;
  audio: HTMLAudioElement;
  source: MediaElementAudioSourceNode | null;
  gain: GainNode | null;
  released: boolean;
  playing: boolean;
  buffering: boolean;
  hasPlayed: boolean;
  pending: boolean;
  attempt: number;
  timeout?: ReturnType<typeof setTimeout>;
  from: number;
  to: number;
  fadeAt: number;
  fadeDuration: number;
  retiring: boolean;
}
let musicScene: Place = "home";
let failedScene: Place | null = null;
const musicTracks = new Set<MusicTrack>();
let musicTarget: MusicTrack | null = null;
let fadeTimer: ReturnType<typeof setInterval> | undefined;
let context: AudioContext | null = null;
let musicGain: GainNode | null = null;
let effectsGain: GainNode | null = null;
const effectSources = new Set<OscillatorNode>();
let lastEffect = 0;
let lastEffectKind: AudioEffectKind | null = null;

let current: HTMLAudioElement | null = null;
let utterance: SpeechSynthesisUtterance | null = null;
let generation = 0;
let voiceActive = false;
let voiceTimeout: ReturnType<typeof setTimeout> | undefined;

const visible = () => typeof document !== "undefined" && !document.hidden;
const clamp = (value: number) => Number.isFinite(value) ? Math.max(0, Math.min(1, value)) : 0;

function musicLevel() {
  return preferences.music ? preferences.musicVolume * (voiceActive ? 0.22 : 1) : 0;
}

function fadeClock(track: MusicTrack) {
  // Native gain automation stops when its AudioContext is suspended. Its
  // envelope and retirement must use that same clock, not elapsed wall time.
  return track.gain && context ? context.currentTime * 1000 : performance.now();
}

function trackLevel(track: MusicTrack, now = fadeClock(track)) {
  const progress = track.fadeDuration ? Math.min(1, Math.max(0, (now - track.fadeAt) / track.fadeDuration)) : 1;
  return track.from + (track.to - track.from) * progress;
}

function isTrackReady(track: MusicTrack) {
  // paused=false also describes an element waiting for enough buffered data.
  return track.playing && !track.buffering && !track.audio.paused && track.audio.readyState >= 3;
}

function ensureContext() {
  if (context || typeof window === "undefined") return context;
  const Constructor = window.AudioContext ||
    (window as Window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Constructor) return null;
  try {
    context = new Constructor();
    effectsGain = context.createGain();
    effectsGain.connect(context.destination);
    // Track fades live upstream of this master: voice ducking and the volume
    // slider therefore cannot cancel or overwrite a crossfade automation.
    musicGain = context.createGain();
    musicGain.connect(context.destination);
    updateMix(true);
  } catch {
    effectsGain?.disconnect();
    musicGain?.disconnect();
    effectsGain = musicGain = null;
    const failed = context;
    context = null;
    if (failed && failed.state !== "closed") void failed.close().catch(() => {});
  }
  return context;
}

function updateMix(immediate = false) {
  const level = musicLevel();
  const effectLevel = preferences.effects ? (voiceActive ? 0.17 : 0.42) : 0;
  if (context && musicGain) {
    const now = context.currentTime;
    musicGain.gain.cancelScheduledValues(now);
    if (immediate) musicGain.gain.setValueAtTime(level, now);
    else musicGain.gain.setTargetAtTime(level, now, voiceActive ? 0.035 : 0.16);
  }
  for (const track of musicTracks) {
    if (!track.gain) track.audio.volume = clamp(level * trackLevel(track));
  }
  if (context && effectsGain) {
    effectsGain.gain.cancelScheduledValues(context.currentTime);
    effectsGain.gain.setTargetAtTime(effectLevel, context.currentTime, 0.018);
  }
}

function wantsMusic() {
  return initialized && unlocked && visible() && preferences.music && preferences.musicVolume > 0;
}

function clearTrackTimeout(track: MusicTrack) {
  if (track.timeout !== undefined) clearTimeout(track.timeout);
  track.timeout = undefined;
}

function releaseTrack(track: MusicTrack) {
  if (track.released) return;
  track.released = true;
  track.attempt++;
  clearTrackTimeout(track);
  track.audio.onplaying = track.audio.onwaiting = track.audio.onerror = null;
  track.audio.pause();
  track.audio.removeAttribute("src");
  track.audio.load();
  track.source?.disconnect();
  track.gain?.disconnect();
  track.source = track.gain = null;
  musicTracks.delete(track);
  if (musicTarget === track) musicTarget = null;
}

function stopFadeTimer() {
  if (fadeTimer !== undefined) clearInterval(fadeTimer);
  fadeTimer = undefined;
}

function tickFades() {
  let unfinished = false;
  for (const track of musicTracks) {
    const now = fadeClock(track);
    const level = trackLevel(track, now);
    if (!track.gain) track.audio.volume = clamp(musicLevel() * level);
    if (now < track.fadeAt + track.fadeDuration) unfinished = true;
    else if (track.retiring) releaseTrack(track);
  }
  if (!unfinished) stopFadeTimer();
}

function fadeTrack(track: MusicTrack, target: number, milliseconds: number, retiring = false) {
  const clock = fadeClock(track);
  const start = trackLevel(track, clock);
  track.from = start;
  track.to = target;
  track.fadeAt = clock;
  track.fadeDuration = milliseconds;
  track.retiring = retiring;
  if (context && track.gain) {
    const now = clock / 1000;
    track.gain.gain.cancelScheduledValues(now);
    track.gain.gain.setValueAtTime(start, now);
    if (milliseconds) track.gain.gain.linearRampToValueAtTime(target, now + milliseconds / 1000);
    else track.gain.gain.setValueAtTime(target, now);
  } else track.audio.volume = clamp(musicLevel() * (milliseconds ? start : target));
  if (milliseconds && fadeTimer === undefined) fadeTimer = setInterval(tickFades, 32);
}

// Turning music off or hiding the page invalidates pending play requests. Keep
// at most the already-playing current scene, paused at its current position.
function pauseMusic() {
  stopFadeTimer();
  failedScene = null;
  for (const track of musicTracks) {
    if (track.scene !== musicScene || !track.hasPlayed) {
      releaseTrack(track);
      continue;
    }
    track.attempt++;
    clearTrackTimeout(track);
    track.audio.onplaying = track.audio.onwaiting = track.audio.onerror = null;
    track.pending = track.playing = false;
    track.buffering = false;
    track.audio.pause();
    fadeTrack(track, 1, 0);
  }
  musicTarget = null;
}

function transitionTo(track: MusicTrack) {
  if (musicTarget === track && !track.retiring) return;
  musicTarget = track;
  failedScene = null;
  fadeTrack(track, 1, CROSSFADE_MS);
  for (const other of musicTracks) {
    if (other !== track) fadeTrack(other, 0, CROSSFADE_MS, true);
  }
}

function failTrack(track: MusicTrack, attempt: number) {
  if (track.released || attempt !== track.attempt) return;
  const wasCurrent = track.scene === musicScene;
  releaseTrack(track);
  if (wasCurrent) failedScene = musicScene;
  // A loading/decoding/autoplay failure never silences the known-good old song.
  for (const survivor of musicTracks) {
    if (survivor.playing && !survivor.audio.paused) {
      musicTarget = survivor;
      fadeTrack(survivor, 1, 180);
    }
  }
}

function createTrack(scene: Place): MusicTrack | null {
  if (typeof Audio === "undefined") return null;
  const audio = new Audio(`${import.meta.env.BASE_URL}audio/music-${scene}.mp3`);
  audio.loop = true;
  audio.preload = "none";
  audio.dataset.audioRole = "background-music";
  audio.dataset.musicScene = scene;
  audio.volume = 0;
  const track: MusicTrack = {
    scene, audio, source: null, gain: null, released: false, playing: false, buffering: false,
    hasPlayed: false, pending: false, attempt: 0, from: 0, to: 0,
    fadeAt: performance.now(), fadeDuration: 0, retiring: false,
  };
  musicTracks.add(track);
  if (context && musicGain) {
    try {
      track.gain = context.createGain();
      track.gain.gain.setValueAtTime(0, context.currentTime);
      track.gain.connect(musicGain);
      track.source = context.createMediaElementSource(audio);
      track.source.connect(track.gain);
      track.fadeAt = fadeClock(track);
      audio.volume = 1;
    } catch {
      // A partially connected source must not be left silently consuming media.
      releaseTrack(track);
      return null;
    }
  }
  return track;
}

function startTrack(track: MusicTrack) {
  if (track.pending || !wantsMusic()) return;
  // A browser can pause media independently (for example after an audio-focus
  // interruption). Restarting that same deck must schedule its fade-in again.
  if (musicTarget === track) musicTarget = null;
  // Returning to a still-buffering outgoing deck must cancel its retirement,
  // while the other ready song keeps sounding until this deck emits playing.
  for (const other of musicTracks) {
    if (other !== track && isTrackReady(other)) {
      musicTarget = other;
      fadeTrack(other, 1, 180);
    }
  }
  track.pending = true;
  track.playing = false;
  track.buffering = true;
  const attempt = ++track.attempt;
  const request = lifecycle;
  const valid = () => !track.released && attempt === track.attempt && request === lifecycle;
  fadeTrack(track, 0, 0);
  track.audio.onplaying = () => {
    if (!valid()) return;
    if (!wantsMusic()) { pauseMusic(); return; }
    // A pending candidate (including a restarted previously-played deck) is
    // obsolete as soon as the selection changes. This is not the same as an
    // already-audible outgoing deck recovering from a buffering gap.
    if (track.pending && track.scene !== musicScene) { releaseTrack(track); return; }
    if (track.audio.readyState < 3) return;
    clearTrackTimeout(track);
    track.pending = false;
    track.buffering = false;
    track.playing = track.hasPlayed = true;
    // An outgoing deck can recover from a buffering gap, but that event must
    // never retarget the crossfade away from the user's latest scene.
    if (track.scene === musicScene) transitionTo(track);
  };
  track.audio.onwaiting = () => { if (valid()) track.buffering = true; };
  track.audio.onerror = () => failTrack(track, attempt);
  track.timeout = setTimeout(() => failTrack(track, attempt), 15000);
  try {
    // Do not await context.resume() or a fetch before this call: the first
    // gesture must reach HTMLMediaElement.play() in the same activation task.
    void Promise.resolve(track.audio.play()).then(() => {
      if (track.released || request !== lifecycle ||
        (attempt !== track.attempt && !track.pending && !track.playing)) track.audio.pause();
    }).catch(() => failTrack(track, attempt));
  } catch {
    failTrack(track, attempt);
  }
}

function resumeMusic(retry = false) {
  if (!wantsMusic()) return;
  if (retry) failedScene = null;
  updateMix();
  const match = [...musicTracks].find(track => track.scene === musicScene);
  if (match) {
    // Returning to an existing target can make transitionTo() a no-op. Retire
    // the abandoned loader here instead of leaving a silent loop behind.
    for (const other of musicTracks) {
      if (other !== match && other.pending) releaseTrack(other);
    }
    if (match.pending) return;
    if (isTrackReady(match)) transitionTo(match);
    else startTrack(match);
    return;
  }
  if (failedScene === musicScene) return;
  // Rapid moves can interrupt an earlier transition. Preserve its most audible
  // ready track, retire every obsolete/pending deck, then admit only one new deck.
  const survivor = [...musicTracks]
    .filter(track => track.playing && !track.audio.paused)
    .sort((a, b) => Number(isTrackReady(b)) - Number(isTrackReady(a)) || trackLevel(b) - trackLevel(a))[0];
  for (const track of musicTracks) if (track !== survivor) releaseTrack(track);
  if (survivor) {
    musicTarget = survivor;
    fadeTrack(survivor, 1, 180);
  }
  const track = createTrack(musicScene);
  if (track) startTrack(track);
  else failedScene = musicScene;
}

/** Select a scene without bypassing user activation or the music preference. */
export function setMusicScene(place: Place): void {
  if (!musicPlaces.includes(place)) return;
  if (musicScene !== place) failedScene = null;
  musicScene = place;
  ensureLifecycle();
  if (!wantsMusic()) pauseMusic();
  else resumeMusic();
}

function stopEffects() {
  for (const source of effectSources) {
    try { source.stop(); } catch { /* A source may already have ended. */ }
    source.disconnect();
  }
  effectSources.clear();
}

function pauseForBackground() {
  pauseMusic();
  stopEffects();
  if (voiceActive) stopVoice();
  if (context?.state === "running") void context.suspend().catch(() => {});
}

function onVisibility() {
  if (!visible()) pauseForBackground();
  else if (unlocked) unlockAudio();
}

function onGesture(event: Event) {
  if (event instanceof KeyboardEvent && event.repeat) return;
  unlockAudio();
}

function ensureLifecycle() {
  if (initialized || typeof window === "undefined" || typeof document === "undefined") return;
  initialized = true;
  window.addEventListener("pointerdown", onGesture, { capture: true, passive: true });
  // Safari may grant media activation on the completed tap instead of pointerdown.
  window.addEventListener("click", onGesture, { capture: true, passive: true });
  window.addEventListener("keydown", onGesture, { capture: true });
  document.addEventListener("visibilitychange", onVisibility);
  window.addEventListener("pagehide", pauseForBackground);
  window.addEventListener("pageshow", onVisibility);
}

/** Apply preferences immediately. Persistence is intentionally a separate call. */
export function configureAudio(value: AudioPreferences): void {
  preferences = normalizeAudioPreferences(value);
  ensureLifecycle();
  updateMix();
  if (!preferences.effects) stopEffects();
  if (!wantsMusic()) pauseMusic();
  else resumeMusic();
}

/** Safe to call on every user gesture; all autoplay/resume promises are handled. */
export function unlockAudio(): void {
  ensureLifecycle();
  if (!visible()) return;
  unlocked = true;
  const active = ensureContext();
  if (active && active.state !== "running" && active.state !== "closed") {
    void active.resume().catch(() => {
      if (context === active) stopEffects();
    });
  }
  resumeMusic(true);
}

function tone(active: AudioContext, frequency: number, end: number, delay: number, duration: number, volume: number, shape: OscillatorType = "sine") {
  if (!effectsGain) return;
  const at = active.currentTime + delay;
  const source = active.createOscillator();
  const envelope = active.createGain();
  source.type = shape;
  source.frequency.setValueAtTime(frequency, at);
  source.frequency.exponentialRampToValueAtTime(end, at + duration);
  envelope.gain.setValueAtTime(0, at);
  envelope.gain.linearRampToValueAtTime(volume, at + Math.min(0.008, duration / 4));
  envelope.gain.exponentialRampToValueAtTime(0.0001, at + duration);
  source.connect(envelope);
  envelope.connect(effectsGain);
  effectSources.add(source);
  source.onended = () => {
    effectSources.delete(source);
    source.disconnect();
    envelope.disconnect();
  };
  source.start(at);
  source.stop(at + duration + 0.015);
}

function emitEffect(kind: AudioEffectKind, active: AudioContext) {
  if (active !== context || !preferences.effects || !visible() || effectSources.size >= 12) return;
  const note = (frequency: number, end: number, delay: number, duration: number, volume = 0.085, shape: OscillatorType = "sine") =>
    tone(active, frequency, end, delay, duration, volume, shape);
  switch (kind) {
    case "click": note(740, 570, 0, 0.045, 0.055); break;
    case "pet": note(520, 690, 0, 0.10); note(740, 860, 0.075, 0.12, 0.07); break;
    case "feed": note(380, 570, 0, 0.075, 0.085, "triangle"); note(760, 620, 0.07, 0.11, 0.07); break;
    case "tease": note(470, 310, 0, 0.09, 0.075, "triangle"); note(330, 260, 0.085, 0.10); break;
    case "reward": note(880, 880, 0, 0.14); note(1108, 1108, 0.065, 0.14); note(1318, 1318, 0.13, 0.20, 0.07); break;
    case "travel": note(420, 840, 0, 0.15, 0.07, "triangle"); note(1046, 880, 0.10, 0.09, 0.045); break;
    case "outfit": note(980, 1240, 0, 0.055, 0.055); note(1480, 1180, 0.04, 0.13, 0.055); break;
    case "dance": note(196, 196, 0, 0.105, 0.11, "triangle"); note(392, 392, 0.095, 0.10, 0.07); note(294, 294, 0.20, 0.12, 0.09, "triangle"); break;
  }
}

/** Original, short synthesized sounds; no additional media files or network calls. */
export function playEffect(kind: AudioEffectKind): void {
  if (!preferences.effects || !unlocked || !visible()) return;
  const now = Date.now();
  if (now - lastEffect < 40 && (kind === "click" || kind === lastEffectKind)) return;
  lastEffect = now;
  lastEffectKind = kind;
  const active = ensureContext();
  if (!active || active.state === "closed") return;
  if (active.state === "running") emitEffect(kind, active);
  else {
    void active.resume().then(() => {
      if (Date.now() - now < 180) emitEffect(kind, active);
    }).catch(() => {});
  }
}

function detachVoiceAudio() {
  if (!current) return;
  const audio = current;
  current = null;
  audio.onended = audio.onerror = audio.onplaying = audio.onpause = null;
  audio.pause();
  audio.removeAttribute("src");
  audio.load();
}

function clearVoiceTimeout() {
  if (voiceTimeout !== undefined) clearTimeout(voiceTimeout);
  voiceTimeout = undefined;
}

function notifyError(onError?: () => void) {
  try { onError?.(); } catch { /* Consumer errors must not reject playback promises. */ }
}

function finishVoice(request: number, failed = false, onError?: () => void) {
  if (request !== generation) return;
  generation++;
  clearVoiceTimeout();
  detachVoiceAudio();
  if (utterance) utterance.onend = utterance.onerror = null;
  utterance = null;
  voiceActive = false;
  updateMix();
  if (failed) notifyError(onError);
}

function watchVoice(request: number, milliseconds: number, onError?: () => void) {
  clearVoiceTimeout();
  voiceTimeout = setTimeout(() => {
    if (request !== generation) return;
    stopVoice();
    notifyError(onError);
  }, milliseconds);
}

export function stopVoice(): void {
  generation++;
  clearVoiceTimeout();
  detachVoiceAudio();
  if (utterance) utterance.onend = utterance.onerror = null;
  utterance = null;
  voiceActive = false;
  updateMix();
  if (typeof window !== "undefined" && "speechSynthesis" in window) {
    try { window.speechSynthesis.cancel(); } catch { /* Speech service is unavailable. */ }
  }
}

export function speak(text: string, quoteId: string | undefined, volume: number, onError?: () => void): void {
  stopVoice();
  if (!text.trim() || !visible() || clamp(volume) === 0) return;
  ensureLifecycle();
  const request = generation;
  voiceActive = true;
  updateMix();
  const synth = (sentence: string) => {
    if (request !== generation) return;
    if (!sentence) { finishVoice(request); return; }
    if (!("speechSynthesis" in window) || typeof window.SpeechSynthesisUtterance !== "function") {
      finishVoice(request, true, onError);
      return;
    }
    try {
      const voice = new SpeechSynthesisUtterance(sentence);
      utterance = voice;
      voice.lang = "zh-CN";
      voice.rate = 1.4;
      voice.pitch = 1.25;
      voice.volume = clamp(volume);
      const chinese = window.speechSynthesis.getVoices().find(v => v.lang.startsWith("zh"));
      if (chinese) voice.voice = chinese;
      voice.onend = () => finishVoice(request);
      voice.onerror = e => finishVoice(request, e.error !== "interrupted" && e.error !== "canceled", onError);
      watchVoice(request, Math.max(10000, Math.min(120000, sentence.length * 240 + 5000)), onError);
      window.speechSynthesis.speak(voice);
    } catch {
      finishVoice(request, true, onError);
    }
  };
  if (quoteId && quoteMap[quoteId]) {
    const audio = new Audio(`${import.meta.env.BASE_URL}audio/${quoteId}.mp3`);
    current = audio;
    audio.dataset.audioRole = "character-voice";
    audio.volume = clamp(volume);
    let settled = false;
    let playing = false;
    const fallback = () => {
      if (settled || request !== generation) return;
      settled = true;
      detachVoiceAudio();
      synth(text);
    };
    audio.onended = () => {
      if (settled || request !== generation) return;
      settled = true;
      detachVoiceAudio();
      const rest = text.startsWith(quoteMap[quoteId].text)
        ? text.slice(quoteMap[quoteId].text.length).replace(/^[。\s]+/, "")
        : "";
      if (rest) synth(rest);
      else finishVoice(request);
    };
    audio.onerror = fallback;
    audio.onplaying = () => {
      if (request !== generation) return;
      playing = true;
      watchVoice(request, Number.isFinite(audio.duration) ? Math.max(10000, audio.duration * 1000 + 5000) : 60000, onError);
    };
    audio.onpause = () => {
      if (playing && !audio.ended && !settled) finishVoice(request);
    };
    watchVoice(request, 15000, onError);
    try { void Promise.resolve(audio.play()).catch(fallback); }
    catch { fallback(); }
  } else synth(text);
}

export function disposeAudio(): void {
  lifecycle++;
  initialized = false;
  unlocked = false;
  stopFadeTimer();
  lastEffect = 0;
  lastEffectKind = null;
  stopVoice();
  stopEffects();
  if (typeof window !== "undefined" && typeof document !== "undefined") {
    window.removeEventListener("pointerdown", onGesture, { capture: true });
    window.removeEventListener("click", onGesture, { capture: true });
    window.removeEventListener("keydown", onGesture, { capture: true });
    document.removeEventListener("visibilitychange", onVisibility);
    window.removeEventListener("pagehide", pauseForBackground);
    window.removeEventListener("pageshow", onVisibility);
  }
  for (const track of musicTracks) releaseTrack(track);
  musicTarget = null;
  failedScene = null;
  musicGain?.disconnect();
  effectsGain?.disconnect();
  musicGain = effectsGain = null;
  const active = context;
  context = null;
  if (active && active.state !== "closed") void active.close().catch(() => {});
}
