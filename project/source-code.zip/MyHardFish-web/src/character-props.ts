import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import type { CharacterActivityProp, CharacterFood } from './character-activity';

type PropKey=Exclude<CharacterActivityProp,'none'|'food'|'cup'>|CharacterFood|'pan'|'clipboard';
/** Construct once, attach to the posed wrists each frame, hide instead of rebuilding. */
export class CharacterProps {
  readonly root=new THREE.Group();
  private readonly items=new Map<PropKey,THREE.Group>();
  private readonly details:THREE.Object3D[]=[];
  private readonly box:THREE.BufferGeometry;
  private readonly cylinder:THREE.BufferGeometry;
  private readonly ring:THREE.BufferGeometry;
  private readonly drops:THREE.Mesh[]=[];
  private readonly steam:THREE.Mesh[]=[];
  private readonly crumbs:THREE.Mesh[]=[];
  private readonly effectRoot=new THREE.Group();
  private readonly bite=new THREE.Group();
  private readonly page=new THREE.Group();
  private active:PropKey|null=null;
  constructor(sphere:THREE.BufferGeometry,private readonly material:(color:string)=>THREE.Material,geometries:Set<THREE.BufferGeometry>) {
    this.root.name='cached-activity-props';
    this.box=new RoundedBoxGeometry(1,1,1,2,.045);this.cylinder=new THREE.CylinderGeometry(1,1,1,20,1);this.ring=new THREE.TorusGeometry(1,.12,8,28);
    for(const g of [this.box,this.cylinder,this.ring])geometries.add(g);
    const item=(key:PropKey)=>{const g=new THREE.Group();g.name=`activity-prop-${key}`;g.userData.qaRole='activity-prop';g.userData.prop=key;g.visible=false;this.root.add(g);this.items.set(key,g);return g;};
    const book=item('book');
    for(const side of [-1,1]) {
      const leaf=new THREE.Group();leaf.position.x=side*.185;leaf.rotation.y=side*.17;book.add(leaf);
      this.mesh(leaf,this.box,[.365,.47,.042],[0,0,0],'#547b78');
      this.mesh(leaf,this.box,[.325,.427,.018],[0,0,.031],'#f4efdc');
      for(let j=0;j<6;j++)this.detail(this.mesh(leaf,this.box,[.225,.009,.003],[0,.145-j*.052,.043],'#aeb7a2'));
    }
    this.page.position.set(0,0,.061);book.add(this.page);this.detail(this.mesh(this.page,this.box,[.34,.414,.004],[.17,0,0],'#ebe7cf'));
    this.mesh(book,this.box,[.026,.49,.07],[0,0,-.01],'#355d59');
    const bun=item('bun');this.mesh(bun,sphere,[.135,.106,.124],[0,0,.06],'#efdab0');
    for(let j=0;j<5;j++){const a=j*Math.PI*2/5;this.detail(this.mesh(bun,sphere,[.025,.018,.061],[Math.sin(a)*.03,.089,.06+Math.cos(a)*.021],'#cbb892'));}
    bun.add(this.bite);this.bite.position.set(0,.015,.12);this.mesh(this.bite,sphere,[.045,.04,.018],[0,0,0],'#d9b989');
    const peach=item('peach');for(const side of [-1,1])this.mesh(peach,sphere,[.085,.125,.12],[side*.044,0,.06],side<0?'#e5958c':'#f4b18d');
    const leaf=this.mesh(peach,sphere,[.068,.016,.024],[.055,.126,.06],'#5f8960');leaf.rotation.z=.3;
    const rice=item('rice');this.mesh(rice,this.cylinder,[.16,.09,.16],[0,-.02,.1],'#7c9e98');
    this.mesh(rice,sphere,[.155,.071,.155],[0,.031,.1],'#f4e9cd');for(let i=0;i<5;i++)this.detail(this.mesh(rice,sphere,[.018,.008,.009],[Math.sin(i*2)*.10,.091,.1+Math.cos(i*2)*.065],i%2?'#91a35b':'#da8653'));
    for(const key of ['milk','coffee'] as const){const cup=item(key);this.mesh(cup,this.cylinder,[.113,.23,.113],[0,-.045,.065],key==='milk'?'#e3e8d9':'#b78d69');this.mesh(cup,this.cylinder,[.094,.009,.094],[0,.075,.065],key==='milk'?'#faf1d4':'#52372b');const handle=this.mesh(cup,this.ring,[.081,.091,.05],[-.13,-.03,.065],key==='milk'?'#cbd7c2':'#896846');handle.rotation.y=Math.PI/2;}
    const spatula=item('spatula');this.mesh(spatula,this.cylinder,[.021,.43,.021],[0,-.14,0],'#b99965');this.mesh(spatula,this.box,[.15,.19,.031],[0,-.42,0],'#687e7d');for(let i=0;i<3;i++)this.detail(this.mesh(spatula,this.box,[.012,.12,.034],[-.045+i*.045,-.42,0],'#46565a'));
    const pan=item('pan');this.mesh(pan,this.cylinder,[.275,.075,.275],[0,0,0],'#394b50');this.mesh(pan,this.cylinder,[.249,.007,.249],[0,.041,0],'#d5ad6d');const rim=this.mesh(pan,this.ring,[.26,.26,.26],[0,.045,0],'#718888');rim.rotation.x=Math.PI/2;this.mesh(pan,this.box,[.29,.052,.073],[.35,0,0],'#9d7955');
    const steamMaterial=new THREE.MeshStandardMaterial({color:'#eef0df',transparent:true,opacity:.42,depthWrite:false,roughness:1});
    for(let i=0;i<5;i++){const puff=this.mesh(pan,sphere,[.04,.07,.04],[0,.12,0],steamMaterial);puff.castShadow=puff.receiveShadow=false;puff.name=`cook-steam-${i}`;puff.userData.qaRole='cook-steam';this.steam.push(puff);}
    const can=item('wateringCan');this.mesh(can,this.cylinder,[.175,.29,.175],[0,-.15,.09],'#6f9b89');const handle=this.mesh(can,this.ring,[.19,.23,.14],[0,-.1,-.045],'#456e60');const spout=this.mesh(can,this.cylinder,[.047,.34,.047],[0,-.18,.34],'#8bb19a');spout.rotation.x=Math.PI*.33;this.mesh(can,this.cylinder,[.085,.048,.085],[0,-.265,.49],'#b5c5a2').rotation.x=Math.PI*.33;
    handle.rotation.y=Math.PI/2;
    for(let i=0;i<7;i++){const drop=this.mesh(can,sphere,[.016,.048,.016],[0,-.35-i*.07,.51],'#8ec3c3');drop.userData.qaRole='water-drop';this.drops.push(drop);}
    const bag=item('bag');this.mesh(bag,this.box,[.43,.45,.25],[0,-.34,0],'#bfad7d');const bagHandle=this.mesh(bag,this.ring,[.135,.17,.095],[0,-.073,0],'#836e4d');bagHandle.rotation.y=Math.PI/2;this.mesh(bag,sphere,[.11,.11,.10],[-.12,-.115,0],'#c97968');const baguette=this.mesh(bag,this.cylinder,[.05,.42,.05],[.12,-.04,0],'#d9b16d');baguette.rotation.z=-.18;this.detail(this.mesh(bag,this.box,[.19,.115,.008],[0,-.34,.133],'#77977b'));
    const ball=item('ball');this.mesh(ball,sphere,[.23,.23,.23],[0,0,0],'#e0b67a');for(const a of [0,Math.PI/2]){const stripe=this.mesh(ball,this.ring,[.217,.217,.217],[0,0,0],'#799d90');stripe.rotation.y=a;}
    const pencil=item('pencil');this.mesh(pencil,this.cylinder,[.024,.32,.024],[0,-.095,0],'#d8ad64');this.mesh(pencil,this.cylinder,[.018,.058,.018],[0,-.281,0],'#6b655e');
    const clipboard=item('clipboard');this.mesh(clipboard,this.box,[.50,.028,.39],[0,0,0],'#bd9e6c');this.mesh(clipboard,this.box,[.435,.005,.325],[0,.018,0],'#f1ead5');for(let i=0;i<4;i++)this.detail(this.mesh(clipboard,this.box,[.30,.006,.009],[0,.023,-.10+i*.065],'#a2b1a7'));
    const glass=item('magnifier');this.mesh(glass,this.cylinder,[.027,.22,.027],[0,.055,0],'#8a7456');this.mesh(glass,this.ring,[.15,.15,.10],[0,.27,0],'#66877f');const lensMaterial=new THREE.MeshStandardMaterial({color:'#b9e0de',transparent:true,opacity:.35,roughness:.1});this.mesh(glass,sphere,[.133,.133,.012],[0,.27,0],lensMaterial);
    const lantern=item('lantern');this.mesh(lantern,sphere,[.18,.24,.18],[0,-.32,0],'#e2b369');this.mesh(lantern,this.ring,[.12,.14,.08],[0,-.066,0],'#736348');for(const y of [-.51,-.15])this.mesh(lantern,this.cylinder,[.13,.035,.13],[0,y,0],'#87775c');
    this.effectRoot.name='activity-effect-crumbs';this.effectRoot.visible=false;this.root.add(this.effectRoot);
    for(let i=0;i<4;i++){const crumb=this.mesh(this.effectRoot,sphere,[.018,.012,.015],[0,0,0],'#d5b883');crumb.name=`eat-crumb-${i}`;crumb.userData.qaRole='eat-crumb';crumb.castShadow=false;this.crumbs.push(crumb);}
  }
  private detail<T extends THREE.Object3D>(object:T){this.details.push(object);return object;}
  private mesh(parent:THREE.Object3D,geometry:THREE.BufferGeometry,scale:number[],position:number[],color:string|THREE.Material) {
    const mesh=new THREE.Mesh(geometry,typeof color==='string'?this.material(color):color);mesh.scale.set(scale[0],scale[1],scale[2]);mesh.position.set(position[0],position[1],position[2]);mesh.castShadow=mesh.receiveShadow=true;parent.add(mesh);return mesh;
  }
  setQuality(low:boolean){for(const detail of this.details)detail.visible=!low;}
  update(prop:CharacterActivityProp,food:CharacterFood,time:number,right:THREE.Vector3,left:THREE.Vector3,amount:number,reduced:boolean) {
    for(const group of this.items.values())group.visible=false;
    this.effectRoot.visible=false;
    this.active=null;
    if(prop==='none'||amount<.025)return;
    const key:PropKey=prop==='food'?food:prop==='cup'?food==='milk'?'milk':'coffee':prop;
    const item=this.items.get(key);if(!item)return;this.active=key;
    item.visible=true;item.scale.setScalar(Math.min(1,amount*2));item.rotation.set(0,0,0);item.position.copy(right);
    const slow=reduced?.3:1;
    if(prop==='book'){item.position.copy(right).add(left).multiplyScalar(.5);item.position.y+=.11;item.position.z+=.055;item.rotation.x=-.12;this.page.rotation.y=-Math.max(0,Math.sin(time*.9))*1.75*slow;}
    if(prop==='food'||prop==='cup'){
      const drink=key==='milk'||key==='coffee';item.position.x+=drink?.10:.08;item.position.y-=drink?.10:0;item.position.z-=.07;item.rotation.x=drink?-.12-Math.max(0,Math.sin(time*2.3))*.20*slow:0;this.bite.visible=key==='bun'&&Math.sin(time*2.3)>.6;
      if(key==='bun'||key==='peach'||key==='rice'){
        this.effectRoot.visible=true;this.effectRoot.position.copy(item.position);const phase=(time*2.3/(Math.PI*2))%1;
        for(let i=0;i<this.crumbs.length;i++){const crumb=this.crumbs[i],fall=(phase+i*.07)%1;crumb.visible=fall<.48;crumb.position.set((i-1.5)*.024+Math.sin(i*3)*fall*.055,-.03-fall*.42,.08+fall*.065);}
      }
    }
    if(prop==='spatula'){
      item.rotation.z=-.28;item.rotation.x=-.13;const pan=this.items.get('pan')!;pan.visible=true;pan.scale.setScalar(Math.min(1,amount*2));pan.position.copy(left);pan.position.x-=.39;pan.position.z+=.05;pan.rotation.set(0,0,0);
      this.steam.forEach((puff,i)=>{const rise=(time*.33+i/5)%1;puff.position.set(Math.sin(time*.7+i*2)*.11,.07+rise*.41,Math.cos(i*2)*.08);puff.scale.set(.032+rise*.025,.049+rise*.035,.032+rise*.025);});
    }
    if(prop==='wateringCan'){item.rotation.x=.12+Math.max(0,Math.sin(time*1.5))*.20*slow;this.drops.forEach((drop,i)=>{drop.position.set(Math.sin(i*2)*.027,-.31-((time*.65+i/7)%1)*.55,.51+Math.sin(i)*.025);});}
    if(prop==='bag')item.rotation.z=Math.sin(time*1.8)*.06*slow;
    if(prop==='ball'){item.position.copy(right).add(left).multiplyScalar(.5);item.position.y+=.07+Math.max(0,Math.sin(time*2.3))*.32*slow;item.rotation.set(time*.3,time*.55,0);}
    if(prop==='pencil'){item.rotation.z=-.35;item.rotation.x=.25;const board=this.items.get('clipboard')!;board.visible=true;board.scale.setScalar(Math.min(1,amount*2));board.position.copy(left);board.position.x-=.22;board.position.y-=.055;board.position.z+=.015;board.rotation.set(0,0,0);}
    if(prop==='magnifier'){item.rotation.y=-.08;item.position.z+=.11;}
  }
  clear(){for(const group of this.items.values())group.visible=false;this.effectRoot.visible=false;this.active=null;}
  get activeProp(){return this.active;}
  get activeObject(){return this.active?this.items.get(this.active)??null:null;}
}
