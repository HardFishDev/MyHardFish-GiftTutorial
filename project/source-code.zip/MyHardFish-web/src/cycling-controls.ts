export const CYCLING_CONTROL_ACTIONS = [
  { id: 'steerLeft', label: '向左变道' },
  { id: 'steerRight', label: '向右变道' },
  { id: 'brake', label: '按住减速' },
  { id: 'pause', label: '暂停 / 继续' },
  { id: 'nextCamera', label: '切换视角' },
  { id: 'orbitLeft', label: '向左环视' },
  { id: 'orbitRight', label: '向右环视' },
  { id: 'tiltUp', label: '抬高视角' },
  { id: 'tiltDown', label: '降低视角' },
  { id: 'resetCamera', label: '复位视角' },
] as const;

export type CyclingControlAction = typeof CYCLING_CONTROL_ACTIONS[number]['id'];
export type CyclingKeyBindings = Record<CyclingControlAction, string[]>;
export type CyclingTouchOrientation = 'portrait' | 'landscape';
export type CyclingTouchGroup = 'steering' | 'brake' | 'tools';
export interface CyclingTouchPosition { x: number; y: number }
export type CyclingTouchPositions = Record<CyclingTouchGroup, CyclingTouchPosition>;
export interface CyclingTouchPreferences {
  handedness: 'right' | 'left';
  size: 'normal' | 'large';
  /** Additional lift in CSS pixels; the renderer also respects safe area insets. */
  verticalOffset: number;
  /** Top-left travel within the bottom control band, excluding group bounds and safe insets. */
  positions: Record<CyclingTouchOrientation, CyclingTouchPositions>;
}
export interface CyclingControlPreferences {
  version: 1;
  bindings: CyclingKeyBindings;
  touch: CyclingTouchPreferences;
}
export interface CyclingKeyboardInput {
  code?: string;
  key?: string;
  shiftKey?: boolean;
  ctrlKey?: boolean;
  metaKey?: boolean;
  altKey?: boolean;
  isComposing?: boolean;
}
export type CyclingBindingValidation =
  | { ok: true; bindings: CyclingKeyBindings }
  | { ok: false; error: string };

// Control preferences are deliberately separate from game saves and exported ZIPs.
export const CYCLING_CONTROL_PREFERENCES_KEY = 'hardfish.cycling-controls.v1';
export const CYCLING_TOUCH_MAX_VERTICAL_OFFSET = 96;

const defaultBindings: CyclingKeyBindings = {
  steerLeft: ['ArrowLeft', 'KeyA'],
  steerRight: ['ArrowRight', 'KeyD'],
  brake: ['ArrowDown', 'KeyS'],
  pause: ['KeyP', 'Space'],
  nextCamera: ['KeyC'],
  orbitLeft: ['KeyQ'],
  orbitRight: ['KeyE'],
  tiltUp: ['Shift+KeyQ'],
  tiltDown: ['Shift+KeyE'],
  resetCamera: ['KeyR'],
};
const defaultPositions: Record<CyclingTouchOrientation, CyclingTouchPositions> = {
  portrait: { steering: { x: .03, y: 1 }, brake: { x: .97, y: 1 }, tools: { x: .97, y: 0 } },
  landscape: { steering: { x: .03, y: 1 }, brake: { x: .97, y: 1 }, tools: { x: .5, y: 1 } },
};
const touchGroups: CyclingTouchGroup[] = ['steering', 'brake', 'tools'];
const orientations: CyclingTouchOrientation[] = ['portrait', 'landscape'];
const keyLabels: Record<string, string> = {
  ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓', Space: '空格',
  Backquote: '`', Minus: '-', Equal: '=', BracketLeft: '[', BracketRight: ']',
  Backslash: '\\', Semicolon: ';', Quote: "'", Comma: ',', Period: '.', Slash: '/',
  IntlBackslash: '国际 \\', IntlRo: '国际 Ro', IntlYen: '¥',
  NumpadDecimal: '数字键盘 .', NumpadAdd: '数字键盘 +', NumpadSubtract: '数字键盘 -',
  NumpadMultiply: '数字键盘 ×', NumpadDivide: '数字键盘 ÷', NumpadEqual: '数字键盘 =',
};
const fallbackCodes: Record<string, string> = {
  ArrowLeft: 'ArrowLeft', ArrowRight: 'ArrowRight', ArrowUp: 'ArrowUp', ArrowDown: 'ArrowDown',
  ' ': 'Space', Spacebar: 'Space',
  '`': 'Backquote', '~': 'Backquote', '-': 'Minus', '_': 'Minus', '=': 'Equal', '+': 'Equal',
  '[': 'BracketLeft', '{': 'BracketLeft', ']': 'BracketRight', '}': 'BracketRight',
  '\\': 'Backslash', '|': 'Backslash', ';': 'Semicolon', ':': 'Semicolon', "'": 'Quote', '"': 'Quote',
  ',': 'Comma', '<': 'Comma', '.': 'Period', '>': 'Period', '/': 'Slash', '?': 'Slash',
  '!': 'Digit1', '@': 'Digit2', '#': 'Digit3', '$': 'Digit4', '%': 'Digit5',
  '^': 'Digit6', '&': 'Digit7', '*': 'Digit8', '(': 'Digit9', ')': 'Digit0',
};

function record(value: unknown): Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown> : {};
}
function boundedNumber(value: unknown, fallback: number, min: number, max: number): number {
  return typeof value === 'number' && Number.isFinite(value)
    ? Math.max(min, Math.min(max, value)) : fallback;
}
function allowedCode(code: string): boolean {
  // A whitelist leaves browser navigation, dialog controls and modifier keys usable.
  return /^(Key[A-Z]|Digit[0-9]|Numpad[0-9])$/.test(code)
    || Object.prototype.hasOwnProperty.call(keyLabels, code);
}
function allowedChord(value: unknown): value is string {
  if (typeof value !== 'string') return false;
  const code = value.startsWith('Shift+') ? value.slice(6) : value;
  return allowedCode(code);
}

/** Physical key code; useful when releasing a held key after Shift is released. */
export function cyclingKeyCode(event: CyclingKeyboardInput): string | null {
  if (event.code && event.code !== 'Unidentified') return allowedCode(event.code) ? event.code : null;
  const key = event.key || '';
  if (/^[a-z]$/i.test(key)) return `Key${key.toUpperCase()}`;
  if (/^[0-9]$/.test(key)) return `Digit${key}`;
  return Object.prototype.hasOwnProperty.call(fallbackCodes, key) ? fallbackCodes[key] : null;
}

/** A chord is an allowed KeyboardEvent.code, optionally prefixed with "Shift+". */
export function cyclingKeyChord(event: CyclingKeyboardInput): string | null {
  if (event.ctrlKey || event.metaKey || event.altKey || event.isComposing
    || ['Dead', 'Process', 'Compose'].includes(event.key || '')) return null;
  const code = cyclingKeyCode(event);
  return code ? `${event.shiftKey ? 'Shift+' : ''}${code}` : null;
}

export function cyclingKeyLabel(chord: string | null | undefined): string {
  if (!chord) return '未设置';
  const shifted = chord.startsWith('Shift+');
  const code = shifted ? chord.slice(6) : chord;
  const label = /^Key[A-Z]$/.test(code) ? code.slice(3)
    : /^Digit[0-9]$/.test(code) ? code.slice(5)
    : /^Numpad[0-9]$/.test(code) ? `数字键盘 ${code.slice(6)}`
    : keyLabels[code] || code;
  return `${shifted ? 'Shift + ' : ''}${label}`;
}

export function validateCyclingBindings(value: unknown): CyclingBindingValidation {
  const input = record(value);
  const bindings = {} as CyclingKeyBindings;
  const owners = new Map<string, typeof CYCLING_CONTROL_ACTIONS[number]>();
  for (const action of CYCLING_CONTROL_ACTIONS) {
    const chords = input[action.id];
    if (!Array.isArray(chords) || chords.length < 1 || chords.length > 2)
      return { ok: false, error: `“${action.label}”需要设置 1–2 个按键。` };
    bindings[action.id] = [];
    for (const chord of chords) {
      if (!allowedChord(chord))
        return { ok: false, error: `“${action.label}”的按键不可用。请使用字母、数字、方向键、空格或符号，可加 Shift；Esc、Tab、Enter 和浏览器快捷键保留。` };
      const owner = owners.get(chord);
      if (owner) return { ok: false, error: owner.id === action.id
        ? `“${action.label}”的两个按键不能重复（${cyclingKeyLabel(chord)}）。`
        : `${cyclingKeyLabel(chord)} 已用于“${owner.label}”，不能同时用于“${action.label}”。` };
      owners.set(chord, action);
      bindings[action.id].push(chord);
    }
  }
  return { ok: true, bindings };
}

/** Returns a fresh mapping on success and never modifies the current bindings. */
export function updateCyclingBinding(
  bindings: CyclingKeyBindings, action: CyclingControlAction, slot: 0 | 1, chord: string | null,
): CyclingBindingValidation {
  const next = { ...bindings, [action]: [...bindings[action]] };
  if (chord === null) next[action].splice(slot, 1);
  else next[action][slot] = chord;
  return validateCyclingBindings(next);
}

export function matchCyclingControlAction(
  event: CyclingKeyboardInput, bindings: CyclingKeyBindings,
): CyclingControlAction | null {
  const chord = cyclingKeyChord(event);
  return chord ? CYCLING_CONTROL_ACTIONS.find(action => bindings[action.id].includes(chord))?.id ?? null : null;
}

export function createDefaultCyclingControls(): CyclingControlPreferences {
  return {
    version: 1,
    bindings: Object.fromEntries(CYCLING_CONTROL_ACTIONS.map(action => [action.id, [...defaultBindings[action.id]]])) as CyclingKeyBindings,
    touch: {
      handedness: 'right', size: 'normal', verticalOffset: 0,
      positions: Object.fromEntries(orientations.map(orientation => [orientation,
        Object.fromEntries(touchGroups.map(group => [group, { ...defaultPositions[orientation][group] }])),
      ])) as Record<CyclingTouchOrientation, CyclingTouchPositions>,
    },
  };
}

export function normalizeCyclingTouchPreferences(value: unknown): CyclingTouchPreferences {
  const defaults = createDefaultCyclingControls().touch;
  const touch = record(value);
  const positions = record(touch.positions);
  for (const orientation of orientations) {
    const layout = record(positions[orientation]);
    for (const group of touchGroups) {
      const position = record(layout[group]);
      const fallback = defaults.positions[orientation][group];
      defaults.positions[orientation][group] = {
        x: boundedNumber(position.x, fallback.x, 0, 1),
        y: boundedNumber(position.y, fallback.y, 0, 1),
      };
    }
  }
  return {
    handedness: touch.handedness === 'left' ? 'left' : 'right',
    size: touch.size === 'large' ? 'large' : 'normal',
    verticalOffset: boundedNumber(touch.verticalOffset, 0, 0, CYCLING_TOUCH_MAX_VERTICAL_OFFSET),
    positions: defaults.positions,
  };
}

export function normalizeCyclingControlPreferences(value: unknown): CyclingControlPreferences {
  const defaults = createDefaultCyclingControls();
  const input = record(value);
  if (input.version !== undefined && input.version !== 1) return defaults;
  const result = validateCyclingBindings(input.bindings);
  return {
    version: 1,
    bindings: result.ok ? result.bindings : defaults.bindings,
    touch: normalizeCyclingTouchPreferences(input.touch),
  };
}

/** Positions are stored in the right-handed layout; mirror for a left-handed view. */
export function getCyclingTouchPositions(
  touch: CyclingTouchPreferences, orientation: CyclingTouchOrientation,
): CyclingTouchPositions {
  return Object.fromEntries(touchGroups.map(group => {
    const position = touch.positions[orientation][group];
    return [group, { x: touch.handedness === 'left' ? 1 - position.x : position.x, y: position.y }];
  })) as CyclingTouchPositions;
}

export function loadCyclingControlPreferences(storage?: Pick<Storage, 'getItem'>): CyclingControlPreferences {
  try {
    return normalizeCyclingControlPreferences(JSON.parse((storage ?? localStorage).getItem(CYCLING_CONTROL_PREFERENCES_KEY) || 'null'));
  } catch {
    return createDefaultCyclingControls();
  }
}

export function saveCyclingControlPreferences(
  preferences: CyclingControlPreferences, storage?: Pick<Storage, 'setItem'>,
): void {
  const result = validateCyclingBindings(preferences.bindings);
  if (!result.ok) throw new Error(result.error);
  // The UI applies preferences first, then reports a blocked/quota-limited save.
  (storage ?? localStorage).setItem(CYCLING_CONTROL_PREFERENCES_KEY, JSON.stringify(normalizeCyclingControlPreferences(preferences)));
}

export function resetCyclingControlPreferences(storage?: Pick<Storage, 'setItem'>): CyclingControlPreferences {
  const defaults = createDefaultCyclingControls();
  saveCyclingControlPreferences(defaults, storage);
  return defaults;
}
