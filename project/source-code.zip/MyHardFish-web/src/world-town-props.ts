import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import type { EnvironmentBuilder } from './environment';

export function path(b:EnvironmentBuilder,x:number,z:number,w:number,d:number,color='#d5cbb0',height=.055) {
  const mesh=b.surface([w,.09,d],[x,height-.045,z],color,'stone',.015);
  const uv=mesh.geometry.getAttribute('uv');for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)*w/2.4,uv.getY(i)*d/2.4);
  mesh.castShadow=false;b.elevation(x,z,w,d,height);
  if(w>d){for(let px=x-w/2+2;px<x+w/2;px+=2.4)b.surface([.027,.012,d-.08],[px,height+.007,z],'#b6b79a','stone',0).castShadow=false;}
  else{for(let pz=z-d/2+2;pz<z+d/2;pz+=2.4)b.surface([w-.08,.012,.027],[x,height+.007,pz],'#b6b79a','stone',0).castShadow=false;}
  return mesh;
}

export function lamp(b:EnvironmentBuilder,x:number,z:number,scale=1) {
  const g=new THREE.Group();g.position.set(x,0,z);g.scale.setScalar(scale);b.root.add(g);
  b.cylinder(.22,.3,.24,[0,.13,0],'#65776a',g);b.cylinder(.055,.10,4.1,[0,2.1,0],'#526b60',g);
  b.box([.58,.73,.58],[0,4.2,0],'#efd4a0',.07,g);
  b.cylinder(.48,.34,.24,[0,4.66,0],'#617565',g);b.sphere([.09,.15,.09],[0,4.89,0],'#a88c61',g);
  for(const a of [-.25,.25])for(const c of [-.25,.25])b.box([.035,.75,.035],[a,4.2,c],'#617565',.01,g);
  b.obstacle(x,z,.46*scale,.46*scale);
}

export function flowerBed(b:EnvironmentBuilder,x:number,z:number,w:number,d:number,flowers=true) {
  b.surface([w,.38,d],[x,.21,z],'#b4b89b','stone',.15);b.surface([w-.2,.05,d-.2],[x,.42,z],'#827e56','plaster',.1);b.obstacle(x,z,w,d);
  const n=Math.max(8,Math.floor(w*d*2));
  for(let i=0;i<n;i++){
    const px=x+Math.sin(i*2.399)*(w-.4)*.42,pz=z+Math.cos(i*2.399)*(d-.4)*.42;
    b.sphere([.22,.31,.23],[px,.7,pz],i%2?'#829d70':'#97aa80').castShadow=false;
    if(flowers)b.sphere([.14,.075,.14],[px,.99+(i%3)*.04,pz],['#e2b99a','#ece1a8','#c89991'][i%3]).castShadow=false;
  }
}

export function fence(b:EnvironmentBuilder,x:number,z:number,length:number,rotation=0) {
  const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=rotation;b.root.add(g);
  for(let i=-length/2;i<=length/2;i+=1.35){b.surface([.12,1.08,.12],[i,.54,0],'#b1aa85','wood',.025,g);b.sphere([.10,.08,.10],[i,1.1,0],'#d3c49e',g);}
  for(const y of [.36,.82])b.surface([length,.11,.075],[0,y,0],'#b5ad8a','wood',.02,g);
  b.obstacle(x,z,Math.abs(Math.cos(rotation))*length+.14,Math.abs(Math.sin(rotation))*length+.14);
  return g;
}

/** Solid street architecture. Its destination is an explicit door in WORLD_EXITS. */
export function building(b:EnvironmentBuilder,x:number,z:number,w:number,d:number,h:number,color:string,roofColor:string,rotation=0) {
  const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=rotation;b.root.add(g);
  b.surface([w+.35,.38,d+.35],[0,.2,0],'#aab19a','stone',.08,g);
  b.surface([w,h,d],[0,h/2+.35,0],color,'plaster',.08,g);
  const canopy=b.occluder(`building-roof:${x}:${z}`,g);
  for(const side of [-1,1]){
    const roof=b.surface([w*.56,.19,d+.85],[side*w*.25,h+.85,0],roofColor,'wood',.025,canopy);roof.rotation.z=-side*.23;
    for(let i=0;i<5;i++){const tile=b.surface([w*.55,.03,.055],[side*w*.25,h+.97,-d/2-.3+i*(d+.6)/4],roofColor,'wood',.008,canopy);tile.rotation.z=-side*.23;}
  }
  b.surface([.18,.2,d+.95],[0,h+1.47,0],roofColor,'wood',.03,canopy);
  b.surface([w+.22,.11,.13],[0,h-.13,d/2+.09],'#e6ddc6','wood',.02,g);
  b.surface([w+.12,.14,.13],[0,.74,d/2+.08],'#c4b999','stone',.02,g);
  const windows=Math.max(2,Math.floor(w/3.4));
  for(let i=0;i<windows;i++){
    const wx=-w/2+(i+.5)*w/windows;
    for(const wy of h>6?[2.0,4.7]:[2.0]){
      b.surface([1.45,1.65,.12],[wx,wy,d/2+.10],'#e8dfc9','wood',.025,g);
      b.surface([1.19,1.4,.05],[wx,wy,d/2+.18],'#75938a','metal',.015,g);
      b.surface([.055,1.43,.055],[wx,wy,d/2+.225],'#e7dfc7','wood',.01,g);
      b.surface([1.25,.055,.055],[wx,wy,d/2+.226],'#e7dfc7','wood',.01,g);
      b.surface([1.58,.12,.44],[wx,wy-.92,d/2+.23],'#c7bda0','stone',.02,g);
      for(const side of [-1,1])b.surface([.28,1.61,.09],[wx+side*.88,wy,d/2+.10],'#889c83','wood',.02,g);
    }
  }
  b.surface([1.45,2.45,.16],[0,1.35,d/2+.13],'#80907a','wood',.05,g);
  b.surface([1.09,.74,.035],[0,2.04,d/2+.23],'#9fbbb0','metal',.02,g);b.sphere([.05,.05,.04],[.46,1.22,d/2+.26],'#cbb078',g);
  const porch=b.occluder(`building-awning:${x}:${z}`,g);
  const awning=b.surface([2.55,.11,1.35],[0,2.94,d/2+.67],roofColor,'fabric',.04,porch);awning.rotation.x=.12;
  b.surface([1.05,.65,.83],[w*.3,h+1.1,-d*.25],'#c3b496','stone',.035,canopy);
  const c=Math.abs(Math.cos(rotation)),s=Math.abs(Math.sin(rotation));b.obstacle(x,z,w*c+d*s+.4,d*c+w*s+.4);
  return g;
}

export function noticeboard(b:EnvironmentBuilder,x:number,z:number,title:string,subtitle:string,width=4) {
  for(const side of [-1,1])b.surface([.15,3.25,.15],[x+side*(width/2-.2),1.64,z],'#8d7d5d','wood',.035);
  b.surface([width,1.95,.18],[x,2.2,z],'#b89e75','wood',.055);
  b.label(`${title}\n${subtitle}`,[x,2.24,z+.12],width-.3,'#536c5b','#efe2c2');
  b.surface([width+.45,.14,.67],[x,3.3,z],'#758b72','wood',.03).rotation.x=-.14;
  b.obstacle(x,z,width+.1,.65);
}

export function crate(b:EnvironmentBuilder,x:number,y:number,z:number,w=1.1) {
  b.surface([w,.66,w*.75],[x,y+.33,z],'#bd9d72','wood',.035);
  for(let i=0;i<4;i++)b.surface([w+.025,.035,.025],[x,y+.11+i*.16,z+w*.375+.018],'#927b56','wood',.003);
  for(const side of [-1,1])b.surface([.075,.68,.035],[x+side*w*.39,y+.33,z+w*.375+.035],'#d5b68a','wood',.01);
}

export function pennants(b:EnvironmentBuilder,from:[number,number,number],to:[number,number,number],count=14) {
  const a=new THREE.Vector3(...from),c=new THREE.Vector3(...to),delta=c.clone().sub(a);
  for(let i=0;i<=count;i++){
    const t=i/count,p=a.clone().addScaledVector(delta,t);p.y-=Math.sin(t*Math.PI)*.65;
    if(i<count){const next=a.clone().addScaledVector(delta,(i+1)/count);next.y-=Math.sin((i+1)/count*Math.PI)*.65;const dir=next.sub(p),wire=b.cylinder(.012,.012,dir.length(),[p.x+dir.x/2,p.y+dir.y/2,p.z+dir.z/2],'#817f66');wire.quaternion.setFromUnitVectors(THREE.Object3D.DEFAULT_UP,dir.normalize());}
    if(i>0&&i<count){const flag=b.mesh(new THREE.ConeGeometry(.22,.43,3),[p.x,p.y-.22,p.z],['#c99478','#9aad86','#d6ba75'][i%3]);flag.rotation.z=Math.PI;flag.scale.z=.12;flag.castShadow=false;}
  }
}

/** Distant foliage shares one geometry and one draw per spatial cell. */
export function forest(b:EnvironmentBuilder,trees:readonly (readonly [number,number,number])[]) {
  const pieces:THREE.BufferGeometry[]=[];
  const add=(g:THREE.BufferGeometry,color:string)=>{const geometry=g.index?g.toNonIndexed():g;if(geometry!==g)g.dispose();const c=new THREE.Color(color),n=geometry.getAttribute('position').count,data=new Float32Array(n*3);for(let i=0;i<n;i++)data.set([c.r,c.g,c.b],i*3);geometry.setAttribute('color',new THREE.BufferAttribute(data,3));pieces.push(geometry);};
  const trunk=new THREE.CylinderGeometry(.15,.3,3.6,7);trunk.translate(0,1.8,0);add(trunk,'#7c715b');
  for(let i=0;i<5;i++){const g=new THREE.IcosahedronGeometry(1,1);g.scale(1.4,1.7,1.35);g.translate(Math.sin(i*2.4)*.68,3.5+i%2*.65,Math.cos(i*2.4)*.68);add(g,['#789465','#829b70','#92a77d','#6d885e','#a2b187'][i]);}
  const geometry=mergeGeometries(pieces)!;pieces.forEach(p=>p.dispose());
  const material=new THREE.MeshStandardMaterial({vertexColors:true,roughness:.93});
  const cells=new Map<string,(readonly [number,number,number])[]>();for(const tree of trees){const key=`${Math.floor(tree[0]/16)},${Math.floor(tree[1]/16)}`;const list=cells.get(key)??[];list.push(tree);cells.set(key,list);}
  const matrix=new THREE.Matrix4(),rotation=new THREE.Quaternion(),scale=new THREE.Vector3();
  for(const cell of cells.values()){
    const mesh=new THREE.InstancedMesh(geometry,material,cell.length);mesh.userData.keep=true;mesh.castShadow=true;mesh.receiveShadow=true;
    cell.forEach(([x,z,s],i)=>{rotation.setFromAxisAngle(THREE.Object3D.DEFAULT_UP,i*2.4);matrix.compose(new THREE.Vector3(x,0,z),rotation,scale.setScalar(s));mesh.setMatrixAt(i,matrix);});mesh.computeBoundingSphere();b.root.add(mesh);
  }
}

export function boundaryForest(b:EnvironmentBuilder,half:number,count=90) {
  const trees:[number,number,number][]=[];
  for(let i=0;i<count;i++){const a=i*2.399,r=half+8+(i%7)*2.3;trees.push([Math.sin(a)*r,Math.cos(a)*r,1.35+(i%5)*.16]);}
  forest(b,trees);
}
