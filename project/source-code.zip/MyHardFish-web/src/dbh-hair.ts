import * as THREE from 'three';
import { batchJointMeshes, canvasTexture, line, mesh, point } from './dbh-geometry';
import { getDbhSkullSection } from './dbh-face-sculpt';

const mix = THREE.MathUtils.lerp;
const ease = (a: number, b: number, x: number) => THREE.MathUtils.smoothstep(x, a, b);

/** Soft layered hair sculpted as shallow, closed volumes, in neck-local coordinates. */
export function createDbhHair() {
  const root = new THREE.Group(); root.name = 'dbh-layered-flowing-hair'; root.userData.textureStatus = 'ready';
  const moving = new THREE.Group(); moving.name = 'dbh-hair-secondary-motion'; root.add(moving);
  // Subtle strands follow the length of each lock. The silhouette and light, rather
  // than a high-contrast photograph, describe the large flowing sections.
  const grain = canvasTexture(512, 1024, ctx => {
    const across = ctx.createLinearGradient(0, 0, 512, 0);
    across.addColorStop(0, '#403638'); across.addColorStop(.25, '#453a38');
    across.addColorStop(.58, '#4a403d'); across.addColorStop(1, '#403638');
    ctx.fillStyle = across; ctx.fillRect(0, 0, 512, 1024);
    for (let i = 0; i < 17; i++) {
      ctx.lineWidth = 2.5 + (i % 3); ctx.strokeStyle = i % 2 ? 'rgba(30,23,19,.10)' : 'rgba(170,145,122,.09)';
      const x = i * 30.3; ctx.beginPath(); ctx.moveTo(x, 0); ctx.bezierCurveTo(x + 4, 340, x - 3, 660, x, 1024); ctx.stroke();
    }
    for (let i = 0; i < 76; i++) {
      const x = i * 6.79, wave = Math.sin(i * 2.71) * 1.8;
      ctx.lineWidth = .6 + (i % 4) * .18;
      ctx.strokeStyle = i % 3 === 0 ? 'rgba(157,134,115,.15)' : 'rgba(28,22,19,.12)';
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.bezierCurveTo(x + wave, 280, x - wave, 760, x + wave * .3, 1024); ctx.stroke();
    }
  });
  grain.wrapS = THREE.RepeatWrapping; grain.anisotropy = 8;
  const strandNormals = canvasTexture(512, 16, ctx => {
    for (let x = 0; x < 512; x++) {
      const nx = .105 * Math.sin(x * .215) + .065 * Math.sin(x * .918);
      ctx.fillStyle = `rgb(${Math.round(128 + nx * 127)},128,${Math.round(128 + Math.sqrt(1 - nx * nx) * 127)})`;
      ctx.fillRect(x, 0, 1, 16);
    }
  });
  strandNormals.colorSpace = THREE.NoColorSpace; strandNormals.wrapS = THREE.RepeatWrapping;
  const main = new THREE.MeshPhysicalMaterial({ map: grain, normalMap: strandNormals, normalScale: new THREE.Vector2(.55, .55), color: '#ffffff', roughness: .60, metalness: 0, specularIntensity: .3, sheen: .2, sheenColor: '#827773', sheenRoughness: .72, side: THREE.DoubleSide });
  const shade = main.clone(); shade.color.set('#eee9e5');
  const soft = main.clone(); soft.color.set('#f8f3ed');
  const materials = [main, soft, main, shade, soft];

  // Share the skull surface rather than keeping an independently drifting copy.
  const fitSection = (y: number) => {
    const p = getDbhSkullSection(y);
    return { x: p.halfWidth, z: (p.front - p.back) / 2, center: (p.front + p.back) / 2 };
  };
  const scalpCenter = -.066;
  const scalp = (y: number) => {
    const radius = Math.sqrt(Math.max(.000001, 1 - ((y - .478) / .442) ** 2));
    const fittedWidth = Math.min(.318 * radius, fitSection(y).x + .034);
    return { x: mix(.318 * radius, fittedWidth, 1 - ease(.55, .71, y)), front: .277 * radius, back: .344 * radius };
  };
  const capPoint = (angle: number, y: number, lift = .002) => {
    const p = scalp(y), facing = Math.cos(angle);
    return point(Math.sin(angle) * (p.x + lift), y, facing * ((facing >= 0 ? p.front : p.back) + lift) + scalpCenter);
  };
  const scalpFrontZ = (x: number, y: number) => {
    const p = scalp(y);
    return scalpCenter + p.front * Math.sqrt(Math.max(.006, 1 - (x / p.x) ** 2));
  };
  function geometry(positions: number[], uvs: number[], indices: number[]) {
    // All overlapping layers share the relocated ear clearance. Moving only the
    // scalp lining would leave the back density and outer waves across the ear.
    for (let i = 0; i < positions.length; i += 3) {
      const x = positions[i], halfWidth = Math.abs(x);
      if (halfWidth <= .238) continue;
      const ear = Math.exp(-(((positions[i + 1] - .425) / .112) ** 4) - (((positions[i + 2] + .130) / .072) ** 4));
      positions[i] = Math.sign(x) * (halfWidth - (halfWidth - .238) * ear);
    }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2)); g.setIndex(indices); g.computeVertexNormals(); return g;
  }
  function seam(g: THREE.BufferGeometry, columns: number, rows: number) {
    const n = g.getAttribute('normal'), v = new THREE.Vector3();
    for (let row = 0; row <= rows; row++) {
      const a = row * (columns + 1), b = a + columns;
      v.set(n.getX(a) + n.getX(b), n.getY(a) + n.getY(b), n.getZ(a) + n.getZ(b)).normalize();
      n.setXYZ(a, v.x, v.y, v.z); n.setXYZ(b, v.x, v.y, v.z);
    }
  }

  // A fitted scalp lining stays behind the layered locks. The frontal edge is high
  // and hidden by the swept fringe, avoiding the previous horizontal bowl-cut rim.
  {
    const rows = 52, columns = 96, p: number[] = [], uv: number[] = [], ix: number[] = [];
    for (let row = 0; row <= rows; row++) for (let col = 0; col <= columns; col++) {
      const angle = col / columns * Math.PI * 2, front = Math.cos(angle), side = Math.sin(angle);
      const hiddenFrontalEdge = .756 + .018 * Math.sin(angle * 3 + .4) + .012 * Math.sin(angle * 7);
      // The arch rises over the new ear, then descends behind it. A varying edge
      // stays beneath the temple locks instead of exposing a horizontal sideburn.
      const sideEdge = .30 + .185 * ease(-.70, -.07, front)
        + .042 * Math.exp(-(((front + .21) / .21) ** 2)) + .012 * Math.sin(angle * 4.7);
      const end = mix(sideEdge, hiddenFrontalEdge, ease(.45, .84, front)), y = mix(.919, end, row / rows), radius = scalp(y);
      const ear = Math.exp(-(((y - .425) / .110) ** 2) - (((front + .20) / .19) ** 2));
      p.push(side * (radius.x - .062 * ear), y, front * (front >= 0 ? radius.front : radius.back) + scalpCenter - .020 * ear);
      uv.push(col / columns * 2, (y + .8) / 1.72);
      if (row && col) { const a = row * (columns + 1) + col, b = a - columns - 1; ix.push(a - 1, a, b, a - 1, b, b - 1); }
    }
    const center = p.length / 3; p.push(0, .920, scalpCenter); uv.push(.5, 1);
    for (let col = 0; col < columns; col++) ix.push(center, col, col + 1);
    const g = geometry(p, uv, ix); seam(g, columns, rows); mesh(moving, g, main).name = 'dbh-soft-scalp-lining';
  }
  // A shallow back lining fills the narrow spaces between layers without dictating
  // the visible hem: the individual outer locks extend well beyond it.
  {
    const rows = 44, columns = 52, p: number[] = [], uv: number[] = [], ix: number[] = [];
    for (let row = 0; row <= rows; row++) for (let col = 0; col <= columns; col++) {
      const a = -1.48 + col / columns * 2.96, t = row / rows;
      const y = mix(.59, -.79 + .06 * Math.abs(Math.sin(a)), t);
      const taper = 1 - .95 * ease(.44, 1, t), width = (.313 + .028 * Math.sin(t * Math.PI)) * taper;
      const wave = Math.sin(t * 6.5 + a * 2) * .013 * Math.sin(t * Math.PI);
      const skullClearance = .090 * ease(.10, .55, y);
      p.push(Math.sin(a) * width + wave, y, -Math.cos(a) * (.277 + skullClearance + .021 * Math.sin(t * 5.2)) * taper - .032);
      uv.push(col / columns * 2, 1 - t);
      if (row && col) { const v = row * (columns + 1) + col, b = v - columns - 1; ix.push(v - 1, b, v, v - 1, b - 1, b); }
    }
    mesh(moving, geometry(p, uv, ix), shade).name = 'dbh-back-hair-density';
  }

  /** A flattened lens section keeps a lock soft and substantial from every angle. */
  function lock(name: string, path: THREE.Vector3[], width: number, depth: number, outward: THREE.Vector3, material: THREE.Material, rootWidth = .55, tipStart = .58) {
    const curve = new THREE.CatmullRomCurve3(path), rows = 64, columns = 18;
    const p: number[] = [], uv: number[] = [], ix: number[] = [];
    const previous = new THREE.Vector3();
    const fittedFringe = name.startsWith('dbh-swept-fringe-');
    const centerAt = (t: number) => {
      const value = curve.getPoint(THREE.MathUtils.clamp(t, 0, 1));
      if (fittedFringe) value.z = mix(value.z, scalpFrontZ(value.x, value.y) + .013, ease(.47, .66, value.y));
      return value;
    };
    for (let row = 0; row <= rows; row++) {
      const t = row / rows, center = centerAt(t);
      const tangent = fittedFringe ? centerAt(t + .0005).sub(centerAt(t - .0005)).normalize() : curve.getTangent(t).normalize();
      const across = new THREE.Vector3().crossVectors(tangent, outward);
      if (across.lengthSq() < .000001) across.copy(previous).projectOnPlane(tangent);
      if (across.lengthSq() < .000001) across.crossVectors(tangent, point(1, 0, 0));
      across.normalize(); if (row && across.dot(previous) < 0) across.negate(); previous.copy(across);
      const normal = new THREE.Vector3().crossVectors(across, tangent).normalize();
      const taper = Math.max(.003, Math.pow(1 - ease(tipStart, 1, t), .72));
      const rootFade = .003 + .997 * ease(0, .18, t);
      const breadth = width * rootFade * mix(rootWidth, 1, ease(0, .27, t)) * taper;
      const thickness = depth * rootFade * mix(.45, 1, ease(0, .22, t)) * Math.pow(taper, .8);
      for (let col = 0; col <= columns; col++) {
        const angle = col / columns * Math.PI * 2, lateral = Math.cos(angle), surface = Math.sin(angle);
        // Shallow relief is broad enough to read as a strand group, never a rope.
        const volume = surface * (1 + .035 * Math.cos(lateral * Math.PI * 3));
        const vertex = center.clone().addScaledVector(across, lateral * breadth).addScaledVector(normal, volume * thickness);
        if (fittedFringe) {
          // A wide fringe must curve around the forehead at its edges too. A
          // fitted centre with flat lateral edges leaves a visible scalp window.
          const attachment = ease(.49, .66, vertex.y);
          vertex.z += (scalpFrontZ(vertex.x, vertex.y) - scalpFrontZ(center.x, center.y)) * attachment;
        }
        p.push(vertex.x, vertex.y, vertex.z); uv.push((lateral + 1) / 2, 1 - t);
        if (row && col) { const a = row * (columns + 1) + col, b = a - columns - 1; ix.push(a - 1, a, b, a - 1, b, b - 1); }
      }
    }
    const first = p.length / 3, last = first + 1;
    p.push(...centerAt(0).toArray(), ...centerAt(1).toArray()); uv.push(.5, 1, .5, 0);
    for (let col = 0; col < columns; col++) { ix.push(first, col, col + 1); const a = rows * (columns + 1) + col; ix.push(last, a + 1, a); }
    const g = geometry(p, uv, ix); seam(g, columns, rows); mesh(moving, g, material).name = name;
  }

  // Large back sections form overlapping S waves, with staggered ends and crests.
  for (let i = 0; i < 13; i++) {
    const a = [-1.44, -1.25, -1.04, -.8, -.59, -.31, -.08, .16, .4, .63, .87, 1.1, 1.35][i], sx = Math.sin(a), cz = Math.cos(a), phase = i * 1.73;
    const sway = Math.sin(phase), end = -.76 - .09 * cz + .05 * Math.sin(i * 2.3) + .05 * Math.abs(sx);
    lock(`dbh-back-wave-${i}`, [
      capPoint(Math.PI - a * .65, .887, .001), capPoint(Math.PI - a * .85, .76, .006),
      point(sx * .322, .43, -cz * .370 - .047 - .120 * Math.abs(sx) ** 8),
      point(sx * .353 + sway * .025, .13, -cz * .335 - .025 - .040 * Math.abs(sx) ** 8),
      point(sx * .424 + sway * .037, -.13, -cz * .390 - .027 + .018 * Math.cos(phase)),
      point(sx * .322 - sway * .028, -.38, -cz * .320 - .024 + .018 * Math.cos(phase)),
      point(sx * .335 + sway * .035, end + .135, -cz * .310 - .034),
      point(sx * .252 + sway * .065, end, -cz * .219 - .020 + .040 * Math.cos(phase)),
    ], .061 + (i % 3) * .005, .008 + (i % 2) * .0015, point(sx, .015, -cz), materials[i % materials.length], .27, .44);
  }
  // Outer layers follow an envelope beyond the long layers until their actual
  // tips. Dipping into the underlying volume made their visible ends look cut off.
  const backEnvelope = (y: number) => {
    const sections = [[.79, .235, .255], [.45, .342, .395], [.16, .356, .380], [-.12, .443, .410], [-.36, .351, .355], [-.58, .364, .332], [-.88, .223, .220]];
    for (let i = 0; i < sections.length - 1; i++) if (y >= sections[i + 1][0]) {
      const t = ease(sections[i + 1][0], sections[i][0], y);
      return { x: mix(sections[i + 1][1], sections[i][1], t), z: mix(sections[i + 1][2], sections[i][2], t) };
    }
    return { x: .223, z: .22 };
  };
  for (let i = 0; i < 7; i++) {
    const a = [-1.24, -.93, -.51, -.07, .37, .81, 1.18][i], phase = i * 1.8;
    const surface = (y: number) => {
      const p = backEnvelope(y), turn = a + .11 * Math.sin((.32 - y) * 7 + phase) * (1 - ease(.25, .7, y));
      return point(Math.sin(turn) * (p.x + .012), y, -Math.cos(turn) * (p.z + .014) - .025);
    };
    lock(`dbh-back-upper-layer-${i}`, [capPoint(Math.PI - a * .85, .83, .003),
      surface(.55), surface(.24), surface(-.025), surface(-.24), surface([-.39, -.54, -.67, -.45, -.59, -.73, -.48][i]),
    ], .052 + (i % 2) * .008, .006, point(Math.sin(a), 0, -Math.cos(a)), materials[(i + 1) % materials.length], .24, .48);
  }

  // A long, asymmetric sweep is broken up by narrower overlapping wisps. The
  // part sits slightly right of centre; the tips never form an even row of teeth.
  const fringe = [
    { root: -.008, middle: -.201, lower: -.254, x: -.226, end: .278, width: .039 },
    { root: .020, middle: -.119, lower: -.177, x: -.207, end: .408, width: .054 },
    { root: .063, middle: .010, lower: -.026, x: -.091, end: .391, width: .058 },
    { root: .090, middle: .166, lower: .225, x: .243, end: .326, width: .042 },
    { root: .071, middle: .092, lower: .103, x: .116, end: .486, width: .023 },
    { root: .003, middle: -.186, lower: -.239, x: -.221, end: .451, width: .024 },
    { root: .039, middle: -.074, lower: -.116, x: -.154, end: .431, width: .027 },
    { root: .069, middle: .033, lower: -.012, x: -.058, end: .376, width: .021 },
    { root: .088, middle: .137, lower: .178, x: .216, end: .449, width: .024 },
    { root: .105, middle: .240, lower: .258, x: .220, end: .237, width: .034 },
  ];
  const faceHairZ = (x: number, y: number) => {
    const p = fitSection(y);
    return p.center + p.z * Math.pow(Math.max(.005, 1 - (x / p.x) ** 2), .39) + .023;
  };
  for (const [i, f] of fringe.entries()) {
    const upperX = mix(f.root * .70, f.middle, .53);
    lock(`dbh-swept-fringe-${i}`, [point(f.root * .70, .905 - (i % 3) * .003, -.040),
      point(upperX, .805, scalpFrontZ(upperX, .805) + .011),
      point(f.middle, .668, scalpFrontZ(f.middle, .668) + .017),
      point(f.lower, .527, Math.max(faceHairZ(f.lower, .527), scalpFrontZ(f.lower, .527) + .010)),
      point(f.x, f.end, faceHairZ(f.x, f.end)),
    ], f.width * 1.12, i < 4 ? .0065 : .0038, point(0, .04, 1), materials[i % materials.length], .10, .53);
  }

  for (const side of [-1, 1]) {
    const s = side;
    // Short overlapping temple sweeps soften the lining's edge before the ear.
    // They taper at different heights and stay fitted to the skull, leaving the
    // relocated ear and the longer cheek lock distinct from the scalp lining.
    for (const [i, sweep] of [
      { angle: 1.12, turn: 1.25, end: .367, width: .034 },
      { angle: 1.28, turn: 1.41, end: .409, width: .032 },
      { angle: 1.43, turn: 1.53, end: .456, width: .027 },
    ].entries()) {
      lock(`dbh-temple-edge-sweep-${side}-${i}`, [
        capPoint(s * (sweep.angle - .11), .784, .006),
        capPoint(s * sweep.angle, .675, .008),
        capPoint(s * (sweep.turn + .035), .557, .009),
        capPoint(s * sweep.turn, .490, .010),
        capPoint(s * (sweep.turn - .035), sweep.end, .009),
      ], sweep.width, .0038, point(s * .96, 0, .22), materials[i], .14, .49);
    }
    // Only one short cheek lock and one main shoulder lock pass in front of each
    // ear. They follow the cheek rather than standing away from the face.
    lock(`dbh-short-cheek-lock-${side}`, [capPoint(s * 1.02, .858, .003),
      point(s * .242, .62, .101), point(s * .249, .416, .078),
      point(s * .214, .235, .074), point(s * .198, .064, .084),
    ], .026, .0058, point(s * .32, 0, .95), soft, .15, .30);
    lock(`dbh-front-shoulder-lock-${side}`, [capPoint(s * 1.24, .862, .003),
      point(s * .262, .616, .066), point(s * .268, .374, .026),
      point(s * .361, .12, .119), point(s * .298, -.135, .235),
      point(s * .377, -.375, .170), point(s * .293, side < 0 ? -.67 : -.555, .211),
    ], side < 0 ? .042 : .037, .0065, point(s * .44, 0, .9), main, .16, .34);
    lock(`dbh-loose-front-tip-${side}`, [point(s * .278, .369, .061),
      point(s * .331, .111, .154), point(s * .382, -.095, .212),
      point(s * .318, -.303, .253), point(s * .341, side < 0 ? -.505 : -.415, .170),
    ], .027, .0041, point(s * .38, 0, .92), soft, .20, .30);

    // The substantial long side sections stay behind the ear and shoulder. Their
    // silhouette still reads from the front without forming a curtain over the face.
    for (let i = 0; i < 4; i++) {
      const a = s * (1.65 + i * .17), end = -.645 - i * .049 + .018 * Math.sin(i * 2.4 + side);
      lock(`dbh-behind-ear-wave-${side}-${i}`, [capPoint(a, .879 - i * .011, .003),
        point(s * (.280 + i * .005), .616, -.187 - i * .035),
        point(s * (.307 + i * .008), .364, -.235 - i * .037),
        point(s * (.359 + i * .014), .087, -.169 - i * .038),
        point(s * (.425 + i * .008), -.223, -.221 - i * .031),
        point(s * (.330 + i * .010), -.463, -.256 - i * .029),
        point(s * (.306 - i * .014) + .019 * Math.sin(i * 2 + side), end, -.158 - i * .038),
      ], .045 + (i % 2) * .006, .007, point(s * .94, 0, -.34), materials[(i + 1) % materials.length], .16, .40);
    }
    line(moving, soft, [point(s * .302, .533, -.213), point(s * .405, .215, -.198), point(s * .460, -.055, -.090), point(s * .382, -.32, .014)], .0013, 36);
    line(moving, shade, [point(s * .345, .135, -.193), point(s * .436, -.165, -.089), point(s * .405, -.42, .012), point(s * .349, -.655, .086)], .0012, 36);
  }
  line(moving, soft, [point(.019, .914, -.057), point(-.025, .941, -.051), point(-.079, .931, -.055), point(-.127, .896, -.059)], .0012, 24);
  batchJointMeshes(root);
  function update(t: number, dt: number, action: string) {
    const k = 1 - Math.exp(-Math.min(.1, Math.max(0, dt)) * 8);
    moving.rotation.z = mix(moving.rotation.z, Math.sin(t * 1.12) * .003 + (action === 'dance' ? Math.sin(t * 4.1 - .4) * .012 : 0), k);
    moving.rotation.x = mix(moving.rotation.x, Math.sin(t * 1.56 + .4) * .003, k);
  }
  const dispose = () => { grain.dispose(); strandNormals.dispose(); };
  return { root, update, dispose };
}
