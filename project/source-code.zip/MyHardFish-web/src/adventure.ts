import { adventureItems, discoveries, quests } from "./adventure-content";
import { foods, friends, places } from "./content";
import type { GameState } from "./engine";
import type {
  AdventureAction, AdventureLogEntry, AdventureReward, AdventureState, AdventureView,
  GameKind, QuestChoice, QuestDefinition, QuestProgress, QuestRequirementView, QuestView,
} from "./adventure-types";
import type { Place } from "./scene";

const bounded = (n: number, max: number) => Math.max(0, Math.min(max, n));
const completed = (a: AdventureState, id: string) => a.quests[id]?.status === "completed";
const available = (a: AdventureState, quest: QuestDefinition) => quest.prerequisites.every(id => completed(a, id));
const progress = (now: number, revision: number): QuestProgress => ({
  status: "active", stage: 0, startedAt: now, stageStartedAt: now,
  stageStartedRevision: revision, objectives: {}, choices: {},
});

export function createAdventure(now: number, revision = 0): AdventureState {
  const a: AdventureState = {
    schema: 1, trackedQuest: null, quests: {}, items: {},
    relations: Object.fromEntries(friends.map(friend => [friend.id, 0])),
    flags: [], discoveries: [], log: [],
  };
  for (const quest of quests) {
    if (!quest.autoStart || !available(a, quest)) continue;
    a.quests[quest.id] = progress(now, revision);
    a.trackedQuest ??= quest.id;
    a.log.push({ at: now, kind: "quest", title: quest.title, text: quest.intro, questId: quest.id });
  }
  return a;
}

function log(s: GameState, entry: AdventureLogEntry) {
  s.adventure.log = [...s.adventure.log.slice(-199), entry];
  s.journal = [...s.journal.slice(-99), { at: entry.at, text: `${entry.title}：${entry.text}`.slice(0, 800) }];
}

function reward(s: GameState, value: AdventureReward | undefined) {
  if (!value) return;
  s.shells += value.shells || 0;
  s.bond += value.bond || 0;
  for (const [id, n] of Object.entries(value.items || {}))
    if (adventureItems.some(item => item.id === id)) s.adventure.items[id] = bounded((s.adventure.items[id] || 0) + n, 99);
  for (const [id, n] of Object.entries(value.foods || {})) {
    const food = foods.find(item => item.id === id);
    if (food) s.inventory[food.id] = bounded(s.inventory[food.id] + n, 99);
  }
  for (const [id, n] of Object.entries(value.relations || {}))
    if (friends.some(friend => friend.id === id)) s.adventure.relations[id] = bounded((s.adventure.relations[id] || 0) + n, 100);
  for (const flag of value.flags || []) if (!s.adventure.flags.includes(flag)) s.adventure.flags.push(flag);
  for (const outfit of value.outfits || []) if (!s.owned.includes(outfit)) s.owned.push(outfit);
}

function costReason(s: GameState, choice: QuestChoice): string {
  for (const [id, n] of Object.entries(choice.costItems || {})) {
    if ((s.adventure.items[id] || 0) < n)
      return `还需要${adventureItems.find(item => item.id === id)?.name || id} ×${n}`;
  }
  for (const [id, n] of Object.entries(choice.costFoods || {})) {
    const food = foods.find(item => item.id === id);
    if (!food || s.inventory[food.id] < n) return `还需要${food?.name || id} ×${n}，可以补货或选另一种做法`;
  }
  if (s.shells < (choice.costShells || 0)) return `还需要 ${choice.costShells} 贝壳，可以选不花钱的做法`;
  return "";
}

function requirements(s: GameState, quest: QuestDefinition, p: QuestProgress | undefined): QuestRequirementView[] {
  const stage = p?.status === "active" ? quest.stages[p.stage] : null;
  return (stage?.requirements || []).map(requirement => {
    const target = requirement.kind === "game" ? requirement.count || 1 : 1;
    const current = requirement.kind === "discovery"
      ? Number(s.adventure.discoveries.includes(requirement.discoveryId))
      : p?.objectives[requirement.id] || 0;
    return { requirement, current: Math.min(current, target), target, met: current >= target };
  });
}

export function getQuestView(s: GameState, id: string): QuestView | null {
  const quest = quests.find(item => item.id === id);
  if (!quest) return null;
  const p = s.adventure.quests[id] as QuestProgress | undefined;
  const status = p?.status || (available(s.adventure, quest) ? "available" : "locked");
  const stage = p?.status === "active" ? quest.stages[p.stage] || null : null;
  const objectives = requirements(s, quest, p);
  const unmet = objectives.find(item => !item.met);
  const missing = quest.prerequisites.filter(id => !completed(s.adventure, id))
    .map(id => quests.find(item => item.id === id)?.title || id);
  const reason = status === "locked" ? `先完成${missing.map(title => `「${title}」`).join("、")}`
    : status === "available" ? "先接下这份委托"
    : status === "completed" ? "这段共同经历已经完成"
    : stage && s.place !== stage.place ? `先到${places.find(place => place.id === stage.place)?.name || stage.place}`
    : unmet ? unmet.requirement.label : "";
  const choices = (stage?.choices || []).map(choice => {
    const blocked = reason || costReason(s, choice);
    return { choice, enabled: !blocked, reason: blocked };
  });
  return { quest, status, progress: p || null, stage, completedStages: p?.stage || 0,
    requirements: objectives, choices, ready: status === "active" && choices.some(choice => choice.enabled), reason };
}

export function getAdventureView(s: GameState): AdventureView {
  const views = quests.map(quest => getQuestView(s, quest.id)!);
  return {
    quests: views,
    tracked: views.find(view => view.quest.id === s.adventure.trackedQuest && view.status !== "completed")
      || views.find(view => view.status === "active") || views.find(view => view.status === "available") || null,
    completedCount: views.filter(view => view.status === "completed").length,
    activeCount: views.filter(view => view.status === "active").length,
    availableCount: views.filter(view => view.status === "available").length,
    discoveredCount: s.adventure.discoveries.length,
  };
}

export function latestFriendQuest(s: GameState, friendId: string): QuestDefinition | null {
  const related = quests.filter(quest => quest.friendIds.includes(friendId) && completed(s.adventure, quest.id));
  // Logs preserve actual ordering even if two completions share a millisecond.
  const recent = [...s.adventure.log].reverse().find(entry => entry.kind === "quest"
    && entry.title.startsWith("完成 · ") && related.some(quest => quest.id === entry.questId));
  return related.find(quest => quest.id === recent?.questId)
    || related.sort((a, b) => (s.adventure.quests[b.id].completedAt || 0) - (s.adventure.quests[a.id].completedAt || 0))[0]
    || null;
}

/** Auto-accept unlocked main-chain entries without issuing rewards. */
export function syncAdventures(s: GameState, now: number) {
  for (const quest of quests) {
    if (!quest.autoStart || s.adventure.quests[quest.id] || !available(s.adventure, quest)) continue;
    s.adventure.quests[quest.id] = progress(now, s.revision);
    log(s, { at: now, kind: "quest", questId: quest.id, title: quest.title, text: quest.intro });
  }
  if (!s.adventure.trackedQuest || completed(s.adventure, s.adventure.trackedQuest))
    s.adventure.trackedQuest = quests.find(quest => s.adventure.quests[quest.id]?.status === "active")?.id || null;
}

export type AdventureEvent =
  | { kind: "game"; game: GameKind; score: number; place: Place; startedRevision: number }
  | { kind: "story"; storyId: string; place: Place };

/** Only accepted tasks at their current stage observe a new, legitimate completion. */
export function recordAdventureEvent(s: GameState, event: AdventureEvent) {
  for (const quest of quests) {
    const p = s.adventure.quests[quest.id];
    if (!p || p.status !== "active") continue;
    const stage = quest.stages[p.stage];
    if (!stage) continue;
    if (event.kind === "game" && (stage.place !== event.place || event.startedRevision <= p.stageStartedRevision)) continue;
    for (const requirement of stage.requirements || []) {
      if (event.kind === "game" && requirement.kind === "game" && requirement.game === event.game && event.score >= (requirement.minScore || 0))
        p.objectives[requirement.id] = Math.min(requirement.count || 1, (p.objectives[requirement.id] || 0) + 1);
      if (event.kind === "story" && requirement.kind === "story" && requirement.storyId === event.storyId)
        p.objectives[requirement.id] = 1;
    }
  }
}

export function applyAdventureAction(
  s: GameState, action: AdventureAction, now: number,
  reply: (quoteId: string | undefined, text: string) => void,
) {
  if (action.type === "discover") {
    const discovery = discoveries.find(item => item.id === action.value);
    if (!discovery) { s.notice = "这里暂时没有这条发现"; return; }
    if (s.place !== discovery.place || action.hotspot !== discovery.hotspot) { s.notice = "先走到发现所在的地点，看看那个物件"; return; }
    if (s.adventure.discoveries.includes(discovery.id)) { s.notice = "已经记进发现册了"; return; }
    s.adventure.discoveries.push(discovery.id);
    reward(s, discovery.reward);
    log(s, { at: now, kind: "discovery", title: discovery.title, text: discovery.text });
    s.notice = `新发现「${discovery.title}」`;
    reply(discovery.quoteId, discovery.text);
    return;
  }
  if (action.type === "startQuest" || action.type === "trackQuest") {
    const view = getQuestView(s, action.value);
    if (!view) { s.notice = "没有找到这份委托"; return; }
    if (view.status === "locked" || view.status === "completed") { s.notice = view.reason; return; }
    if (action.type === "startQuest" && view.status === "available") {
      s.adventure.quests[view.quest.id] = progress(now, s.revision);
      log(s, { at: now, kind: "quest", questId: view.quest.id, title: view.quest.title, text: view.quest.intro });
      s.notice = `接下委托「${view.quest.title}」`;
    } else if (view.status === "available") { s.notice = "先接下这份委托，再开始追踪"; return; }
    s.adventure.trackedQuest = view.quest.id;
    return;
  }
  const view = getQuestView(s, action.questId);
  if (!view?.stage || view.status !== "active" || view.stage.id !== action.stageId) { s.notice = "这一步已经完成，看看现在的目标吧"; return; }
  if (s.place !== view.stage.place || action.hotspot !== view.stage.hotspot) { s.notice = "先走到这一步对应的地点和物件旁"; return; }
  const selected = view.choices.find(item => item.choice.id === action.choiceId);
  if (!selected) { s.notice = "这个选项不属于当前这一步"; return; }
  if (!selected.enabled) { s.notice = selected.reason; return; }
  const choice = selected.choice;
  // Validation above checks every cost before making any irreversible change.
  for (const [id, n] of Object.entries(choice.costItems || {})) s.adventure.items[id] -= n;
  for (const [id, n] of Object.entries(choice.costFoods || {})) {
    const food = foods.find(item => item.id === id)!;
    s.inventory[food.id] -= n;
  }
  s.shells -= choice.costShells || 0;
  reward(s, choice.reward);
  const p = s.adventure.quests[view.quest.id];
  p.choices[view.stage.id] = choice.id;
  p.stage++;
  p.objectives = {};
  p.stageStartedAt = now;
  p.stageStartedRevision = s.revision;
  log(s, { at: now, kind: "stage", questId: view.quest.id, stageId: view.stage.id, title: view.stage.title, text: choice.text });
  reply(choice.quoteId || view.stage.quoteId, choice.text);
  if (p.stage === view.quest.stages.length) {
    p.status = "completed";
    p.completedAt = now;
    reward(s, view.quest.reward);
    log(s, { at: now, kind: "quest", questId: view.quest.id, title: `完成 · ${view.quest.title}`, text: view.quest.ending });
    s.notice = `完成「${view.quest.title}」${view.quest.reward.shells ? ` · +${view.quest.reward.shells} 贝壳` : ""}`;
  } else s.notice = `已完成「${view.stage.title}」· 下一步：${view.quest.stages[p.stage].title}`;
  syncAdventures(s, now);
}
