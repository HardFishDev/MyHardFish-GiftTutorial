export interface AudioPreferences {
  music: boolean;
  effects: boolean;
  musicVolume: number;
}

// Deliberately separate from save slots and exported game ZIPs.
export const AUDIO_PREFERENCES_KEY = "hardfish.audio-preferences.v1";
const defaults: AudioPreferences = { music: true, effects: true, musicVolume: 0.3 };

export function normalizeAudioPreferences(value: unknown): AudioPreferences {
  const input = value && typeof value === "object"
    ? value as Partial<AudioPreferences>
    : {};
  return {
    music: typeof input.music === "boolean" ? input.music : defaults.music,
    effects: typeof input.effects === "boolean" ? input.effects : defaults.effects,
    musicVolume: typeof input.musicVolume === "number" && Number.isFinite(input.musicVolume)
      ? Math.max(0, Math.min(1, input.musicVolume))
      : defaults.musicVolume,
  };
}

export function loadAudioPreferences(): AudioPreferences {
  try {
    return normalizeAudioPreferences(JSON.parse(localStorage.getItem(AUDIO_PREFERENCES_KEY) || "null"));
  } catch {
    // Private browsing, blocked storage and malformed older values are non-fatal.
    return { ...defaults };
  }
}

export function saveAudioPreferences(preferences: AudioPreferences): void {
  // The caller applies changes first, then reports persistence failures to the player.
  localStorage.setItem(AUDIO_PREFERENCES_KEY, JSON.stringify(normalizeAudioPreferences(preferences)));
}
