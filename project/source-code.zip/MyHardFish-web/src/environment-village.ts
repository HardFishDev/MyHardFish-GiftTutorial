import type { EnvironmentBuilder } from './environment';
import { path, lamp, flowerBed, building, noticeboard, pennants, boundaryForest, fence, crate } from './world-town-props';

export function buildVillage(b:EnvironmentBuilder) {
  b.bounds={minX:-40,maxX:40,minZ:-40,maxZ:40};b.navigationStep=.52;b.chunkSize=14;b.spawn.set(8,0,10);
  b.floor('#92a27e','plaster',144);boundaryForest(b,40,100);
  // A connected street plan: a central square, a ring road and seven real neighbourhood doors.
  path(b,0,0,75,6.2);path(b,0,0,6.5,74);path(b,-22,1,5,55);path(b,22,1,5,55);path(b,0,-24,49,5);path(b,0,24,49,5);
  path(b,-28,14,14,4.6);path(b,-27,-25,10,4.6);path(b,25,-21,14,4.6);path(b,25,18,10,4.6);
  const plaza=b.cylinder(11.3,11.3,.10,[0,.01,-2],'#d4c9a9');plaza.material=b.material('#d4c9a9','stone');plaza.castShadow=false;b.elevation(0,-2,18,18,.06);
  const ring=b.torus(10.5,.075,[0,.075,-2],'#b8b994');ring.rotation.x=-Math.PI/2;ring.castShadow=false;
  // The bell is a visible navigation landmark from every entrance, with an open space around it.
  b.cylinder(2.1,2.4,.36,[0,.20,-4],'#b3b69a');b.cylinder(1.65,1.85,.22,[0,.48,-4],'#d6caaa');
  for(const side of [-1,1])b.surface([.29,4.3,.29],[side*1.2,2.65,-4],'#8a7c59','wood',.045);
  b.surface([3.3,.25,.48],[0,4.72,-4],'#9e8760','wood',.05);
  const bell=b.cylinder(.52,.92,1.08,[0,3.69,-4],'#b29757');bell.material=b.material('#b29757','metal');
  b.cylinder(.09,.14,.39,[0,3.08,-4],'#766443');b.cylinder(.055,.055,2.1,[.3,2.15,-3.6],'#aa9a73');b.obstacle(0,-4,4.7,4.7);
  b.label('老母猪村',[0,5.35,-3.89],4.7,'#526c59','#e9ddbd');
  // Keep the resident clear of the bell, benches and their approach paths.
  const dbh=b.hotspot('npc:dbh','与 dbh 聊天',[-3.8,1.88,1.7],[1.5,3.65,1.1]);
  Object.assign(dbh.userData,{approach:[-1.65,3.3],kind:'interaction',radius:2.5,activityTarget:[-3.8,2.7,1.7]});
  b.obstacle(-3.8,1.7,1.05,.8);
  const dbhName=b.label('dbh',[-3.8,3.92,1.7],.78,'#eee8da','#505450');
  dbhName.scale.y=.55;
  if(dbhName.material.map){dbhName.material.map.repeat.set(.5,.4);dbhName.material.map.offset.set(.25,.3);}
  Object.assign(dbhName.userData,{keep:true,action:'npc:dbh',label:'与 dbh 聊天'});
  dbh.userData.marker=dbhName;
  for(const [x,z,r] of [[-8,-5,Math.PI/2],[8,-5,-Math.PI/2],[-6,7,0],[6,7,0]])b.bench(x,z,r);
  for(const [x,z] of [[-9,-11],[9,-11],[-9,7],[9,7]])flowerBed(b,x,z,2.1,1.3);
  noticeboard(b,-16,1,'猴的村务留言','今天也有人在等你',4.1);
  // Residential frontages and communal buildings stand beyond the street; none blocks a door.
  building(b,-36.5,14,11.5,7.4,5.1,'#d7c6a3','#89947a',Math.PI/2);
  building(b,-34,-25,10,7,4.6,'#d9d3b7','#839774',Math.PI/2);
  building(b,0,-38,14,8.0,6.9,'#d4d1b7','#82948b');
  building(b,35,-21,13,7.4,5.4,'#c7ceb5','#7f9992',-Math.PI/2);
  building(b,31,18,12,8,5,'#d9c8ac','#b39475',-Math.PI/2);
  building(b,-32,-9,8.4,7,6.3,'#c4c9af','#8a9b83',Math.PI/2);
  building(b,-30,30,10.5,8,4.8,'#d8ccb0','#a59a7c',Math.PI/2);
  // A tiny post office, bicycles, stacked deliveries and a sheltered waiting nook.
  b.surface([1.2,1.7,.9],[-26,.86,10.5],'#a18f65','wood',.08);b.surface([.8,.16,.045],[-26,1.44,11],'#4e6657','metal',.02);b.label('投递',[-26,.9,11],.72);
  b.obstacle(-26,10.5,1.3,1);
  for(const [x,z] of [[-25,16],[-25,18]]){
    for(const dx of [-.7,.7]){const wheel=b.torus(.48,.045,[x+dx,.5,z],'#4f665b');wheel.rotation.y=0;}
    b.surface([1.4,.06,.06],[x,.85,z],'#859f8a','metal',.012).rotation.z=.3;
    b.cylinder(.028,.028,1.05,[x+.62,1.06,z],'#8fa98e').rotation.z=.22;b.surface([.46,.08,.18],[x-.3,1.25,z],'#8b795c','wood',.04);b.obstacle(x,z,2.2,.5);
  }
  crate(b,27,0,23);crate(b,28.3,0,23);crate(b,27.4,.66,23);
  // The shared garden is reached from two streets, with working beds and a tool shelter.
  path(b,15,-15,13,3.4);path(b,18,-17,3.5,11);
  for(const [x,z] of [[14.7,-20],[21.3,-20],[14.7,-25],[21.3,-25]])flowerBed(b,x,z,4,2.4);
  b.surface([3.8,.22,1.5],[18,1.1,-18],'#bba076','wood',.045);for(const x of [16.5,19.5])b.surface([.14,1.1,.14],[x,.55,-18],'#887854','wood');b.obstacle(18,-18,4.1,1.7);
  for(let i=0;i<6;i++){const x=16.7+i*.52;b.cylinder(.17,.13,.32,[x,1.36,-18],'#b99066');b.sphere([.23,.29,.20],[x,1.66,-18],i%2?'#819d68':'#a1b483');}
  b.label('一起种的小花园',[18,2.5,-18.1],3.6);fence(b,18,-28,11);fence(b,12,-22,11,Math.PI/2);fence(b,24,-22,11,Math.PI/2);
  // Side-lane details make walking to a neighbour more than crossing a lawn.
  for(const [x,z,s] of [[-15,-15,1.55],[-15,15,1.4],[14,14,1.4],[29,-9,1.25],[-11,30,1.5],[11,30,1.4],[-31,3,1.5],[31,7,1.35],[-9,-31,1.4],[10,-31,1.5]])b.tree(x,z,s);
  for(const [x,z] of [[-11,0],[11,0],[0,12],[0,-15],[-20,12],[-20,-13],[20,12],[20,-11],[-3,28],[3,-29],[-29,20],[29,-16]])lamp(b,x,z);
  for(const [x,z] of [[-16,20],[15,23],[-15,-20],[13,-8]])flowerBed(b,x,z,3.8,1.55);
  pennants(b,[-10,5,12],[10,5,12],18);pennants(b,[-10,5,-16],[10,5,-16],18);
  for(let i=0;i<6;i++){const x=-36+i*14.4;fence(b,x,39,10);fence(b,x,-39,10);}
  const notice=b.flagGroup('notice_ready');b.label('集合通知 · 已送达',[-16,1.03,1.16],3.3,'#5c755e','#e0c38d',notice);
  const harvest=b.flagGroup('harvest_ready');for(let i=0;i<10;i++)b.sphere([.12,.13,.12],[14.7+Math.sin(i*2.4),.99,-20+Math.cos(i*2.4)*.55],'#b58472',harvest);
  const celebration=b.flagGroup('festival_ready');for(let i=0;i<13;i++){const glow=b.sphere([.11,.15,.11],[-9+i*1.5,4.7-Math.sin(i/12*Math.PI)*.5,12],'#ffe3a6',celebration),m=b.material('#ffe3a6');m.emissive.set('#e8bd77');m.emissiveIntensity=.75;glow.material=m;}
}
