import type { Place } from './scene';

export type DbhAction = 'idle' | 'talk' | 'wave' | 'nod' | 'think' | 'cheer' | 'dance' | 'stretch' | 'photo' | 'gift' | 'bye';

/** Original game dialogue, not quotations or a personality claim about the QQ owner. */
export const DBH_TOPICS = [
  { id: 'hello', label: '怎么称呼你？', opening: '叫我 dbh 就好。衣服上也有，记不住的时候可以偷偷看一眼。你呢，今天想认真逛村子，还是随便走走？', action: 'wave', replies: [
    { label: '先随便走走，碰到什么算什么', text: '这条路线我熟：没有路线。累了就回广场，我一般都在这里。', action: 'nod' },
    { label: '想多认识一位村里的朋友', text: '那今天已经完成一件事了。下次路过直接打招呼，不用重新做自我介绍。', action: 'cheer' },
  ] },
  { id: 'shirt', label: '聊聊这件 DBH T 恤', opening: '灰色宽松 T 恤、炭灰短裤、凉鞋——出门三件套。口袋不用塞满，带一点好心情就够了。你觉得哪种散步最舒服？', action: 'talk', replies: [
    { label: '有树荫、有微风的那种', text: '赞成。头发被风吹乱了也没关系，等风停了再整理。我们把下午留给树荫。', action: 'stretch' },
    { label: '有人陪着，就很好', text: '那我把旁边的位置留给你。可以一直聊，也可以谁都不说话。', action: 'nod' },
  ] },
  { id: 'village', label: '你在广场等什么？', opening: '等大家慢慢把村子过热闹。公告栏的标题一直在改，花园倒是认真分好了三只筐。想替今天留下一点什么？', action: 'think', replies: [
    { label: '记住一个不起眼的小细节', text: '很好。去看看公告栏、花园和集合钟吧。手记里有我的小约定，接下以后再出发。', action: 'nod' },
    { label: '先留一张合影', text: '我先找好角度。去「一起做点事」选合影，我们把今天的广场也拍进去。', action: 'photo' },
  ] },
  { id: 'weather', label: '今天有点累', opening: '那就先别赶路。把肩膀放松，呼一口气。在这里歇会儿，不需要先完成什么。', action: 'stretch', replies: [
    { label: '陪我安静待一会儿', text: '嗯，我在。等你想出发的时候，再告诉我就好。', action: 'idle' },
    { label: '给我一点出发的勇气', text: '那就先走一小段，走到路口也算。我们一点一点来。', action: 'cheer' },
  ] },
] as const satisfies readonly { id: string; label: string; opening: string; action: DbhAction; replies: readonly { label: string; text: string; action: DbhAction }[] }[];

export const DBH_DESTINATIONS: readonly { place: Place; hotspot: string; label: string; note: string }[] = [
  { place: 'village', hotspot: 'village_board', label: '村务公告栏', note: '看看大家又改了什么标题。' },
  { place: 'village', hotspot: 'village_garden', label: '共同小花园', note: '认认熟浆果、酸浆果和种子。' },
  { place: 'river', hotspot: 'river_observatory', label: '河岸观景台', note: '沿着河走，看看等待亮起的瓶灯。' },
  { place: 'market', hotspot: 'market_table', label: '夜市长桌', note: '走累了，找个能坐下来聊天的地方。' },
];

export const DBH_CLUES = [
  { id: 'board', hotspot: 'village_board', label: '村务公告栏', question: '第七版标题改成了什么？', answer: 'gather', options: [{ id: 'concert', label: '盛大演唱会' }, { id: 'gather', label: '随便聚聚' }, { id: 'race', label: '全村跑步赛' }], hint: '读读「第七版活动标题」，答案在层层叠叠的纸上。' },
  { id: 'garden', hotspot: 'village_garden', label: '共同小花园', question: '三只筐分别装什么？', answer: 'berries', options: [{ id: 'tools', label: '铲子、水壶、手套' }, { id: 'flowers', label: '红花、黄花、白花' }, { id: 'berries', label: '熟浆果、酸浆果、种子' }], hint: '看看「三只筐的共同花园」，每种作物都有自己的位置。' },
  { id: 'square', hotspot: 'village_square', label: '村口集合钟', question: '难鱼问大家还缺什么？', answer: 'tables', options: [{ id: 'tables', label: '桌子呢？' }, { id: 'tickets', label: '门票呢？' }, { id: 'umbrella', label: '雨伞呢？' }], hint: '读读「先画了一个很大的饼」，留意难鱼的那句话。' },
] as const;

export const DBH_GIFTS = [
  { id: 'paper_star', label: '一起折纸星', material: '一张小纸条，折出今天的好心情。', reply: '最后一个角，你来压。好啦，这颗星星就叫「今天也有好好见面」。', memory: '纸星约定' },
  { id: 'leaf_bookmark', label: '做一枚叶子书签', material: '把落叶夹进纸卡，让散步有个书签。', reply: '叶脉像村里的小路。以后翻到这页，就想起我们在广场吹过的风。', memory: '留住一片风' },
] as const;

export const DBH_MEMORIES: Record<string, { title: string; text: string }> = {
  first_meeting: { title: '广场上的第一声招呼', text: 'dbh 抬起手，给刚刚到来的你留了一个位置。' },
  dance: { title: '不用踩准的节拍', text: '在村中心跟着 dbh 晃了一小段，最后都笑了。' },
  photo: { title: '把今天留在画面里', text: 'dbh 在广场摆好姿势，等你按下快门。照片由合影按钮另行保存。' },
  paper_star: { title: '纸星约定', text: '一起压平最后一个纸角，留下一颗只属于这次见面的星星。' },
  leaf_bookmark: { title: '留住一片风', text: '一片落叶变成书签，广场的微风也有了可以停靠的地方。' },
  village_walk: { title: '和 dbh 的村中散步手记', text: '公告栏的第七版标题、三只作物筐、还没搬来的桌子——三个小发现，拼成了我们熟悉的村子。' },
};
