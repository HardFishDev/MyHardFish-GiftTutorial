import * as THREE from 'three';
import { MarchingCubes } from 'three/addons/objects/MarchingCubes.js';
import { mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';
import { ellipsoid, loft, mesh, point, smoothUvSeamNormals } from './dbh-geometry';
import type { ProfileRing } from './dbh-geometry';

/** One continuous anatomical surface, with soft skinning through the joint. */
export function createDbhLimb(parent: THREE.Object3D, skin: THREE.Material, profile: ProfileRing[], jointY: number, endY: number, blend: number, endBlend = 0) {
  const geometry = loft(profile, 40);
  const position = geometry.getAttribute('position'), indices: number[] = [], weights: number[] = [], colors: number[] = [];
  const isLeg = profile.some(ring => ring.y < -1.6), side = Math.sign(parent.position.x) || 1;
  const warm = new THREE.Color('#d7a5a0'), shade = new THREE.Color();
  for (let i = 0; i < position.count; i++) {
    const x = position.getX(i), y = position.getY(i), z = position.getZ(i);
    const joint = Math.exp(-(((y-jointY)/.12)**2));
    const front = THREE.MathUtils.smoothstep(z, -.01, .09);
    if(isLeg) {
      const knee = .006 * joint * front * Math.exp(-(((x+side*.032)/.082)**2));
      const ankle = .004 * Math.exp(-(((y+1.76)/.065)**2));
      position.setXYZ(i,x + Math.sign(x)*ankle,y,z+knee);
    }
    shade.set('#ffffff').lerp(warm,joint*(isLeg?.22:.10)*(isLeg?front*Math.exp(-(((x+side*.032)/.073)**2)):1-front));
    const variation=1-.005*(.5+.5*Math.sin(y*73+x*35));
    colors.push(shade.r*variation,shade.g*variation,shade.b*variation);
    const middleWeight = THREE.MathUtils.smoothstep(-y, -jointY - blend, -jointY + blend);
    const endWeight = endBlend > 0 ? THREE.MathUtils.smoothstep(-y, -endY - endBlend, -endY + endBlend) : 0;
    indices.push(0, 1, 2, 0); weights.push(1 - middleWeight, middleWeight * (1 - endWeight), middleWeight * endWeight, 0);
  }
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  geometry.computeVertexNormals();
  smoothUvSeamNormals(geometry, 41);
  geometry.setAttribute('skinIndex', new THREE.Uint16BufferAttribute(indices, 4));
  geometry.setAttribute('skinWeight', new THREE.Float32BufferAttribute(weights, 4));
  const limbSkin = (skin as THREE.MeshStandardMaterial).clone(); limbSkin.vertexColors = true;
  const object = new THREE.SkinnedMesh(geometry, limbSkin); object.name = 'dbh-continuous-anatomy';
  object.castShadow = object.receiveShadow = true; object.userData.unbatched = true;
  object.frustumCulled = false;
  const base = new THREE.Bone(), middle = new THREE.Bone(), end = new THREE.Bone();
  middle.position.y = jointY; end.position.y = endY - jointY;
  base.add(middle); middle.add(end); object.add(base); parent.add(object);
  parent.updateWorldMatrix(true, true);
  object.bind(new THREE.Skeleton([base, middle, end]));
  return { object, middle, end };
}

/** A joined, softly tailored garment with a real crotch and two leg openings. */
export function createDbhShorts(parent: THREE.Group, cloth: THREE.Material, legs: THREE.Bone[]) {
  const size = 82, field = new MarchingCubes(size, cloth, false, false, 100000);
  field.isolation = 0;
  const smoothUnion = (a: number, b: number, k: number) => {
    if (k < .0001) return Math.min(a, b);
    const h = THREE.MathUtils.clamp(.5 + .5 * (b - a) / k, 0, 1);
    return THREE.MathUtils.lerp(b, a, h) - k * h * (1 - h);
  };
  for (let iz = 0; iz < size; iz++) for (let iy = 0; iy < size; iy++) for (let ix = 0; ix < size; ix++) {
    const x = (ix / size * 2 - 1) * .44, y = 2.09 + (iy / size * 2 - 1) * .34, z = (iz / size * 2 - 1) * .33;
    const waist = (Math.sqrt((x / .353) ** 2 + ((y - 2.17) / .193) ** 2 + (z / .197) ** 2) - 1) * .19;
    const legDistance = (side: number) => {
      const localX = x - side * .182;
      const fold = .0018 * Math.sin(z * 39 + y * 27 + side) + .001 * Math.sin(localX * 63 - y * 20);
      const tuckedWaist = 1 - .15 * THREE.MathUtils.smoothstep(y, 2.14, 2.24);
      // A broad, continuous seat follows the pelvis. The old narrow rear
      // Gaussian plus a hard waist clamp formed a shelf in the side view.
      const seat = .019 * Math.exp(-(((y-2.07)/.21)**2));
      const centerZ = .041 - seat * .35;
      const radial = (Math.sqrt((localX / (.184 * tuckedWaist)) ** 2 + ((z-centerZ) / ((.215+seat) * tuckedWaist)) ** 2) - 1) * .175 + fold*.6;
      const hem = 1.842 + THREE.MathUtils.clamp(.5+side*localX/.362,0,1) ** 1.6 * .065 + .06 * (z-.02) + .003 * Math.sin(z * 10 + side);
      return Math.max(radial, hem - y, y - 2.246);
    };
    const join = .072 * THREE.MathUtils.smoothstep(y, 1.86, 2.10);
    const frontPanel=(Math.sqrt((x/.15)**2+((y-2.085)/.175)**2+((z-.075)/.175)**2)-1)*.15;
    const clothDistance = smoothUnion(smoothUnion(smoothUnion(legDistance(-1), legDistance(1), join), waist, .046),frontPanel,.026);
    field.field[ix + iy * size + iz * size * size] = -clothDistance;
  }
  field.update();
  const count = field.geometry.drawRange.count, geometry = new THREE.BufferGeometry();
  const sourcePositions = field.geometry.getAttribute('position'), sourceNormals = field.geometry.getAttribute('normal');
  const positions = new Float32Array(count * 3), normals = new Float32Array(count * 3), uv = new Float32Array(count * 2), indices: number[] = [], weights: number[] = [];
  const normal = new THREE.Vector3();
  for (let i = 0; i < count; i++) {
    let x = sourcePositions.getX(i) * .44, z = sourcePositions.getZ(i) * .33;
    const y = 2.09 + sourcePositions.getY(i) * .34;
    z += .085 * THREE.MathUtils.smoothstep(y, 1.985, 2.16);
    // The upper waist must fit beneath the shirt as one combined surface, not
    // merely as two narrower trouser legs. Reserve space for the torso's sway.
    if (y > 2.095) {
      const t = THREE.MathUtils.clamp((y - 2.17) / .18, 0, 1);
      const rx = THREE.MathUtils.lerp(.368, .344, t), rz = THREE.MathUtils.lerp(.235, .217, t);
      const waistCenter = .04 + .085 * THREE.MathUtils.smoothstep(y, 1.985, 2.16);
      const radial = Math.hypot(x / rx, (z-waistCenter) / rz);
      if (radial > 1) {
        const blend = THREE.MathUtils.smoothstep(y, 2.095, 2.22);
        const scale = THREE.MathUtils.lerp(1, 1 / radial, blend); x *= scale; z = waistCenter + (z-waistCenter)*scale;
      }
    }
    positions.set([x, y, z], i * 3);
    normal.set(sourceNormals.getX(i) / .44, sourceNormals.getY(i) / .34, sourceNormals.getZ(i) / .33).normalize(); normals.set(normal.toArray(), i * 3);
    uv.set([(x + .44) / .88, (y - 1.75) / .68], i * 2);
    const amount = 1 - THREE.MathUtils.smoothstep(y, 2.045, 2.22), right = THREE.MathUtils.smoothstep(x, -.075, .075);
    indices.push(0, 1, 2, 0); weights.push(1 - amount, amount * (1 - right), amount * right, 0);
  }
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3)); geometry.setAttribute('normal', new THREE.BufferAttribute(normals, 3)); geometry.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  geometry.setAttribute('skinIndex', new THREE.Uint16BufferAttribute(indices, 4)); geometry.setAttribute('skinWeight', new THREE.Float32BufferAttribute(weights, 4));
  field.geometry.dispose();
  geometry.deleteAttribute('normal');
  const joinedGeometry = mergeVertices(geometry, .000001); joinedGeometry.computeVertexNormals(); geometry.dispose();
  const shorts = new THREE.SkinnedMesh(joinedGeometry, cloth); shorts.name = 'dbh-tailored-shorts'; shorts.userData.unbatched = true; shorts.castShadow = shorts.receiveShadow = true; shorts.frustumCulled = false;
  const waistBone = new THREE.Bone(); shorts.add(waistBone); parent.add(shorts); parent.updateWorldMatrix(true, true);
  shorts.bind(new THREE.Skeleton([waistBone, ...legs]));
  // Thin rolled hems follow an analytic curve, avoiding a voxel-stepped cuff edge.
  const hemMaterial=(cloth as THREE.MeshStandardMaterial).clone(); hemMaterial.color.set('#e1e1e1');
  for(let index=0;index<2;index++){
    const side=index===0?-1:1;
    const hem=Array.from({length:80},(_,i)=>{
      const angle=i/80*Math.PI*2,dx=Math.sin(angle)*.184,z=Math.cos(angle)*.223+.038;
      const y=1.842+THREE.MathUtils.clamp(.5+side*dx/.362,0,1)**1.6*.065+.06*(z-.02)+.003*Math.sin(z*10+side)+.005;
      return point(dx+side*.182,y,z);
    });
    const cuffGeometry = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(hem,true),80,.005,6,true);
    const cuffPosition=cuffGeometry.getAttribute('position'), cuffIndices:number[]=[], cuffWeights:number[]=[];
    for(let vertex=0;vertex<cuffPosition.count;vertex++){
      const x=cuffPosition.getX(vertex),y=cuffPosition.getY(vertex);
      const amount=1-THREE.MathUtils.smoothstep(y,2.045,2.22),right=THREE.MathUtils.smoothstep(x,-.075,.075);
      cuffIndices.push(0,1,2,0);cuffWeights.push(1-amount,amount*(1-right),amount*right,0);
    }
    cuffGeometry.setAttribute('skinIndex',new THREE.Uint16BufferAttribute(cuffIndices,4));
    cuffGeometry.setAttribute('skinWeight',new THREE.Float32BufferAttribute(cuffWeights,4));
    const cuff=new THREE.SkinnedMesh(cuffGeometry,hemMaterial);cuff.name='dbh-soft-shorts-hem';
    cuff.userData.unbatched=true;cuff.frustumCulled=false;cuff.castShadow=cuff.receiveShadow=true;
    parent.add(cuff);parent.updateWorldMatrix(true,true);cuff.bind(new THREE.Skeleton([waistBone,...legs]));
  }
  return shorts;
}

/** The foot and toes are one sculpted surface; fitted leather bands are sampled above that surface. */
export function createDbhFoot(parent: THREE.Group, skin: THREE.Material, nail: THREE.Material, sole: THREE.Material, leather: THREE.Material, side: number) {
  const toes = [
    { x: -.071, z: .301, rx: .029, ry: .024, rz: .043 }, { x: -.02, z: .307, rx: .023, ry: .022, rz: .042 },
    { x: .023, z: .299, rx: .021, ry: .021, rz: .038 }, { x: .06, z: .286, rx: .018, ry: .019, rz: .035 },
    { x: .089, z: .271, rx: .015, ry: .017, rz: .03 },
  ];
  const ellipsoidDistance = (x: number, y: number, z: number, cx: number, cy: number, cz: number, rx: number, ry: number, rz: number) => (Math.sqrt(((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 + ((z - cz) / rz) ** 2) - 1) * Math.min(rx, ry, rz);
  const join = (a: number, b: number, k: number) => { const h = THREE.MathUtils.clamp(.5 + .5 * (b - a) / k, 0, 1); return THREE.MathUtils.lerp(b, a, h) - k * h * (1 - h); };
  const distance = (x: number, y: number, z: number) => {
    let d = ellipsoidDistance(x, y, z, 0, .145, -.051, .069, .048, .075);
    d = join(d, ellipsoidDistance(x, y, z, 0, .208, -.012, .062, .110, .073), .032);
    d = join(d, ellipsoidDistance(x, y, z, 0, .159, .085, .083, .094, .138), .031);
    d = join(d, ellipsoidDistance(x, y, z, side * -.003, .13, .104, .096, .05, .184), .015);
    d = join(d, ellipsoidDistance(x, y, z, 0, .126, .222, .108, .038, .077), .012);
    for (const toe of toes) d = join(d, ellipsoidDistance(x, y, z, toe.x * side, .124, toe.z, toe.rx, toe.ry, toe.rz), .006);
    return Math.max(d, .093 - y);
  };
  const resolution = 62, field = new MarchingCubes(resolution, skin, false, false, 24000); field.isolation = 0;
  for (let iz = 0; iz < resolution; iz++) for (let iy = 0; iy < resolution; iy++) for (let ix = 0; ix < resolution; ix++) {
    const x = (ix / resolution * 2 - 1) * .142, y = .192 + (iy / resolution * 2 - 1) * .112, z = .103 + (iz / resolution * 2 - 1) * .264;
    field.field[ix + iy * resolution + iz * resolution * resolution] = -distance(x, y, z);
  }
  field.update();
  const count = field.geometry.drawRange.count, position = field.geometry.getAttribute('position'), normalSource = field.geometry.getAttribute('normal');
  const vertices = new Float32Array(count * 3), normals = new Float32Array(count * 3), uvs = new Float32Array(count * 2), normal = new THREE.Vector3();
  for (let i = 0; i < count; i++) {
    const x = position.getX(i) * .142, y = .192 + position.getY(i) * .112, z = .103 + position.getZ(i) * .264;
    vertices.set([x, y, z], i * 3); normal.set(normalSource.getX(i) / .142, normalSource.getY(i) / .112, normalSource.getZ(i) / .264).normalize(); normals.set(normal.toArray(), i * 3); uvs.set([x / .284 + .5, z / .528 + .3], i * 2);
  }
  const footGeometry = new THREE.BufferGeometry(); footGeometry.setAttribute('position', new THREE.BufferAttribute(vertices, 3)); footGeometry.setAttribute('normal', new THREE.BufferAttribute(normals, 3)); footGeometry.setAttribute('uv', new THREE.BufferAttribute(uvs, 2)); field.geometry.dispose();
  mesh(parent, footGeometry, skin).name = 'dbh-sculpted-foot-and-toes';
  for (const toe of toes) ellipsoid(parent, nail, point(toe.x * side, .123 + toe.ry, toe.z + .012), point(toe.rx * .61, .0014, toe.rz * .38), 20);

  const outline = [point(-.07, -.139, 0), point(-.097, -.111, 0), point(-.105, -.028, 0), point(-.113, .14, 0), point(-.122, .267, 0), point(-.102, .338, 0), point(-.054, .364, 0), point(.016, .356, 0), point(.086, .325, 0), point(.121, .266, 0), point(.109, .134, 0), point(.088, -.089, 0), point(.057, -.136, 0)];
  const outlineCurve = new THREE.CatmullRomCurve3(outline, true), contour = outlineCurve.getPoints(72).map(p => new THREE.Vector2(p.x * side, p.y));
  const footprint = new THREE.Shape(contour);
  const soleGeometry = new THREE.ExtrudeGeometry(footprint, { depth: .055, bevelEnabled: true, bevelSize: .006, bevelThickness: .007, bevelSegments: 4, steps: 1 });
  const solePosition = soleGeometry.getAttribute('position');
  for(let i=0;i<solePosition.count;i++){
    const forefoot = THREE.MathUtils.smoothstep(solePosition.getY(i),.04,.3);
    const lower = THREE.MathUtils.smoothstep(solePosition.getZ(i),.014,.05);
    solePosition.setZ(i,solePosition.getZ(i)-.017*forefoot*lower);
  }
  soleGeometry.computeVertexNormals();
  const bottom = mesh(parent, soleGeometry, sole, point(0, .07, 0)); bottom.rotation.x = Math.PI / 2;
  const bed = mesh(parent, new THREE.ExtrudeGeometry(footprint, { depth: .009, bevelEnabled: true, bevelSize: .003, bevelThickness: .004, bevelSegments: 2, steps: 1 }), leather, point(0, .089, 0), point(.967, .967, 1)); bed.rotation.x = Math.PI / 2;
  const surface = (x: number, z: number) => {
    let upper = .325;
    for (let y = .319; y >= .093; y -= .006) {
      if (distance(x, y, z) < 0) {
        let lower = y;
        for (let i = 0; i < 8; i++) { const mid = (upper + lower) / 2; if (distance(x, mid, z) < 0) lower = mid; else upper = mid; }
        return (upper + lower) / 2;
      }
      upper = y;
    }
    return .092;
  };
  for (const [centerZ, width] of [[.232, .052], [.112, .049]]) {
    const cols = 80, rows = 12, vertices: number[] = [], uvs: number[] = [], indices: number[] = [];
    for (let layer = 0; layer < 2; layer++) for (let row = 0; row <= rows; row++) for (let col = 0; col <= cols; col++) {
      const x = -.127 + col / cols * .254, z = centerZ + (row / rows - .5) * width + x * side * .08;
      // Carry the band past the skin's steep lateral edge before turning down to
      // the sole. Sampling that edge directly makes a chord cut through the foot.
      const core = surface(THREE.MathUtils.clamp(x, -.091, .091), z) + (layer ? .013 : .02);
      const y = THREE.MathUtils.lerp(core, layer ? .091 : .098, THREE.MathUtils.smoothstep(Math.abs(x), .1, .127));
      vertices.push(x, y, z); uvs.push(col / cols, row / rows);
    }
    const layerSize = (rows + 1) * (cols + 1);
    for (let layer = 0; layer < 2; layer++) for (let row = 0; row < rows; row++) for (let col = 0; col < cols; col++) {
      const a = layer * layerSize + row * (cols + 1) + col, b = a + 1, c = a + cols + 1, d = c + 1;
      if (layer) indices.push(a, b, c, b, d, c); else indices.push(a, c, b, b, c, d);
    }
    for (let col = 0; col < cols; col++) for (const row of [0, rows]) {
      const a = row * (cols + 1) + col, b = a + 1;
      if (row === 0) indices.push(a, b, a + layerSize, b, b + layerSize, a + layerSize);
      else indices.push(a, a + layerSize, b, b, a + layerSize, b + layerSize);
    }
    for (let row = 0; row < rows; row++) for (const col of [0, cols]) {
      const a = row * (cols + 1) + col, b = a + cols + 1;
      if (col === 0) indices.push(a, a + layerSize, b, b, a + layerSize, b + layerSize);
      else indices.push(a, b, a + layerSize, b, b + layerSize, a + layerSize);
    }
    const geometry = new THREE.BufferGeometry(); geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3)); geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2)); geometry.setIndex(indices); geometry.computeVertexNormals();
    mesh(parent, geometry, leather).name = 'dbh-fitted-leather-sandal-band';
  }
}
