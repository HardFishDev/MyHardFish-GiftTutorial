import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import type { Place } from './scene';
import { OUTDOOR_PLACES } from './world-layout';

/** Decorative motion costs one particle draw, plus four pond rings in the park. */
export class WorldAtmosphere {
  readonly root=new THREE.Group();
  private particles:THREE.Points;
  private data:Float32Array;
  private origins:Float32Array;
  private sprite:THREE.CanvasTexture;
  private rings:THREE.Mesh[]=[];
  private clouds:THREE.Mesh[]=[];
  private chime:THREE.Group|undefined;
  constructor(private place:Place) {
    const canvas=document.createElement('canvas');canvas.width=canvas.height=32;
    const ctx=canvas.getContext('2d')!,g=ctx.createRadialGradient(16,16,0,16,16,15);
    g.addColorStop(0,'rgba(255,255,255,.75)');g.addColorStop(.3,'rgba(255,255,255,.35)');g.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=g;ctx.fillRect(0,0,32,32);this.sprite=new THREE.CanvasTexture(canvas);
    const outdoor=OUTDOOR_PLACES.includes(place),spread=place==='village'?32:place==='park'?14:24;
    const count=outdoor?72:place==='kitchen'?20:32;
    this.data=new Float32Array(count*3);this.origins=new Float32Array(count*3);
    for(let i=0;i<count;i++){
      const a=i*2.399,f=(i*.61803398875)%1;
      if(place==='kitchen')this.origins.set([-7.26+Math.sin(a)*.16,2.17+f*1.1,-9.28+Math.cos(a)*.16],i*3);
      else if(outdoor)this.origins.set([Math.sin(a)*(3+f*spread),.3+((i*.381)%1)*4.8,Math.cos(a)*(4+f*spread)],i*3);
      else this.origins.set([-8+f*9,1.3+((i*.381)%1)*4.0,-8+((i*.723)%1)*9],i*3);
    }
    this.data.set(this.origins);
    const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(this.data,3));
    this.particles=new THREE.Points(geometry,new THREE.PointsMaterial({color:outdoor?'#f4e3ae':'#fff3d8',size:place==='kitchen'?.36:.08,transparent:true,opacity:place==='kitchen'?.22:.38,map:this.sprite,depthWrite:false,sizeAttenuation:true}));this.particles.frustumCulled=false;this.root.add(this.particles);
    if(place==='park'||place==='river'){
      for(let i=0;i<4;i++){
        const ring=new THREE.Mesh(new THREE.RingGeometry(.73,.746,48),new THREE.MeshBasicMaterial({color:'#d7e7d6',transparent:true,opacity:.3,depthWrite:false,side:THREE.DoubleSide}));
        ring.rotation.x=-Math.PI/2;ring.position.set(place==='river'?8+(i%2)*4:-7.7+(i%2)*3.6,place==='river'?.045:.083,place==='river'?10+Math.floor(i/2)*7:-7.25+Math.floor(i/2)*4.3);this.rings.push(ring);this.root.add(ring);
      }
    }
    if(outdoor){
      const cloudMaterial=new THREE.MeshBasicMaterial({color:'#ebeedc',transparent:true,opacity:.72,depthWrite:false});
      for(let i=0;i<3;i++){
        const pieces:THREE.BufferGeometry[]=[];
        for(let n=0;n<5;n++){const geometry=new THREE.SphereGeometry(1,12,8);geometry.scale(2.0+n%2,.8+(n%2)*.3,1.05);geometry.translate((n-2)*1.65,Math.sin(n)*.3,Math.cos(n)*.2);pieces.push(geometry);}
        const geometry=mergeGeometries(pieces)!;pieces.forEach(g=>g.dispose());const cloud=new THREE.Mesh(geometry,cloudMaterial);cloud.position.set(-19+i*17,13+i*1.7,-30-i*9);cloud.userData.startX=cloud.position.x;this.clouds.push(cloud);this.root.add(cloud);
      }
    }
    if(place==='home'){
      this.chime=new THREE.Group();this.chime.position.set(10.47,3.9,-1.72);this.root.add(this.chime);
      const material=new THREE.MeshStandardMaterial({color:'#b9a777',metalness:.45,roughness:.36});
      const top=new THREE.Mesh(new THREE.CylinderGeometry(.18,.18,.045,18),material);this.chime.add(top);
      for(let i=0;i<4;i++){const a=i*Math.PI/2,rod=new THREE.Mesh(new THREE.CylinderGeometry(.021,.021,.45+i*.075,10),material);rod.position.set(Math.sin(a)*.12,-.45-i*.03,Math.cos(a)*.12);this.chime.add(rod);}
      const line=new THREE.Mesh(new THREE.CylinderGeometry(.005,.005,.8,5),new THREE.MeshBasicMaterial({color:'#827858'}));line.position.y=-.4;this.chime.add(line);
      const sail=new THREE.Mesh(new THREE.PlaneGeometry(.13,.28),new THREE.MeshStandardMaterial({color:'#ebe0bd',side:THREE.DoubleSide}));sail.position.y=-.89;this.chime.add(sail);
    }
  }
  update(time:number,reduced:boolean,lowQuality:boolean) {
    this.root.visible=!lowQuality;
    if(lowQuality||reduced)return;
    for(let i=0;i<this.data.length/3;i++){
      const j=i*3;
      this.data[j]=this.origins[j]+Math.sin(time*.25+i)*.22;
      this.data[j+2]=this.origins[j+2]+Math.cos(time*.20+i*.3)*.17;
      this.data[j+1]=this.place==='kitchen'?2.13+((this.origins[j+1]-2.13+time*.19)%1.18):this.origins[j+1]+Math.sin(time*.31+i*.7)*.13;
    }
    this.particles.geometry.getAttribute('position').needsUpdate=true;
    for(let i=0;i<this.rings.length;i++){
      const progress=(time*.18+i*.27)%1;this.rings[i].scale.setScalar(.3+progress*1.8);(this.rings[i].material as THREE.MeshBasicMaterial).opacity=Math.sin(progress*Math.PI)*.25;
    }
    for(let i=0;i<this.clouds.length;i++)this.clouds[i].position.x=this.clouds[i].userData.startX+Math.sin(time*.013+i)*4;
    if(this.chime){this.chime.rotation.z=Math.sin(time*1.3)*.047;this.chime.rotation.x=Math.sin(time*.8)*.032;}
  }
  dispose(){
    const materials=new Set<THREE.Material>();
    this.root.traverse(object=>{if(object instanceof THREE.Mesh||object instanceof THREE.Points){object.geometry.dispose();const list=Array.isArray(object.material)?object.material:[object.material];list.forEach(material=>materials.add(material));}});
    materials.forEach(material=>material.dispose());this.sprite.dispose();this.root.removeFromParent();this.root.clear();
  }
}
