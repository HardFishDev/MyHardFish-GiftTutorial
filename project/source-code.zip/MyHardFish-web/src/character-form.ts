import * as THREE from 'three';
import { MarchingCubes } from 'three/addons/objects/MarchingCubes.js';
import { mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';

/** Analytic sculpt based on the supplied three-view reference, in metres. */
export const FORM = { height: 3.55, hipX: .46, hipY: .73, eyeX: .385, eyeY: 3.205, mouthY: 2.19 };
const clamp = THREE.MathUtils.clamp;
function ellipsoid(x:number,y:number,z:number,cx:number,cy:number,cz:number,rx:number,ry:number,rz:number) {
  x-=cx;y-=cy;z-=cz;
  const k0=Math.hypot(x/rx,y/ry,z/rz),k1=Math.hypot(x/(rx*rx),y/(ry*ry),z/(rz*rz));
  return k0<1e-8?-Math.min(rx,ry,rz):k0*(k0-1)/k1;
}
function union(a:number,b:number,k:number) {
  const h=clamp(.5+.5*(b-a)/k,0,1);
  return THREE.MathUtils.lerp(b,a,h)-k*h*(1-h);
}
function subtract(shape:number,cutter:number,k:number) {return -union(-shape,cutter,k);}

/** Signed distance also makes the rig's clearance checks reproducible on CPU. */
export function characterDistance(x:number,y:number,z:number,face=true):number {
  let d=ellipsoid(x,y,z,0,1.91,-.015,.65,1.12,.37);
  d=union(d,ellipsoid(x,y,z,0,2.65,-.015,.485,.74,.325),.24);
  for(let side=-1;side<=1;side+=2) {
    d=union(d,ellipsoid(x,y,z,side*.282,3.158,-.025,.45,.392,.39),.135);
    d=union(d,ellipsoid(x,y,z,side*.46,.97,-.015,.208,.411,.274),.28);
  }
  // A rounded arch separates the white leg tips all the way through the back.
  d=subtract(d,ellipsoid(x,y,z,0,.255,0,.405,.89,1.4),.055);
  if(!face)return d;
  // Nose bridge and tip are blended into the same porcelain surface.
  d=union(d,ellipsoid(x,y,z,-.005,2.59,.341,.073,.33,.083),.135);
  d=union(d,ellipsoid(x,y,z,-.005,2.385,.401,.085,.115,.090),.080);
  for(let side=-1;side<=1;side+=2) {
    const ex=side*FORM.eyeX;
    // Soft lids/ridge are porcelain. Only the small inset eyeball is black.
    d=union(d,ellipsoid(x,y,z,ex,3.269,.326,.157,.044,.067),.055);
    d=subtract(d,ellipsoid(x,y,z,ex,FORM.eyeY,.355,.141,.090,.078),.030);
  }
  return d;
}

export function frontSurface(x:number,y:number,offset=0):number {
  let previous=1.0;
  // Scan before bisecting: the nose and shallow eye sockets are non-convex.
  for(let z=.975;z>=-.5;z-=.025) {
    if(characterDistance(x,y,z)<=0) {
      let lo=z,hi=previous;
      for(let i=0;i<12;i++){const mid=(lo+hi)*.5;if(characterDistance(x,y,mid)<=0)lo=mid;else hi=mid;}
      return (lo+hi)*.5+offset;
    }
    previous=z;
  }
  return offset;
}

export function sectionPoint(y:number,angle:number,offset=0,target=new THREE.Vector3()):THREE.Vector3 {
  const sx=Math.sin(angle),sz=Math.cos(angle);let lo=0,hi=1.2;
  for(let i=0;i<22;i++){const r=(lo+hi)*.5;if(characterDistance(sx*r,y,sz*r,false)<=0)lo=r;else hi=r;}
  return target.set(sx*(lo+offset),y,sz*(lo+offset));
}

function isoGeometry(resolution:number,bounds:[number,number,number,number,number,number],field:(x:number,y:number,z:number)=>number) {
  const placeholder=new THREE.MeshBasicMaterial();
  const cubes=new MarchingCubes(resolution,placeholder,false,false,75000);
  cubes.isolation=0;
  const [minX,maxX,minY,maxY,minZ,maxZ]=bounds;
  const sx=(maxX-minX)/2,sy=(maxY-minY)/2,sz=(maxZ-minZ)/2;
  const ox=(maxX+minX)/2,oy=(maxY+minY)/2,oz=(maxZ+minZ)/2;
  let i=0;
  for(let z=0;z<resolution;z++)for(let y=0;y<resolution;y++)for(let x=0;x<resolution;x++)
    cubes.field[i++]=-field(minX+(maxX-minX)*x/resolution,minY+(maxY-minY)*y/resolution,minZ+(maxZ-minZ)*z/resolution);
  cubes.update();
  const count=cubes.count;
  const geometry=new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.BufferAttribute(cubes.positionArray.slice(0,count*3),3));
  geometry.setAttribute('normal',new THREE.BufferAttribute(cubes.normalArray.slice(0,count*3),3));
  geometry.scale(sx,sy,sz);geometry.translate(ox,oy,oz);
  // The iso-surface is static. Index coincident vertices once, never per frame.
  const indexed=mergeVertices(geometry,1e-5);
  geometry.dispose();cubes.geometry.dispose();placeholder.dispose();
  indexed.computeBoundingBox();indexed.computeBoundingSphere();
  return indexed;
}

export function createBodyGeometry(low=false) {
  const g=isoGeometry(low?56:86,[-.95,.95,.38,3.68,-.64,.76],characterDistance);
  const p=g.getAttribute('position');const left=new Float32Array(p.count*3),right=new Float32Array(p.count*3);
  for(let i=0;i<p.count;i++) {
    const x=p.getX(i),y=p.getY(i),weight=clamp((1.36-y)/.72,0,1)**1.4;
    const a=x<0?right:left;a[i*3+2]=weight*.28;
  }
  g.morphAttributes.position=[new THREE.BufferAttribute(left,3),new THREE.BufferAttribute(right,3)];
  g.morphTargetsRelative=true;
  return g;
}

export function createFootGeometry() {
  const g=isoGeometry(38,[-.22,.22,-.06,.41,-.18,.46],(x,y,z)=>union(
    ellipsoid(x,y,z,0,.105,.13,.125,.105,.267),
    ellipsoid(x,y,z,0,.228,-.013,.077,.16,.087),.057));
  const bottom=g.boundingBox!.min.y;g.translate(0,-bottom,0);g.computeBoundingBox();
  return g;
}
