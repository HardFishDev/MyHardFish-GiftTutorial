import * as THREE from 'three';

export type CharacterActivityKind = 'sit'|'read'|'cook'|'water'|'shop'|'play'|'write'|'inspect'|'talk'|'celebrate'|'eat';
export type CharacterActivityProp = 'book'|'food'|'cup'|'spatula'|'wateringCan'|'bag'|'ball'|'pencil'|'magnifier'|'lantern'|'none';
export type CharacterFood = 'bun'|'milk'|'peach'|'rice'|'coffee';
/** Positions and heights are unscaled character-root local coordinates (+Z front). */
export interface CharacterActivityContext {
  kind: CharacterActivityKind;
  seated?: boolean;
  seatHeight?: number;
  surfaceHeight?: number;
  target?: [number,number,number];
  prop?: CharacterActivityProp;
  food?: CharacterFood;
}
export type CharacterActivity = CharacterActivityContext;
export const ACTIVITY_KINDS: readonly CharacterActivityKind[] = ['sit','read','cook','water','shop','play','write','inspect','talk','celebrate','eat'];
export const DEFAULT_ACTIVITY_PROP: Record<CharacterActivityKind,CharacterActivityProp> = {
  sit:'none',read:'book',cook:'spatula',water:'wateringCan',shop:'bag',play:'ball',write:'pencil',inspect:'magnifier',talk:'none',celebrate:'none',eat:'food',
};
// Midpoint of the two supporting thighs. The seated mesh's lower surface is
// about y=.88; a small clearance keeps the porcelain clear of the seat plane.
export const SEAT_CONTACT = [0,.87,.10] as const;

/** Bend the white leg continuations forward about the pelvis, with a smooth waist. */
export function seatedLegPoint(x:number,y:number,z:number,target:THREE.Vector3) {
  const f=THREE.MathUtils.smoothstep(1.45-y,0,.49),angle=f*Math.PI*.415;
  const dy=y-1.24,dz=z+.015;
  return target.set(x,1.24+dy*Math.cos(angle)+dz*Math.sin(angle),-.015-dy*Math.sin(angle)+dz*Math.cos(angle));
}

/** One cached sitting shape per LOD; no vertex allocations during animation. */
export function addSeatedMorph(geometry:THREE.BufferGeometry) {
  const positions=geometry.getAttribute('position'),normals=geometry.getAttribute('normal');
  const offset=new Float32Array(positions.count*3),shape=new Float32Array(positions.count*3),p=new THREE.Vector3();
  for(let i=0;i<positions.count;i++) {
    const x=positions.getX(i),y=positions.getY(i),z=positions.getZ(i);
    seatedLegPoint(x,y,z,p);
    shape.set([p.x,p.y,p.z],i*3);offset.set([p.x-x,p.y-y,p.z-z],i*3);
  }
  (geometry.morphAttributes.position??=[]).push(new THREE.BufferAttribute(offset,3));
  const posed=geometry.clone();posed.setAttribute('position',new THREE.BufferAttribute(shape,3));posed.computeVertexNormals();
  const posedNormals=posed.getAttribute('normal'),normalOffset=new Float32Array(normals.count*3);
  for(let i=0;i<normals.count;i++)for(let axis=0;axis<3;axis++)normalOffset[i*3+axis]=posedNormals.array[i*3+axis]-normals.array[i*3+axis];
  geometry.morphAttributes.normal=[new THREE.BufferAttribute(new Float32Array(normals.count*3),3),new THREE.BufferAttribute(new Float32Array(normals.count*3),3),new THREE.BufferAttribute(normalOffset,3)];
  geometry.boundingSphere!.radius+=.8;
  posed.dispose();
  return geometry;
}
