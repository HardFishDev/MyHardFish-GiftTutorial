import { useEffect, useRef, useState } from 'react';
import { ArrowClockwise, ArrowCounterClockwise, Bicycle, Camera, Heart, Pause, Play, Trophy, ShareNetwork, SlidersHorizontal, Check } from '@phosphor-icons/react';
import { CyclingScene } from './cycling-scene';
import { createCyclingState, startCycling, steerCycling, stepCycling, cyclingReward, CYCLING_LENGTH, CYCLING_DIFFICULTIES, getCyclingDifficulty } from './cycling';
import type { CyclingCamera, CyclingDifficulty } from './cycling';
import type { NanyuOutfit } from './character';
import './cycling.css';
import { CyclingAudio } from './cycling-audio';
import CyclingControlSettings from './CyclingControlSettings';
import CyclingTouchControls from './CyclingTouchControls';
import SceneTransitionIndicator from './SceneTransitionIndicator';
import { waitForScenePaint } from './scene-transition';
import { loadCyclingControlPreferences, saveCyclingControlPreferences, normalizeCyclingControlPreferences, cyclingKeyCode, cyclingKeyLabel, matchCyclingControlAction } from './cycling-controls';
import type { CyclingTouchPreferences } from './cycling-controls';

const cameras: { id: CyclingCamera; label: string }[] = [
  { id: 'follow', label: '跟随视角' }, { id: 'overhead', label: '俯视视角' }, { id: 'side', label: '侧后视角' },
];

export interface CyclingGameProps {
  onStart: (difficulty?: CyclingDifficulty) => boolean;
  onFinish: (score: number) => void;
  lowQuality?: boolean;
  outfit?: NanyuOutfit;
  voiceEnabled?: boolean;
  voiceVolume?: number;
  effectsEnabled?: boolean;
  onReady?: () => void;
  onExit?: () => void;
}

export default function CyclingGame({ onStart, onFinish, lowQuality = false, outfit = 'classic', voiceEnabled = true, voiceVolume = .75, effectsEnabled = true, onReady }: CyclingGameProps) {
  const [difficulty, setDifficulty] = useState<CyclingDifficulty>('normal');
  const config = getCyclingDifficulty(difficulty);
  const difficultyRef = useRef(difficulty); difficultyRef.current = difficulty;
  const [routeRequest, setRouteRequest] = useState(0);
  const [preferences, setPreferences] = useState(loadCyclingControlPreferences);
  const preferencesRef = useRef(preferences); preferencesRef.current = preferences;
  const [draft, setDraft] = useState(preferences);
  const [settingsMode, setSettingsMode] = useState<'closed' | 'sheet' | 'layout'>('closed');
  const settingsRef = useRef(settingsMode);
  const layoutBefore = useRef<CyclingTouchPreferences>(preferences.touch);
  const layoutPanel = useRef<HTMLDivElement>(null);
  const [layoutValid, setLayoutValid] = useState(true);
  const [settingsNotice, setSettingsNotice] = useState('');
  const [sceneLoading, setSceneLoading] = useState(true);
  const readyRef = useRef(false);
  const audioReady = useRef(false);
  const [effects, setEffects] = useState(effectsEnabled);
  const [voice, setVoice] = useState(voiceEnabled);
  const sound = useRef<CyclingAudio | null>(null);
  const lastEvent = useRef(0);
  const readyCallback = useRef(onReady); readyCallback.current = onReady;
  const [shareStatus, setShareStatus] = useState('');
  const [shareFallback, setShareFallback] = useState('');
  const shareInput = useRef<HTMLInputElement>(null);
  const shareTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const [snapshot, setSnapshot] = useState(() => createCyclingState());
  const run = useRef(snapshot);
  const [camera, setCamera] = useState<CyclingCamera>('follow');
  const cameraRef = useRef(camera);
  const [paused, setPaused] = useState(false);
  const pausedRef = useRef(false);
  const [braking, setBraking] = useState(false);
  const brakingRef = useRef(false);
  const brakeSources = useRef(new Set<string>());
  const [ready, setReady] = useState(false);
  const [error, setError] = useState('');
  const failed = useRef(false);
  const [startError, setStartError] = useState('');
  const host = useRef<HTMLDivElement>(null);
  const root = useRef<HTMLDivElement>(null);
  const scene = useRef<CyclingScene | null>(null);
  const claimed = useRef(false);
  const finish = useRef(onFinish);
  finish.current = onFinish;
  function canControl() { return readyRef.current && !failed.current && !scene.current?.transitioning && settingsRef.current === 'closed'; }
  function markReady(value: boolean) { readyRef.current = value; setReady(value); }
  function clearBrake() { brakeSources.current.clear(); brakingRef.current = false; setBraking(false); }
  function setBrakeSource(source: string, active: boolean) {
    if (active) {
      if (!canControl() || pausedRef.current || run.current.phase !== 'riding') return;
      brakeSources.current.add(source);
    } else brakeSources.current.delete(source);
    brakingRef.current = brakeSources.current.size > 0; setBraking(brakingRef.current);
  }
  function selectCamera(value: CyclingCamera) {
    if (!canControl()) return;
    scene.current?.resetCamera(); cameraRef.current = value; setCamera(value);
  }
  function pause(value: boolean) {
    if (!value && !canControl()) return;
    pausedRef.current = value; setPaused(value);
    if (value) sound.current?.pause(); else sound.current?.unlock();
    setSnapshot(run.current); clearBrake();
  }
  function steer(direction: -1 | 1) {
    if (pausedRef.current || !canControl()) return;
    run.current = steerCycling(run.current, direction); setSnapshot(run.current);
  }
  function changeSettingsMode(value: typeof settingsMode) { settingsRef.current = value; setSettingsMode(value); }
  function openSettings() {
    if (run.current.phase === 'riding') pause(true);
    clearBrake(); setDraft(normalizeCyclingControlPreferences(preferencesRef.current));
    setSettingsNotice(''); changeSettingsMode('sheet');
  }
  function closeSettings() { clearBrake(); changeSettingsMode('closed'); requestAnimationFrame(() => root.current?.focus({ preventScroll: true })); }
  function cancelLayout() { setDraft(value => ({ ...value, touch: layoutBefore.current })); changeSettingsMode('sheet'); }
  function saveSettings() {
    const next = normalizeCyclingControlPreferences(draft);
    preferencesRef.current = next; setPreferences(next);
    try { saveCyclingControlPreferences(next); setSettingsNotice(''); }
    catch { setSettingsNotice('设置已应用，但浏览器未允许保存；刷新页面后可能恢复默认。'); }
    closeSettings();
  }
  function start() {
    if (!canControl() || run.current.phase === 'riding') return;
    if (!onStart(difficultyRef.current)) { setStartError('精力不足，回村休息后再来骑一圈。'); return; }
    claimed.current = false; setStartError(''); pause(false); lastEvent.current = 0;
    run.current = startCycling(createCyclingState(undefined, difficultyRef.current)); setSnapshot(run.current);
    root.current?.focus({ preventScroll: true });
  }
  function chooseDifficulty(value: CyclingDifficulty) {
    if (run.current.phase === 'riding' || settingsRef.current !== 'closed' || failed.current) return;
    markReady(false); setSceneLoading(true); clearBrake();
    run.current = createCyclingState(undefined, value); setSnapshot(run.current);
    lastEvent.current = 0; setStartError(''); difficultyRef.current = value; setDifficulty(value);
    setRouteRequest(value => value + 1);
  }
  async function share() {
    const link = new URL(location.href); link.search = ''; link.hash = 'cycling';
    clearTimeout(shareTimer.current); setShareFallback('');
    try {
      if (!navigator.clipboard?.writeText) throw new Error('Clipboard unavailable');
      await navigator.clipboard.writeText(link.href);
      setShareStatus('直链已复制');
      shareTimer.current = setTimeout(() => setShareStatus(''), 3500);
    } catch {
      setShareFallback(link.href); setShareStatus('请复制下方直链');
    }
  }
  useEffect(() => {
    if (settingsMode !== 'layout') return;
    layoutPanel.current?.querySelector<HTMLElement>('[tabindex="0"]')?.focus({ preventScroll: true });
    const keydown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); cancelLayout(); }
      if (event.key === 'Tab') {
        const elements = [...(layoutPanel.current?.querySelectorAll<HTMLElement>('button:not(:disabled),[tabindex="0"]') ?? [])];
        const first = elements[0], last = elements.at(-1);
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
    };
    window.addEventListener('keydown', keydown, true);
    return () => window.removeEventListener('keydown', keydown, true);
  }, [settingsMode]);
  useEffect(() => { if (shareFallback) shareInput.current?.select(); }, [shareFallback]);
  useEffect(() => () => clearTimeout(shareTimer.current), []);
  useEffect(() => {
    const audio = new CyclingAudio({ effects, voice, volume: voiceVolume }); sound.current = audio;
    return () => { audio.dispose(); sound.current = null; };
  }, []);
  useEffect(() => { sound.current?.setEnabled({ effects, voice, volume: voiceVolume }); }, [effects, voice, voiceVolume]);
  useEffect(() => {
    let frame = 0, last = 0, lastPublish = 0;
    let disposed = false;
    const initialPaint = new AbortController();
    markReady(false); setSceneLoading(true); failed.current = false; setError('');
    const target = host.current!;
    const contextLost = (event: Event) => {
      event.preventDefault(); failed.current = true; markReady(false); setSceneLoading(false); pause(true);
      readyCallback.current?.(); setError('3D 画面已中断，请返回村庄后重新进入。未完成的骑行不会结算。');
    };
    const animate = (time: number) => {
      const delta = last ? Math.min((time - last) / 1000, .25) : 0; last = time;
      const active = readyRef.current && !scene.current?.transitioning && !document.hidden && !failed.current;
      if (active) {
        const running = !pausedRef.current && settingsRef.current === 'closed';
        if (running) run.current = stepCycling(run.current, delta, brakingRef.current);
        for (const event of run.current.events) {
          if (event.id <= lastEvent.current) continue;
          lastEvent.current = event.id;
          if (event.kind === 'hole' || event.kind === 'barrier') sound.current?.hit(event.kind);
          else sound.current?.pickup(event.kind);
        }
        scene.current?.update(run.current, cameraRef.current, running ? delta : 0);
        if (time - lastPublish >= 80 || run.current.phase === 'finished' && !claimed.current) {
          setSnapshot(run.current); lastPublish = time;
        }
        if (run.current.phase === 'finished' && !claimed.current) {
          claimed.current = true; clearBrake(); finish.current(run.current.score);
        }
      } else last = 0;
      frame = requestAnimationFrame(animate);
    };
    void (async () => {
      try {
        if (!await waitForScenePaint(initialPaint.signal)) return;
        const renderer = new CyclingScene(target, { lowQuality, outfit, difficulty: difficultyRef.current, onTransition: busy => {
          if (disposed || failed.current) return;
          setSceneLoading(busy); markReady(!busy && audioReady.current); if (busy) { clearBrake(); last = 0; }
        } });
        scene.current = renderer; renderer.update(run.current, cameraRef.current, 0);
        target.querySelector('canvas')?.addEventListener('webglcontextlost', contextLost);
        frame = requestAnimationFrame(animate);
        await (sound.current?.ready ?? Promise.resolve());
        if (disposed || failed.current) return;
        audioReady.current = true;
        markReady(!renderer.transitioning); setSceneLoading(renderer.transitioning); readyCallback.current?.();
      } catch {
        if (disposed) return;
        failed.current = true; markReady(false); setSceneLoading(false); scene.current?.dispose(); scene.current = null;
        setError('这台设备暂时无法打开骑行地图。请返回设置，开启省电画质后重试。'); readyCallback.current?.();
      }
    })();
    const interrupt = () => { clearBrake(); if (run.current.phase === 'riding') pause(true); last = 0; };
    const visibility = () => { if (document.hidden) interrupt(); last = 0; };
    window.addEventListener('blur', interrupt); document.addEventListener('visibilitychange', visibility);
    return () => {
      disposed = true; initialPaint.abort(); readyRef.current = false; cancelAnimationFrame(frame);
      window.removeEventListener('blur', interrupt); document.removeEventListener('visibilitychange', visibility);
      target.querySelector('canvas')?.removeEventListener('webglcontextlost', contextLost);
      scene.current?.dispose(); scene.current = null;
    };
  }, [lowQuality, outfit]);
  useEffect(() => {
    const renderer = scene.current;
    if (!renderer || !routeRequest) return;
    let cancelled = false;
    void renderer.setDifficulty(difficulty, run.current, cameraRef.current).catch(() => {
      if (cancelled) return;
      failed.current = true; markReady(false); setSceneLoading(false);
      setError('这条路线暂时未能准备好，请退出骑行后重新进入。');
    });
    return () => { cancelled = true; };
  }, [difficulty, routeRequest]);
  useEffect(() => {
    const keydown = (event: KeyboardEvent) => {
      if (event.defaultPrevented || !canControl() || event.isComposing
        || event.target instanceof HTMLElement && event.target.closest('input,textarea,select,[contenteditable=true]')) return;
      if (event.key === ' ' && event.target instanceof HTMLElement && event.target.closest('button')) return;
      const action = matchCyclingControlAction(event, preferencesRef.current.bindings);
      if (!action) return;
      event.preventDefault();
      if (action === 'brake') { setBrakeSource(`key:${cyclingKeyCode(event)}`, true); return; }
      if (action === 'orbitLeft' || action === 'orbitRight') { scene.current?.rotateCamera(action === 'orbitLeft' ? -.16 : .16, 0); return; }
      if (action === 'tiltUp' || action === 'tiltDown') { scene.current?.rotateCamera(0, action === 'tiltUp' ? -.10 : .10); return; }
      if (event.repeat) return;
      if (action === 'resetCamera') scene.current?.resetCamera();
      if (action === 'steerLeft') steer(-1);
      if (action === 'steerRight') steer(1);
      if (action === 'nextCamera') selectCamera(cameras[(cameras.findIndex(v => v.id === cameraRef.current) + 1) % cameras.length].id);
      if (action === 'pause' && run.current.phase === 'riding') pause(!pausedRef.current);
    };
    const keyup = (event: KeyboardEvent) => setBrakeSource(`key:${cyclingKeyCode(event)}`, false);
    window.addEventListener('keydown', keydown); window.addEventListener('keyup', keyup);
    return () => { window.removeEventListener('keydown', keydown); window.removeEventListener('keyup', keyup); };
  }, []);
  const reward = cyclingReward(snapshot.score, snapshot.difficulty);
  const riding = snapshot.phase === 'riding';
  return <div className="cycling-game" ref={root} tabIndex={-1} data-testid="cycling-game"
    data-phase={snapshot.phase} data-distance={snapshot.distance.toFixed(2)} data-lane={snapshot.lane}
    data-difficulty={snapshot.difficulty} data-speed={snapshot.speed.toFixed(3)} data-slowdown-remaining={snapshot.slowdownRemaining.toFixed(3)} data-events={JSON.stringify(snapshot.events)}
    data-braking={braking} data-settings={settingsMode} data-loading={sceneLoading} data-score={snapshot.score} data-integrity={snapshot.integrity} data-paused={paused}
    data-course={JSON.stringify(snapshot.items)}>
    <div className="cycling-play-surface" inert={settingsMode !== 'closed'}>
    <div className="cycling-scene" ref={host} data-testid="cycling-scene" aria-label="村外环线，独立 3D 骑行地图" />
    <div className="cycling-top">
      <div className="cycling-route"><Bicycle size={21} /><span>{config.mapName}<small>{config.label} · {CYCLING_LENGTH} 米</small></span><button className="cycling-share" aria-label="分享骑行直链" title="复制骑行直链" onClick={share}>{shareStatus === '直链已复制' ? <Check size={18} /> : <ShareNetwork size={18} />}</button>{!riding && <button className="cycling-settings-trigger" aria-label="操作设置" title="操作设置" onClick={openSettings}><SlidersHorizontal size={21} /></button>}</div>
      <div className="cycling-view-tools"><div className="cycling-cameras" role="group" aria-label="骑行视角">
        {cameras.map(view => <button key={view.id} aria-label={view.label} aria-pressed={camera === view.id} disabled={!ready} onClick={() => selectCamera(view.id)}><Camera size={15} /><span>{view.label.replace('视角', '')}</span></button>)}
        <button className="cycling-reset-camera" aria-label="复位视角" title={`复位视角（${preferences.bindings.resetCamera.map(cyclingKeyLabel).join(" / ")}）`} disabled={!ready} onClick={() => scene.current?.resetCamera()}><ArrowCounterClockwise size={17} /></button>
      </div><small className="cycling-view-hint">拖动 / 滑动旋转 · 滚轮 / 双指缩放</small>

      </div>
    </div>
    {shareStatus && <div className="cycling-share-status" role="status">{shareStatus}{shareFallback && <input ref={shareInput} aria-label="骑行直链" value={shareFallback} readOnly onFocus={event => event.target.select()} />}</div>}
    {settingsNotice && <div className="cycling-settings-notice" role="alert">{settingsNotice}<button aria-label="关闭设置提示" onClick={() => setSettingsNotice('')}>关闭</button></div>}
    {snapshot.phase !== 'ready' && <div className="cycling-dashboard">
      <div><small>本局得分</small><strong>{snapshot.score.toString().padStart(3, '0')}</strong></div>
      <div><small>骑行进度</small><strong>{Math.floor(snapshot.distance)}<em> / {CYCLING_LENGTH} m</em></strong><progress value={snapshot.distance} max={CYCLING_LENGTH} aria-label="骑行进度" /></div>
      <div className="cycling-integrity" aria-label={`耐久 ${snapshot.integrity} / 3`}><small>自行车耐久</small><span>{[1, 2, 3].map(n => <Heart key={n} size={21} weight={n <= snapshot.integrity ? 'fill' : 'regular'} />)}</span></div>
      <div className="cycling-hud-speed"><small>速度 · {config.label}</small><strong>{Math.round(snapshot.speed * 3.6)}<em> km/h</em></strong><span>{['左车道', '中车道', '右车道'][snapshot.lane + 1]}</span></div>
    </div>}
    {error ? <div className="cycling-card cycling-error" role="alert"><h3>骑行地图暂不可用</h3><p>{error}</p></div> : snapshot.phase === 'ready' ? <div className="cycling-card cycling-intro">
      <span className="cycling-kicker">难鱼的村外兜风计划</span><h3>车把握好，<br />出发捡点好东西。</h3>
      <div className="cycling-difficulties" role="group" aria-label="选择骑行难度">{CYCLING_DIFFICULTIES.map(route => <button key={route.id} aria-label={`${route.label}难度`} aria-pressed={difficulty === route.id} onClick={() => chooseDifficulty(route.id)} data-theme={route.theme}><strong>{route.label}</strong><span>{route.mapName}</span></button>)}</div>
      <p className="cycling-route-description">{config.description}</p>
      <div className="cycling-route-facts"><span><strong>{Math.round(config.startSpeed * 3.6)}–{Math.round(config.maxSpeed * 3.6)}</strong> km/h</span><span>得分奖励 <strong>×{config.rewardMultiplier}</strong></span><span>最高 <strong>{cyclingReward(1000, difficulty).shells}</strong> 贝壳</span></div>
      <div className="cycling-legend"><span><i className="cover" />井盖 +40</span><span><i className="bottle" />空瓶 +15</span><span><i className="parcel" />包裹 +25</span><span><i className="hole" />空井 / 路障 −1 耐久</span></div>
      <details className="cycling-help"><summary>操作与规则</summary><p className="cycling-instructions">自动向前 · {preferences.bindings.steerLeft.map(cyclingKeyLabel).join(' / ')} 向左 · {preferences.bindings.steerRight.map(cyclingKeyLabel).join(' / ')} 向右<br />{preferences.bindings.brake.map(cyclingKeyLabel).join(' / ')} 按住减速 · {preferences.bindings.nextCamera.map(cyclingKeyLabel).join(' / ')} 切换视角<br />{preferences.bindings.pause.map(cyclingKeyLabel).join(' / ')} 暂停 · {preferences.bindings.resetCamera.map(cyclingKeyLabel).join(' / ')} 复位视角<br />拖动 / 滑动自由旋转，滚轮 / 双指缩放。<br />手机使用底部按钮；操作设置可调整键位与按钮位置。碰撞后短暂减速，拾取不减速。</p></details>
      <button className="primary wide" onClick={start} disabled={!ready}><Bicycle size={21} />{ready ? '开始骑行 · 8 精力' : '正在准备自行车…'}</button>
      <small>到达终点或耐久耗尽时结算；中途退出不领奖。<br />到达终点每格剩余耐久 +50 分，最高 1000 分。</small>
      {startError && <p role="alert">{startError}</p>}
    </div> : snapshot.phase === 'finished' ? <div className="cycling-card cycling-result">
      <Trophy size={32} /><span className="cycling-kicker">{snapshot.distance >= CYCLING_LENGTH ? '顺利骑完全程' : '先修好车，下次再出发'}</span>
      <h3>{snapshot.score}<small> 分</small></h3><p>骑行 {Math.floor(snapshot.distance)} 米 · 拾取 {snapshot.collected} 件 · 碰撞 {snapshot.hits} 次</p>
      <div className="cycling-payout">+{reward.shells} 贝壳 <span>+{reward.bond} 熟悉度</span></div><p className="cycling-instructions">{config.label}难度 · 得分奖励 ×{config.rewardMultiplier}<br />奖励已结算，最高分已记入本地存档。</p>
      <button className="primary wide" disabled={!ready} onClick={start}><ArrowClockwise size={18} />再骑一圈 · 8 精力</button>
      <button className="cycling-change-route" onClick={() => chooseDifficulty(difficulty)}>换条路线</button>
      {startError && <p role="alert">{startError}</p>}
    </div> : paused && <div className="cycling-card cycling-paused"><Pause size={30} /><h3>路边歇一会儿</h3><p>骑行已暂停，进度与耐久保持不变。</p><button className="primary wide" disabled={!ready} onClick={() => pause(false)}><Play size={18} />继续骑行</button></div>}
    {riding && !error && <>
      {!paused && <div className="cycling-feedback" role="status">{snapshot.message || '看清前方，空井要绕开。'}</div>}
      <CyclingTouchControls preferences={preferences.touch} disabled={!ready} paused={paused} lane={snapshot.lane} braking={braking}
        onSteer={steer} onBrakeSource={setBrakeSource} onPause={() => pause(true)} onSettings={openSettings} />
    </>}
    </div>
    {sceneLoading && !error && <SceneTransitionIndicator label={`正在准备${config.mapName}…`} className="cycling-transition" />}
    {settingsMode === 'sheet' && <CyclingControlSettings draft={draft} onChange={setDraft} onSave={saveSettings} onClose={closeSettings}
      onEditLayout={() => { layoutBefore.current = normalizeCyclingControlPreferences(draft).touch; setLayoutValid(true); changeSettingsMode('layout'); }}
      effects={effects} voice={voice} onEffects={() => setEffects(value => !value)} onVoice={() => setVoice(value => !value)} />}
    {settingsMode === 'layout' && <div className="cycling-layout-editor" ref={layoutPanel} role="dialog" aria-modal="true" aria-label="调整按钮位置">
      <div className="cycling-layout-editor-head"><h3>调整按钮位置</h3><p>拖动按钮组，或聚焦后用方向键微调。横屏和竖屏分别保存。</p>
        {!layoutValid && <p role="alert">按钮重叠或超出范围，请挪到空白位置。</p>}
        <div><button onClick={cancelLayout}>取消调整</button><button className="primary" disabled={!layoutValid} onClick={() => changeSettingsMode('sheet')}>完成布局</button></div>
      </div>
      <CyclingTouchControls preferences={draft.touch} editing paused lane={0} braking={false} onSteer={() => {}} onBrakeSource={() => {}} onPause={() => {}} onSettings={() => {}}
        onChange={touch => setDraft(value => ({ ...value, touch }))} onLayoutValidChange={setLayoutValid} />
    </div>}
  </div>;
}
