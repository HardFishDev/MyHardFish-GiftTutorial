import { strFromU8, strToU8, unzipSync, zipSync } from "fflate";
import { newGame, quoteMap, step } from "./engine";
import type { GameState } from "./engine";
import { achievementInfo, foods, friends, outfits, places, stories } from "./content";
import { adventureItems, discoveries, quests } from "./adventure-content";
import { createAdventure } from "./adventure";
import type { AdventureState, QuestProgress } from "./adventure-types";
import { normalizeDbhState } from './dbh-state';
import { CYCLING_MAX_SCORE } from './cycling';

export const SAVE_KEY = "hardfish.save.v1";
const SLOT_KEY = "hardfish.slots.v1";
const BACKUP_KEY = "hardfish.before-restore.v1";
export type Slot = { label: string; savedAt: number; state: GameState } | null;
export type Archive = { state: GameState; slots: Slot[] };
const object = (v: unknown): Record<string, unknown> => {
  if (!v || typeof v !== "object" || Array.isArray(v))
    throw Error("存档内容不是有效对象");
  return v as Record<string, unknown>;
};
const number = (v: unknown, min = 0, max = 999999, integer = false): number => {
  if (
    typeof v !== "number" ||
    !Number.isFinite(v) ||
    v < min ||
    v > max ||
    (integer && !Number.isInteger(v))
  )
    throw Error("存档中的数值超出范围");
  return v;
};
const string = (v: unknown, max = 200): string => {
  if (typeof v !== "string" || v.length > max)
    throw Error("存档中的文字格式不正确");
  return v;
};
const bool = (v: unknown) => {
  if (typeof v !== "boolean") throw Error("存档设置格式不正确");
  return v;
};
function enumValue<T extends string>(v: unknown, allowed: readonly T[]): T {
  if (typeof v !== "string" || !allowed.includes(v as T))
    throw Error("存档包含无法识别的项目");
  return v as T;
}
function array<T>(v: unknown, max: number, read: (i: unknown) => T): T[] {
  if (!Array.isArray(v) || v.length > max)
    throw Error("存档列表格式不正确或过大");
  return v.map(read);
}

function validateAdventure(value: unknown, state: GameState): AdventureState {
  const v = object(value);
  if (v.schema !== 1) throw Error("不支持这份探索进度的版本");
  const result = createAdventure(state.updatedAt, state.revision);
  result.quests = {};
  const questValues = object(v.quests);
  if (Object.keys(questValues).length > quests.length) throw Error("探索任务列表过大");
  for (const [id, value] of Object.entries(questValues)) {
    const quest = quests.find(item => item.id === id);
    if (!quest) throw Error("存档包含无法识别的探索任务");
    const q = object(value);
    const status = enumValue(q.status, ["active", "completed"] as const);
    const stage = number(q.stage, 0, quest.stages.length, true);
    if ((status === "completed") !== (stage === quest.stages.length)) throw Error("任务阶段与完成状态不一致");
    const p: QuestProgress = {
      status, stage, startedAt: number(q.startedAt, 0, 1e14),
      stageStartedAt: number(q.stageStartedAt, 0, 1e14),
      stageStartedRevision: number(q.stageStartedRevision, 0, state.revision, true),
      objectives: {}, choices: {},
    };
    if (status === "completed") p.completedAt = number(q.completedAt, 0, 1e14);
    else if (q.completedAt !== undefined) throw Error("未完成任务不应有结算时间");
    const choices = object(q.choices);
    if (Object.keys(choices).length !== stage) throw Error("任务已完成步骤与选择记录不一致");
    for (const [stageId, choice] of Object.entries(choices)) {
      const stageIndex = quest.stages.findIndex(item => item.id === stageId);
      if (stageIndex < 0 || stageIndex >= stage) throw Error("任务选择不属于已完成步骤");
      p.choices[stageId] = enumValue(choice, quest.stages[stageIndex].choices.map(item => item.id));
    }
    const objectives = object(q.objectives);
    const requirements = status === "active" ? quest.stages[stage].requirements || [] : [];
    for (const [objectiveId, count] of Object.entries(objectives)) {
      const requirement = requirements.find(item => item.id === objectiveId);
      if (!requirement || requirement.kind === "discovery") throw Error("任务目标进度不属于当前步骤");
      p.objectives[objectiveId] = number(count, 0, requirement.kind === "game" ? requirement.count || 1 : 1, true);
    }
    result.quests[id] = p;
  }
  for (const [id] of Object.entries(result.quests)) {
    const quest = quests.find(item => item.id === id)!;
    if (!quest.prerequisites.every(required => result.quests[required]?.status === "completed"))
      throw Error("任务前置进度不完整");
  }
  result.trackedQuest = v.trackedQuest === null ? null : enumValue(v.trackedQuest, Object.keys(result.quests));
  if (result.trackedQuest && result.quests[result.trackedQuest].status !== "active") throw Error("追踪任务必须仍在进行中");
  result.items = {};
  for (const [id, count] of Object.entries(object(v.items))) {
    enumValue(id, adventureItems.map(item => item.id));
    result.items[id] = number(count, 0, 99, true);
  }
  for (const [id, points] of Object.entries(object(v.relations))) {
    enumValue(id, friends.map(friend => friend.id));
    result.relations[id] = number(points, 0, 100, true);
  }
  const allFlags = [...new Set([
    ...quests.flatMap(quest => [...(quest.reward.flags || []), ...quest.stages.flatMap(stage => stage.choices.flatMap(choice => choice.reward?.flags || []))]),
    ...discoveries.flatMap(discovery => discovery.reward?.flags || []),
  ])];
  result.flags = [...new Set(array(v.flags, allFlags.length, id => enumValue(id, allFlags)))];
  result.discoveries = [...new Set(array(v.discoveries, discoveries.length, id => enumValue(id, discoveries.map(item => item.id))))];
  result.log = array(v.log, 200, value => {
    const entry = object(value);
    const questId = entry.questId === undefined ? undefined : enumValue(entry.questId, quests.map(quest => quest.id));
    const stageId = entry.stageId === undefined ? undefined : enumValue(entry.stageId, quests.find(quest => quest.id === questId)?.stages.map(stage => stage.id) || []);
    return {
      at: number(entry.at, 0, 1e14), kind: enumValue(entry.kind, ["quest", "stage", "discovery"] as const),
      title: string(entry.title, 160), text: string(entry.text, 1000),
      ...(questId ? { questId } : {}), ...(stageId ? { stageId } : {}),
    };
  });
  return result;
}
export function validateState(value: unknown): GameState {
  const v = object(value);
  if (v.version !== 1)
    throw Error("不支持这个存档版本，请使用本游戏导出的 ZIP");
  const s = newGame();
  const time = (v: unknown) => number(v, 0, 1e14);
  s.createdAt = time(v.createdAt);
  s.updatedAt = time(v.updatedAt);
  s.name = string(v.name, 16);
  for (const key of ["hunger", "mood", "energy", "bond"] as const)
    s[key] = number(v[key], 0, 100);
  s.shells = number(v.shells, 0, 999999, true);
  s.place = enumValue(
    v.place,
    places.map((p) => p.id),
  );
  s.outfit = enumValue(
    v.outfit,
    outfits.map((o) => o.id),
  );
  const inv = object(v.inventory);
  for (const f of foods) s.inventory[f.id] = number(inv[f.id], 0, 99, true);
  s.owned = [
    ...new Set(
      array(v.owned, outfits.length, (x) =>
        enumValue(
          x,
          outfits.map((o) => o.id),
        ),
      ),
    ),
  ];
  if (!s.owned.includes("classic") || !s.owned.includes(s.outfit))
    throw Error("存档装扮信息不完整");
  s.visited = [
    ...new Set(
      array(v.visited, places.length, (x) =>
        enumValue(
          x,
          places.map((p) => p.id),
        ),
      ),
    ),
  ];
  s.collected = [
    ...new Set(
      array(v.collected, Object.keys(quoteMap).length, (x) =>
        enumValue(x, Object.keys(quoteMap)),
      ),
    ),
  ];
  s.achievements = [
    ...new Set(
      array(v.achievements, achievementInfo.length, (x) =>
        enumValue(
          x,
          achievementInfo.map((a) => a.id),
        ),
      ),
    ),
  ];
  const allEndings = stories.flatMap((story) =>
    Object.entries(story.nodes)
      .filter(([, n]) => n.ending)
      .map(([id]) => `${story.id}:${id}`),
  );
  s.endings = [
    ...new Set(
      array(v.endings, allEndings.length, (x) => enumValue(x, allEndings)),
    ),
  ];
  const readCounts = (x: unknown) => {
    const o = object(x);
    const c = { ...s.counts };
    for (const k of Object.keys(c) as (keyof typeof c)[])
      c[k] = number(o[k], 0, 1e9, true);
    return c;
  };
  s.counts = readCounts(v.counts);
  const daily = object(v.daily);
  const date = string(daily.date, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw Error("每日进度日期无效");
  s.daily = {
    date,
    counts: readCounts(daily.counts),
    claimed: [
      ...new Set(
        array(daily.claimed, 3, (x) => enumValue(x, ["chat", "feed", "play"])),
      ),
    ],
  };
  const records = object(v.records);
  s.records = {
    bottle: number(records.bottle, 0, 6, true),
    cook: number(records.cook, 0, 3, true),
    math: number(records.math, 0, 5, true),
    words: records.words === undefined ? 0 : number(records.words, 0, 5, true),
    harvest: records.harvest === undefined ? 0 : number(records.harvest, 0, 5, true),
    cycling: records.cycling === undefined ? 0 : number(records.cycling, 0, CYCLING_MAX_SCORE, true),
  };
  if (v.story !== null) {
    const p = object(v.story);
    const id = enumValue(
      p.id,
      stories.map((e) => e.id),
    );
    const story = stories.find((e) => e.id === id)!;
    const node = enumValue(p.node, Object.keys(story.nodes));
    if (story.nodes[node].ending) throw Error("剧情进度无效");
    s.story = { id, node };
  }
  s.messages = array(v.messages, 80, (item) => {
    const m = object(item);
    return {
      who: enumValue(m.who, ["you", "fish"] as const),
      text: string(m.text, 600),
      at: time(m.at),
      ...(m.quoteId !== undefined
        ? { quoteId: enumValue(m.quoteId, Object.keys(quoteMap)) }
        : {}),
    };
  });
  s.journal = array(v.journal, 100, (item) => {
    const j = object(item);
    return { at: time(j.at), text: string(j.text, 800) };
  });
  s.topic = string(v.topic, 24);
  const settings = object(v.settings);
  s.settings = {
    voice: bool(settings.voice),
    gentle: bool(settings.gentle),
    lowQuality: bool(settings.lowQuality),
    volume: number(settings.volume, 0, 1),
  };
  s.lastReward = time(v.lastReward);
  s.revision = number(v.revision, 0, 1e12, true);
  // Missing extension means a real old v1 archive. Partial or invalid new data is rejected.
  s.adventure = v.adventure === undefined ? createAdventure(s.updatedAt, s.revision) : validateAdventure(v.adventure, s);
  s.dbh = normalizeDbhState(v.dbh);
  // A restored save never restores a live claim token for an unfinished UI minigame.
  s.activeGame = null;
  // Transient effects are deliberately reconstructed, never trusted from an archive.
  const last = [...s.messages].reverse().find((m) => m.who === "fish");
  s.reaction = {
    id: s.revision,
    text: last?.text || quoteMap.greeting.text,
    quoteId: last?.quoteId,
    motion: "idle",
  };
  return s;
}
function validateSlots(v: unknown): Slot[] {
  const slots = array(v, 3, (x) => {
    if (x === null) return null;
    const slot = object(x);
    return {
      label: string(slot.label, 40),
      savedAt: number(slot.savedAt, 0, 1e14),
      state: validateState(slot.state),
    };
  });
  while (slots.length < 3) slots.push(null);
  return slots;
}
export function loadGame(): { state: GameState; error: string } {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    return {
      state: raw
        ? step(validateState(JSON.parse(raw)), { type: "tick" })
        : newGame(),
      error: "",
    };
  } catch {
    return {
      state: newGame(),
      error:
        "本地存档暂时无法读取。旧数据未覆盖；可以在存档管理中导入备份，或明确保存当前进度。",
    };
  }
}
export function saveGame(s: GameState) {
  localStorage.setItem(SAVE_KEY, JSON.stringify(s));
}
export function loadSlots(): Slot[] {
  const raw = localStorage.getItem(SLOT_KEY);
  return raw ? validateSlots(JSON.parse(raw)) : [null, null, null];
}
export function saveSlots(slots: Slot[]) {
  localStorage.setItem(SLOT_KEY, JSON.stringify(slots));
}
export function backupBeforeRestore(s: GameState) {
  localStorage.setItem(BACKUP_KEY, JSON.stringify(s));
}
export function loadBackup(): GameState | null {
  const raw = localStorage.getItem(BACKUP_KEY);
  return raw ? validateState(JSON.parse(raw)) : null;
}
export function restoreStored(
  current: GameState,
  next: GameState,
  incomingSlots?: Slot[],
) {
  const keys = [SAVE_KEY, SLOT_KEY, BACKUP_KEY];
  const before = keys.map((key) => localStorage.getItem(key));
  try {
    backupBeforeRestore(current);
    if (incomingSlots) saveSlots(incomingSlots);
    saveGame(next);
  } catch (error) {
    // localStorage has no multi-key transaction. Roll back successful earlier writes on failure.
    keys.forEach((key, i) => {
      if (localStorage.getItem(key) !== before[i]) {
        if (before[i] === null) localStorage.removeItem(key);
        else localStorage.setItem(key, before[i]!);
      }
    });
    throw error;
  }
}
export function makeArchive(state: GameState, slots: Slot[]): Uint8Array {
  return zipSync(
    {
      "manifest.json": strToU8(
        JSON.stringify({
          game: "my-groupmate-hardfish",
          version: 1,
          exportedAt: new Date().toISOString(),
        }),
      ),
      "save.json": strToU8(JSON.stringify(state)),
      "slots.json": strToU8(JSON.stringify(slots)),
      "说明.txt": strToU8(
        "我的群友难鱼\n在游戏的「存档管理」中导入此 ZIP。包含当前进度和三个手动存档。聊天与进度仅保存在你的浏览器及此文件中。\n",
      ),
    },
    { level: 6 },
  );
}
export function readArchive(bytes: Uint8Array): Archive {
  if (bytes.byteLength > 2 * 1024 * 1024)
    throw Error("文件超过 2 MB，请选择本游戏导出的存档 ZIP");
  let total = 0;
  const allowed = ["manifest.json", "save.json", "slots.json"];
  const files = unzipSync(bytes, {
    filter: (file) => {
      if (!allowed.includes(file.name)) return false;
      total += file.originalSize;
      if (file.originalSize > 1024 * 1024 || total > 3 * 1024 * 1024)
        throw Error("存档解压后过大");
      return true;
    },
  });
  if (allowed.some((name) => !files[name]))
    throw Error("缺少存档文件，请选择本游戏导出的 ZIP");
  const manifest = object(JSON.parse(strFromU8(files["manifest.json"])));
  if (manifest.game !== "my-groupmate-hardfish" || manifest.version !== 1)
    throw Error("这不是受支持的难鱼存档");
  return {
    state: validateState(JSON.parse(strFromU8(files["save.json"]))),
    slots: validateSlots(JSON.parse(strFromU8(files["slots.json"]))),
  };
}
export function downloadFile(data: BlobPart, filename: string, type: string) {
  const url = URL.createObjectURL(new Blob([data], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}
