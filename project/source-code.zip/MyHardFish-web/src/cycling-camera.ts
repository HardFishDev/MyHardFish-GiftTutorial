type PointerPosition={x:number;y:number};

/** Canvas-only gestures, leaving the riding controls and game clock untouched. */
export class CyclingCameraControls {
  private readonly pointers=new Map<number,PointerPosition>();
  private disposed=false;

  constructor(private readonly canvas:HTMLCanvasElement,private readonly rotate:(azimuth:number,polar:number)=>void,private readonly zoom:(factor:number)=>void) {
    canvas.addEventListener('pointerdown',this.onPointerDown);
    canvas.addEventListener('pointermove',this.onPointerMove);
    canvas.addEventListener('pointerup',this.onPointerEnd);
    canvas.addEventListener('pointercancel',this.onPointerEnd);
    canvas.addEventListener('lostpointercapture',this.onPointerEnd);
    canvas.addEventListener('wheel',this.onWheel,{passive:false});
    canvas.addEventListener('webglcontextlost',this.cancelGesture);
    window.addEventListener('blur',this.cancelGesture);
    document.addEventListener('visibilitychange',this.onVisibilityChange);
    canvas.style.cursor='grab';
  }

  private onPointerDown=(event:PointerEvent)=>{
    if(event.pointerType==='mouse'&&event.button!==0)return;
    event.preventDefault();
    this.pointers.set(event.pointerId,{x:event.clientX,y:event.clientY});
    try{this.canvas.setPointerCapture(event.pointerId);}catch{this.pointers.delete(event.pointerId);}
    this.canvas.style.cursor=this.pointers.size?'grabbing':'grab';
  };

  private onPointerMove=(event:PointerEvent)=>{
    const previous=this.pointers.get(event.pointerId);if(!previous)return;
    if(event.pointerType==='mouse'&&(event.buttons&1)===0){this.onPointerEnd(event);return;}
    event.preventDefault();
    const next={x:event.clientX,y:event.clientY};
    // Keep each finger's baseline current, including while a pinch is active.
    // Lifting either finger therefore resumes rotation without a stale delta.
    if(this.pointers.size===1){
      this.pointers.set(event.pointerId,next);
      const rect=this.canvas.getBoundingClientRect();
      this.rotate(-(next.x-previous.x)/Math.max(1,rect.width)*Math.PI*2,-(next.y-previous.y)/Math.max(1,rect.height)*Math.PI);
    }else if(this.pointers.size===2){
      const other=[...this.pointers.entries()].find(([id])=>id!==event.pointerId)![1];
      const before=Math.hypot(previous.x-other.x,previous.y-other.y),after=Math.hypot(next.x-other.x,next.y-other.y);
      this.pointers.set(event.pointerId,next);
      if(before>4&&after>4)this.zoom(before/after);
    }else this.pointers.set(event.pointerId,next);
  };

  private onPointerEnd=(event:PointerEvent)=>{
    this.pointers.delete(event.pointerId);
    if(this.canvas.hasPointerCapture(event.pointerId))this.canvas.releasePointerCapture(event.pointerId);
    this.canvas.style.cursor=this.pointers.size?'grabbing':'grab';
  };

  private onWheel=(event:WheelEvent)=>{
    event.preventDefault();
    const units=event.deltaMode===1?16:event.deltaMode===2?this.canvas.clientHeight:1;
    this.zoom(Math.exp(Math.max(-.5,Math.min(.5,event.deltaY*units*.001))));
  };

  private onVisibilityChange=()=>{if(document.hidden)this.cancelGesture();};

  readonly cancelGesture=()=>{
    const ids=[...this.pointers.keys()];this.pointers.clear();
    for(const id of ids)if(this.canvas.hasPointerCapture(id))this.canvas.releasePointerCapture(id);
    this.canvas.style.cursor='grab';
  };

  dispose(){
    if(this.disposed)return;this.disposed=true;this.cancelGesture();
    this.canvas.removeEventListener('pointerdown',this.onPointerDown);
    this.canvas.removeEventListener('pointermove',this.onPointerMove);
    this.canvas.removeEventListener('pointerup',this.onPointerEnd);
    this.canvas.removeEventListener('pointercancel',this.onPointerEnd);
    this.canvas.removeEventListener('lostpointercapture',this.onPointerEnd);
    this.canvas.removeEventListener('wheel',this.onWheel);
    this.canvas.removeEventListener('webglcontextlost',this.cancelGesture);
    window.removeEventListener('blur',this.cancelGesture);
    document.removeEventListener('visibilitychange',this.onVisibilityChange);
  }
}
