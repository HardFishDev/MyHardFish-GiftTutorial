import * as THREE from 'three';
import { canvasTexture, ellipsePoints, line, loft, mesh, point, smoothUvSeamNormals } from './dbh-geometry';

/** A relaxed jersey shirt: shaped shoulder line, soft diagonal drape and a thin ribbed neck. */
export function createDbhShirt(torso: THREE.Group, cloth: THREE.Material, seam: THREE.Material) {
  const rings = [
    { y: -.092, x: .366, z: .262, cz: .068 }, { y: -.052, x: .374, z: .267, cz: .068 },
    { y: .075, x: .350, z: .261, cz: .064 }, { y: .24, x: .318, z: .247, cz: .064 },
    { y: .43, x: .327, z: .247, cz: .06 }, { y: .63, x: .346, z: .25, cz: .05 },
    { y: .77, x: .372, z: .242, cz: .033 }, { y: .885, x: .357, z: .202, cz: .016 },
    { y: .995, x: .27, z: .145, cz: .004 }, { y: 1.065, x: .159, z: .117 },
  ];
  const gauss = (x: number, y: number, cx: number, cy: number, sx: number, sy: number) => Math.exp(-(((x-cx)/sx)**2+((y-cy)/sy)**2));
  const drape = (x: number, y: number, z: number) => {
    const front = THREE.MathUtils.smoothstep(z, .02, .15);
    const chest = front * .014 * (gauss(x,y,-.15,.69,.15,.22)+gauss(x,y,.15,.69,.15,.22));
    const left = .015 * gauss(x,y,-.255,.16,.105,.23) * Math.sin(y*24+x*11+.5);
    const right = .011 * gauss(x,y,.267,.27,.085,.23) * Math.sin(y*22-x*16+1.9);
    const hem = .011 * gauss(x,y,.035,-.025,.35,.065) * Math.sin(x*23+y*8+.8);
    const shoulder = .005 * gauss(Math.abs(x),y,.295,.79,.10,.12) * Math.sin(y*32+x*20);
    return chest + Math.sign(z) * (left+right+hem+shoulder) * Math.min(1,Math.abs(z)/.08);
  };
  const hemY = (x: number, z: number) => -.09 + .008*Math.sin(x*9+1.1)+.008*Math.cos(x*16-z*4);
  const geometry = loft(rings, 64, false, 12), positions = geometry.getAttribute('position');
  for (let i=0;i<positions.count;i++) {
    const x=positions.getX(i),y=positions.getY(i),z=positions.getZ(i);
    const neck = THREE.MathUtils.smoothstep(y,.88,1.065);
    const dip = .075 * Math.max(0,z/.112) * neck;
    const lower = 1-THREE.MathUtils.smoothstep(y,-.092,.08);
    const shoulderDrape = .018 * gauss(x,y,0,.86,.42,.105) * Math.sin(x*8+.5) * Math.min(1,Math.abs(z)/.12);
    positions.setXYZ(i,x,y-dip+lower*(hemY(x,z)+.09)+shoulderDrape,z+drape(x,y,z));
  }
  geometry.computeVertexNormals();smoothUvSeamNormals(geometry,65);
  mesh(torso,geometry,cloth).name='dbh-soft-jersey-shirt';
  line(torso,seam,ellipsePoints(.368,.264,-.084,.068,80).map(p=>{p.y=hemY(p.x,p.z)+.006;p.z+=drape(p.x,-.084,p.z);return p;}),.0028,80,true);
  line(torso,seam,ellipsePoints(.159,.118,1.065,0,64).map(p=>{p.y-=Math.max(0,p.z/.112)*.075;return p;}),.006,64,true);
  const print=canvasTexture(256,128,ctx=>{ctx.clearRect(0,0,256,128);ctx.fillStyle='#e4e2dc';ctx.font='600 67px Arial';ctx.textAlign='center';ctx.fillText('DBH',128,88);});
  const logo=new THREE.PlaneGeometry(.205,.091,24,8), lp=logo.getAttribute('position');
  // Project the print onto the finished draped cloth, including its Hermite
  // sections. A separate linear approximation clips through the new chest.
  const projectionMesh=new THREE.Mesh(geometry,cloth), projector=new THREE.Raycaster();
  projectionMesh.updateMatrixWorld();
  for(let i=0;i<lp.count;i++){
    const x=lp.getX(i)+.173,y=lp.getY(i)+.724;
    projector.set(point(x,y,1),point(0,0,-1));
    const hit=projector.intersectObject(projectionMesh,false)[0];
    lp.setXYZ(i,x,y,(hit?.point.z??.3)+.0015);
  }
  logo.computeVertexNormals();
  mesh(torso,logo,new THREE.MeshStandardMaterial({map:print,transparent:true,depthWrite:false,roughness:.98,polygonOffset:true,polygonOffsetFactor:-1})).name='dbh-shirt-print';
  for(const side of [-1,1])line(torso,seam,[point(side*.374,-.055,.068),point(side*.322,.2,.064),point(side*.333,.5,.057),point(side*.372,.8,.03)],.002,36);
}
