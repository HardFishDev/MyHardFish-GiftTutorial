import type { AdventureItem, DiscoveryDefinition, QuestDefinition } from './adventure-types';

/** Original game adaptation. Private source messages and accounts stay in research/. */
export const adventureItems: AdventureItem[] = [
  { id: 'route_note', name: '手绘筹备路线', description: '把村中心、工坊、河岸和夜市连起来。路线很清楚，旁边的吐槽更清楚。', icon: 'map' },
  { id: 'order_slip', name: '浆果订单', description: '熟浆果、酸浆果和种子分开放。难鱼特意把价格写在了正面。', icon: 'leaf' },
  { id: 'berry_crate', name: '分好的作物筐', description: '为村庆分好的游戏作物。保管在任务袋里，不会被当零食吃掉。', icon: 'basket' },
  { id: 'price_card', name: '透明价目牌', description: '数量、用途、交接人都写清楚，拒绝谜语人定价。', icon: 'tag' },
  { id: 'lamp_parts', name: '小灯材料包', description: '酒窝装好的小灯和挂钩，猴在袋上写了三个“马上”。', icon: 'lamp' },
  { id: 'wiring_plan', name: '灯串排布图', description: '酒窝画的灯串位置图。数好格子就能装，背面没有突然加钱的条款。', icon: 'grid' },
  { id: 'blank_letter', name: '空白瓶签', description: '可以写梗、写一句谢谢，也可以留白。', icon: 'note' },
  { id: 'paired_card', name: '配好的瓶信卡', description: '把上句和下句拼起来了。狐狸的烂梗也终于有了下文。', icon: 'bottle' },
  { id: 'bottle_lantern', name: '一盏瓶灯', description: '纸瓶里亮着暖光，瓶签写着“本瓶下班后不回复”。', icon: 'lamp' },
  { id: 'word_card', name: '随身词卡', description: '把 berry、bridge、bottle 和眼前的实物连起来。', icon: 'book' },
  { id: 'bilingual_menu', name: '双语小菜单', description: '难鱼和雨夜一起核过的物品标签。不会的词可以再看一遍。', icon: 'book' },
  { id: 'grocery_card', name: '拼桌采购清单', description: '写着大家各自想吃什么，也给“不用给我准备”留了一格。', icon: 'basket' },
  { id: 'shared_meal', name: '拼桌餐盒', description: '为村庆准备的任务餐盒。想吃、留一份或只收祝福都可以。', icon: 'bowl' },
  { id: 'memory_page', name: '共同作品记录页', description: '作物筐、灯串和饭盒都挤进了同一页，难鱼还在给猴补催更记录。', icon: 'photo' },
  { id: 'mounting_tabs', name: '可移除展示夹', description: '展出前确认，撤下时不留痕。', icon: 'clip' },
  { id: 'exhibit_card', name: '展览说明卡', description: '可以写参与的搭子，也可以只写作品名字。两种说明都记得那几天一起做成的事。', icon: 'note' },
  { id: 'festival_pass', name: '开村日纪念票', description: '难鱼盖了个歪歪的鱼章，旁边手写“今天心情好”。', icon: 'ticket' },
  { id: 'quiet_bookmark', name: '安静角书签', description: '今天写到这里也很好。可以停一停，再继续。', icon: 'book' },
  { id: 'sticker_sheet', name: '难鱼原创贴纸页', description: '游戏原创的吐槽贴纸，只逗眼前的小事，不追着谁骂。', icon: 'sticker' },
];

export const discoveries: DiscoveryDefinition[] = [
  { id:'home_notice', place:'home', hotspot:'home_notice', title:'门缝里的筹备单', text:'猴把“难鱼国际应援会”划掉三次，最后留了一行空白。难鱼看完：名字先放着，事情倒是可以一起做。', quoteId:'whatname', reward:{shells:2} },
  { id:'home_record', place:'home', hotspot:'home_record', title:'功劳簿和催更簿', text:'小本子前半本记共同作品，后半本记猴说过几次“马上”。难鱼翻了翻：后半本是不是该加页了。', quoteId:'read', reward:{shells:2} },
  { id:'home_terrace', place:'home', hotspot:'home_terrace', title:'露台上的暂停键', text:'风铃下面正好能坐两个人。难鱼把椅子挪开一点：今天的任务又不会长腿跑掉。', quoteId:'fine', reward:{bond:1} },
  { id:'kitchen_recipe', place:'kitchen', hotspot:'kitchen_recipe', title:'菜谱上的五个词', text:'菜谱边角夹着物品词卡。雨夜说边用边记，难鱼把“recipe”贴到菜谱正中间，表示这个例子已经够明显了。', quoteId:'idea', reward:{shells:2} },
  { id:'kitchen_fridge', place:'kitchen', hotspot:'kitchen_fridge', title:'随便，随便，再随便', text:'冰箱上贴着六个人的口味，四个人写了“随便”。难鱼在下面回了一句：那我炒空气你们也吃吗。', quoteId:'hardjudge', reward:{shells:2} },
  { id:'kitchen_table', place:'kitchen', hotspot:'kitchen_table', title:'先坐下，再想菜单', text:'餐桌上多摆了一个空碗。难鱼说空着也行，先把椅子坐热，比讨论半小时奶油重要。', quoteId:'okay', reward:{bond:1} },
  { id:'park_bottle', place:'park', hotspot:'park_bottle', title:'公园里的旧瓶签', text:'狐狸把纸瓶分成“主意不错”和“纯属嘴硬”两堆。难鱼决定自己看，暂时不相信这个分类员。', quoteId:'bottle', reward:{shells:2} },
  { id:'park_picnic', place:'park', hotspot:'park_picnic', title:'忽然有礼貌的两秒', text:'胡辣汤把垫子铺好，顺手给难鱼让了个位置。她憋了一句嫌弃，最后出口的居然是“谢谢”。', quoteId:'thankyou', reward:{bond:1} },
  { id:'park_pavilion', place:'park', hotspot:'park_pavilion', title:'雨棚下的备用计划', text:'亭子里挂着一把公共伞。活动遇上雨就往里面挪，迟到的人也能赶上热饭。', quoteId:'rain', reward:{shells:2} },
  { id:'shop_list', place:'shop', hotspot:'shop_list', title:'公开贴出来的价目', text:'价签把数量和用途写得明明白白。难鱼指着最后一行：总算不用点五次确认才知道卖了什么。', quoteId:'nice', reward:{shells:2} },
  { id:'shop_fruit', place:'shop', hotspot:'shop_fruit', title:'差点当成装饰的桃子', text:'胡辣汤说这篮桃子摆着好看，难鱼说吃着也不错。两个人争完，篮子里刚好少了一颗。', quoteId:'idea', reward:{shells:2} },
  { id:'shop_bulletin', place:'shop', hotspot:'shop_bulletin', title:'便民板上的改名记录', text:'公告原本叫“全村唯一指定购物中心”。难鱼把“唯一指定”圈了起来，猴识趣地递上橡皮。', quoteId:'whatname', reward:{shells:2} },
  { id:'school_blackboard', place:'school', hotspot:'school_blackboard', title:'用得上的五道题', text:'黑板上没有分数排名，只有灯串数量和桌椅格子。jin佬说先算眼前这一步；难鱼同意，边同意边抱怨。', quoteId:'math', reward:{shells:2} },
  { id:'school_desk', place:'school', hotspot:'school_desk', title:'从屏幕里认出单词', text:'雨夜把物品图放在单词旁边。难鱼说自己玩英文界面的游戏时也这么认东西，今天就在村里试五个。', quoteId:'game', reward:{shells:2} },
  { id:'school_club', place:'school', hotspot:'school_club', title:'不赶进度的课间角', text:'长文章被拆成几小段。狐狸贡献“不背最快”的主意，jin佬把椅子推过来：那先把这一段看懂。', quoteId:'manythanks', reward:{bond:1} },
  { id:'village_square', place:'village', hotspot:'village_square', title:'先画了一个很大的饼', text:'猴说开村日一定热闹。难鱼环顾空荡荡的广场：“你饼画得挺大，桌子呢？”', quoteId:'greeting', reward:{shells:2} },
  { id:'village_board', place:'village', hotspot:'village_board', title:'第七版活动标题', text:'村务板被贴了七层纸，标题从“应援会”一路改到“随便聚聚”。难鱼抽走猴的笔：第八版我来。', quoteId:'whatname', reward:{shells:2} },
  { id:'village_garden', place:'village', hotspot:'village_garden', title:'三只筐的共同花园', text:'熟浆果、酸浆果、种子各有一只筐。这片花园把当年联机的作物讨论变成了眼前能玩的订单。', quoteId:'idea', reward:{shells:2} },
  { id:'workshop_server', place:'workshop', hotspot:'workshop_server', title:'先说清楚再开工', text:'酒窝在准备台摆好小游戏用的图纸。难鱼的第一条需求是：按钮要看得懂，点一次就够，别藏确认弹窗。', quoteId:'plugins', reward:{shells:2} },
  { id:'workshop_recycle', place:'workshop', hotspot:'workshop_recycle', title:'总算出现的回收箱', text:'猴给箱子刷了一层新漆。难鱼绕着看了一圈，最关心的依然是浆果究竟收不收。', quoteId:'merchant', reward:{shells:2} },
  { id:'workshop_project', place:'workshop', hotspot:'workshop_project', title:'共同作品台', text:'台上有纸板、展示夹和一些没装好的小灯。难鱼说照着教程也能做出东西，先做完这一块再说。', quoteId:'done', reward:{shells:2} },
  { id:'river_bottle', place:'river', hotspot:'river_bottle', title:'一瓶塞了三条评论', text:'瓶签写着“捡漂流瓶”，里面塞着三张互相接不上话的纸。狐狸说这是艺术，难鱼说这是没分好类。', quoteId:'bottle', reward:{shells:2} },
  { id:'river_dock', place:'river', hotspot:'river_dock', title:'也可以不回信', text:'码头有一只写着“先收着”的小盒子。接得住的玩笑就回一句，没心情的瓶签也可以安静放下。', quoteId:'read', reward:{bond:1} },
  { id:'river_observatory', place:'river', hotspot:'river_observatory', title:'一排等着亮起的瓶灯', text:'观景台朝着村中心。狐狸想给每盏灯起一个很长的名字，被难鱼用一张空白标签制止了。', quoteId:'silent', reward:{shells:2} },
  { id:'market_stall', place:'market', hotspot:'market_stall', title:'能看懂的夜市标签', text:'摊子先摆了物品图，再写中文和英文。不会的词可以点开看，摆摊不用突然变成考试。', quoteId:'nice', reward:{shells:2} },
  { id:'market_table', place:'market', hotspot:'market_table', title:'嘴上说不饿的那一位', text:'长桌还没摆好，难鱼已经问了三遍什么时候开饭。被指出来以后，她说自己只是替大家检查进度。', quoteId:'okay', reward:{bond:1} },
  { id:'market_stage', place:'market', hotspot:'market_stage', title:'不用上台的舞台', text:'点歌台还没亮。难鱼先约法一条：有人愿意唱就唱，不愿意的人负责端着杯子看天。', quoteId:'okay', reward:{shells:2} },
];

export const quests: QuestDefinition[] = [
  {
    id:'village_opening', title:'把开村日写进日历', intro:'猴塞来一张筹备单。先把名字和路线说清楚，再决定这个村要怎么热闹。', friendIds:['monkey','rainnight'], source:'原创改编；原型来自2023年应援会起名拉扯、邀请难鱼一起建图，以及2024年联机告示牌讨论。开村日是虚构串联。', prerequisites:[], autoStart:true,
    stages:[
      { id:'pick_route', title:'去小窝看筹备单', place:'home', hotspot:'home_notice', text:'筹备单的标题写得比任务还长。难鱼揉了一下纸角：“事情可以做，名字先别替我决定。”你们先记下路线。', quoteId:'whatname', choices:[
        {id:'keep_draft',label:'收下草稿，一起改',text:'难鱼把“指定应援会”划掉，留出写活动内容的位置。',reward:{items:{route_note:1}}},
        {id:'draw_own',label:'不贴旧标题，自己画一份',text:'旧标题收进抽屉。路线重新画，邀请仍然有效。',reward:{items:{route_note:1}}},
      ]},
      { id:'name_board', title:'到村务板确认称呼', place:'village', hotspot:'village_board', text:'猴的新标题又有十七个字。难鱼举起橡皮：“你是办活动，还是参加起名大赛？”', requirements:[{id:'see_board',kind:'discovery',discoveryId:'village_board',label:'读一读村务板'}], choices:[
        {id:'joint_name',label:'改成“大家的开村日”',text:'难鱼数了一遍，终于不用换更长的木板了。'},
        {id:'blank_names',label:'改成“先把桌子搬来”',text:'猴沉默三秒。难鱼表示这才叫准确传达活动现状。'},
      ]},
      { id:'walk_garden', title:'沿路线看看共同花园', place:'village', hotspot:'village_garden', text:'第一处空地已经留好三只筐。难鱼想起那些收不完的作物，决定这次先分类，再谈回收。', requirements:[{id:'see_garden',kind:'discovery',discoveryId:'village_garden',label:'找到共同花园'}], choices:[
        {id:'mark_crates',label:'在路线图上标出作物筐',text:'三个小方格画在路线旁，第一项具体工作终于出现了。'},
        {id:'remember_route',label:'先记路，等开工再画',text:'不赶着填满地图。难鱼说先知道箱子在哪也很有用。'},
      ]},
      { id:'post_route', title:'回到广场贴出路线', place:'village', hotspot:'village_square', text:'路线从广场通向工坊，再到河岸和夜市。开村日没有截止倒计时，大家准备到哪一步就做到哪一步。', choices:[
        {id:'post_paper',label:'交上手绘路线',text:'纸图贴好，猴把原本过长的欢迎词折到了背面。',costItems:{route_note:1}},
        {id:'say_route',label:'照着路线念，让猴抄公用版',text:'难鱼念完路线，把草稿压在公用图后面。猴的字居然还能看。',costItems:{route_note:1}},
      ]},
    ], reward:{shells:18,bond:3,relations:{monkey:2,rainnight:1},flags:['notice_ready']}, ending:'村务板正式启用。下一件事：让那个一直被催的浆果回收箱真正工作起来。',
  },
  {
    id:'berry_orders', title:'浆果回收，今天安排', intro:'作物已经装不下了。你和难鱼把催更变成订单，把订单变成看得懂的交接。', friendIds:['monkey','jiuwo'], source:'改编自2023年8月连续数日的MC群服作物定价、浆果回收、种子爆仓和一键回收讨论；三筐订单为游戏设计。', prerequisites:['village_opening'], autoStart:true,
    stages:[
      {id:'collect_order',title:'在工坊领一份订单',place:'workshop',hotspot:'workshop_recycle',text:'猴终于把回收箱放出来了。难鱼拍拍崭新的箱盖：“箱子刷漆倒挺快，按钮呢？”猴默默递过来一张手写订单。',requirements:[{id:'see_recycle',kind:'discovery',discoveryId:'workshop_recycle',label:'检查回收箱'}],choices:[
        {id:'paper_order',label:'领走纸订单',text:'难鱼在用途旁边画了三个大圈，省得一会儿还要问。',reward:{items:{order_slip:1}}},
        {id:'copy_order',label:'自己抄一张，原件留在箱上',text:'订单两边都看得见，谁也不用凭记性对账。',reward:{items:{order_slip:1}}},
      ]},
      {id:'sort_harvest',title:'在共同花园完成五张订单',place:'village',hotspot:'village_garden',text:'难鱼守着三只筐，你来认订单。选错可以重看，没有限时；这次认真分完一轮就算完成。',requirements:[{id:'harvest_round',kind:'game',game:'harvest',label:'完成一轮浆果订单',minScore:0,count:1}],choices:[
        {id:'box_sorted',label:'按订单装好分类作物',text:'难鱼看着整齐的筐：“高级。”这次没把种子混进水果里。',costItems:{order_slip:1},reward:{items:{berry_crate:1}},quoteId:'nice'},
        {id:'double_check',label:'一起复核订单再装筐',text:'难鱼把最后一张标签转正，在订单上画了一个大大的勾。',costItems:{order_slip:1},reward:{items:{berry_crate:1}}},
      ]},
      {id:'check_prices',title:'去便利店核对价目牌',place:'shop',hotspot:'shop_list',text:'价目牌最底下挤着一行“确认费”。难鱼把猴喊回来：“你这按钮还没做出来，收费项目先上线了？”',requirements:[{id:'see_price',kind:'discovery',discoveryId:'shop_list',label:'查看公开价目'}],choices:[
        {id:'write_prices',label:'把数量和用途都写出来',text:'难鱼把小字放大：看得清楚，总比再弹五次确认强。',reward:{items:{price_card:1}}},
        {id:'no_pricing',label:'把“确认费”改成“猴搬筐”',text:'猴看完新的价目表，决定主动贡献体力。难鱼很满意这个定价。',reward:{items:{price_card:1}}},
      ]},
      {id:'deliver_crate',title:'把作物交回工坊',place:'workshop',hotspot:'workshop_recycle',text:'回收箱旁边终于有了明确的交接区。难鱼亲自看着这一筐登记完成，决定暂时不催第二遍。',choices:[
        {id:'deliver',label:'交付作物筐和价目牌',text:'猴在清单上盖了章，箱子第一次名副其实。',costItems:{berry_crate:1,price_card:1}},
        {id:'shared_delivery',label:'让猴搬筐，我们按价目牌登记',text:'难鱼拿着价目牌念数量，猴搬完最后一筐才发现“确认费”真变成了自己的力气。',costItems:{berry_crate:1,price_card:1}},
      ]},
    ],reward:{shells:24,bond:3,relations:{monkey:3,jiuwo:1},flags:['harvest_ready']},ending:'整齐的作物筐摆进了村中心。工坊可以用腾出来的桌面准备夜市小灯。',
  },
  {
    id:'workshop_lights',title:'按钮呢，灯总该亮了吧',intro:'回收箱有了，猴又说灯串“马上”。酒窝决定先把图纸摊开。',friendIds:['jiuwo','monkey','jin'],source:'改编自2023年联机自动化、回收按钮讨论与2024年难鱼的插件点子；工坊灯串工程为原创玩法。',prerequisites:['berry_orders'],autoStart:true,
    stages:[
      {id:'parts',title:'去联机准备台领小灯',place:'workshop',hotspot:'workshop_server',text:'桌上摆着一袋小灯，袋子写着“高端联动系统”。酒窝拆开一看，挂钩还没装。难鱼：“高级在哪里？”',quoteId:'plugins',requirements:[{id:'inspect_server',kind:'discovery',discoveryId:'workshop_server',label:'查看联机准备台'}],choices:[
        {id:'follow_guide',label:'请酒窝拿来图纸，一步步做',text:'“照着教程也行。”难鱼把材料按图摆开，终于不用听猴介绍名字了。',reward:{items:{lamp_parts:1}}},
        {id:'rename_system',label:'先把“高端系统”改成“小灯”',text:'标签缩短以后，酒窝递来的材料包显得诚实了很多。',reward:{items:{lamp_parts:1}}},
      ]},
      {id:'count_lights',title:'到教室算清灯串数量',place:'school',hotspot:'school_blackboard',text:'jin佬把需要的灯和挂钩画成格子。狐狸提议凭感觉，难鱼直接把粉笔交给你：还是算一下，省得灯只亮半边。',quoteId:'math',requirements:[{id:'math_round',kind:'game',game:'math',label:'完成一轮口算，核对排布',minScore:0,count:1}],choices:[
        {id:'draw_grid',label:'把数量标在排布图上',text:'错的地方已经一起改过。难鱼把这一版圈出来：能用就行，别再出第九版。',reward:{items:{wiring_plan:1}}},
        {id:'color_grid',label:'按区域给图纸涂颜色',text:'jin佬把同一区域涂成同色。难鱼表示这比猜谜语友好得多。',reward:{items:{wiring_plan:1}}},
      ]},
      {id:'install',title:'回共同作品台装好小灯',place:'workshop',hotspot:'workshop_project',text:'图纸和材料终于对上了。酒窝准备试亮，猴已经清了清嗓子，打算宣布自己的功劳。',choices:[
        {id:'joint_test',label:'按图装灯，让酒窝试亮',text:'小灯亮了。难鱼抢在猴前面宣布：“参与搬袋子的那位也辛苦了。”',costItems:{lamp_parts:1,wiring_plan:1}},
        {id:'monkey_test',label:'按图装灯，请猴按下开关',text:'猴按完开关开始鼓掌。难鱼跟着拍了两下：“恭喜你学会按按钮。”',costItems:{lamp_parts:1,wiring_plan:1}},
      ]},
    ],reward:{shells:24,bond:3,relations:{jiuwo:3,jin:1},flags:['workshop_ready']},ending:'工坊的小灯亮起来了。多出来的灯芯正好可以装进河岸纸瓶。',
  },
  {
    id:'river_letters',title:'狐狸的分类，先别信',intro:'河岸纸瓶缺了下半句。狐狸自告奋勇整理，结果把吐槽和祝福塞进同一瓶。',friendIds:['fox','jiuwo'],source:'改编自2024年1至3月QQ群机器人漂流瓶指令、评论和互损；纸卡配对与实体瓶灯为原创演绎。',prerequisites:['workshop_lights'],autoStart:true,
    stages:[
      {id:'find_labels',title:'先去公园拿空白瓶签',place:'park',hotspot:'park_bottle',text:'狐狸的分类是“我说得对”和“别人还没理解”。难鱼听完，决定亲自把瓶签重新写一遍。',requirements:[{id:'old_bottle',kind:'discovery',discoveryId:'park_bottle',label:'检查公园瓶签'}],choices:[
        {id:'blank_card',label:'拿一张空白瓶签',text:'难鱼翻到背面：“这面没写狐狸名言，能用。”',reward:{items:{blank_letter:1}}},
        {id:'erase_card',label:'把旧分类擦掉，换个标题',text:'“先看内容再下结论。”难鱼写完，顺手把狐狸的分类笔收走了。',reward:{items:{blank_letter:1}}},
      ]},
      {id:'pair_letters',title:'到河信箱配好纸卡',place:'river',hotspot:'river_bottle',text:'这些纸卡需要找到对应的图案。狐狸坚持自己的记性很好，刚说完就翻错一张。难鱼示意你接手。',quoteId:'bottle',requirements:[{id:'bottle_round',kind:'game',game:'bottle',label:'完成一轮纸瓶配对',minScore:0,count:1}],choices:[
        {id:'number_pairs',label:'按顺序给配对卡编号',text:'纸卡终于接上了。难鱼对狐狸说：记性那么好，下次别负责记性这部分。',reward:{items:{paired_card:1}}},
        {id:'picture_pairs',label:'用图案把配对卡夹在一起',text:'酒窝递来夹子。难鱼一边夹一边宣布：本次效率提升与狐狸保持距离有关。',reward:{items:{paired_card:1}}},
      ]},
      {id:'answer',title:'在码头写一句瓶签',place:'river',hotspot:'river_dock',text:'有一张写着“今天辛苦了”。难鱼先看了看背面，确认没有埋伏，才拿起笔。',requirements:[{id:'dock',kind:'discovery',discoveryId:'river_dock',label:'走到码头的小盒子旁'}],choices:[
        {id:'dry_reply',label:'写“知道了，下次也记得夸”',text:'嘴硬得很完整。狐狸看完说这封信很好认，难鱼让他少点评。',costItems:{blank_letter:1}},
        {id:'thank_reply',label:'只写一句“谢谢”',text:'难鱼写完迅速把纸折好，像怕谁抓住她有礼貌的证据。',costItems:{blank_letter:1}},
        {id:'keep_blank',label:'把瓶签折成小船，先不回',text:'纸船放进码头盒子。难鱼靠着栏杆看了一会儿水，难得没有催谁。',costItems:{blank_letter:1}},
      ]},
      {id:'hang_lantern',title:'把配好的纸卡送去观景台',place:'river',hotspot:'river_observatory',text:'把图案卡围成瓶灯的外罩，酒窝带来的灯芯正好装进去。狐狸又想给它起一个十七字的名字。',choices:[
        {id:'short_name',label:'贴一张“灯”字标签',text:'难鱼表示一个字已经够看懂。狐狸失去了今天第二次命名权。',costItems:{paired_card:1},reward:{items:{bottle_lantern:1}}},
        {id:'no_name',label:'保留卡片图案，让灯自己说话',text:'光从图案间透出来。难鱼这次没有点评，只说了一句“高级”。',costItems:{paired_card:1},reward:{items:{bottle_lantern:1}},quoteId:'nice'},
      ]},
    ],reward:{shells:24,bond:3,relations:{fox:3,jiuwo:1},flags:['river_ready']},ending:'观景台有了第一盏瓶灯。夜市摊牌还空着，轮到雨夜的词卡计划了。',
  },
  {
    id:'market_words',title:'把夜市切成英文模式',intro:'雨夜准备了物品词卡。难鱼说边用边认，比只盯着一页字靠谱；狐狸说自己已经会了。',friendIds:['rainnight','jin','fox'],source:'改编自2024-03难鱼向雨夜建议用英文游戏环境记词、向jin佬请教背文，以及2026-04联机英语交流。夜市标签是原创设计。',prerequisites:['river_letters'],autoStart:true,
    stages:[
      {id:'word_notes',title:'到课桌拿场景词卡',place:'school',hotspot:'school_desk',text:'词卡上是berry、bridge、bottle。雨夜把河岸照片放到旁边。难鱼指着瓶子：“刚做完的东西，你总不能马上不认识。”',requirements:[{id:'desk_cards',kind:'discovery',discoveryId:'school_desk',label:'翻看课桌词卡'}],choices:[
        {id:'picture_notes',label:'把词卡和物品图夹在一起',text:'雨夜收好卡夹，难鱼认真补上了刚才漏掉的一个词。',reward:{items:{word_card:1}}},
        {id:'sound_notes',label:'和jin佬一起念一遍再带走',text:'难鱼念完后催狐狸也来一遍。刚才说都会的人突然开始整理书包。',reward:{items:{word_card:1}}},
      ]},
      {id:'word_round',title:'去夜市摊认五张物品卡',place:'market',hotspot:'market_stall',text:'摊牌被风吹乱了。先把词和物品重新配好；看不懂可以重看，重点是把整轮做完。',requirements:[{id:'words_round',kind:'game',game:'words',label:'完成一轮场景词卡',minScore:0,count:1}],choices:[
        {id:'write_menu',label:'用词卡写双语小菜单',text:'难鱼把对上的标签贴好。狐狸想把自己的名字也翻译一下，被她忽略了。',costItems:{word_card:1},reward:{items:{bilingual_menu:1}}},
        {id:'draw_menu',label:'给双语小菜单补上物品图',text:'图、词、实物摆在一起，雨夜说这次一眼就能联想到。',costItems:{word_card:1},reward:{items:{bilingual_menu:1}}},
      ]},
      {id:'recipe_label',title:'去厨房检查最后一张标签',place:'kitchen',hotspot:'kitchen_recipe',text:'有人把recipe贴到了冰箱门上。难鱼问是谁，狐狸说概念上冰箱也是做饭的一部分。jin佬看了他一眼。',requirements:[{id:'recipe',kind:'discovery',discoveryId:'kitchen_recipe',label:'找到菜谱和标签'}],choices:[
        {id:'move_label',label:'把recipe移回菜谱',text:'难鱼把标签贴正：“概念上你也可以先闭嘴。”'},
        {id:'draw_arrow',label:'画一根大箭头指向菜谱',text:'箭头足够大，连狐狸都没有继续解释的空间了。'},
      ]},
      {id:'post_menu',title:'把菜单交给夜市点歌台',place:'market',hotspot:'market_stage',text:'猴正在招呼人：“那个，那个装吃的那个。”难鱼把菜单推过去，决定让今天新学的词立刻上岗。',choices:[
        {id:'post_front',label:'把菜单贴在台前',text:'猴终于能照着念。难鱼满意地退后一步，雨夜悄悄又复习了一遍。',costItems:{bilingual_menu:1}},
        {id:'counter_copy',label:'把菜单夹在台边，给猴当提词卡',text:'猴每忘一个词就往边上看。难鱼说这张卡今天工作量很大。',costItems:{bilingual_menu:1}},
      ]},
    ],reward:{shells:24,bond:3,relations:{rainnight:3,jin:1},flags:['words_ready']},ending:'夜市挂上了图文标签。写着recipe的那页菜谱，也终于该真的派上用场。',
  },
  {
    id:'shared_table',title:'说了随便，怎么还加菜',intro:'六个人给了七种菜单意见。难鱼决定先做一锅能吃的，再处理大家的“随便”。',friendIds:['rainnight','soup','monkey'],source:'改编自群内食物闲聊、2024-03雨夜提出补生日蛋糕而难鱼感谢后拒绝、4月继续讨论替代；本次拼桌筹备为原创情节。',prerequisites:['market_words'],autoStart:true,
    stages:[
      {id:'list',title:'去便利店检查拼桌清单',place:'shop',hotspot:'shop_fruit',text:'猴说“随便”，胡辣汤说“都行”，下一条又分别补了三个要求。难鱼把清单铺平：“我请问呢，随便是哪道菜？”',quoteId:'ask',requirements:[{id:'fruit',kind:'discovery',discoveryId:'shop_fruit',label:'查看采购篮'}],choices:[
        {id:'small_menu',label:'把清单缩成一份热饭和水果',text:'难鱼划掉第八条临时要求，只留下真正能端上桌的东西。',reward:{items:{grocery_card:1}}},
        {id:'divide_menu',label:'分工：我们做饭，让猴摆水果',text:'猴终于领到一个不会新增确认按钮的工作。',reward:{items:{grocery_card:1}}},
      ]},
      {id:'cook',title:'回厨房做一轮热饭',place:'kitchen',hotspot:'kitchen_recipe',text:'锅已经热了。难鱼盯着火候条，宣布自己负责点评，但最后还是把铲子递到了你手边。',requirements:[{id:'cook_round',kind:'game',game:'cook',label:'完成一轮火候小游戏',minScore:0,count:1}],choices:[
        {id:'box_meal',label:'按采购清单装好餐盒',text:'火候失误的部分一起调整过了。难鱼先尝一口，点评比之前小声了很多。',costItems:{grocery_card:1},reward:{items:{shared_meal:1}}},
        {id:'plain_meal',label:'按清单做成简简单单的一餐',text:'没有复杂摆盘。难鱼说盘子上的饭比盘子本身重要，这回很有道理。',costItems:{grocery_card:1},reward:{items:{shared_meal:1}}},
      ]},
      {id:'cake_offer',title:'在餐桌回应雨夜的小提议',place:'kitchen',hotspot:'kitchen_table',text:'雨夜问要不要再准备一份小甜点。难鱼先道谢，再看了看已经装满的桌子。这件事由她自己选。',choices:[
        {id:'fruit_bite',label:'留一小份水果就好',text:'难鱼把水果碟挪过来：“这个份量挺合理。”雨夜记下了她的选择。'},
        {id:'card_only',label:'只收祝福，甜点先不用',text:'“谢谢，但是不用了。”小卡片放在杯边，雨夜没有再劝第二遍。',quoteId:'thankyou'},
        {id:'another_day',label:'今天吃不下，改天再说',text:'雨夜把提议记到便条背面。难鱼把椅子往旁边挪了挪，叫他先来吃饭。'},
      ]},
      {id:'serve',title:'把餐盒送到夜市拼桌',place:'market',hotspot:'market_table',text:'胡辣汤已经摆好了筷子，猴还在和桌布较劲。难鱼端着餐盒走过去，嘴上说好慢，脚步倒是挺快。',choices:[
        {id:'serve_center',label:'把餐盒摆在桌子中间',text:'热饭揭开，刚才说不饿的人最先坐下。难鱼解释自己是在验收成果。',costItems:{shared_meal:1}},
        {id:'serve_portions',label:'请胡辣汤帮忙分好餐盒',text:'胡辣汤递来一份，难鱼接得很自然，过了一秒才补上一声谢谢。',costItems:{shared_meal:1}},
      ]},
    ],reward:{shells:24,bond:3,foods:{rice:1},relations:{rainnight:2,soup:2},flags:['table_ready']},ending:'拼桌有了热饭。大家吃着吃着，开始聊那些在联机世界里折腾过的作品。',
  },
  {
    id:'memory_exhibit',title:'这次展牌谁也别乱改',intro:'从旗帜馆到共同作品，难鱼已经有一整页可展示的东西。狐狸的笔必须暂时保管。',friendIds:['soup','jiuwo','fox'],source:'改编自2023年群友邀请难鱼建图、2024-03旗帜馆和纪念馆讨论及告示牌被改的冲突；展出本次游戏成果为原创串联。',prerequisites:['shared_table'],autoStart:true,
    stages:[
      {id:'collect_memory',title:'回小窝翻共同作品记录',place:'home',hotspot:'home_record',text:'本子里已经有作物筐、小灯和餐盒。难鱼翻到猴的催更记录，想了想，决定今天先展前半本。',requirements:[{id:'record',kind:'discovery',discoveryId:'home_record',label:'查看作品记录本'}],choices:[
        {id:'draw_objects',label:'画一页这几天做成的东西',text:'难鱼画的小灯有点歪，但每一件都能认出来。',reward:{items:{memory_page:1}}},
        {id:'write_captions',label:'给每件东西写一句吐槽',text:'第一页标题是“原来催更真的有用”。猴看见以后决定给你们递胶带。',reward:{items:{memory_page:1}}},
      ]},
      {id:'old_story',title:'在共同作品台聊聊小小展览',place:'workshop',hotspot:'workshop_project',text:'胡辣汤提起以前联机时那些奇奇怪怪的展馆。难鱼挑了一段讲，讲到一半还不忘纠正狐狸的版本。',requirements:[{id:'museum_story',kind:'story',storyId:'soup_museum',label:'读完或重温《客厅里的小小展览》'}],choices:[
        {id:'use_clips',label:'给记录页配上展示夹',text:'酒窝把夹子找齐。难鱼强调：夹子可以借，展牌不许顺手改。',reward:{items:{mounting_tabs:1}}},
        {id:'use_stands',label:'请酒窝做一个小纸板展架',text:'展架比上次的小，倒是很稳。难鱼说先做得出来，再考虑“大建筑师”头衔。',reward:{items:{mounting_tabs:1}}},
      ]},
      {id:'caption',title:'到公园野餐垫边整理说明卡',place:'park',hotspot:'park_picnic',text:'胡辣汤帮忙把记录页按住，狐狸试图在空白处写“本展由我指导”。难鱼当场抽走了笔。',requirements:[{id:'picnic',kind:'discovery',discoveryId:'park_picnic',label:'到野餐垫边整理材料'}],choices:[
        {id:'joint_credit',label:'写上真正参与的搭子',text:'谁分筐、谁做灯、谁端饭，写得明明白白。狐狸也分到一项：贡献错误示范。',costItems:{memory_page:1},reward:{items:{exhibit_card:1}}},
        {id:'work_titles',label:'只写作品名字，留一句集体吐槽',text:'“几个人总算做成了一点东西。”难鱼读完表示可以，句子里没夹带狐狸的功劳。',costItems:{memory_page:1},reward:{items:{exhibit_card:1}}},
      ]},
      {id:'install_exhibit',title:'把小展览摆到村务板旁',place:'village',hotspot:'village_board',text:'展示夹和说明卡都到了。难鱼把标题摆正，专门盯了狐狸两秒。狐狸非常自觉地把手背到身后。',choices:[
        {id:'front_row',label:'用展示夹挂出说明卡',text:'一排共同作品就位。难鱼端详半天：“还行，比那块破标题强。”',costItems:{mounting_tabs:1,exhibit_card:1}},
        {id:'low_row',label:'把说明卡夹低一点，路过就能看',text:'小展览挪到顺手的位置，连端着饭的人都能看见。难鱼觉得这个高度不错。',costItems:{mounting_tabs:1,exhibit_card:1}},
      ]},
    ],reward:{shells:28,bond:4,relations:{soup:2,jiuwo:2,fox:1},flags:['exhibition_ready']},ending:'村务板旁多了一排共同作品。再把最后一盏瓶灯送去夜市，就可以真的开场了。',
  },
  {
    id:'opening_night',title:'今天心情好，开场吧',intro:'公告、作物、灯、词卡、热饭和作品都到了。最后差的不是物资，是猴那篇过长的开场词。',friendIds:['monkey','fox','jiuwo','soup','rainnight','jin'],source:'原创改编终章；汇合联机共建、2025年群内跨年活动策划玩笑、英语互助和嘴硬感谢等原型，开村日不是真实历史事件。',prerequisites:['memory_exhibit'],autoStart:true,
    stages:[
      {id:'rain_plan',title:'先去公园亭子看看备用安排',place:'park',hotspot:'park_pavilion',text:'天气看着还行，难鱼却特意来检查雨棚。上次没带伞的事，谁提谁挨她一眼。',requirements:[{id:'pavilion',kind:'discovery',discoveryId:'park_pavilion',label:'检查亭子和公共伞'}],choices:[
        {id:'bring_umbrella',label:'记下伞的位置，再去河岸',text:'“这次不可能再忘。”难鱼说完还回头看了看伞。'},
        {id:'move_backup',label:'和酒窝把备用椅子挪到亭下',text:'雨棚下留好了位置。酒窝说这叫预案，难鱼说这叫终于长记性。'},
      ]},
      {id:'collect_light',title:'到观景台取最后一盏瓶灯',place:'river',hotspot:'river_observatory',text:'第一盏瓶灯还亮着。难鱼把你的那一盏拿好，看着河边多起来的光，短暂忘了催谁。',requirements:[{id:'observatory',kind:'discovery',discoveryId:'river_observatory',label:'沿河岸走到观景台'}],choices:[
        {id:'walk_slowly',label:'沿着河岸慢慢带灯回去',text:'难鱼走在旁边，提醒你别把灯碰歪。讲得比她自己端饭还认真。'},
        {id:'call_fox',label:'叫狐狸来扶灯，给他个正经活',text:'狐狸终于有了不会被划掉的贡献：扶稳这盏灯。'},
      ]},
      {id:'open_stage',title:'把瓶灯交给夜市点歌台',place:'market',hotspot:'market_stage',text:'猴的开场词还有三页。难鱼把灯往台上一放：“你念完饭都凉了，能不能只说重点？”',choices:[
        {id:'one_sentence',label:'挂好瓶灯，只说“开饭了”',text:'猴念了全场最受欢迎的三个字，大家的反应比彩排热烈得多。',costItems:{bottle_lantern:1},reward:{items:{festival_pass:1}}},
        {id:'shared_switch',label:'挂好瓶灯，请大家一起数三声',text:'灯亮起来，难鱼的嘴角动了一下。被看到以后，她说是风吹的。',costItems:{bottle_lantern:1},reward:{items:{festival_pass:1}}},
      ]},
      {id:'festival',title:'回村广场盖下最后一个鱼章',place:'village',hotspot:'village_square',text:'空广场现在有了箱筐、灯光和小展览。难鱼拿着印章走过来：“我心情好，先不骂你。”',quoteId:'greeting',choices:[
        {id:'front_seat',label:'把纪念票盖好，去热闹那边坐',text:'难鱼跟着过去，抢先找了个离饭最近的位置。她说这叫合理规划。'},
        {id:'quiet_seat',label:'把纪念票盖好，去边上看灯',text:'你们坐到边上，能听见猴还在讲被删掉的开场词。难鱼小声说：“幸亏坐得远。”'},
      ]},
    ],reward:{shells:40,bond:5,relations:{monkey:2,fox:2,jiuwo:2,soup:2,rainnight:2,jin:2},flags:['festival_ready']},ending:'开村日真的办起来了。共同作品和亮起的小灯留在村里，没逛完的地方、没听完的故事，明天还在。',
  },
  {
    id:'quiet_corner',title:'jin佬，今天先写到这里',intro:'工坊图纸算完了，课间角还坐着一个埋头改笔记的人。难鱼决定过去看两眼。',friendIds:['jin','fox'],source:'改编自2024年4月jin佬分享理解文章的方法、6月难鱼反过来鼓励jin佬；安静角布置是原创支线。',prerequisites:['workshop_lights'],
    stages:[
      {id:'desk_chat',title:'去课间角看看长文章',place:'school',hotspot:'school_club',text:'jin佬还在改笔记，狐狸又说“不背最快”。难鱼把狐狸的话当背景音，先问jin佬已经写到哪一段。',requirements:[{id:'club',kind:'discovery',discoveryId:'school_club',label:'查看课间角的分段笔记'}],choices:[
        {id:'small_step',label:'把下一步缩成一小段',text:'难鱼把后面的纸暂时翻过去，眼前终于只剩一件事。',reward:{items:{quiet_bookmark:1}}},
        {id:'pause_mark',label:'先夹上书签，稍后再接着写',text:'jin佬合上本子。难鱼说留个书签比下次从第一页找起强。',reward:{items:{quiet_bookmark:1}}},
      ]},
      {id:'terrace_pause',title:'去小窝露台透透气',place:'home',hotspot:'home_terrace',text:'风铃晃了一下。难鱼忽然说jin佬已经很优秀了，说完盯着远处，仿佛刚才开口的是风铃。',requirements:[{id:'terrace',kind:'discovery',discoveryId:'home_terrace',label:'找到露台的椅子'}],choices:[
        {id:'say_thanks',label:'替jin佬认真收下这句鼓励',text:'难鱼咳了一声：“知道了就行，别循环播放。”'},
        {id:'quiet_company',label:'不追问，陪她坐一会儿',text:'你没有拆穿她。风铃响了几次，难鱼先把椅背往后靠了靠。'},
      ]},
      {id:'leave_bookmark',title:'回课间角留下书签',place:'school',hotspot:'school_club',text:'书签还差一行字。狐狸提议写“不背最快”，难鱼说这条建议的出场次数已经超标了。',choices:[
        {id:'one_paragraph',label:'夹好书签，写“下次从这一段开始”',text:'书签停在刚才的位置。jin佬看了一眼，笑着把本子收好。',costItems:{quiet_bookmark:1}},
        {id:'already_good',label:'夹好书签，写“已经很好，明天继续”',text:'难鱼写得很快。狐狸刚想念出声，就被她用眼神按了静音。',costItems:{quiet_bookmark:1}},
      ]},
    ],reward:{shells:18,bond:4,relations:{jin:4,fox:1},flags:['quiet_ready']},ending:'课间角多了一张书签和一把空椅子。难鱼把鼓励说出口以后，仍然保留了嘴硬的部分。',
  },
  {
    id:'sticker_guestbook',title:'你懂不懂表情包艺术',intro:'酒窝想给留言本配几张贴纸。难鱼说自己的表情包没有一张没用，然后翻出了三张长得差不多的。',friendIds:['jiuwo','jin','monkey'],source:'改编自2023至2026年长期表情包使用、2024年难鱼自述制作经验和自嘲P图、2026年向jin老师要表情包；贴纸簿为原创支线。',prerequisites:['river_letters'],
    stages:[
      {id:'notice_request',title:'在便利店留言板看委托',place:'shop',hotspot:'shop_bulletin',text:'留言板写着“急需有用的表情包”。难鱼反问酒窝：有用是什么意思，震耳欲聋的沉默还不够有用吗？',requirements:[{id:'bulletin',kind:'discovery',discoveryId:'shop_bulletin',label:'读留言板上的贴纸委托'}],choices:[
        {id:'dry_stickers',label:'做一页“已阅、6、寒心”',text:'难鱼说三句话就够应付半天。酒窝觉得这个效率很有她的风格。',reward:{items:{sticker_sheet:1}}},
        {id:'warm_stickers',label:'做一页“谢谢、喵、搞好了”',text:'难鱼表示这些也在她的词库里，别搞得像发现了新物种。',reward:{items:{sticker_sheet:1}}},
      ]},
      {id:'test_sheet',title:'在共同作品台试排贴纸',place:'workshop',hotspot:'workshop_project',text:'猴把“寒心”贴到了饭盒图上。难鱼看一眼就把它挪走：“饭做得挺好，你先别替别人点评。”',requirements:[{id:'project',kind:'discovery',discoveryId:'workshop_project',label:'查看共同作品台'}],choices:[
        {id:'sort_tone',label:'把吐槽和感谢分成两列',text:'jin佬帮忙排齐。难鱼看着两列贴纸，承认这样找起来是快一点。'},
        {id:'mix_tone',label:'让每张吐槽旁边都跟一句感谢',text:'“寒心。谢谢。”难鱼念了一遍，自己先觉得这个组合很怪，又很合适。'},
      ]},
      {id:'place_sheet',title:'把贴纸页送到夜市长桌',place:'market',hotspot:'market_table',text:'长桌留言本终于等到贴纸。酒窝说每人先试一张，猴的手已经伸向最大的“6”。',choices:[
        {id:'public_book',label:'把整页贴纸夹进留言本',text:'第一张留言是“搞好了”。难鱼看完又补了一个小小的鱼脑袋。',costItems:{sticker_sheet:1}},
        {id:'table_cards',label:'把贴纸做成桌边的留言卡',text:'卡片一张张摆开。难鱼说别光夸艺术，谁路过谁写一句。',costItems:{sticker_sheet:1}},
      ]},
    ],reward:{shells:18,bond:3,relations:{jiuwo:3,jin:1},flags:['stickers_ready']},ending:'夜市长桌旁多了一本难鱼风格的留言簿：半页嫌弃，半页认真，哪半页都是她。',
  },
];
