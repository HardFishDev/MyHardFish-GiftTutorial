import * as THREE from 'three';
import type { Obstacle } from './environment';

type Bounds={minX:number;maxX:number;minZ:number;maxZ:number};
const directions=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]] as const;

/** Spatial collision buckets and an octile A* grid; no rendering or DOM dependencies. */
export class WorldNavigation {
  readonly points:THREE.Vector3[]=[];readonly valid:Uint8Array;
  readonly width:number;readonly height:number;readonly minX:number;readonly minZ:number;
  private buckets=new Map<string,Obstacle[]>();private binSize=4;
  constructor(readonly bounds:Bounds,readonly obstacles:readonly Obstacle[],readonly step=.5,readonly radius=.6) {
    this.minX=bounds.minX+radius+.02;this.minZ=bounds.minZ+radius+.02;
    this.width=Math.floor((bounds.maxX-this.minX-radius-.02)/step)+1;this.height=Math.floor((bounds.maxZ-this.minZ-radius-.02)/step)+1;
    for(const obstacle of obstacles)for(let z=Math.floor((obstacle.z-obstacle.d/2-radius)/this.binSize);z<=Math.floor((obstacle.z+obstacle.d/2+radius)/this.binSize);z++)for(let x=Math.floor((obstacle.x-obstacle.w/2-radius)/this.binSize);x<=Math.floor((obstacle.x+obstacle.w/2+radius)/this.binSize);x++){
      const key=`${x},${z}`,list=this.buckets.get(key)??[];list.push(obstacle);this.buckets.set(key,list);
    }
    this.valid=new Uint8Array(this.width*this.height);
    for(let z=0;z<this.height;z++)for(let x=0;x<this.width;x++){const p=new THREE.Vector3(this.minX+x*step,0,this.minZ+z*step);this.points.push(p);this.valid[z*this.width+x]=this.blocked(p.x,p.z)?0:1;}
  }
  blocked(x:number,z:number,margin=this.radius) {
    const b=this.bounds;if(x<b.minX+margin||x>b.maxX-margin||z<b.minZ+margin||z>b.maxZ-margin)return true;
    const candidates=margin<=this.radius?(this.buckets.get(`${Math.floor(x/this.binSize)},${Math.floor(z/this.binSize)}`)??[]):this.obstacles;
    return candidates.some(o=>Math.abs(x-o.x)<o.w/2+margin&&Math.abs(z-o.z)<o.d/2+margin);
  }
  clearSegment(a:{x:number;z:number},b:{x:number;z:number}) {
    if(this.blocked(a.x,a.z)||this.blocked(b.x,b.z))return false;
    const dx=b.x-a.x,dz=b.z-a.z;
    const minX=Math.min(a.x,b.x),maxX=Math.max(a.x,b.x),minZ=Math.min(a.z,b.z),maxZ=Math.max(a.z,b.z);
    // A sampled line can skip a very short intersection at a furniture corner.
    // Slab clipping tests the complete segment against the actor-expanded AABB;
    // the cheap bounds rejection keeps this allocation-free in path smoothing.
    for(const obstacle of this.obstacles){
      const left=obstacle.x-obstacle.w/2-this.radius,right=obstacle.x+obstacle.w/2+this.radius;
      const back=obstacle.z-obstacle.d/2-this.radius,front=obstacle.z+obstacle.d/2+this.radius;
      if(maxX<=left||minX>=right||maxZ<=back||minZ>=front)continue;
      let enter=0,exit=1;
      if(Math.abs(dx)>1e-12){const first=(left-a.x)/dx,last=(right-a.x)/dx;enter=Math.max(enter,Math.min(first,last));exit=Math.min(exit,Math.max(first,last));}
      else if(a.x<=left||a.x>=right)continue;
      if(Math.abs(dz)>1e-12){const first=(back-a.z)/dz,last=(front-a.z)/dz;enter=Math.max(enter,Math.min(first,last));exit=Math.min(exit,Math.max(first,last));}
      else if(a.z<=back||a.z>=front)continue;
      if(enter<exit-1e-12)return false;
    }
    return true;
  }
  nearest(x:number,z:number) {
    const cx=THREE.MathUtils.clamp(Math.round((x-this.minX)/this.step),0,this.width-1),cz=THREE.MathUtils.clamp(Math.round((z-this.minZ)/this.step),0,this.height-1);
    let best=-1,distance=Infinity;
    for(let radius=0;radius<Math.max(this.width,this.height);radius++){
      for(let dz=-radius;dz<=radius;dz++)for(let dx=-radius;dx<=radius;dx++){
        if(radius&&Math.abs(dx)!==radius&&Math.abs(dz)!==radius)continue;
        const ix=cx+dx,iz=cz+dz,id=iz*this.width+ix;if(ix<0||ix>=this.width||iz<0||iz>=this.height||!this.valid[id])continue;
        const p=this.points[id],d=(p.x-x)**2+(p.z-z)**2;if(d<distance){best=id;distance=d;}
      }
      if(best>=0&&(radius*this.step-this.step)>Math.sqrt(distance))break;
    }
    return best;
  }
  findPath(from:{x:number;z:number},x:number,z:number):THREE.Vector3[] {
    if(!Number.isFinite(x)||!Number.isFinite(z))return [];
    const goal=new THREE.Vector3(x,0,z);
    if(!this.blocked(x,z)&&this.clearSegment(from,goal))return[goal];
    const start=this.nearest(from.x,from.z),end=this.nearest(x,z);if(start<0||end<0)return[];
    const scores=new Float64Array(this.points.length).fill(Infinity),previous=new Int32Array(this.points.length).fill(-1),closed=new Uint8Array(this.points.length);
    const heap:{id:number;f:number}[]=[];
    const push=(id:number,f:number)=>{heap.push({id,f});let i=heap.length-1;while(i){const p=(i-1)>>1;if(heap[p].f<=heap[i].f)break;[heap[p],heap[i]]=[heap[i],heap[p]];i=p;}};
    const pop=()=>{const best=heap[0],last=heap.pop()!;if(heap.length){heap[0]=last;let i=0;for(;;){let next=i,l=i*2+1,r=l+1;if(l<heap.length&&heap[l].f<heap[next].f)next=l;if(r<heap.length&&heap[r].f<heap[next].f)next=r;if(next===i)break;[heap[i],heap[next]]=[heap[next],heap[i]];i=next;}}return best.id;};
    const ex=end%this.width,ez=Math.floor(end/this.width),heuristic=(id:number)=>{const dx=Math.abs(id%this.width-ex),dz=Math.abs(Math.floor(id/this.width)-ez);return Math.max(dx,dz)+(Math.SQRT2-1)*Math.min(dx,dz);};
    scores[start]=0;push(start,heuristic(start));let closest=start;
    while(heap.length){
      const id=pop();if(closed[id])continue;closed[id]=1;if(heuristic(id)<heuristic(closest))closest=id;if(id===end){closest=end;break;}
      const ix=id%this.width,iz=Math.floor(id/this.width);
      for(const [dx,dz]of directions){const nx=ix+dx,nz=iz+dz,next=nz*this.width+nx;if(nx<0||nx>=this.width||nz<0||nz>=this.height||!this.valid[next]||closed[next])continue;if(dx&&dz&&(!this.valid[iz*this.width+nx]||!this.valid[nz*this.width+ix]))continue;
        const cost=scores[id]+(dx&&dz?Math.SQRT2:1);if(cost>=scores[next])continue;scores[next]=cost;previous[next]=id;push(next,cost+heuristic(next));
      }
    }
    const reversed:THREE.Vector3[]=[];for(let id=closest;id>=0;id=previous[id])reversed.push(this.points[id].clone());const path=reversed.reverse();
    if(!this.blocked(x,z)&&path.length&&this.clearSegment(path[path.length-1],goal))path.push(goal);
    const simplified:THREE.Vector3[]=[];let origin=from,index=0;
    while(index<path.length){let far=index;while(far+1<path.length&&this.clearSegment(origin,path[far+1]))far++;if(!this.clearSegment(origin,path[far]))return[];simplified.push(path[far]);origin=path[far];index=far+1;}
    return simplified;
  }
}
