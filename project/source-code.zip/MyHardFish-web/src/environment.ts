import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import type { Place } from './scene';
import { buildSchool } from './environment-school';
import { buildKitchen, buildShop } from './environment-interiors';
import { buildPark } from './environment-park';
import { buildHomeTerrace } from './world-home-terrace';
import { OUTDOOR_PLACES, PLACE_LABELS, WORLD_EXITS, spotsForPlace } from './world-layout';
import { buildVillage } from './environment-village';
import { buildWorkshop, buildRiver, buildMarket } from './environment-districts';
import type { WorldSeatDefinition } from './world-activity-anchors';
import type { WorldActivityKind } from './world-activities';
import { addWorldInteractions } from './world-interaction-props';

type XYZ = [number, number, number];
type Surface = 'wood' | 'plaster' | 'fabric' | 'stone' | 'tile' | 'metal';
export interface Obstacle { x:number; z:number; w:number; d:number; }
export interface EnvironmentLighting {
  outdoor:boolean; fog:string; fogNear:number; fogFar:number;
  sun:string; sunIntensity:number; ambientIntensity:number;sky?:string;
}
export interface Environment {
  root:THREE.Group; walkable:THREE.Object3D[]; hotspots:THREE.Object3D[];
  seats:WorldSeatDefinition[];
  obstacles:Obstacle[]; bounds:{minX:number;maxX:number;minZ:number;maxZ:number};
  spawn:THREE.Vector3; background:string; lighting:EnvironmentLighting;
  entries:Partial<Record<Place,{x:number;z:number;facing:number}>>;
  camera?:{desktop:XYZ;mobile:XYZ};
  navigationStep:number; heightAt(x:number,z:number):number; dispose():void;
}

// A deterministic grain keeps saved worlds visually consistent across reloads.
function texture(kind:Surface) {
  const canvas=document.createElement('canvas');canvas.width=canvas.height=256;
  const c=canvas.getContext('2d')!;c.fillStyle='#ffffff';c.fillRect(0,0,256,256);
  let seed=47;const random=()=>{seed=(seed*16807)%2147483647;return seed/2147483647;};
  if(kind==='wood') {
    for(let i=0;i<650;i++){const y=random()*256;c.strokeStyle=`rgba(61,39,20,${random()*.16})`;c.lineWidth=.2+random()*.7;c.beginPath();c.moveTo(0,y);c.bezierCurveTo(70,y+random()*9,190,y-random()*7,256,y+random()*3);c.stroke();}
    for(let y=0;y<256;y+=64){c.fillStyle='rgba(57,42,28,.16)';c.fillRect(0,y,256,1);c.fillRect((y*3)%256,y,1,64);}
  } else if(kind==='tile') {
    c.fillStyle='#d9d7cc';c.fillRect(0,0,256,256);c.fillStyle='#fffef8';
    for(let y=0;y<2;y++)for(let x=0;x<2;x++)c.fillRect(x*128+2,y*128+2,124,124);
  } else if(kind==='fabric') {
    for(let i=0;i<256;i+=3){c.fillStyle=i%2?'rgba(80,60,40,.06)':'rgba(80,60,40,.11)';c.fillRect(i,0,1,256);c.fillRect(0,i,256,1);}
  } else {
    for(let i=0;i<10000;i++){const v=Math.floor(155+random()*100);c.fillStyle=`rgba(${v},${v},${v},${kind==='stone'?.24:.1})`;const s=kind==='stone'?1+random()*3:1;c.fillRect(random()*256,random()*256,s,s);}
  }
  const t=new THREE.CanvasTexture(canvas);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=4;return t;
}

export class EnvironmentBuilder {
  root=new THREE.Group(); walkable:THREE.Object3D[]=[];hotspots:THREE.Object3D[]=[];obstacles:Obstacle[]=[];
  seats:WorldSeatDefinition[]=[];
  bounds={minX:-10.2,maxX:10.2,minZ:-10.2,maxZ:10.2};spawn=new THREE.Vector3(0,0,1.5);background='#d5e2db';
  lighting:EnvironmentLighting={outdoor:false,fog:'#e3ddce',fogNear:44,fogFar:110,sun:'#ffe6c2',sunIntensity:2.3,ambientIntensity:1.65};
  entries:Environment['entries']={};navigationStep=.42;chunkSize=0;
  camera:Environment['camera'];
  occluder(id:string,parent:THREE.Object3D=this.root){const group=new THREE.Group();group.name=id;group.userData.cameraOccluder=true;parent.add(group);return group;}
  flagGroup(flag:string){const group=new THREE.Group();group.userData.worldFlag=flag;this.root.add(group);return group;}
  private materials=new Map<string,THREE.MeshStandardMaterial>();private textures=new Map<Surface,THREE.Texture>();
  private transient=new Set<THREE.Texture>();
  private backWall:THREE.Mesh|undefined;
  private treeMaterial:THREE.MeshStandardMaterial|undefined;
  private elevations:{x:number;z:number;w:number;d:number;y:number|((x:number,z:number)=>number)}[]=[];
  elevation(x:number,z:number,w:number,d:number,y:number){this.elevations.push({x,z,w,d,y});}
  heightZone(x:number,z:number,w:number,d:number,heightAt:(x:number,z:number)=>number){this.elevations.push({x,z,w,d,y:heightAt});}
  material(color:string,kind:Surface='plaster') {
    const key=color+kind;let m=this.materials.get(key);if(m)return m;
    let map=this.textures.get(kind);if(!map){map=texture(kind);this.textures.set(kind,map);}
    m=new THREE.MeshStandardMaterial({color,map,roughness:kind==='metal'?.3:kind==='stone'?.62:.87,metalness:kind==='metal'?.55:0});this.materials.set(key,m);return m;
  }
  mesh(geometry:THREE.BufferGeometry,pos:XYZ,color:string,kind:Surface='plaster',parent:THREE.Object3D=this.root):THREE.Mesh<THREE.BufferGeometry,THREE.Material> {
    const m=new THREE.Mesh(geometry,this.material(color,kind));m.position.set(...pos);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;
  }
  box(size:XYZ,pos:XYZ,color:string,radius=.04,parent:THREE.Object3D=this.root) {
    return this.mesh(radius>0?new RoundedBoxGeometry(...size,2,Math.min(radius,...size.map(n=>n/2))):new THREE.BoxGeometry(...size),pos,color,'plaster',parent);
  }
  surface(size:XYZ,pos:XYZ,color:string,kind:Surface,radius=.035,parent:THREE.Object3D=this.root) {
    const m=this.box(size,pos,color,radius,parent);m.material=this.material(color,kind);return m;
  }
  cylinder(top:number,bottom:number,height:number,pos:XYZ,color:string,parent:THREE.Object3D=this.root) {
    return this.mesh(new THREE.CylinderGeometry(top,bottom,height,20),pos,color,'plaster',parent);
  }
  sphere(scale:XYZ,pos:XYZ,color:string,parent:THREE.Object3D=this.root) {
    const m=this.mesh(new THREE.SphereGeometry(1,16,12),pos,color,'plaster',parent);m.scale.set(...scale);return m;
  }
  torus(radius:number,tube:number,pos:XYZ,color:string,parent:THREE.Object3D=this.root) {
    return this.mesh(new THREE.TorusGeometry(radius,tube,6,40),pos,color,'plaster',parent);
  }
  obstacle(x:number,z:number,w:number,d:number){this.obstacles.push({x,z,w,d});}
  hotspot(id:string,label:string,pos:XYZ,size:XYZ,parent:THREE.Object3D=this.root) {
    const m=new THREE.Mesh(new THREE.BoxGeometry(...size),new THREE.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false,colorWrite:false}));m.position.set(...pos);m.userData.action=id;m.userData.label=label;m.userData.keep=true;parent.add(m);this.hotspots.push(m);return m;
  }
  seat(id:string,contact:XYZ,approach:XYZ,options:{parent?:THREE.Object3D;facing?:number;width?:number;depth?:number;hotspot?:THREE.Object3D;surface?:XYZ;target?:XYZ;kinds?:readonly WorldActivityKind[]}={}) {
    const parent=options.parent??this.root;
    const point=(name:string,at:XYZ)=>{const p=new THREE.Object3D();p.name=name;p.position.set(...at);parent.add(p);return p;};
    const seatContact=point(`seat:${id}`,contact);seatContact.rotation.y=options.facing??0;
    const hotspot=options.hotspot??this.hotspot('rest','坐下来歇一会儿',[contact[0],contact[1]+.25,contact[2]],[options.width??1.1,1.7,options.depth??1.1],parent);
    const seat:WorldSeatDefinition={id,contact:seatContact,approach:point(`seat-approach:${id}`,approach),width:options.width??1.1,depth:options.depth??1.1,hotspot,kinds:options.kinds??['sit','read','write','eat','talk']};
    if(options.surface)seat.surface=point(`seat-surface:${id}`,options.surface);
    if(options.target)seat.target=point(`seat-target:${id}`,options.target);
    this.seats.push(seat);return seat;
  }
  label(text:string,pos:XYZ,width:number,color='#445b50',bg='#f5eed9',parent:THREE.Object3D=this.root) {
    const c=document.createElement('canvas');c.width=768;c.height=384;const ctx=c.getContext('2d')!;ctx.fillStyle=bg;ctx.fillRect(0,0,768,384);ctx.fillStyle=color;ctx.font='600 70px "Noto Sans CJK SC", sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';
    const lines=text.split('\n');lines.forEach((line,i)=>ctx.fillText(line,384,192+(i-(lines.length-1)/2)*95,700));
    const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;this.transient.add(t);
    const m=new THREE.Mesh(new THREE.PlaneGeometry(width,width/2),new THREE.MeshStandardMaterial({map:t,roughness:1}));m.position.set(...pos);parent.add(m);return m;
  }
  plant(x:number,z:number,scale=1,parent:THREE.Object3D=this.root) {
    const g=new THREE.Group();g.position.set(x,0,z);g.scale.setScalar(scale);parent.add(g);
    this.cylinder(.4,.3,.68,[0,.34,0],'#c79e7e',g);this.cylinder(.36,.36,.03,[0,.69,0],'#4e4636',g);
    for(let i=0;i<11;i++){const a=i*2.399;const h=.9+i*.12;const dx=Math.sin(a)*(.3+i*.02),dz=Math.cos(a)*(.3+i*.02);const stem=this.cylinder(.018,.022,h-.6,[dx*.4,(h+.6)/2,dz*.4],'#547345',g);stem.rotation.z=-dx*.35;const leaf=this.sphere([.16,.39,.055],[dx,h,dz],i%3?'#607f4b':'#879662',g);leaf.rotation.set(Math.cos(a)*.7,a,Math.sin(a)*.85);}
    return g;
  }
  table(x:number,z:number,w:number,d:number,h=1.35) {
    this.surface([w,.14,d],[x,h,z],'#b68c60','wood',.045);
    for(const dx of [-w*.39,w*.39])for(const dz of [-d*.34,d*.34])this.surface([.12,h,.12],[x+dx,h/2,z+dz],'#927355','wood');this.obstacle(x,z,w,d);
  }
  book(x:number,y:number,z:number,color:string,w=.2,h=.55,d=.38,parent:THREE.Object3D=this.root) {
    this.box([w,h,d],[x,y+h/2,z],color,.014,parent);this.box([w*.7,.025,.012],[x,y+h*.72,z+d/2+.008],'#eadfcc',.001,parent);
  }
  cup(x:number,y:number,z:number,color='#e6dfca',parent:THREE.Object3D=this.root) {
    this.cylinder(.14,.115,.24,[x,y+.12,z],color,parent);this.cylinder(.11,.11,.009,[x,y+.245,z],'#675141',parent);const handle=this.torus(.087,.026,[x+.15,y+.13,z],color,parent);handle.rotation.y=Math.PI/2;
  }
  bench(x:number,z:number,rotation=0) {
    const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=rotation;this.root.add(g);
    for(let i=0;i<4;i++)this.surface([3.4,.1,.18],[0,.74,-.32+i*.21],'#b79971','wood',.025,g);
    for(let i=0;i<3;i++)this.surface([3.4,.19,.09],[0,1.02+i*.22,-.48],'#b79971','wood',.02,g);
    for(const x of [-1.27,1.27]){this.surface([.1,.85,.65],[x,.42,0],'#414d45','metal',.02,g);this.surface([.1,1.42,.1],[x,.73,-.47],'#414d45','metal',.02,g);}
    const c=Math.abs(Math.cos(rotation)),s=Math.abs(Math.sin(rotation));this.obstacle(x,z,3.6*c+1.3*s,3.6*s+1.3*c);const hotspot=this.hotspot('rest','坐一会儿',[0,.8,0],[3.5,1.6,1.2],g);
    this.seat(`bench:${x}:${z}`,[0,.79,.18],[0,0,1.65],{parent:g,width:3.2,depth:.74,hotspot});return g;
  }
  tree(x:number,z:number,scale=1) {
    const g=new THREE.Group();g.position.set(x,0,z);g.scale.setScalar(scale);this.root.add(g);
    this.cylinder(.16,.32,3.4,[0,1.7,0],'#827460',g);
    for(let i=0;i<4;i++){const a=i*2.4;const branch=this.cylinder(.055,.11,1.8,[Math.sin(a)*.42,2.6,Math.cos(a)*.42],'#827460',g);branch.rotation.z=Math.sin(a)*.55;branch.rotation.x=Math.cos(a)*.55;this.sphere([1.35,1.45,1.3],[Math.sin(a)*.72,3.7+(i%2)*.45,Math.cos(a)*.72],['#74916a','#839a70','#9aa77a','#678260'][i],g);}
    // One mesh per tree allows the camera to remove obstructing foreground canopies.
    // Vertex colours retain all foliage shades without making every leaf a draw call.
    const parts:THREE.BufferGeometry[]=[];
    for(const object of g.children){if(!(object instanceof THREE.Mesh))continue;object.updateMatrix();let geometry=object.geometry.clone();if(geometry.index){const expanded=geometry.toNonIndexed();geometry.dispose();geometry=expanded;}geometry.applyMatrix4(object.matrix);const count=geometry.getAttribute('position').count,colors=new Float32Array(count*3),color=(object.material as THREE.MeshStandardMaterial).color;for(let i=0;i<count;i++)colors.set([color.r,color.g,color.b],i*3);geometry.setAttribute('color',new THREE.BufferAttribute(colors,3));parts.push(geometry);object.geometry.dispose();}
    g.clear();const merged=mergeGeometries(parts)!;parts.forEach(part=>part.dispose());
    if(!this.treeMaterial){this.treeMaterial=this.material('#ffffff').clone();this.treeMaterial.vertexColors=true;}
    const tree=new THREE.Mesh(merged,this.treeMaterial);tree.castShadow=true;tree.receiveShadow=true;tree.userData.keep=true;g.add(tree);g.userData.tree=true;g.userData.canopyRadius=2.45*scale;g.userData.canopyHeight=3.65*scale;
    this.obstacle(x,z,.75*scale,.75*scale);return g;
  }
  floor(color='#d4bd95',kind:Surface='wood',size=64) {
    const m=this.surface([size,.24,size],[0,-.14,0],color,kind,.0);const floorMaterial=(m.material as THREE.MeshStandardMaterial).clone();const floorMap=floorMaterial.map!.clone();floorMap.repeat.set(size/3,size/3);this.transient.add(floorMap);floorMaterial.map=floorMap;m.material=floorMaterial;m.castShadow=false;this.walkable.push(m);
  }
  walls(color='#e6e2d2') {
    const back=this.surface([38,8,.25],[3,3.95,-11],'#e3decf','plaster',0);back.userData.keep=true;back.userData.wallAxis='z';this.backWall=back;const left=this.surface([.25,8,38],[-11,3.95,3],color,'plaster',0);left.userData.keep=true;left.userData.wallAxis='x';
    this.surface([23.8,.18,.12],[.1,.14,-10.8],'#f5eedb','wood',.01);this.surface([.12,.18,23.8],[-10.8,.14,.1],'#f5eedb','wood',.01);
    // Continuous picture rail and restrained wall panelling add architectural scale.
    this.surface([23.8,.06,.06],[0,1.22,-10.81],'#c9c8b4','wood',.01);
    for(let x=-10;x<12;x+=2)this.box([.035,1.03,.035],[x,.68,-10.8],'#d4d2c0',.004);
  }
  window(x:number,z=-10.76,width=7,height=3.65,y=3.6) {
    // A true opening gives outdoor trees parallax when the player rotates the camera.
    // The surrounding wall remains independently removable for the cutaway camera.
    if(this.backWall){
      this.backWall.removeFromParent();this.backWall.geometry.dispose();this.backWall=undefined;
      const left=x-width/2,right=x+width/2,bottom=y-height/2,top=y+height/2;
      for(const [w,h,px,py] of [[left+16,8,(-16+left)/2,3.95],[22-right,8,(22+right)/2,3.95],[width,bottom+.05,x,(bottom-.05)/2],[width,7.95-top,x,(top+7.95)/2]]){
        const wall=this.surface([w,h,.25],[px,py,-11],'#e3decf','plaster',0);wall.userData.keep=true;wall.userData.wallAxis='z';
      }
      this.surface([64,.13,25],[0,-.045,-24],'#9aaa83','plaster',0).castShadow=false;
      for(const [tx,tz,scale] of [[x-5,-18,1.55],[x+2,-20,1.8],[x+7,-23,1.75],[x-11,-24,2.0]])this.tree(tx,tz,scale);
      for(let i=0;i<12;i++)this.sphere([1.15,.6,.85],[x-12+i*2.1,.4,-15.2-(i%3)*.7],i%2?'#a4b393':'#829b77');
      for(let i=0;i<4;i++){
        const bx=x-18+i*10,bz=-33-(i%2)*3;
        this.surface([7.4,5.2,5.5],[bx,2.5,bz],i%2?'#d7d4bd':'#c5cebf','plaster',.08);
        const roof=this.mesh(new THREE.ConeGeometry(5.6,2.2,4),[bx,6.15,bz],'#9ba99d');roof.rotation.y=Math.PI/4;roof.scale.z=.85;
        for(const wx of [-2,0,2])this.surface([.75,1.1,.06],[bx+wx,3.2,bz+2.79],'#a3b9af','metal',.025);
      }
    }
    for(const sign of [-1,1]){
      this.surface([width+.36,.18,.22],[x,y+sign*(height/2+.09),z],'#f8f2df','wood',.035);
      this.surface([.18,height+.18,.22],[x+sign*(width/2+.09),y,z],'#f8f2df','wood',.035);
    }
    const glass=new THREE.Mesh(new THREE.PlaneGeometry(width,height),new THREE.MeshPhysicalMaterial({color:'#e2eee6',transparent:true,opacity:.11,roughness:.16,metalness:.05,depthWrite:false,side:THREE.DoubleSide}));glass.position.set(x,y,z+.09);glass.userData.keep=true;this.root.add(glass);
    for(const xx of [-width/2,0,width/2])this.surface([.09,height,.1],[x+xx,y,z+.23],'#f8f2df','wood',.01);
    this.surface([width,.09,.1],[x,y-.25,z+.24],'#f8f2df','wood',.01);this.surface([width+.55,.16,.55],[x,y-height/2-.06,z+.2],'#f6edd8','wood',.025);
    for(const sign of [-1,1])for(let i=0;i<6;i++){this.surface([.17,height+.48,.18],[x+sign*(width/2+.1)+i*.1,y+.06,z+.28],i%2?'#a9b7a0':'#b8c3a9','fabric',.07);}
    this.cylinder(.025,.025,width+1,[x,y+height/2+.29,z+.23],'#bda778').rotation.z=Math.PI/2;
  }
  finish():Environment {
    // Merge static props by material, keeping collision proxies separately pickable.
    this.root.updateMatrixWorld(true);const buckets=new Map<string,{material:THREE.Material;geometries:THREE.BufferGeometry[];shadow:boolean;receive:boolean;flag?:string;owner?:THREE.Object3D}>();const remove:THREE.Mesh[]=[];const originals=new Set<THREE.BufferGeometry>();
    this.root.traverse(o=>{if(!(o instanceof THREE.Mesh)||o.userData.keep||this.walkable.includes(o)||Array.isArray(o.material))return;
      const center=new THREE.Vector3().setFromMatrixPosition(o.matrixWorld);
      const cell=this.chunkSize?`${Math.floor(center.x/this.chunkSize)},${Math.floor(center.z/this.chunkSize)}`:'';
      let flag:string|undefined,owner:THREE.Object3D|undefined;for(let parent:THREE.Object3D|null=o;parent;parent=parent.parent){if(parent.userData.worldFlag)flag=String(parent.userData.worldFlag);if(!owner&&parent.userData.cameraOccluder)owner=parent;}
      const key=o.material.uuid+o.castShadow+o.receiveShadow+cell+(flag??'')+(owner?.uuid??'');let bucket=buckets.get(key);if(!bucket){bucket={material:o.material,geometries:[],shadow:o.castShadow,receive:o.receiveShadow,flag,owner};buckets.set(key,bucket);}
      let g=o.geometry.clone();g.applyMatrix4(owner?new THREE.Matrix4().copy(owner.matrixWorld).invert().multiply(o.matrixWorld):o.matrixWorld);if(g.index){const expanded=g.toNonIndexed();g.dispose();g=expanded;}g.deleteAttribute('uv1');g.deleteAttribute('tangent');bucket.geometries.push(g);originals.add(o.geometry);remove.push(o);
    });
    for(const o of remove)o.removeFromParent();for(const g of originals)g.dispose();
    for(const b of buckets.values()){const g=mergeGeometries(b.geometries,false);b.geometries.forEach(g=>g.dispose());if(!g)continue;const m=new THREE.Mesh(g,b.material);m.castShadow=b.shadow;m.receiveShadow=b.receive;if(b.flag)m.userData.worldFlag=b.flag;(b.owner??this.root).add(m);}
    const root=this.root;const textures=this.textures;const transient=this.transient;const pooledMaterials=this.materials;const elevations=this.elevations;
    return {root,walkable:this.walkable,hotspots:this.hotspots,seats:this.seats,obstacles:this.obstacles,bounds:this.bounds,spawn:this.spawn,background:this.background,lighting:this.lighting,entries:this.entries,camera:this.camera,navigationStep:this.navigationStep,heightAt(x,z){let y=0;for(const p of elevations)if(Math.abs(x-p.x)<=p.w/2&&Math.abs(z-p.z)<=p.d/2)y=Math.max(y,typeof p.y==='number'?p.y:p.y(x,z));return y;},dispose(){const materials=new Set<THREE.Material>();root.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose();(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>materials.add(m));}});pooledMaterials.forEach(m=>materials.add(m));const allTextures=new Set<THREE.Texture>([...textures.values(),...transient]);materials.forEach(m=>{for(const value of Object.values(m))if(value instanceof THREE.Texture)allTextures.add(value);m.dispose();});allTextures.forEach(t=>t.dispose());root.clear();}};
  }
}

export function buildHome(b:EnvironmentBuilder) {
  b.floor('#cdb591');b.walls();b.window(-3.7,-10.76,7.9,3.55,3.78);
  const daylight=document.createElement('canvas');daylight.width=512;daylight.height=512;const dc=daylight.getContext('2d')!;
  const sunGlow=dc.createLinearGradient(0,0,0,512);sunGlow.addColorStop(0,'rgba(255,232,177,.2)');sunGlow.addColorStop(.35,'rgba(255,230,164,.28)');sunGlow.addColorStop(1,'rgba(255,233,183,0)');dc.fillStyle=sunGlow;
  for(let x=0;x<3;x++)dc.fillRect(x*171+12,0,150,490);
  const daylightMap=new THREE.CanvasTexture(daylight);daylightMap.colorSpace=THREE.SRGBColorSpace;
  const patch=new THREE.Mesh(new THREE.PlaneGeometry(8,11),new THREE.MeshBasicMaterial({map:daylightMap,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1}));patch.rotation.x=-Math.PI/2;patch.rotation.z=.13;patch.position.set(-2.3,.045,-3.2);b.root.add(patch);
  // A generous linen sofa, cushions and softly rounded piping.
  const sofa=new THREE.Group();sofa.position.set(-4.9,0,-5.3);b.root.add(sofa);
  for(const x of [-2.3,2.3])for(const z of [-.65,.65])b.surface([.15,.3,.15],[x,.2,z],'#795e45','wood',.025,sofa);
  b.surface([5.9,.54,1.95],[0,.56,0],'#b9bba4','fabric',.2,sofa);b.surface([5.9,1.22,.38],[0,1.17,-.8],'#bcc0a9','fabric',.17,sofa);
  for(const x of [-2.76,2.76])b.surface([.42,.86,1.98],[x,.95,0],'#b7bca3','fabric',.16,sofa);
  for(let i=0;i<3;i++){const x=-1.8+i*1.8;b.surface([1.74,.22,1.48],[x,.93,.05],'#d2d2bb','fabric',.1,sofa);b.surface([1.71,.75,.32],[x,1.34,-.51],'#c8cbb3','fabric',.15,sofa);}
  for(const [x,color,rz] of [[-1.9,'#bf866c',.14],[1.7,'#dbc6a0',-.2]] as const){const p=b.surface([.85,.82,.29],[x,1.37,-.2],color,'fabric',.15,sofa);p.rotation.z=rz;p.rotation.x=-.15;}
  const blanket=b.surface([1.13,.045,1.75],[.68,1.066,.3],'#eee3c7','fabric',.02,sofa);blanket.rotation.y=.08;
  b.obstacle(-4.9,-5.3,6.1,2.25);const sofaSpot=b.hotspot('rest','躺平一会儿',[-4.9,1,-5.3],[6,2,2.2]);b.seat('home-sofa',[-4.9,1.04,-4.95],[-4.9,0,-3.35],{width:1.7,depth:1.48,hotspot:sofaSpot});
  // Woven carpet, border bands and a low oval oak coffee table.
  b.surface([7.7,.033,6.1],[-3.9,.018,-1.65],'#d6d3b6','fabric',.07);
  for(const sign of [-1,1]){b.surface([7.35,.008,.05],[-3.9,.039,-1.65+sign*2.79],'#a8ad91','fabric',.01);b.surface([.05,.008,5.59],[-3.9+sign*3.66,.039,-1.65],'#a8ad91','fabric',.01);}
  const coffeeStart=b.root.children.length;
  const table=b.cylinder(1.24,1.24,.16,[-4.9,.93,-1.9],'#c4a078');table.scale.x=1.6;table.material=b.material('#c4a078','wood');
  for(const x of [-5.9,-3.9])b.surface([.26,.85,.62],[x,.47,-1.9],'#a78865','wood',.08);
  b.obstacle(-4.9,-.65,4.0,2.5);b.cup(-4.1,1.02,-1.7);const book=b.surface([.95,.085,.65],[-5.32,1.06,-1.91],'#718378','fabric',.02);book.rotation.y=-.18;b.label('摸鱼手册',[-5.32,1.106,-1.91],.72).rotation.x=-Math.PI/2;
  b.cylinder(.38,.32,.06,[-4.8,1.045,-2.24],'#e2dac4');for(let i=0;i<3;i++)b.sphere([.13,.11,.13],[-4.98+i*.17,1.14,-2.24],i%2?'#d2ac62':'#bb8568');
  const coffeeParts=b.root.children.slice(coffeeStart);const coffee=new THREE.Group();coffee.position.z=1.25;b.root.add(coffee);coffeeParts.forEach(part=>coffee.add(part));
  const reading=b.hotspot('read','翻开摸鱼手册',[-5.32,1.48,-.66],[1.3,.8,1]);reading.userData.approach=[-4.9,-3.35];
  // A side table, warm lamp and record player turn the room into a lived-in home.
  b.table(-9,-5.4,1.45,1.35,1.11);b.cylinder(.22,.3,.1,[-9,1.23,-5.4],'#b99763');const tableLamp=b.occluder('home-table-lamp');b.cylinder(.035,.045,1.15,[-9,1.77,-5.4],'#a98c5f',tableLamp);b.cylinder(.34,.64,.62,[-9,2.3,-5.4],'#ead9b5',tableLamp);
  b.plant(-9.4,-8.5,1.4);b.obstacle(-9.4,-8.5,1.3,1.3);b.plant(9.3,-9,1.5);b.obstacle(9.3,-9,1.5,1.5);
  // Wall-length bookcase with varied books, ceramic vases and a village noticeboard.
  b.surface([4.8,3.75,.68],[4.8,1.88,-10.22],'#bfa787','wood',.05);
  for(let shelf=0;shelf<4;shelf++){const y=.22+shelf*.88;b.surface([4.66,.1,.76],[4.8,y,-10.15],'#d9c4a2','wood',.025);for(let i=0;i<13;i++){if((i+shelf)%5===0)continue;b.book(2.72+i*.32,y+.06,-10.0,['#71877c','#b39476','#d7b580','#84949a','#ba8f7c'][i%5],.22,.48+(i%3)*.11,.37);}}
  b.obstacle(4.8,-10.1,4.9,1);b.surface([2.15,1.17,.1],[1.0,3.65,-10.76],'#ac8962','wood',.04);b.label('老母猪村\n今日也要快乐摸鱼',[1,3.65,-10.69],1.96,'#4a6152','#e8dac0');b.hotspot('friends','群友留言板',[1,3.65,-10.62],[2.2,1.3,.4]);
  // A warm reading corner has its own low chair and a shaded floor lamp.
  const armchair=new THREE.Group();armchair.position.set(-7.7,0,1.9);armchair.rotation.y=.25;b.root.add(armchair);
  b.surface([1.8,.43,1.73],[0,.54,0],'#c6977c','fabric',.18,armchair);b.surface([1.78,1.1,.31],[0,1.03,-.72],'#cb9d80','fabric',.16,armchair);b.surface([1.34,.18,1.32],[0,.82,.05],'#d7ab8c','fabric',.11,armchair);
  for(const side of [-1,1]){b.surface([.29,.57,1.67],[side*.85,.94,0],'#c99a7d','fabric',.13,armchair);for(const z of [-.6,.6])b.surface([.1,.3,.1],[side*.66,.18,z],'#795f49','wood',.02,armchair);}
  b.obstacle(-7.7,1.9,2.2,2);const chairSpot=b.hotspot('rest','窝进小沙发',[-7.7,.9,1.9],[2.15,1.8,2]);b.seat('home-reading-chair',[0,.91,.25],[0,0,1.8],{parent:armchair,width:1.34,depth:1.32,hotspot:chairSpot});
  b.cylinder(.43,.47,.08,[-1.4,.04,-6.7],'#807863');const floorLamp=b.occluder('home-reading-lamp');b.cylinder(.035,.047,3.22,[-1.4,1.65,-6.7],'#918269',floorLamp);b.cylinder(.4,.67,.69,[-1.4,3.16,-6.7],'#e4d3ad',floorLamp);b.obstacle(-1.4,-6.7,.8,.8);
  b.surface([.83,.08,.58],[-5.87,1.095,-.19],'#c89878','fabric',.02).rotation.y=.2;
  b.surface([.7,.052,.49],[-5.87,1.158,-.19],'#e6d5b4','fabric',.02).rotation.y=-.1;
  // Writing corner: laptop, chair, stationery, shelving and an invitation to chat.
  b.table(6.65,-5.1,4.2,1.65,1.42);b.surface([.99,.055,.73],[6.6,1.54,-5.0],'#818d88','metal',.025);const screen=b.surface([.99,.67,.045],[6.6,1.86,-5.36],'#455a50','metal',.03);screen.rotation.x=-.15;b.label('群聊进行中',[6.6,1.86,-5.325],.85,'#d9e8cf','#455a50');b.cup(7.91,1.52,-5.02,'#be9974');
  b.surface([1.08,.16,1.05],[6.65,.84,-3.7],'#b88970','fabric',.15);b.surface([1.08,.93,.15],[6.65,1.27,-3.24],'#bb8c74','fabric',.1);for(const x of [-.4,.4])for(const z of [-.36,.36])b.cylinder(.035,.045,.8,[6.65+x,.4,-3.7+z],'#6b6457');b.obstacle(6.65,-3.7,1.2,1.3);b.hotspot('friends','看一眼群聊',[6.6,1.9,-5.0],[1.5,1,.9]);b.seat('home-writing-chair',[6.65,.92,-3.8],[5.25,0,-3.55],{facing:Math.PI,width:1.08,depth:1.05,surface:[6.65,1.49,-5.1],target:[6.6,1.6,-5]});
  b.surface([2.6,.1,.45],[6.7,3.73,-10.49],'#c1a883','wood');b.plant(5.8,-10.36,.4).position.y=3.78;
  // Wardrobe / changing corner and a framed fish print.
  // The upper cabinet can block the writing chair from a side-front camera.
  // Its low base and the independent collision/hotspot remain in place.
  const wardrobeUpper=b.occluder('home-wardrobe-upper');
  b.surface([2.5,1.14,1.22],[9.15,.58,-3.5],'#c9b69a','wood',.07);
  b.surface([2.5,2.76,1.22],[9.15,2.53,-3.5],'#c9b69a','wood',.07,wardrobeUpper);
  for(const dx of [-.62,.62]){b.surface([1.19,1.025,.06],[9.15+dx,.6375,-2.86],'#dac8ac','wood',.035);b.surface([1.19,2.705,.06],[9.15+dx,2.5025,-2.86],'#dac8ac','wood',.035,wardrobeUpper);b.cylinder(.032,.032,.38,[9.15+dx*.24,1.94,-2.8],'#8d7c5e',wardrobeUpper);}b.obstacle(9.15,-3.5,2.6,1.4);b.hotspot('closet','换一身心情',[9.15,1.9,-3.3],[2.6,3.9,1.4]);
  b.surface([1.9,1.07,.08],[-10.76,3.7,-3.9],'#a48b67','wood',.03).rotation.y=Math.PI/2;
  const picture=b.label('好好生活\n慢慢摸鱼',[-10.69,3.7,-3.9],1.72,'#526b59','#eae3cc');picture.rotation.y=Math.PI/2;
  // Foreground greenery and entry mat complete the space beyond the central play area.
  b.plant(8.1,5.4,1.4);b.obstacle(8.1,5.4,1.6,1.6);b.surface([2.8,.025,1.5],[-6.5,.02,7.7],'#a9b39a','fabric');b.surface([2.6,.86,.8],[-9.25,.45,3.1],'#bda686','wood',.045);b.obstacle(-9.25,3.1,2.8,1);b.plant(-9.1,3.2,.5).position.y=.9;
  b.hotspot('story','房间里的小故事',[-4.9,1.2,-.65],[3.6,.5,2]);
}

export function buildEnvironment(place:Place,extra?:(place:Place,b:EnvironmentBuilder)=>void):Environment {
  const b=new EnvironmentBuilder();
  const outdoor=OUTDOOR_PLACES.includes(place);
  if(outdoor)b.lighting={outdoor:true,fog:'#cfdbc6',fogNear:50,fogFar:145,sun:'#fff0cb',sunIntensity:3.0,ambientIntensity:1.85};
  if(place==='village')buildVillage(b);
  else if(place==='workshop')buildWorkshop(b);
  else if(place==='river')buildRiver(b);
  else if(place==='market')buildMarket(b);
  else if(place==='home'){buildHome(b);buildHomeTerrace(b);}
  else {
    b.floor(outdoor?'#879d74':place==='school'?'#c8b58e':'#d7c7a8',outdoor?'plaster':place==='kitchen'?'tile':'wood',outdoor?70:64);
    if(outdoor){b.bounds={minX:-17,maxX:17,minZ:-17,maxZ:17};b.background='#d4dfcc';}
    else b.walls(place==='school'?'#d4dccb':'#e8e2d1');
    if(place==='school')buildSchool(b);
    else if(place==='kitchen')buildKitchen(b);
    else if(place==='shop')buildShop(b);
    else if(place==='park')buildPark(b);
    else if(extra)extra(place,b);
    else {b.bench(-5,-5);b.plant(7,-6,2);b.label('村口的风',[0,3.5,-10.7],4);}
  }
  registerGeography(b,place);
  addWorldInteractions(b,place);
  return b.finish();
}

function registerGeography(b:EnvironmentBuilder,place:Place) {
  for(const exit of WORLD_EXITS[place]) {
    const g=new THREE.Group();g.position.set(exit.x,0,exit.z);g.rotation.y=exit.rotation??0;b.root.add(g);
    const indoor=!OUTDOOR_PLACES.includes(place),width=indoor?1.55:3.8,doorHeight=indoor?3.95:5.55;
    // A legible physical threshold, with no invisible automatic teleports.
    b.surface([width,.055,1.15],[0,.038,0],indoor?'#b5ac8c':'#d8c9a6','stone',.03,g);
    for(const side of [-1,1]){
      b.surface([.10,doorHeight,.10],[side*(width/2),doorHeight/2,0],'#718575','wood',.025,g);
      b.obstacle(exit.x+Math.cos(g.rotation.y)*side*width/2,exit.z-Math.sin(g.rotation.y)*side*width/2,.13,.13);
    }
    b.surface([width+.25,.25,.22],[0,doorHeight-.05,0],'#718575','wood',.03,g);
    b.label(PLACE_LABELS[exit.to],[0,indoor?3.55:4.65,.13],width-.16,'#eae5ca','#536e61',g);
    const hotspot=b.hotspot(`travel:${exit.to}`,`前往${PLACE_LABELS[exit.to]}`,[exit.x,doorHeight/2,exit.z],[indoor?1.45:3.3,doorHeight,1.3]);
    hotspot.rotation.y=g.rotation.y;hotspot.userData.approach=exit.approach;hotspot.userData.kind='travel';hotspot.userData.radius=2.1;
    b.entries[exit.to]={x:exit.approach[0],z:exit.approach[1],facing:Math.atan2(exit.approach[0]-exit.x,exit.approach[1]-exit.z)};
  }
  for(const spot of spotsForPlace(place)) {
    const y=spot.y??1.7;
    const hotspot=b.hotspot(`adventure:${spot.id}`,spot.label,[spot.x,y+.25,spot.z],[.85,.85,.85]);
    hotspot.userData.approach=spot.approach;hotspot.userData.kind='adventure';hotspot.userData.radius=2.5;
    const seal=b.cylinder(.15,.15,.065,[spot.x,y+.55,spot.z],'#d9b978');seal.rotation.x=Math.PI/2;seal.userData.keep=true;seal.userData.action=`adventure:${spot.id}`;seal.userData.label=spot.label;hotspot.userData.marker=seal;
    const stamp=b.box([.06,.12,.075],[spot.x,y+.55,spot.z+.06],'#fff4ca',.012);stamp.rotation.z=.16;
  }
  if(place==='home'){
    const stickers=b.flagGroup('stickers_ready');
    for(let i=0;i<5;i++){const note=b.surface([.24,.25,.018],[.3+i*.33,3.15,-10.58],['#e0bf87','#b9caa0','#ccaa90'][i%3],'fabric',.03,stickers);note.rotation.z=(i-2)*.055;}
  }
  if(place==='school'){
    const words=b.flagGroup('words_ready');
    for(let i=0;i<3;i++)b.label(['milk · 牛奶','berry · 浆果','friend · 朋友'][i],[7.75,1.85-i*.42,-10.48],2.3,'#d9e3c7','#34584d',words);
  }
}
