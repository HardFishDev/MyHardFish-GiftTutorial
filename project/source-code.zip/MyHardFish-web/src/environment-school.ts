import * as THREE from 'three';
import type { EnvironmentBuilder } from './environment';

/** A lived-in village classroom, with generous aisles around the playable character. */
export function buildSchool(b: EnvironmentBuilder) {
  const wood = '#bf9670', steel = '#667b77', paper = '#eee8d3';
  // A long chalkboard has actual chalk grain, erased writing and lesson notes.
  b.surface([14.2, 3.3, .17], [0, 3.95, -10.69], '#8c7455', 'wood', .025);
  b.surface([13.85, 2.96, .045], [0, 3.95, -10.57], '#34584d', 'plaster', .01);
  const canvas = document.createElement('canvas'); canvas.width = 1536; canvas.height = 384;
  const c = canvas.getContext('2d')!;
  c.fillStyle = '#34584d'; c.fillRect(0, 0, 1536, 384);
  let seed=391; const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647;};
  for(let i=0;i<9000;i++){c.fillStyle=`rgba(220,231,202,${rnd()*.09})`;c.fillRect(rnd()*1536,rnd()*384,1+rnd()*3,1);}
  c.fillStyle='#e2e6cd';c.font='500 56px "Noto Sans CJK SC",sans-serif';c.fillText('五题就下课',66,82);
  c.strokeStyle='#bccab2'; c.lineWidth=2;c.beginPath();c.moveTo(66,101);c.lineTo(608,101);c.stroke();
  c.font='35px "Noto Sans CJK SC",sans-serif';
  c.fillText('先做一点，做完就溜。',66,163);
  c.fillStyle='#d7d4a0';c.font='32px monospace';c.fillText('12 + 8 = ?       6 × 7 = ?',68,237);c.fillText('32 − 9 = ?       9 + 5 = ?',68,292);
  c.strokeStyle='#779889';c.beginPath();c.moveTo(785,36);c.lineTo(785,340);c.stroke();
  c.fillStyle='#dde4ca';c.font='33px "Noto Sans CJK SC",sans-serif';c.fillText('课间群聊',864,77);
  c.font='26px "Noto Sans CJK SC",sans-serif';c.fillStyle='#b9d2c1';c.fillText('jin佬：先读懂，再慢慢背。',866,139);c.fillStyle='#e0cfa2';c.fillText('狐狸：不背最快。',866,194);c.fillStyle='#e5e7d4';c.fillText('难鱼：谢谢大师。',866,249);c.fillStyle='#a9bcaa';c.fillText('今日值日  ·  自愿摸鱼小组',866,320);
  const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=4;
  const board=new THREE.Mesh(new THREE.PlaneGeometry(13.58,2.8),new THREE.MeshStandardMaterial({map:texture,roughness:1}));board.position.set(0,3.95,-10.538);b.root.add(board);
  b.surface([14.2,.1,.3],[0,2.28,-10.48],'#8e795d','wood',.016);
  for(let i=0;i<5;i++){const chalk=b.cylinder(.02,.02,.2,[-2.3+i*.12,2.35,-10.4],i%2?'#d8b4a0':'#ecebdc');chalk.rotation.z=Math.PI/2;}
  b.surface([.32,.065,.16],[4.4,2.37,-10.42],'#bd9c6a','wood');
  b.hotspot('math','五道题，写完就下课',[0,3.8,-10.4],[13.8,3,.45]);
  // Big, layered windows and deep sills make sunlight a part of the architecture.
  for(const z of [-5,3.8]) {
    const g=new THREE.Group();g.position.set(-10.78,3.66,z);g.rotation.y=Math.PI/2;b.root.add(g);
    b.surface([5.8,3.5,.13],[0,0,0],'#ede8d7','wood',.015,g);
    const glass=b.box([5.55,3.23,.025],[0,0,.086],'#b6d1c7',0,g);glass.material=new THREE.MeshBasicMaterial({color:'#c7ddd2'});
    for(let i=0;i<7;i++)b.sphere([.55,.53,.025],[-2.45+i*.8,-1.15+(i%3)*.14,.105],i%2?'#9bb399':'#acc0a5',g).castShadow=false;
    for(const x of [-2.7,-.9,.9,2.7])b.surface([.08,3.25,.07],[x,0,.14],'#f3eedb','wood',.01,g);
    b.surface([5.55,.08,.06],[0,-.27,.145],'#f3eedb','wood',.01,g);
    b.surface([6,.14,.55],[0,-1.79,.21],'#e7ddbf','wood',.02,g);
    const rod=b.cylinder(.025,.025,6.2,[0,1.93,.18],'#8b947f',g);rod.rotation.z=Math.PI/2;
    for(const side of [-1,1])for(let fold=0;fold<5;fold++)b.surface([.14,3.82,.15],[side*(2.62+fold*.13),-.04,.2],fold%2?'#b2c1b1':'#c5ceba','fabric',.055,g);
  }
  // School desks, under-desk racks, blue chairs, books, pencils and school bags.
  const desk=(x:number,z:number,index:number)=> {
    const g=new THREE.Group();g.position.set(x,0,z);b.root.add(g);
    b.surface([2.65,.14,1.55],[0,1.35,0],wood,'wood',.045,g);
    b.surface([2.32,.42,1.21],[0,1.06,-.04],'#b0926d','wood',.03,g);
    b.surface([2.08,.25,.018],[0,1.1,.58],'#6c6951','wood',.005,g);
    for(const dx of [-1.05,1.05]) {
      b.surface([.1,1.2,.1],[dx,.62,.04],steel,'metal',.015,g);
      b.surface([.35,.06,1.55],[dx,.06,.04],steel,'metal',.02,g);
      b.surface([2.13,.07,.07],[0,.44,-.52],steel,'metal',.01,g);
    }
    const chairZ=1.2;
    b.surface([1.12,.12,.95],[0,.78,chairZ],'#769a98','wood',.09,g);
    b.surface([1.12,.66,.1],[0,1.22,chairZ+.42],'#769a98','wood',.09,g);
    for(const dx of [-.42,.42])for(const dz of [-.32,.32])b.surface([.065,.74,.065],[dx,.39,chairZ+dz],steel,'metal',.01,g);
    for(const dx of [-.42,.42])b.surface([.065,1.16,.065],[dx,.96,chairZ+.42],steel,'metal',.01,g);
    // Each desk gets a different composition of open pages or closed exercise books.
    const exercise=new THREE.Group();exercise.position.set(-.42,1.448,-.12);exercise.rotation.y=(index%3-1)*.15;g.add(exercise);
    b.surface([.93,.045,.71],[0,0,0],['#c89c7e','#6f958e','#afba8c'][index%3],'fabric',.018,exercise);
    b.surface([.86,.015,.63],[0,.031,0],paper,'plaster',.007,exercise);
    for(let line=0;line<5;line++)b.box([.67,.003,.007],[0,.041,-.23+line*.095],'#b9c4b1',0,exercise);
    b.box([.007,.004,.59],[-.27,.044,0],'#c19f91',0,exercise);
    const pencil=b.cylinder(.018,.018,.63,[.55,1.455,.02],index%2?'#a48153':'#758c77',g);pencil.rotation.z=Math.PI/2;pencil.rotation.y=.4;
    if(index%3===0) {b.cylinder(.11,.095,.38,[.9,1.57,-.41],'#a0b3a5',g);for(let pen=0;pen<4;pen++){const p=b.cylinder(.012,.012,.48,[.86+(pen%2)*.065,1.86,-.45+Math.floor(pen/2)*.065],['#b99161','#7a9895','#b67567','#829662'][pen],g);p.rotation.z=(pen-1)*.09;}}
    if(index%3===1){b.cylinder(.085,.085,.34,[.96,1.6,-.38],'#d1c09e',g);b.cylinder(.088,.088,.055,[.96,1.79,-.38],'#6f8b7d',g);}
    if(index%4===0){const bag=b.surface([.71,.77,.32],[.73,.79,chairZ+.34],'#b49572','fabric',.12,g);bag.rotation.z=-.16;b.surface([.51,.36,.055],[.75,.66,chairZ+.54],'#c0a47d','fabric',.06,g);const strap=b.torus(.2,.022,[.69,1.26,chairZ+.31],'#806f58',g);strap.scale.y=1.6;}
    b.obstacle(x,z+.42,2.8,3.0);
    b.seat(`school-desk:${index}`,[0,.84,1.1],[x>7?-2.08:2.08,0,1.1],{parent:g,facing:Math.PI,width:1.12,depth:.95,surface:[0,1.42,0],target:[-.2,1.48,.05]});
  };
  let i=0;for(const z of [-6.7,-1.5,4.4])for(const x of [-6.85,-2.55,3.6,8])desk(x,z,i++);
  // Teacher's desk, a reading light, and a globe assembled from real curved geometry.
  b.table(6.35,-9,3.5,1.25,1.6);
  for(let k=0;k<4;k++)b.surface([.86,.065,.59],[5.48,1.72+k*.063,-9.05],['#a29374','#718c80','#bcab87','#899d8b'][k],'fabric',.013);
  b.cup(7.5,1.7,-9.04,'#d4c6aa');
  b.cylinder(.26,.32,.09,[6.72,1.71,-9.1],'#8b7759');b.cylinder(.022,.022,.54,[6.72,1.98,-9.1],'#b89e6c');
  const globe=new THREE.Group();globe.position.set(6.72,2.3,-9.1);globe.rotation.z=-.3;b.root.add(globe);
  b.sphere([.37,.37,.37],[0,0,0],'#8db3b2',globe);
  for(let r=0;r<3;r++){const ring=b.torus(.375,.009,[0,0,0],'#c7d9b8',globe);ring.rotation.y=r*Math.PI/3;}
  const equator=b.torus(.375,.012,[0,0,0],'#ccb585',globe);equator.rotation.x=Math.PI/2;
  const axis=b.torus(.43,.022,[0,0,0],'#ae9873',globe);axis.rotation.y=Math.PI/2;
  b.hotspot('story:grammar_club','和jin佬读一小段',[6.35,1.9,-9],[3.6,1.3,1.4]);
  // A real analogue clock, switch plates, and a village club bulletin board.
  const clockFace=b.cylinder(.51,.51,.035,[8.65,4.86,-10.68],'#e8e6d0');clockFace.rotation.x=Math.PI/2;
  b.torus(.52,.034,[8.65,4.86,-10.645],'#657e72');
  for(let n=0;n<12;n++){const a=n*Math.PI/6;const tick=b.box([.025,.075,.018],[8.65+Math.sin(a)*.43,4.86+Math.cos(a)*.43,-10.617],'#5d7566',.001);tick.rotation.z=-a;}
  const hour=b.box([.04,.26,.023],[8.65,4.96,-10.59],'#526a5c',.005);hour.rotation.z=-.4;
  const minute=b.box([.025,.37,.026],[8.8,4.88,-10.57],'#526a5c',.005);minute.rotation.z=-1.35;
  b.sphere([.045,.045,.018],[8.65,4.86,-10.555],'#ba8d6a');
  const notice=new THREE.Group();notice.position.set(-10.7,3.48,8.9);notice.rotation.y=Math.PI/2;b.root.add(notice);
  b.surface([3.2,2.05,.1],[0,0,0],'#a18765','wood',.03,notice);
  b.surface([2.98,1.83,.03],[0,0,.07],'#c3ad87','fabric',.01,notice);
  b.label('自习室来信\n今天已经很好了',[0,.36,.1],2.28,'#536e5b','#ebe4cf',notice);
  for(let n=0;n<3;n++){const note=b.surface([.71,.61,.01],[-.94+n*.94,-.54,.103],['#e0cd9e','#c6d3b7','#d8b8a4'][n],'plaster',.003,notice);note.rotation.z=(n-1)*.05;b.sphere([.025,.025,.018],[-.94+n*.94,-.28,.129],'#8c9f81',notice);}
  b.hotspot('friends','课间看一眼群友留言',[-10.6,3.4,8.9],[.5,2.2,3.3]);
  b.surface([.24,.35,.05],[10.42,1.5,-10.81],'#e5e3d0','plaster',.02);
  for(const x of [10.36,10.47])b.surface([.07,.18,.018],[x,1.52,-10.77],'#f4edd6','plaster',.005);
  // Low storage, plants, dustpan and orderly stacks of communal books.
  b.surface([1.58,1.7,2.7],[-9.75,.86,-8.1],'#af9b78','wood',.03);b.obstacle(-9.75,-8.1,1.8,2.9);
  for(let n=0;n<7;n++)b.book(-9.4,1.75,-9.14+n*.29,['#8ea08d','#b49b7f','#c4b590'][n%3],.4,.53,.22);
  b.plant(-9.8,7,.82);b.obstacle(-9.8,7,1,1);
  b.plant(9.5,-9.1,.8);b.obstacle(9.5,-9.1,1.1,1.1);
  for(const x of [-5.5,3.1])for(const z of [-6.5,2]) {
    const fixture=b.occluder(`school-light:${x}:${z}`);
    b.surface([2.8,.095,.43],[x,5.75,z],'#e8e3cf','metal',.025,fixture);
    const light=b.box([2.53,.025,.29],[x,5.688,z],'#fdf4cf',.01,fixture);light.material=new THREE.MeshBasicMaterial({color:'#fff4d2'});light.castShadow=false;
    for(const dx of [-1,1])b.cylinder(.01,.01,.65,[x+dx,6.1,z],'#9faaa0',fixture);
  }
}
