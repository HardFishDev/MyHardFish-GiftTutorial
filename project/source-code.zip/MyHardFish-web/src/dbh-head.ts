import * as THREE from 'three';
import { createDbhHair } from './dbh-hair';
import { createDbhFace } from './dbh-face-sculpt';
import { mesh } from './dbh-geometry';

/** The face is a continuous skin sculpt with separate anatomical eyes and articulating lids. */
export function createDbhHead(skin: THREE.Material) {
  const root = new THREE.Group(); root.name = 'dbh-sculpted-head';
  root.userData.textureStatus = 'ready';
  const face = createDbhFace(); root.add(face.root);
  const earMaterial=(skin as THREE.MeshStandardMaterial).clone();
  earMaterial.color.set('#ffffff');earMaterial.vertexColors=true;
  for(const side of [-1,1]){
    // Ear cartilage is a continuous relief facing outwards, with its rim embedded in the head.
    const ep:number[]=[],ec:number[]=[],ei:number[]=[],rings=20,sectors=64;
    const baseColor=new THREE.Color('#f7cbbb'),concha=new THREE.Color('#d99587');
    const addEarVertex=(r:number,a:number,back=false)=>{
      const u=r*Math.sin(a),v=r*Math.cos(a);
      const soft=(x:number,y:number,cx:number,cy:number,wx:number,wy:number)=>Math.exp(-(((x-cx)/wx)**2+((y-cy)/wy)**2));
      // Helix fades toward the attached front margin; the internal Y-shaped
      // antihelix and tragus make this an asymmetric ear instead of an oval rim.
      const attachment=THREE.MathUtils.smoothstep(u,.12,.72)*Math.exp(-((v/.50)**2));
      const helix=.009*Math.exp(-(((r-.81)/.13)**2))*(1-.70*attachment);
      const antihelix=.005*Math.exp(-(((u-(-.28+.26*v+.12*v*v))/.12)**2))*Math.exp(-(((v-.07)/.74)**4));
      const branch=.0035*soft(u,v,.06,.39,.32,.12);
      const conchaWell=.0045*soft(u,v,.18,-.06,.38,.44);
      const tragus=.0055*soft(u,v,.57,-.08,.18,.24);
      const lobule=.0025*soft(u,v,-.04,-.72,.52,.28);
      const depth=.021+.004*Math.sqrt(Math.max(0,1-r*r))+helix+antihelix+branch+tragus+lobule-conchaWell;
      const height=v>=0?.083:.079;
      const width=.046*(1-.10*v-.18*Math.max(0,-v));
      ep.push(side*(back?.222:.238+depth),.425+height*v+.003*u*(1-v*v),-.130+width*u-.007*v+.003*v*v);
      const warmth=.46*soft(u,v,.12,-.02,.48,.62)+.13*soft(u,v,-.25,.43,.5,.4);
      const color=baseColor.clone().lerp(concha,back?0:warmth);ec.push(color.r,color.g,color.b);
    };
    const tri=(a:number,b:number,c:number)=>side>0?ei.push(a,b,c):ei.push(a,c,b);
    addEarVertex(0,0);
    for(let ring=1;ring<=rings;ring++)for(let s=0;s<sectors;s++)addEarVertex(ring/rings,s/sectors*Math.PI*2);
    for(let s=0;s<sectors;s++)tri(0,1+s,1+(s+1)%sectors);
    for(let ring=1;ring<rings;ring++)for(let s=0;s<sectors;s++){
      const a=1+(ring-1)*sectors+s,b=1+(ring-1)*sectors+(s+1)%sectors,c=a+sectors,d=b+sectors;
      tri(a,c,b);tri(b,c,d);
    }
    const backStart=ep.length/3;
    for(let s=0;s<sectors;s++)addEarVertex(1,s/sectors*Math.PI*2,true);
    const backCenter=ep.length/3;addEarVertex(0,0,true);
    for(let s=0;s<sectors;s++){
      const a=1+(rings-1)*sectors+s,b=1+(rings-1)*sectors+(s+1)%sectors,c=backStart+s,d=backStart+(s+1)%sectors;
      tri(a,c,b);tri(b,c,d);tri(backCenter,d,c);
    }
    const earGeometry=new THREE.BufferGeometry();earGeometry.setAttribute('position',new THREE.Float32BufferAttribute(ep,3));earGeometry.setAttribute('color',new THREE.Float32BufferAttribute(ec,3));earGeometry.setIndex(ei);earGeometry.computeVertexNormals();
    const ear=mesh(root,earGeometry,earMaterial);ear.name=`dbh-sculpted-ear-${side}`;
    ear.receiveShadow=false;ear.userData.unbatched=true;
  }
  const hair = createDbhHair(); root.add(hair.root);
  function update(t: number, dt: number, action: string, yaw = 0, pitch = 0) {
    face.update(t, dt, action, yaw, pitch);
    hair.update(t, dt, action);
  }
  const dispose = () => { face.dispose(); hair.dispose(); };
  return { root, update, dispose };
}
