import { DBH_CLUES, DBH_GIFTS, DBH_TOPICS } from './dbh-content';
import type { DbhAction } from './dbh-content';
import type { Place } from './scene';

export type DbhState = {
  schema: 1;
  credited: string[];
  quest: { status: 'available' | 'active' | 'completed'; visited: string[]; answers: Record<string, string> };
  memories: string[];
};
export type DbhEvent =
  | { type: 'greet' }
  | { type: 'talk'; topic: string }
  | { type: 'action'; action: DbhAction }
  | { type: 'craft'; gift: string }
  | { type: 'startQuest' }
  | { type: 'answer'; clue: string; answer: string }
  | { type: 'finishQuest' };

const creditIds = new Set(['greet', ...DBH_TOPICS.map(topic => `talk:${topic.id}`), ...['dance', 'stretch', 'photo', 'cheer'].map(action => `action:${action}`), ...DBH_GIFTS.map(gift => `craft:${gift.id}`)]);
const memoryForCredit: Record<string, string> = { greet: 'first_meeting', 'action:dance': 'dance', 'action:photo': 'photo', 'craft:paper_star': 'paper_star', 'craft:leaf_bookmark': 'leaf_bookmark' };
const object = (value: unknown): Record<string, unknown> => value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};
const strings = (value: unknown) => Array.isArray(value) ? value.slice(0, 64).filter((v): v is string => typeof v === 'string') : [];

export function createDbhState(): DbhState {
  return { schema: 1, credited: [], quest: { status: 'available', visited: [], answers: {} }, memories: [] };
}

/** Bounded, versioned save data. Memories and relationship are derived from valid events. */
export function normalizeDbhState(value: unknown): DbhState {
  const raw = object(value);
  if (raw.schema !== 1) return createDbhState();
  const credited = [...new Set(strings(raw.credited).filter(id => creditIds.has(id)))];
  const quest = object(raw.quest);
  const status = quest.status === 'active' || quest.status === 'completed' ? quest.status : 'available';
  const visited = status === 'available' ? [] : [...new Set(strings(quest.visited).filter(id => DBH_CLUES.some(clue => clue.hotspot === id)))];
  const rawAnswers = object(quest.answers);
  const answers: Record<string, string> = {};
  for (const clue of DBH_CLUES) {
    const answer = rawAnswers[clue.id];
    if (visited.includes(clue.hotspot) && typeof answer === 'string' && clue.options.some(option => option.id === answer)) answers[clue.id] = answer;
  }
  const complete = status === 'completed' && DBH_CLUES.every(clue => visited.includes(clue.hotspot) && answers[clue.id] === clue.answer);
  const memories = credited.map(id => memoryForCredit[id]).filter(Boolean);
  if (complete) memories.push('village_walk');
  return { schema: 1, credited, quest: { status: status === 'completed' && !complete ? 'active' : status, visited, answers }, memories };
}

/** Call only when an actual in-world exploration spot has been opened/reached. */
export function recordDbhVisit(input: DbhState, place: Place, hotspot?: string): DbhState {
  const state = normalizeDbhState(input);
  if (place !== 'village' || state.quest.status !== 'active' || !hotspot || !DBH_CLUES.some(clue => clue.hotspot === hotspot) || state.quest.visited.includes(hotspot)) return state;
  return { ...state, quest: { ...state.quest, visited: [...state.quest.visited, hotspot] } };
}

export function applyDbhInteraction(input: DbhState, event: DbhEvent): DbhState {
  const state = normalizeDbhState(input);
  let credit: string | undefined;
  if (event.type === 'greet') credit = 'greet';
  if (event.type === 'talk') credit = `talk:${event.topic}`;
  if (event.type === 'action') credit = event.action === 'wave' ? 'greet' : `action:${event.action}`;
  if (event.type === 'craft') credit = `craft:${event.gift}`;
  if (credit && creditIds.has(credit) && !state.credited.includes(credit)) state.credited.push(credit);
  if (event.type === 'startQuest' && state.quest.status === 'available') state.quest.status = 'active';
  if (event.type === 'answer' && state.quest.status === 'active') {
    const clue = DBH_CLUES.find(item => item.id === event.clue);
    if (clue && state.quest.visited.includes(clue.hotspot) && clue.options.some(option => option.id === event.answer)) state.quest.answers[clue.id] = event.answer;
  }
  if (event.type === 'finishQuest' && state.quest.status === 'active' && DBH_CLUES.every(clue => state.quest.visited.includes(clue.hotspot) && state.quest.answers[clue.id] === clue.answer)) state.quest.status = 'completed';
  return normalizeDbhState(state);
}

export function dbhFriendship(input: DbhState) {
  const state = normalizeDbhState(input);
  const points = state.credited.length + (state.quest.status === 'completed' ? 3 : 0);
  return { points, label: points >= 8 ? '合拍的搭子' : points >= 4 ? '熟悉的村友' : '初次见面', next: points < 4 ? 4 : points < 8 ? 8 : 14 };
}
