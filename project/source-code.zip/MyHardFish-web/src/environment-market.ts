import * as THREE from 'three';
import type { EnvironmentBuilder } from './environment';
import { path, boundaryForest, building, lamp, flowerBed, crate, pennants } from './world-town-props';

export function buildMarket(b:EnvironmentBuilder) {
  b.bounds={minX:-28,maxX:28,minZ:-28,maxZ:28};b.chunkSize=14;b.navigationStep=.5;b.floor('#9da584','plaster',118);boundaryForest(b,30,64);b.spawn.set(0,0,16);
  path(b,0,0,8.6,53);path(b,0,12,52,5.2);path(b,0,-9,44,4.3);path(b,-15,1,4.5,39);path(b,15,1,4.5,39);
  // Late afternoon: lantern colour without losing the pale character's face in darkness.
  b.lighting={outdoor:true,fog:'#c3c6b5',fogNear:48,fogFar:140,sun:'#f5d3a1',sunIntensity:2.0,ambientIntensity:1.85,sky:'#c9cec4'};
  const stall=(x:number,z:number,color:string,label:string,goods:'food'|'craft'|'drinks')=>{
    const g=new THREE.Group();g.position.set(x,0,z);b.root.add(g);
    b.surface([4.7,1.28,2.5],[0,.66,0],'#b5a17a','wood',.06,g);b.surface([5,.16,2.8],[0,1.38,0],'#d7bd92','wood',.045,g);
    for(const dx of [-2.2,2.2])for(const dz of [-1.13,1.13]){const post=b.occluder(`stall-post:${x}:${z}:${dx}:${dz}`,g);b.surface([.12,3.5,.12],[dx,1.8,dz],'#8b8062','wood',.025,post);}
    const canopy=b.occluder(`stall-canopy:${x}:${z}`,g);
    const roof=b.surface([5.25,.13,3.7],[0,3.63,0],color,'fabric',.055,canopy);roof.rotation.x=.13;
    for(let i=0;i<8;i++)b.surface([.34,.32,.10],[-2.23+i*.63,3.2,1.87],i%2?color:'#e5d6b1','fabric',.07,canopy);
    const sign=b.occluder(`stall-sign:${x}:${z}`,g);b.label(label,[0,2.55,1.19],3.35,'#586c56','#efdfbd',sign);
    if(goods==='food')for(let i=0;i<6;i++){b.cylinder(.29,.31,.08,[-1.65+i*.65,1.52,.3],'#eee2bb',g);for(let n=0;n<3;n++)b.sphere([.10,.1,.11],[-1.79+i*.65+n*.12,1.65,.3],n%2?'#cba572':'#b98967',g);}
    if(goods==='craft')for(let i=0;i<7;i++){b.surface([.42,.14+i%3*.14,.55],[-1.95+i*.65,1.56+i%3*.07,.1],['#9bac86','#d3b186','#b5947e'][i%3],'fabric',.025,g);b.book(-1.7+i*.56,1.47,-.6,['#879e85','#c9b182','#b69883'][i%3],.14,.5,.25,g);}
    if(goods==='drinks')for(let i=0;i<8;i++){b.cylinder(.11,.13,.41,[-1.95+i*.55,1.66,.1],i%2?'#9abcaa':'#c8af7f',g);b.cylinder(.06,.06,.15,[-1.95+i*.55,1.94,.1],'#dfd3ae',g);}
    b.obstacle(x,z,5.1,3);
  };
  stall(-10,-4,'#b98d6c','今天也开张','food');stall(-10,-14,'#90a281','手作与小物','craft');stall(10,-5,'#9cac88','晚风汽水铺','drinks');stall(10,-15,'#bca16c','书与旧唱片','craft');stall(-21,1,'#a8ad80','慢慢挑','craft');stall(21,1,'#b89a80','再来一份','food');
  // A communal table occupies its own pocket beside the main market aisle.
  b.table(9,9,5.2,3.2,1.25);
  for(const z of [6.6,11.4]){
    const bench=b.bench(9,z,z>9?Math.PI:0);
    // Approach from the open end; the forward side is occupied by the tabletop.
    bench.getObjectByName(`seat-approach:bench:9:${z}`)!.position.set(z>9?2.65:-2.65,0,0);
  }
  for(const [x,z]of [[7.4,8.2],[10.6,8.2],[7.4,9.9],[10.6,9.9]]){b.cylinder(.32,.30,.055,[x,1.37,z],'#ece0bd');b.cup(x+.47,1.36,z+.12,'#bcbf99');b.surface([.5,.025,.04],[x,1.42,z+.48],'#b99c74','wood',.005);}
  b.cylinder(.2,.15,.44,[9,1.57,9],'#c0b58c');b.sphere([.33,.4,.33],[9,2,9],'#96a379');
  b.label('胡辣汤的拼桌',[9,2.75,10.1],3.2,'#6a745c','#e7d6af');
  b.label('雨夜 · 先吃饭',[10,2.05,-3.8],2.4,'#6a745c','#e7d6af');
  // Stage: timber planks, modest steps, twin speakers and a microphone.
  b.surface([8.5,.24,4.5],[0,.15,-18],'#b4a17c','wood',.04);b.elevation(0,-18,8.5,4.5,.27);
  b.surface([5,.12,.65],[0,.07,-15.5],'#cdb48a','wood',.02);b.elevation(0,-15.5,5,.65,.13);
  for(const x of [-3.7,3.7]){b.surface([1,1.7,.8],[x,1.1,-17.1],'#607266','wood',.08);for(const y of [.72,1.44]){const speaker=b.cylinder(.3,.3,.055,[x,y,-16.67],'#465d53');speaker.rotation.x=Math.PI/2;}b.obstacle(x,-17.1,1.1,1.1);}
  b.cylinder(.026,.05,2.1,[0,1.32,-17.7],'#6a7a67');b.cylinder(.06,.065,.28,[0,2.44,-17.7],'#819580').rotation.x=Math.PI/2;b.cylinder(.36,.36,.06,[0,.3,-17.7],'#6a7a67');b.obstacle(0,-17.7,.85,.85);
  b.surface([7.7,3.7,.18],[0,2.35,-20.3],'#83947d','wood',.04);b.obstacle(0,-20.3,7.8,.25);b.label('今晚 · 留一点时间给朋友',[0,3.1,-20.17],6.9,'#eee1bf','#71856e');
  for(const x of [-4.5,4.5])b.surface([.16,5.3,.16],[x,2.65,-20],'#8a7a59','wood',.025);
  pennants(b,[-4.5,5.1,-20],[4.5,5.1,-20],14);
  building(b,-21,-20,9,10,5.3,'#c7bda0','#89947b',Math.PI/2);building(b,21,-20,10,10,5.5,'#d0c2a1','#a09171',-Math.PI/2);
  for(const z of [-11,1,17])pennants(b,[-17,5.5,z],[17,5.5,z],25);
  for(const [x,z]of [[-4,19],[4,19],[-5,-8],[5,-8],[-17,10],[17,14],[-17,-11],[17,-11],[-23,16],[23,16]])lamp(b,x,z);
  for(const [x,z]of [[-22,22],[22,22],[-25,-9],[25,-9],[-7,23],[8,23]])b.tree(x,z,1.3);
  flowerBed(b,-10,17,5.4,1.6);flowerBed(b,18,19,5.2,1.6);b.bench(-10,20);
  for(const [x,z]of [[-12,-6.5],[12,-7.5],[-22,4]]){crate(b,x,0,z);crate(b,x+.8,0,z+.75);b.obstacle(x+.4,z+.375,2.1,1.7);}
  const food=b.flagGroup('table_ready');for(let i=0;i<5;i++){b.cylinder(.38,.29,.17,[7.2+i*.9,1.43,9],'#d2b282',food);b.sphere([.27,.09,.22],[7.2+i*.9,1.56,9],i%2?'#b98565':'#b6bc78',food);}
  const festival=b.flagGroup('festival_ready');for(const z of [-11,1,17])for(let i=0;i<17;i++){const x=-16+i*2,y=5.5-Math.sin((i/16)*Math.PI)*.65;const bulb=b.sphere([.12,.17,.12],[x,y,z],'#ffe4a9',festival),m=b.material('#ffe4a9');m.emissive.set('#e4a86b');m.emissiveIntensity=.85;bulb.material=m;}
  b.label('开村夜 · 一起到场',[0,1.83,-20.16],6.5,'#ffe6a9','#71856e',festival);
}
