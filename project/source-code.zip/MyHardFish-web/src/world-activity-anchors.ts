import * as THREE from 'three';
import type { Environment } from './environment';
import type { Place } from './scene';
import { activityForHotspot } from './world-activities';
import type { ActivityPreset, WorldActivityKind } from './world-activities';
import { stories } from './content';

export type ActivityPoint = readonly [number, number, number];
export interface WorldSeatDefinition {
  id: string;
  contact: THREE.Object3D;
  approach: THREE.Object3D;
  width: number;
  depth: number;
  hotspot?: THREE.Object3D;
  target?: THREE.Object3D;
  surface?: THREE.Object3D;
  kinds: readonly WorldActivityKind[];
}
export interface ActivitySeat {
  id: string; position: ActivityPoint; facing: number;
  approach: readonly [number, number]; width: number; depth: number;
  target?: ActivityPoint; surfaceHeight?: number; kinds: readonly WorldActivityKind[];
}
export interface WorldActivityAnchor {
  id: string; hotspotId: string; label: string; place: Place;
  approach: readonly [number, number]; target: ActivityPoint; facing: number;
  surfaceHeight: number; activity: ActivityPreset | null; seat?: ActivitySeat;
  object: THREE.Object3D;
}
const position = (object: THREE.Object3D): ActivityPoint => {
  const p = object.getWorldPosition(new THREE.Vector3()); return [p.x, p.y, p.z];
};
export function resolveSeats(environment: Environment): ActivitySeat[] {
  environment.root.updateMatrixWorld(true);
  return environment.seats.map(seat => {
    const p = position(seat.contact), a = position(seat.approach);
    const forward = seat.contact.getWorldDirection(new THREE.Vector3());
    return { id: seat.id, position: p, facing: Math.atan2(forward.x, forward.z),
      approach: [a[0], a[2]], width: seat.width, depth: seat.depth, kinds: seat.kinds,
      target: seat.target ? position(seat.target) : undefined,
      surfaceHeight: seat.surface ? position(seat.surface)[1] : undefined };
  });
}

/** Actual seat anchors remain attached to furniture even after static mesh merging. */
export function resolveActivityAnchors(environment: Environment, place: Place): WorldActivityAnchor[] {
  const seats = resolveSeats(environment);
  return environment.hotspots.map((object, index) => {
    const hotspotId = String(object.userData.action), label = String(object.userData.label);
    const box = new THREE.Box3().setFromObject(object), p = box.getCenter(new THREE.Vector3());
    const activity = activityForHotspot(place, hotspotId);
    const explicit = environment.seats.find(s => s.hotspot === object);
    let seat = explicit ? seats.find(s => s.id === explicit.id) : undefined;
    if (!seat && activity?.seated) {
      seat = [...seats].filter(s => Math.hypot(s.position[0] - p.x, s.position[2] - p.z) < 5.5)
        .sort((a, b) => Math.hypot(a.position[0] - p.x, a.position[2] - p.z) - Math.hypot(b.position[0] - p.x, b.position[2] - p.z))[0];
    }
    const approach: readonly [number, number] = seat?.approach ?? object.userData.approach ?? [p.x, box.max.z + .86];
    const customTarget = object.userData.activityTarget as ActivityPoint | undefined;
    const target: ActivityPoint = customTarget ?? seat?.target ?? [p.x, Math.min(1.75, Math.max(.65, p.y)), p.z];
    const facing = seat?.facing ?? Math.atan2(target[0] - approach[0], target[2] - approach[1]);
    const id = `${place}:${hotspotId}:${index}`;
    object.userData.activityAnchorId = id;
    if (object.userData.marker) object.userData.marker.userData.activityAnchorId = id;
    return { id, hotspotId, label, place, approach, target, facing, seat,
      surfaceHeight: seat?.surfaceHeight ?? Number(object.userData.surfaceHeight ?? Math.min(1.45, Math.max(.7, p.y))), activity, object };
  });
}

const storyRequests = new Set(stories.map(story => `story:${story.id}`));
export const isStoryActivityRequest = (id: string) => storyRequests.has(id);

// Menu/game IDs are not all scene proxies. Each alias still names a real object
// in the current region; this does not relax walking/exploration ID validation.
const gameAnchors: Partial<Record<Place, Record<string, string>>> = {
  workshop: { words: 'write', harvest: 'adventure:workshop_recycle' },
  school: { words: 'adventure:school_desk' },
  market: { words: 'adventure:market_stall' },
  village: { harvest: 'adventure:village_garden' },
  river: { bottle: 'adventure:river_bottle' },
};

/** Resolve only registered logical requests, always to a same-region object. */
export function resolveLogicalActivityAnchor(
  place: Place, id: string, kind: WorldActivityKind,
  anchors: readonly WorldActivityAnchor[], seats: readonly ActivitySeat[],
  origin: readonly [number, number], seated = false,
  previous?: WorldActivityAnchor,
): WorldActivityAnchor | undefined {
  const alias = gameAnchors[place]?.[id];
  if (alias) return anchors.find(anchor => anchor.hotspotId === alias);
  if (!isStoryActivityRequest(id)) return undefined;
  const distance = (anchor: WorldActivityAnchor) => Math.hypot(anchor.approach[0] - origin[0], anchor.approach[1] - origin[1]);
  const supportsSeat = (anchor: WorldActivityAnchor) => Boolean(
    anchor.seat?.kinds.includes(kind) || seats.some(seat => seat.kinds.includes(kind)
      && Math.hypot(seat.position[0] - anchor.target[0], seat.position[2] - anchor.target[2]) < 7),
  );
  let candidates = anchors.filter(anchor => anchor.place === place && anchor.activity);
  if (seated || kind === 'sit') candidates = candidates.filter(supportsSeat);
  if (!candidates.length) return undefined;
  // Continuing a story may happen after map travel. Keep a suitable existing
  // object, but move cooking/writing/etc. to actual work surfaces when needed.
  const functional = ['cook', 'water', 'shop', 'write', 'read', 'play'].includes(kind);
  const matching = candidates.filter(anchor => anchor.activity?.kind === kind);
  if (functional && matching.length) candidates = matching;
  const direct = candidates.find(anchor => anchor.hotspotId === id);
  if (direct) return direct;
  if (previous && candidates.includes(previous)) return previous;
  return [...candidates].sort((a, b) => distance(a) - distance(b))[0];
}
