import { useEffect, useRef, useState } from 'react';
import type { RefObject } from 'react';
import { ArrowUp, Compass, Hand, NavigationArrow, X } from '@phosphor-icons/react';
import type { FishWorld } from './scene';

export default function WorldControls({ world, enabled }: { world:RefObject<FishWorld|null>; enabled:boolean }) {
  const [snapshot,setSnapshot]=useState<ReturnType<FishWorld['getSnapshot']>|null>(null);
  const stick = useRef<HTMLButtonElement>(null), knob = useRef<HTMLSpanElement>(null), pointer = useRef<number|null>(null);
  const [moving,setMoving]=useState(false);
  const [stickVisible,setStickVisible]=useState(true);
  useEffect(()=>{const timer=setInterval(()=>{if(enabled)setSnapshot(world.current?.getSnapshot()||null);},350);return()=>clearInterval(timer);},[world,enabled]);
  function release() {pointer.current=null;world.current?.setMovement(0,0);if(knob.current)knob.current.style.transform='translate(0,0)';setMoving(false);}
  useEffect(()=>{if(!enabled)release();return()=>{world.current?.setMovement(0,0);};},[enabled]);
  const near=snapshot?.nearestHotspot, nav=snapshot?.navigation, activity=snapshot?.activity;
  const activityLabels:Record<string,string>={sit:'坐着歇一会儿',eat:'吃点东西',read:'翻翻书',cook:'认真炒两下',water:'给花草浇水',shop:'整理手里的物料',play:'抛球玩一会儿',write:'把这件事记下来',inspect:'凑近看看',talk:'边聊边比划',celebrate:'今天心情不错'};
  return <>
    <div className="village-compass" aria-hidden="true"><span>N</span><i style={{transform:`rotate(${-(snapshot?.cameraHeading||0)*180/Math.PI}deg)`}}><NavigationArrow size={16} weight="fill"/></i><span>S</span></div>
    {nav && (!activity || activity.phase==='approaching') && <div className="navigation-status" data-arrived={nav.arrived}><Compass size={16}/><span><b>{nav.label}</b><small>{nav.arrived?'到了，看看这里':`距目标 ${Math.ceil(nav.distance)} 米`}</small></span><button aria-label="取消路线" onClick={()=>world.current?.clearNavigation()}><X size={15}/></button></div>}
    {enabled && activity && activity.phase!=='approaching' && <div className="navigation-status activity-status" role="status"><Hand size={16}/><span><b>{activityLabels[activity.kind]}</b><small>{activity.seatAnchor?'移动可以站起来':'移动可以收起道具'}</small></span><button aria-label="结束当前动作" onClick={()=>{world.current?.cancelActivity();world.current?.clearNavigation();}}><X size={15}/></button></div>}
    <div className={`touch-movement ${moving?'moving':''} ${stickVisible?'':'collapsed'}`}>
      {stickVisible && <button ref={stick} className="touch-stick" aria-label="拖动摇杆移动难鱼" onPointerDown={e=>{pointer.current=e.pointerId;e.currentTarget.setPointerCapture(e.pointerId);setMoving(true);e.preventDefault();}} onPointerMove={e=>{if(pointer.current!==e.pointerId)return;const b=stick.current!.getBoundingClientRect(),dx=e.clientX-(b.x+b.width/2),dy=e.clientY-(b.y+b.height/2),length=Math.hypot(dx,dy),scale=length>26?26/length:1;const x=dx*scale,y=dy*scale;if(knob.current)knob.current.style.transform=`translate(${x}px,${y}px)`;world.current?.setMovement(x/26,y/26);}} onPointerUp={release} onPointerCancel={release} onLostPointerCapture={release}><span className="stick-directions"><ArrowUp size={12}/><ArrowUp size={12}/><ArrowUp size={12}/><ArrowUp size={12}/></span><span className="stick-knob" ref={knob}/></button>}
      <button className="stick-toggle" onClick={()=>{release();setStickVisible(v=>!v);}}>{stickVisible?'收起摇杆':'展开摇杆'}</button>
    </div>
    {near && near.distance<=2.5 && <button className="nearby-interaction" onClick={()=>world.current?.interactNearest()}><Hand size={20}/><span><small>互动 <kbd>E</kbd></small><b>{near.label}</b></span></button>}
  </>;
}
