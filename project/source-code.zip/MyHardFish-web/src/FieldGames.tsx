import { useRef, useState } from 'react';
import { ArrowClockwise, Basket, BookOpen, Check, Leaf, Minus, Package, Plant } from '@phosphor-icons/react';

const WORDS = [
  { word: 'berry', meaning: '浆果', hint: '工坊回收箱里一颗颗红色的果子。', context: 'a basket of berries · 一篮浆果', symbol: '●', options: ['berry', 'bridge', 'bottle'] },
  { word: 'bridge', meaning: '桥', hint: '河岸上，连接两边小路的那座建筑。', context: 'cross the bridge · 走过桥', symbol: '⌒', options: ['bread', 'bridge', 'garden'] },
  { word: 'bottle', meaning: '瓶子', hint: '狐狸把写好的纸条装进它，再交给瓶信站。', context: 'a message in a bottle · 瓶中信', symbol: '♧', options: ['basket', 'button', 'bottle'] },
  { word: 'garden', meaning: '花园', hint: '小窝露台外，大家一起浇水照看的地方。', context: 'in the garden · 在花园里', symbol: '❀', options: ['garden', 'window', 'village'] },
  { word: 'recipe', meaning: '食谱', hint: '先看清用料和步骤，再把锅交给主厨。', context: 'follow the recipe · 按食谱做', symbol: '≋', options: ['reply', 'recipe', 'record'] },
  { word: 'lantern', meaning: '灯笼', hint: '夜市屋檐下发着暖光的圆圆装饰。', context: 'light a lantern · 点亮灯笼', symbol: '◉', options: ['letter', 'lantern', 'ladder'] },
  { word: 'share', meaning: '分享', hint: '把刚找到的方法说给群友，让大家都能用。', context: 'share an idea · 分享一个主意', symbol: '↗', options: ['share', 'save', 'sleep'] },
  { word: 'repair', meaning: '修理', hint: '工坊设备出了小毛病，先查清问题再动手。', context: 'repair a machine · 修理机器', symbol: '⚙', options: ['repeat', 'remember', 'repair'] },
  { word: 'invite', meaning: '邀请', hint: '问群友要不要一起参加，也允许对方说下次。', context: 'invite a friend · 邀请朋友', symbol: '✉', options: ['invite', 'invent', 'inspect'] },
  { word: 'thanks', meaning: '谢谢', hint: '别人给出了能用的办法，她也会认真道谢。', context: 'thanks for your help · 谢谢你的帮助', symbol: '♡', options: ['think', 'thanks', 'things'] },
];
const GOODS = [
  { id: 'ripe', label: '熟浆果', color: '#b86461', note: '红果，果酱摊的主料', Icon: Leaf },
  { id: 'tart', label: '酸浆果', color: '#869960', note: '青果，留给调饮摊', Icon: Plant },
  { id: 'seed', label: '种子袋', color: '#b89459', note: '棕袋，送回种植架', Icon: Package },
] as const;
type Good = typeof GOODS[number]['id'];
type Tray = Record<Good, number>;
const emptyTray = (): Tray => ({ ripe: 0, tart: 0, seed: 0 });
const ORDERS: { owner: string; text: string; needs: Tray }[] = [
  { owner: '果酱摊', text: '先把熟透的挑出来，别顺手塞一袋种子。', needs: { ripe: 2, tart: 0, seed: 0 } },
  { owner: '河岸调饮摊', text: '一份甜、一份酸，口味各留一条路。', needs: { ripe: 1, tart: 1, seed: 0 } },
  { owner: '工坊种植架', text: '这单是补种。果子送错了也长不出种植计划。', needs: { ripe: 0, tart: 0, seed: 2 } },
  { owner: '野餐筹备组', text: '两份熟果配一份酸果，大家可以自己挑。', needs: { ripe: 2, tart: 1, seed: 0 } },
  { owner: '村口回收站', text: '分开装好，今天就不用在群里催三遍了。', needs: { ripe: 1, tart: 1, seed: 1 } },
];
function shuffled<T>(values: readonly T[]) {
  return values.map(value => ({ value, order: Math.random() })).sort((a, b) => a.order - b.order).map(({ value }) => value);
}
export default function FieldGames({ kind, onStart, onFinish, onInteraction }: {
  kind: 'words' | 'harvest'; onStart: () => boolean; onFinish: (score: number) => void;
  onInteraction?: () => void;
}) {
  const [phase, setPhase] = useState<'intro' | 'play' | 'done'>('intro');
  const [round, setRound] = useState(0);
  const [score, setScore] = useState(0);
  const [deck, setDeck] = useState(() => shuffled(WORDS).slice(0, 5).map(card => ({ ...card, options: shuffled(card.options) })));
  const [tray, setTray] = useState<Tray>(emptyTray);
  const [answer, setAnswer] = useState('');
  const [feedback, setFeedback] = useState('');
  const [complete, setComplete] = useState(false);
  const [missed, setMissed] = useState(false);
  const claimed = useRef(false);
  const title = kind === 'words' ? '词卡接力' : '浆果回收';
  const currentWord = deck[round];
  const order = ORDERS[round];
  function start() {
    if (!onStart()) return;
    claimed.current = false;
    setRound(0); setScore(0); setTray(emptyTray()); setAnswer(''); setFeedback(''); setComplete(false); setMissed(false);
    setDeck(shuffled(WORDS).slice(0, 5).map(card => ({ ...card, options: shuffled(card.options) })));
    setPhase('play');
  }
  function next() {
    if (!complete) return;
    if (round === 4) {
      if (claimed.current) return;
      claimed.current = true; setPhase('done'); onFinish(score); return;
    }
    setRound(round + 1); setTray(emptyTray()); setAnswer(''); setFeedback(''); setComplete(false); setMissed(false);
  }
  function choose(word: string) {
    if (complete) return;
    onInteraction?.();
    setAnswer(word);
    if (word === currentWord.word) {
      if (!missed) setScore(s => s + 1);
      setComplete(true); setFeedback(`对上了。${currentWord.context}`);
    } else {
      setMissed(true); setFeedback(`先别急着交。${currentWord.hint} 再试一次，这张会一起学会。`);
    }
  }
  function deliver() {
    if (complete) return;
    onInteraction?.();
    const correct = GOODS.every(good => tray[good.id] === order.needs[good.id]);
    if (correct) {
      if (!missed) setScore(s => s + 1);
      setComplete(true); setFeedback('高级。这筐贴好标签，可以发走了。');
    } else {
      setMissed(true); setFeedback('数量或品种没对上，物料已退回。看着订单重新装一筐，我等你。'); setTray(emptyTray());
    }
  }
  return <div className={`field-game field-${kind}`}>
    <div className="field-game-heading"><span>{kind === 'words' ? <BookOpen size={30} /> : <Basket size={30} />}</span><div><small>老母猪村 · 合作小事</small><h3>{title}</h3></div></div>
    {phase === 'intro' && <>
      <p className="field-intro">{kind === 'words' ? '把英语放回眼前的东西里。看看五张村庄线索卡，选出对应单词；答错可以接着试，难鱼会把用法一起说给你。' : '联机群又在喊浆果回收了。这次给五个摊位按订单装筐，品种和数量都要对；装错原样退回，不会白白丢掉材料。'}</p>
      <div className="field-preview" aria-hidden="true">{kind === 'words' ? <><span>berry</span><i>↔</i><span>一篮浆果</span></> : GOODS.map(({ id, label, Icon }) => <span key={id}><Icon size={24} />{label}</span>)}</div>
      <div className="game-facts"><span>8 精力</span><span>没有倒计时</span><span>完成即有奖励</span></div>
      <p className="fine-print">每项第一次就做对得 1 分，满分 5 分。重试后一样能完成委托。中途关闭不结算。</p>
      <button className="primary wide" onClick={start}>和难鱼一起开始</button>
    </>}
    {phase === 'play' && <>
      <div className="game-progress"><span>{kind === 'words' ? '线索卡' : '订单'} {round + 1} / 5</span><span>一次做对 {score} 项</span></div>
      <div className="field-rounds" aria-hidden="true">{[0, 1, 2, 3, 4].map(n => <i key={n} className={n < round || n === round && complete ? 'done' : n === round ? 'current' : ''} />)}</div>
      {kind === 'words' ? <>
        <div className="word-clue"><span aria-hidden="true">{currentWord.symbol}</span><small>村里的这个东西，英文怎么说？</small><h4>{currentWord.meaning}</h4><p>{currentWord.hint}</p></div>
        <div className="word-options">{currentWord.options.map(word => <button key={word} disabled={complete} className={answer === word ? complete ? 'correct' : 'incorrect' : ''} onClick={() => choose(word)}>{word}{complete && answer === word && <Check size={20} />}</button>)}</div>
      </> : <>
        <div className="harvest-order"><small>送到 {order.owner}</small><h4>本筐需要</h4><div>{GOODS.filter(good => order.needs[good.id]).map(({ id, label, Icon }) => <span key={id}><Icon size={18} />{label} × {order.needs[id]}</span>)}</div><p>{order.text}</p></div>
        <div className="harvest-stock">{GOODS.map(({ id, label, color, Icon }) => <button key={id} aria-label={`装入${label}`} disabled={complete || Object.values(tray).reduce((a, b) => a + b, 0) >= 3} onClick={() => { onInteraction?.(); setTray(v => ({ ...v, [id]: v[id] + 1 })); }}><span style={{ color }}><Icon size={34} weight="duotone" /></span><b>{label}</b><small>点一下，装一份</small></button>)}</div>
        <div className="harvest-tray"><span><Basket size={23} />筐里 {Object.values(tray).reduce((a, b) => a + b, 0)} / 3</span><div>{GOODS.map(({ id, label }) => tray[id] > 0 && <button key={id} aria-label={`取出${label}`} disabled={complete} onClick={() => setTray(v => ({ ...v, [id]: Math.max(0, v[id] - 1) }))}>{label} × {tray[id]}<Minus size={13} /></button>)}{Object.values(tray).every(n => !n) && <small>先按上面的订单装筐</small>}</div></div>
        {!complete && <button className="primary wide" disabled={Object.values(tray).every(n => !n)} onClick={deliver}>核对并交付这一筐</button>}
      </>}
      <p className={`field-feedback ${complete ? 'complete' : ''}`} role="status">{feedback || (kind === 'words' ? '看图景选词，答错也能接着学。' : '种子和果子分开算，最多装三份。')}</p>
      {complete && <button className="primary wide" onClick={next}>{round === 4 ? '收工，记下今天的成果' : kind === 'words' ? '下一张线索卡' : '去装下一筐'}<Check size={18} /></button>}
    </>}
    {phase === 'done' && <div className="game-result"><span className="result-number">{score}<small> / 5</small></span><h4>{score === 5 ? '这回是真的带飞全村了。' : '都完成了。会了比装会了强。'}</h4><p>+{8 + score * 5} 贝壳 · +{3 + score} 熟悉度</p><p className="fine-print">正在进行的相关委托会记录这次成果。可以回到委托簿查看下一步。</p><button className="secondary" onClick={start}><ArrowClockwise size={18} />再玩一局 · 8 精力</button></div>}
  </div>;
}
