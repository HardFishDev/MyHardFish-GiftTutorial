import type { Place, Outfit } from "./scene";
import { relationshipStories } from "./relationships";
export { friends, groupFriends, contextEvents, friendProgress } from "./relationships";

export const places: {
  id: Place;
  name: string;
  subtitle: string;
  activity: string;
}[] = [
  {
    id: "home",
    name: "小窝",
    subtitle: "今天也要理直气壮地摸鱼",
    activity: "窝在沙发里，随便聊聊。",
  },
  {
    id: "kitchen",
    name: "厨房",
    subtitle: "主厨脾气大，手艺待观察",
    activity: "把火候停在绿色区域，做一份热饭。",
  },
  {
    id: "park",
    name: "公园",
    subtitle: "出门可以，伞记得带",
    activity: "池塘里飘来了新的瓶中信。",
  },
  {
    id: "shop",
    name: "便利店",
    subtitle: "我哪来的32块",
    activity: "补充零食，也给难鱼挑件新衣服。",
  },
  {
    id: "school",
    name: "教室",
    subtitle: "学个数学都要我半条命了",
    activity: "五道口算题，和难鱼一起过关。",
  },
  { id: "village", name: "村中心", subtitle: "名字先别替我决定", activity: "看看村务板，打理共同花园，把开村日一点点准备好。" },
  { id: "workshop", name: "联机工坊", subtitle: "浆果回收，今天安排", activity: "整理订单、准备小灯，也给共同作品留一块桌面。" },
  { id: "river", name: "瓶信河岸", subtitle: "回一句，也可以先收着", activity: "配对纸瓶，沿着码头去观景台，把瓶灯挂起来。" },
  { id: "market", name: "夜市", subtitle: "拼桌，不拼输赢", activity: "认物品词卡，摆好长桌，等大家慢慢到齐。" },
];
export const foods = [
  {
    id: "bun",
    name: "热乎小包子",
    note: "两口一个，先吃再骂",
    price: 8,
    hunger: 22,
    mood: 3,
    energy: 3,
    color: "#ead9b1",
    symbol: "bun",
  },
  {
    id: "milk",
    name: "温牛奶",
    note: "睡前的和平协议",
    price: 10,
    hunger: 12,
    mood: 5,
    energy: 15,
    color: "#c7dad8",
    symbol: "milk",
  },
  {
    id: "peach",
    name: "脆甜桃子",
    note: "一口咬掉今天的烦恼",
    price: 12,
    hunger: 18,
    mood: 14,
    energy: 4,
    color: "#ecc3b3",
    symbol: "peach",
  },
  {
    id: "rice",
    name: "蛋炒饭",
    note: "你做饭，她负责点评",
    price: 18,
    hunger: 38,
    mood: 8,
    energy: 8,
    color: "#e5d3a1",
    symbol: "rice",
  },
  {
    id: "coffee",
    name: "苦咖啡",
    note: "提神，但可能挨骂",
    price: 14,
    hunger: 3,
    mood: -5,
    energy: 30,
    color: "#c9bca8",
    symbol: "coffee",
  },
] as const;
export type FoodId = (typeof foods)[number]["id"];
export const outfits: {
  id: Outfit;
  name: string;
  note: string;
  price: number;
  color: string;
}[] = [
  {
    id: "classic",
    name: "原装难鱼",
    note: "白白一条，攻击力不详",
    price: 0,
    color: "#eef0e5",
  },
  {
    id: "mint",
    name: "薄荷围巾",
    note: "寒心的时候，围一下",
    price: 60,
    color: "#abcdb9",
  },
  {
    id: "chef",
    name: "暴躁主厨",
    note: "锅铲在手，谁敢还嘴",
    price: 85,
    color: "#e7d4ae",
  },
  {
    id: "student",
    name: "放学别走",
    note: "书包里只有半条命",
    price: 100,
    color: "#bdccd5",
  },
  {
    id: "night",
    name: "晚安喵",
    note: "今天的互损到此结束",
    price: 120,
    color: "#ccc5df",
  },
];
export type StoryChoice = { label: string; next: string };
export type StoryNode = {
  text: string;
  quote?: string;
  choices?: StoryChoice[];
  ending?: string;
  bond?: number;
  shells?: number;
};
export type Story = {
  id: string;
  title: string;
  place: Place;
  tag: string;
  intro: string;
  minBond: number;
  source: string;
  friendIds?: string[];
  nodes: Record<string, StoryNode>;
};
export const stories: Story[] = [
  {
    id: "fanclub",
    title: "应援会改名风波",
    place: "home",
    tag: "群聊名场面",
    intro: "你偷偷把昵称改成了「难鱼国际应援会」。她好像看到了。",
    minBond: 0,
    source: "2023-06-20：吐槽应援会昵称、要求改名的连续发言。",
    nodes: {
      start: {
        text: "手机响了一声。难鱼抬头，盯住了你刚改好的群昵称。",
        quote: "whatname",
        choices: [
          { label: "立刻改成「普通群友」", next: "rename" },
          { label: "这是对你的高度认可", next: "promote" },
        ],
      },
      rename: {
        text: "你把应援会招牌收起来。她看了一眼，假装没在意。",
        quote: "mercy",
        choices: [
          { label: "递个桃子，和好吧", next: "peace" },
          { label: "把应援会搬进心里", next: "secret" },
        ],
      },
      promote: {
        text: "你还想解释分部规划，她已经盯住了「会长」两个字。",
        quote: "rename",
        choices: [
          { label: "好好好，马上改", next: "peace" },
          { label: "那聘你当名誉会长", next: "chair" },
        ],
      },
      peace: {
        text: "昵称变回普通群友。难鱼把手机放下，给你让了半个沙发。今日和平达成。",
        quote: "greeting",
        ending: "停战协议",
        bond: 8,
        shells: 24,
      },
      secret: {
        text: "桌上多了一张手写会员卡。她说「谁理你」，但没有把卡扔掉。",
        quote: "ignore",
        ending: "地下应援会",
        bond: 7,
        shells: 24,
      },
      chair: {
        text: "她宣布会长的第一项权力是把你踢出应援会。你获得了唯一的终身编外席位。",
        quote: "police",
        ending: "会长被开除",
        bond: 6,
        shells: 24,
      },
    },
  },
  {
    id: "movie",
    title: "今晚到底看什么",
    place: "home",
    tag: "夜间放映",
    intro: "零食有了，沙发有了，只差选一部不会挨骂的电影。",
    minBond: 15,
    source: "2023-06-29 / 30：拒绝深夜看鬼片，被持续剧透后喊闭嘴。",
    nodes: {
      start: {
        text: "遥控器交到你手上，封面那扇阴森的门看上去很有故事。",
        quote: "horror",
        choices: [
          { label: "换一部轻松喜剧", next: "comedy" },
          { label: "只看预告片，行不行", next: "trailer" },
        ],
      },
      comedy: {
        text: "难鱼嘴上嫌弃笑点低，身体却已经窝进靠垫里。",
        quote: "fun",
        choices: [
          { label: "把音量调低，陪她看完", next: "quiet" },
          { label: "比赛谁先笑出声", next: "laugh" },
        ],
      },
      trailer: {
        text: "屏幕还没亮，她先把你的手从播放键上移开。",
        quote: "horroraway",
        choices: [
          { label: "听她的，换喜剧", next: "quiet" },
          { label: "干脆关电视，聊一会儿", next: "talk" },
        ],
      },
      quiet: {
        text: "片尾字幕开始滚动。没人急着起身，今晚就这样慢慢过去了。",
        quote: "fine",
        ending: "沙发里的好时光",
        bond: 12,
        shells: 30,
      },
      laugh: {
        text: "你笑出了声。难鱼宣布获胜，随后也没忍住。没有裁判，双方都说自己赢了。",
        quote: "win",
        ending: "双冠军喜剧夜",
        bond: 10,
        shells: 30,
      },
      talk: {
        text: "电视安静下来。她开始讲白天见到的怪事，讲了很久。",
        quote: "okay",
        ending: "不用电影也可以",
        bond: 12,
        shells: 30,
      },
    },
  },
  {
    id: "rain",
    title: "难鱼今天没带伞",
    place: "park",
    tag: "雨天支线",
    intro: "刚坐下，公园就下雨了。某条鱼比天气更暴躁。",
    minBond: 0,
    source: "2023-07-02：解释出门遇雨没伞，因此没心情接群友的梗。",
    nodes: {
      start: {
        text: "雨点落在长椅上。你们俩摸遍了口袋，只找到一张便利店小票。",
        quote: "rain",
        choices: [
          { label: "去亭子里等雨停", next: "shelter" },
          { label: "把外套举起来，一起跑", next: "run" },
        ],
      },
      shelter: {
        text: "亭檐把雨切成一道帘子。她盯着雨水，嘴终于闲了下来。",
        choices: [
          { label: "聊聊放假要做什么", next: "wait" },
          { label: "下次出门我提醒你带伞", next: "umbrella" },
        ],
      },
      run: {
        text: "跑到店门口，你们都湿了一半。她看了看你，突然想笑。",
        quote: "six",
        choices: [
          { label: "买把伞，一人一半", next: "umbrella" },
          { label: "反正都湿了，等等吧", next: "wait" },
        ],
      },
      wait: {
        text: "雨停得比想象中快。你们又绕公园多走了一圈，没人提刚刚谁先慌的。",
        quote: "happy",
        ending: "雨停之前",
        bond: 9,
        shells: 24,
      },
      umbrella: {
        text: "第二天门边多了一把伞。伞柄贴着「别忘了」三个字。",
        quote: "thankyou",
        ending: "两个人的晴天",
        bond: 11,
        shells: 24,
      },
    },
  },
  {
    id: "download",
    title: "消失的下载按钮",
    place: "home",
    tag: "数码折腾",
    intro: "一个设置，五个窗口，零个下载按钮。难鱼的耐心正在掉电。",
    minBond: 10,
    source:
      "2023-06-28 至 29：找软件下载入口，解决设置后说「搞好了」「多谢」。",
    nodes: {
      start: {
        text: "她把电脑转向你。网页打开了一排，目标按钮就是不出现。",
        quote: "download",
        choices: [
          { label: "一起检查页面和设置", next: "help" },
          { label: "先吐槽一下这个设计", next: "roast" },
        ],
      },
      help: {
        text: "你们发现入口藏在另一个菜单里。终于有点眉目了。",
        quote: "surprise",
        choices: [
          { label: "陪她把最后一步做完", next: "fixed" },
          { label: "让她自己点，记住位置", next: "learn" },
        ],
      },
      roast: {
        text: "她接连吐槽三句，又把鼠标拿了回来。骂归骂，问题还是得解决。",
        quote: "nonsense",
        choices: [
          { label: "打开正确的菜单", next: "fixed" },
          { label: "画一张入口小地图", next: "learn" },
        ],
      },
      fixed: {
        text: "窗口终于显示完成。她短短地说了一句多谢，然后给你推来一杯水。",
        quote: "done",
        ending: "终于搞好了",
        bond: 10,
        shells: 28,
      },
      learn: {
        text: "难鱼把步骤记下来，下次就能反过来给别人指路了。",
        quote: "manythanks",
        ending: "群里的技术支持",
        bond: 12,
        shells: 28,
      },
    },
  },
  {
    id: "afterclass",
    title: "作业只剩半条命",
    place: "school",
    tag: "放学时刻",
    intro: "她把书翻开，又把书合上。数学题还在那里。",
    minBond: 0,
    source: "2023-06-21：吐槽数学困难后又说要提前看；并非完全放弃学习。",
    nodes: {
      start: {
        text: "放学铃响了，桌上那道题依然没动。",
        quote: "math",
        choices: [
          { label: "拆成几个小步骤", next: "steps" },
          { label: "休息五分钟再来", next: "break" },
        ],
      },
      steps: {
        text: "你先写第一步，她盯了一会儿，自己接上了下一行。",
        quote: "surprise",
        choices: [
          { label: "继续，最后一步了", next: "solved" },
          { label: "夸她一句，别太明显", next: "confidence" },
        ],
      },
      break: {
        text: "窗外操场空了。她趴了片刻，重新把笔拿起来。",
        choices: [
          { label: "好，陪你算完", next: "solved" },
          { label: "这次一定可以", next: "confidence" },
        ],
      },
      solved: {
        text: "答案终于对上。她在草稿纸角上画了一条歪歪的小鱼，宣布今天下班。",
        quote: "win",
        ending: "半条命也能通关",
        bond: 9,
        shells: 28,
      },
      confidence: {
        text: "她说你别夸了，耳边却又传来笔尖划纸的声音。下一题也写了。",
        quote: "greeting",
        ending: "再做一道就回家",
        bond: 11,
        shells: 28,
      },
    },
  },
  {
    id: "holiday",
    title: "放假了，然后呢",
    place: "park",
    tag: "慢一点也行",
    intro: "盼了很久的假期到了。难鱼却说有点空虚。",
    minBond: 25,
    source:
      "2026-06-12：先怀念高中，再说放假好空虚、好无聊；并非简单的永远不想上学。",
    nodes: {
      start: {
        text: "不用早起了，不用赶作业了。她在长椅上晃着脚，忽然沉默了一会儿。",
        quote: "holiday",
        choices: [
          { label: "要不捡个漂流瓶", next: "bottles" },
          { label: "没安排也没关系", next: "slow" },
        ],
      },
      bottles: {
        text: "瓶子里是一句「今天也有人在摸鱼」。她觉得这句还能更有攻击力。",
        quote: "bottle",
        choices: [
          { label: "写一封给未来的信", next: "future" },
          { label: "今天先一起玩", next: "today" },
        ],
      },
      slow: {
        text: "你们看了会儿水面。她把下巴搁在长椅边，问明天还来不来。",
        choices: [
          { label: "来，约好了", next: "today" },
          { label: "给下次的我们留个纸条", next: "future" },
        ],
      },
      future: {
        text: "纸条上写着：不知道以后干什么，先记住今天也不错。落款是一条难看的鱼。",
        quote: "idea",
        ending: "寄给未来的鱼",
        bond: 15,
        shells: 36,
      },
      today: {
        text: "今天没有什么大事发生。你们都觉得，还挺好。",
        quote: "fine",
        ending: "普通的一天",
        bond: 15,
        shells: 36,
      },
    },
  },
  {
    id: "dinner",
    title: "主厨接受不了批评",
    place: "kitchen",
    tag: "晚饭争夺战",
    intro: "厨房里传出锅铲声，还有提前写好的五星好评。",
    minBond: 12,
    source:
      "根据群聊互损、事后道谢的表达创作。做饭能力与食物偏好属于游戏设定。",
    nodes: {
      start: {
        text: "难鱼把围裙系好，警告你只准发表建设性的意见。",
        choices: [
          { label: "我帮你备菜", next: "team" },
          { label: "我负责鼓掌", next: "clap" },
        ],
      },
      team: {
        text: "锅里滋啦一声。你们一个翻炒，一个手忙脚乱找盘子。",
        quote: "okay",
        choices: [
          { label: "一起把饭端上桌", next: "dinner" },
          { label: "先给主厨尝一口", next: "chef" },
        ],
      },
      clap: {
        text: "她用锅铲指了指水池：鼓掌不如洗碗。",
        quote: "manners",
        choices: [
          { label: "行，我包洗碗", next: "dinner" },
          { label: "那我先试菜", next: "chef" },
        ],
      },
      dinner: {
        text: "一顿不太整齐的晚饭。难鱼很勉强地承认，两个人干活确实快一点。",
        quote: "thanks",
        ending: "厨房停火协议",
        bond: 12,
        shells: 30,
      },
      chef: {
        text: "味道居然不错。她收下你的好评，宣布你获得下一次的洗碗资格。",
        quote: "nice",
        ending: "主厨的指定饭友",
        bond: 10,
        shells: 30,
      },
    },
  },
  {
    id: "budget",
    title: "三十二块的尊严",
    place: "shop",
    tag: "精打细算",
    intro: "货架上全是想买的东西，口袋里的贝壳却很有自己的想法。",
    minBond: 5,
    source:
      "2023-07-01：「我哪来的32块」原本是拒绝购买游戏。便利店剧情是创作延伸。",
    nodes: {
      start: {
        text: "她看了眼价签，又看了眼你。购物篮里只有空气。",
        quote: "money",
        choices: [
          { label: "挑真正想要的一样", next: "pick" },
          { label: "我请客，别瞪我", next: "treat" },
        ],
      },
      pick: {
        text: "挑来挑去，难鱼最后拿起了一盒能分着吃的小点心。",
        choices: [
          { label: "一起吃比较香", next: "share" },
          { label: "把剩下的贝壳存起来", next: "save" },
        ],
      },
      treat: {
        text: "她先喊了一声富哥，随后把最贵的那包又放回去。",
        quote: "rich",
        choices: [
          { label: "两个人够吃就好", next: "share" },
          { label: "下次换你请", next: "save" },
        ],
      },
      share: {
        text: "点心一人一半。她说这次不算被你收买，下次可以再试。",
        quote: "greeting",
        ending: "半盒点心",
        bond: 10,
        shells: 26,
      },
      save: {
        text: "门口路灯亮了。难鱼开始认真盘算下一次要买什么。",
        quote: "idea",
        ending: "下次还来",
        bond: 10,
        shells: 26,
      },
    },
  },
];

// Relationship scenes are adaptations with locally documented evidence.
stories.push(...relationshipStories);

export const dailyTasks = [
  { id: "chat", label: "聊三句，别冷场", target: 3, reward: 15 },
  { id: "feed", label: "记得吃一顿饭", target: 1, reward: 12 },
  { id: "play", label: "一起玩一局", target: 1, reward: 20 },
] as const;
export const achievementInfo = [
  { id: "hello", title: "熟人见面", text: "累计陪伴互动 10 次", reward: 20 },
  {
    id: "explore",
    title: "全村都认识你",
    text: "到访全部五个场景",
    reward: 30,
  },
  { id: "chef", title: "今天我掌勺", text: "完成 3 次火候挑战", reward: 30 },
  {
    id: "math",
    title: "数学还我半条命",
    text: "口算挑战答对全部 5 题",
    reward: 35,
  },
  {
    id: "collector",
    title: "已阅，收藏了",
    text: "收集 20 句原话",
    reward: 30,
  },
  { id: "fashion", title: "鱼靠衣装", text: "拥有 3 套装扮", reward: 25 },
  { id: "story", title: "我们有故事了", text: "发现 5 个剧情结局", reward: 40 },
  { id: "friend", title: "心情好先不骂你", text: "熟悉度达到 60", reward: 50 },
];
