/** Independent cycling course simulation. No renderer, clocks or save state needed. */
export const CYCLING_LENGTH = 600;
export const CYCLING_MAX_SCORE = 1000;
export const CYCLING_LANE_WIDTH = 2.6;
export type CyclingCamera = 'follow' | 'overhead' | 'side';
export type CyclingDifficulty = 'easy' | 'normal' | 'hard';
export type CyclingDifficultyConfig = {
  id: CyclingDifficulty;
  label: string;
  mapName: string;
  description: string;
  theme: 'riverside' | 'village' | 'nightHarbor';
  startSpeed: number;
  maxSpeed: number;
  brakeSpeed: number;
  /** Multiplies the score-based reward; the participation reward stays unchanged. */
  rewardMultiplier: number;
  length: number;
};
export const CYCLING_DIFFICULTIES: readonly CyclingDifficultyConfig[] = [
  { id: 'easy', label: '简单', mapName: '河畔绿道', description: '沿着明亮河岸慢慢骑，障碍稀疏，留足换道时间。', theme: 'riverside', startSpeed: 8, maxSpeed: 10, brakeSpeed: 4.5, rewardMultiplier: .8, length: CYCLING_LENGTH },
  { id: 'normal', label: '普通', mapName: '村外环线', description: '熟悉的村外小路，拾取好东西，避开空井和路障。', theme: 'village', startSpeed: 11, maxSpeed: 14, brakeSpeed: 6, rewardMultiplier: 1, length: CYCLING_LENGTH },
  { id: 'hard', label: '困难', mapName: '夜港急行道', description: '穿过夜色中的港口，连续双车道障碍考验预判与刹车。', theme: 'nightHarbor', startSpeed: 16, maxSpeed: 21, brakeSpeed: 8, rewardMultiplier: 1.6, length: CYCLING_LENGTH },
];
/** Unknown or pre-difficulty data always falls back to the original normal mode. */
export function getCyclingDifficulty(value?: unknown): CyclingDifficultyConfig {
  return CYCLING_DIFFICULTIES.find(config => config.id === value) || CYCLING_DIFFICULTIES[1];
}
export type CyclingItem = {
  id: string;
  kind: 'cover' | 'bottle' | 'parcel' | 'hole' | 'barrier';
  /** -1 = left, 0 = center, 1 = right. */
  lane: number;
  distance: number;
  collected: boolean;
  passed: boolean;
};
export type CyclingEvent = {
  id: number;
  type: 'pickup' | 'hit';
  /** Active simulation time, in seconds; unaffected by pauses or wall-clock changes. */
  at: number;
  itemId: string;
  kind: CyclingItem['kind'];
  lane: number;
  distance: number;
  points: number;
};
export type CyclingState = {
  difficulty: CyclingDifficulty;
  distance: number;
  speed: number;
  lane: number;
  x: number;
  integrity: number;
  score: number;
  collected: number;
  hits: number;
  elapsed: number;
  invulnerable: number;
  slowdownRemaining: number;
  eventId: number;
  events: CyclingEvent[];
  phase: 'ready' | 'riding' | 'finished';
  items: CyclingItem[];
  message: string;
};

const INVULNERABLE_SECONDS = 1.4;
export const CYCLING_HIT_RECOVERY_SECONDS = 1.2;
const PICKUP_POINTS = { cover: 40, bottle: 15, parcel: 25 } as const;
const PICKUP_NAMES = { cover: '捡到井盖', bottle: '回收饮料瓶', parcel: '拾取路边包裹' } as const;
const bounded = (value: number, min: number, max: number, fallback = min) =>
  Number.isFinite(value) ? Math.max(min, Math.min(max, value)) : fallback;
const scoreValue = (score: number) => Math.floor(bounded(score, 0, CYCLING_MAX_SCORE));

/** Seeded layouts are replayable. Every obstacle row leaves an unobstructed lane. */
export function createCyclingState(seed = 20261003, difficulty: CyclingDifficulty = 'normal'): CyclingState {
  const config = getCyclingDifficulty(difficulty);
  let randomState = (Number.isFinite(seed) ? Math.trunc(seed) : 20261003) >>> 0;
  const random = () => {
    randomState = (Math.imul(randomState, 1664525) + 1013904223) >>> 0;
    return randomState / 4294967296;
  };
  const items: CyclingItem[] = [];
  const add = (kind: CyclingItem['kind'], lane: number, distance: number) =>
    items.push({ id: `cycling-${items.length}`, kind, lane, distance, collected: false, passed: false });
  // A forgiving first pickup gives time to learn steering before the first hazard.
  add('cover', 0, 24);
  let safeLane = 0;
  const firstHazard = config.id === 'easy' ? 64 : config.id === 'hard' ? 40 : 52;
  for (let row = 0, distance = firstHazard; distance <= config.length - 20; row++) {
    if (config.id === 'hard') {
      // Never jump directly between the outer lanes. Even the fastest rows leave
      // enough room to finish one lateral move after clearing the previous row.
      safeLane = safeLane === 0 ? (random() < .5 ? -1 : 1) : 0;
    } else safeLane = Math.max(-1, Math.min(1, safeLane + (random() < 0.5 ? -1 : 1)));
    const blocked = [-1, 0, 1].filter(lane => lane !== safeLane);
    if (random() < 0.5) blocked.reverse();
    add(row % 3 === 1 ? 'barrier' : 'hole', blocked[0], distance);
    if (config.id === 'hard' || config.id === 'normal' && row >= 4 && row % 3 === 1)
      add(config.id === 'normal' || row % 2 ? 'hole' : 'barrier', blocked[1], distance);
    add(row % 3 === 1 ? 'parcel' : 'cover', safeLane, distance);
    if (config.id === 'easy') {
      // Broad reward trails make the leisurely route rewarding despite fewer hazards.
      add('cover', safeLane, distance + 10);
      if (distance + 20 < config.length - 5) add('bottle', safeLane, distance + 20);
    } else if (row % 3 === 0) add('bottle', safeLane, distance + (config.id === 'hard' ? 5 : 10));
    distance += config.id === 'easy' ? 36 : config.id === 'hard' ? [16, 14, 12][row % 3] : 24;
  }
  items.sort((a, b) => a.distance - b.distance);
  return {
    difficulty: config.id, distance: 0, speed: 0, lane: 0, x: 0, integrity: 3, score: 0,
    collected: 0, hits: 0, elapsed: 0, invulnerable: 0, phase: 'ready', items,
    slowdownRemaining: 0, eventId: 0, events: [],
    message: `${config.mapName}：${config.description}`,
  };
}

export function startCycling(state: CyclingState): CyclingState {
  return state.phase === 'ready'
    ? { ...state, difficulty: getCyclingDifficulty(state.difficulty).id, phase: 'riding', speed: getCyclingDifficulty(state.difficulty).startSpeed, message: '出发！左右换道，按住刹车可以减速。' }
    : state;
}

export function steerCycling(state: CyclingState, direction: -1 | 1): CyclingState {
  if (state.phase === 'finished' || (direction !== -1 && direction !== 1)) return state;
  const lane = Math.max(-1, Math.min(1, Math.round(bounded(state.lane, -1, 1, 0)) + direction));
  return lane === state.lane ? state : { ...state, lane };
}

/** Intersect the full movement segment with a pickup/hazard, including lane changes. */
function crossingTime(from: number, to: number, xFrom: number, xTo: number, item: CyclingItem): number | null {
  if (!Number.isFinite(item.distance) || ![-1, 0, 1].includes(item.lane)) return null;
  const xCenter = item.lane * CYCLING_LANE_WIDTH;
  let enter = 0;
  let leave = 1;
  const obstacle = item.kind === 'hole' || item.kind === 'barrier';
  for (const [start, end, center, radius] of [
    [from, to, item.distance, obstacle ? 1.05 : 0.9],
    [xFrom, xTo, xCenter, obstacle ? 0.88 : 0.95],
  ]) {
    const delta = end - start;
    if (Math.abs(delta) < 1e-9) {
      if (Math.abs(start - center) > radius) return null;
    } else {
      const a = (center - radius - start) / delta;
      const b = (center + radius - start) / delta;
      enter = Math.max(enter, Math.min(a, b));
      leave = Math.min(leave, Math.max(a, b));
      if (enter > leave) return null;
    }
  }
  return enter;
}

/** dt is seconds. Background/resume gaps are capped, so a hidden tab cannot skip a road. */
export function stepCycling(state: CyclingState, dt: number, brake = false): CyclingState {
  if (state.phase !== 'riding' || !Number.isFinite(dt) || dt <= 0) return state;
  const duration = Math.min(dt, 0.25);
  const slices = Math.ceil(duration / (1 / 60));
  const slice = duration / slices;
  const config = getCyclingDifficulty(state.difficulty);
  const next: CyclingState = {
    ...state,
    difficulty: config.id,
    distance: bounded(state.distance, 0, config.length),
    speed: bounded(state.speed, 0, config.maxSpeed, config.startSpeed),
    lane: Math.round(bounded(state.lane, -1, 1, 0)),
    x: bounded(state.x, -CYCLING_LANE_WIDTH, CYCLING_LANE_WIDTH, 0),
    integrity: Math.floor(bounded(state.integrity, 0, 3)),
    score: scoreValue(state.score),
    collected: Math.floor(bounded(state.collected, 0, state.items.length)),
    hits: Math.floor(bounded(state.hits, 0, 3)),
    elapsed: bounded(state.elapsed, 0, 3600),
    invulnerable: bounded(state.invulnerable, 0, INVULNERABLE_SECONDS),
    slowdownRemaining: bounded(state.slowdownRemaining, 0, CYCLING_HIT_RECOVERY_SECONDS),
    eventId: Math.floor(bounded(state.eventId, 0, Number.MAX_SAFE_INTEGER - 12)),
    events: (state.events || []).filter(event => Number.isFinite(event.at) && event.at >= state.elapsed - 3).slice(-12),
    items: state.items.map(item => ({ ...item })),
  };
  for (let n = 0; n < slices && next.phase === 'riding'; n++) {
    if (next.integrity === 0) {
      next.phase = 'finished';
      next.speed = 0;
      next.message = '自行车需要修理啦，本次骑行结束。';
      break;
    }
    const from = next.distance;
    const xFrom = next.x;
    next.slowdownRemaining = Math.max(0, next.slowdownRemaining - slice);
    const cruisingSpeed = config.startSpeed + (config.maxSpeed - config.startSpeed) * from / config.length;
    const recovery = 1 - next.slowdownRemaining / CYCLING_HIT_RECOVERY_SECONDS;
    const recoverySpeed = config.brakeSpeed * .75 + (cruisingSpeed - config.brakeSpeed * .75) * recovery;
    const targetSpeed = brake ? Math.min(config.brakeSpeed, recoverySpeed) : recoverySpeed;
    next.speed += (targetSpeed - next.speed) * (1 - Math.exp(-3 * slice));
    next.distance = Math.min(config.length, from + next.speed * slice);
    next.x += (next.lane * CYCLING_LANE_WIDTH - next.x) * (1 - Math.exp(-10 * slice));
    next.elapsed = Math.min(3600, next.elapsed + slice);
    next.invulnerable = Math.max(0, next.invulnerable - slice);
    const encounters = next.items
      .filter(item => !item.collected && !item.passed)
      .map(item => ({ item, time: crossingTime(from, next.distance, xFrom, next.x, item) }))
      .filter((event): event is { item: CyclingItem; time: number } => event.time !== null)
      .sort((a, b) => a.time - b.time);
    for (const { item, time } of encounters) {
      item.passed = true;
      if (item.kind === 'hole' || item.kind === 'barrier') {
        if (next.invulnerable > 0) continue;
        next.integrity--;
        next.hits++;
        next.invulnerable = INVULNERABLE_SECONDS;
        next.slowdownRemaining = CYCLING_HIT_RECOVERY_SECONDS;
        next.speed = Math.max(2.5, Math.min(next.speed * .55, config.brakeSpeed * .75));
        next.events.push({ id: ++next.eventId, type: 'hit', at: next.elapsed - slice * (1 - time), itemId: item.id, kind: item.kind, lane: item.lane, distance: item.distance, points: 0 });
        next.message = item.kind === 'hole' ? '小心无盖井！耐久 −1，赶快换道。' : '碰到路障了！耐久 −1，赶快换道。';
        if (next.integrity === 0) {
          next.distance = from + (next.distance - from) * time;
          next.x = xFrom + (next.x - xFrom) * time;
          next.phase = 'finished';
          next.speed = 0;
          next.message = '自行车需要修理啦，本次骑行结束。';
          break;
        }
      } else {
        item.collected = true;
        next.collected++;
        next.score = Math.min(CYCLING_MAX_SCORE, next.score + PICKUP_POINTS[item.kind]);
        next.events.push({ id: ++next.eventId, type: 'pickup', at: next.elapsed - slice * (1 - time), itemId: item.id, kind: item.kind, lane: item.lane, distance: item.distance, points: PICKUP_POINTS[item.kind] });
        next.message = `${PICKUP_NAMES[item.kind]} +${PICKUP_POINTS[item.kind]} 分`;
      }
    }
    for (const item of next.items) {
      if (next.distance > item.distance + 1.2) item.passed = true;
    }
    if (next.phase === 'riding' && next.distance >= config.length) {
      next.phase = 'finished';
      next.speed = 0;
      next.score = Math.min(CYCLING_MAX_SCORE, next.score + next.integrity * 50);
      next.message = `抵达终点！剩余耐久奖励 +${next.integrity * 50} 分。`;
    }
  }
  next.events = next.events.filter(event => event.at >= next.elapsed - 3).slice(-12);
  return next;
}

/** Scores have a different scale from quiz games; rewards stay deliberately bounded. */
export function cyclingReward(score: number, difficulty: CyclingDifficulty = 'normal'): { shells: number; bond: number } {
  const points = scoreValue(score);
  const multiplier = getCyclingDifficulty(difficulty).rewardMultiplier;
  return { shells: 8 + Math.floor(points / 20 * multiplier), bond: 3 + Math.floor(points / 200 * multiplier) };
}
