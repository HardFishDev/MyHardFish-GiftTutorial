import { Component, lazy, Suspense, useEffect, useRef, useState } from "react";
import type { ReactNode, ErrorInfo } from "react";
import { createRoot } from "react-dom/client";
import LoadingScreen from "./LoadingScreen";
import "./style.css";
const App = lazy(() => import("./App"));
const CyclingStandalone = lazy(() => import("./CyclingStandalone"));

function Entry() {
  const [cycling, setCycling] = useState(() => location.hash.toLowerCase() === "#cycling");
  const routeRef = useRef(cycling);
  useEffect(() => {
    const route = () => {
      const next = location.hash.toLowerCase() === "#cycling";
      if (next === routeRef.current) return;
      routeRef.current = next;
      window.dispatchEvent(new Event("hardfish:before-route"));
      setCycling(next);
    };
    window.addEventListener("hashchange", route);
    return () => window.removeEventListener("hashchange", route);
  }, []);
  return <Suspense key={cycling ? "cycling" : "world"} fallback={<LoadingScreen variant={cycling ? "cycling" : "world"} />} >
    {cycling ? <CyclingStandalone /> : <App />}
  </Suspense>;
}

class ErrorBoundary extends Component<
  { children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("游戏界面暂时遇到问题", error, info.componentStack);
  }
  render() {
    if (this.state.failed)
      return (
        <main className="fatal-error">
          <h1>小窝暂时打了个盹。</h1>
          <p>界面遇到了问题。已保存的进度仍留在浏览器中。</p>
          <button onClick={() => location.reload()}>重新打开小窝</button>
        </main>
      );
    return this.props.children;
  }
}
createRoot(document.getElementById("root")!).render(
  <ErrorBoundary>
    <Entry />
  </ErrorBoundary>,
);
