import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { NanyuCharacter } from './character';
import type { CharacterActivityKind, CharacterActivityProp, CharacterActivityContext, CharacterFood } from './character';
import { ACTIVITY_PRESETS } from './world-activities';
import { resolveActivityAnchors, resolveSeats, resolveLogicalActivityAnchor, isStoryActivityRequest } from './world-activity-anchors';
import type { ActivitySeat, WorldActivityAnchor } from './world-activity-anchors';
import { buildEnvironment } from './environment';
import type { Environment, Obstacle } from './environment';
import { WorldAtmosphere } from './world-atmosphere';
import { WorldNavigation } from './world-navigation';
import { WorldCameraCutaway } from './world-camera-cutaway';
import { createDbhCharacter } from './dbh-character';
import type { DbhAction } from './dbh-character';
import { waitForScenePaint } from './scene-transition';

export type Place = 'home' | 'kitchen' | 'park' | 'shop' | 'school' | 'village' | 'workshop' | 'river' | 'market';
export type Outfit = 'classic' | 'mint' | 'chef' | 'student' | 'night';
export type Motion = 'idle' | 'happy' | 'angry' | 'eat' | 'sleep' | 'dance';
export type CameraMode = 'follow' | 'overview';
export interface BeginActivityOptions {hotspotId?:string;prop?:CharacterActivityProp;food?:CharacterFood;seated?:boolean;duration?:number;}
type PendingActivity={kind:CharacterActivityKind;options:BeginActivityOptions;anchor?:WorldActivityAnchor;seat?:ActivitySeat;approach:THREE.Vector3};
type ActiveActivity=Omit<PendingActivity,'approach'>&{returnPoint:THREE.Vector3;from:THREE.Vector3;goal:THREE.Vector3;facing:number;groundY:number;context:CharacterActivityContext;started:number;expires:number|null;cameraFramed:boolean};
export type WorldHotspot = {id:string;anchorId?:string;label:string;x:number;z:number;distance:number;kind?:'travel'|'adventure'|'interaction';radius?:number};
export type NavigationTarget = {id:string;label:string;x:number;z:number;distance:number;arrived:boolean};
const v = (x=0,y=0,z=0) => new THREE.Vector3(x,y,z);

export class FishWorld {
  renderer:THREE.WebGLRenderer;
  scene=new THREE.Scene();
  camera:THREE.PerspectiveCamera;
  controls:OrbitControls;
  character=new NanyuCharacter();
  fish=this.character.root;
  room=new THREE.Group();
  ray=new THREE.Raycaster();
  target=v();
  route:THREE.Vector3[]=[];
  obstacles:Obstacle[]=[];
  motion:Motion='idle';motionUntil=0;clock=new THREE.Clock();raf=0;
  reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
  place:Place='home';disposed=false;
  walkable:THREE.Object3D[]=[];hotspots:THREE.Object3D[]=[];
  private hotspotMarkers:THREE.Object3D[]=[];
  resizeObserver:ResizeObserver;onInteract:(id:string)=>void;
  elapsed=0;lastMove=0;active=true;quality='high';ready=false;
  private suspended=false;
  private sceneTransition?:AbortController;
  private sceneLoading=false;
  private resumeSceneTransition?:()=>void;
  private sceneRevision=0;
  private environment:Environment|undefined;
  private cleanup:(()=>void)[]=[];
  private keys=new Set<string>();
  private joystick=new THREE.Vector2();
  private resetPointerInput=()=>{};
  private moveMarker:THREE.Mesh;
  private markerUntil=0;
  private sun:THREE.DirectionalLight;
  private ambient:THREE.HemisphereLight;
  private skyTexture:THREE.Texture;
  private environmentMap:THREE.WebGLRenderTarget;
  private nav:WorldNavigation|undefined;
  private navigationTarget:{id:string;label:string;x:number;z:number}|null=null;
  private pendingInteraction:string|null=null;
  private pendingAnchorId:string|undefined;
  private activityAnchors:WorldActivityAnchor[]=[];
  private seats:ActivitySeat[]=[];
  private activity:ActiveActivity|null=null;
  private pendingActivity:PendingActivity|null=null;
  private activityViewOpen=false;
  private focusUntil=0;
  private focusPoint=v();
  private navigationBeacon:THREE.Group;
  private routeLine:THREE.Line;
  private worldFlags=new Set<string>();
  private shadowCenter=v(Infinity,0,Infinity);
  private mobile=false;
  private lastStats=0;
  private lastRender=0;
  private desiredLook=v();
  private lastCharacterPosition=v();
  private tmpDirection=v();
  private tmpForward=v();
  private tmpRight=v();
  private walking=false;
  private cutawayWalls:THREE.Object3D[]=[];
  private cameraTrees:THREE.Object3D[]=[];
  private cameraCutaway:WorldCameraCutaway|undefined;
  private cameraSight=new THREE.Line3();
  private treeCenter=v();
  private sightPoint=v();
  private orbiting=false;
  private inspectUntil=0;
  cameraMode:CameraMode='follow';
  private atmosphere:WorldAtmosphere|undefined;
  private dbh:ReturnType<typeof createDbhCharacter>|null=null;
  private dbhConversation=false;
  private dbhLabel:THREE.Object3D|undefined;
  private dbhAction:DbhAction='idle';
  private dbhActionUntil=0;
  private dbhGreeted=false;
  private dbhLook=v();
  private hotspotInfo:{id:string;anchorId?:string;label:string;x:number;z:number;w:number;d:number;approach?:readonly [number,number];kind:'travel'|'adventure'|'interaction';radius:number}[]=[];

  constructor(private host:HTMLElement,onInteract:(id:string)=>void) {
    this.onInteract=onInteract;
    this.renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,preserveDrawingBuffer:true,powerPreference:'high-performance'});
    this.renderer.setPixelRatio(Math.min(devicePixelRatio,1.65));
    this.renderer.shadowMap.enabled=true;this.renderer.shadowMap.type=THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace=THREE.SRGBColorSpace;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.0;
    const canvas=this.renderer.domElement;canvas.setAttribute('aria-label','难鱼的三维世界。点击地面行走，拖动观察，方向键或 WASD 移动。');canvas.setAttribute('role','img');canvas.tabIndex=0;canvas.style.touchAction='none';
    host.appendChild(canvas);
    this.camera=new THREE.PerspectiveCamera(44,1,.12,260);
    this.controls=new OrbitControls(this.camera,canvas);this.controls.enableDamping=true;this.controls.dampingFactor=.065;this.controls.enablePan=false;this.controls.minDistance=7;this.controls.maxDistance=26;this.controls.minPolarAngle=.45;this.controls.maxPolarAngle=1.39;this.controls.rotateSpeed=.58;this.controls.zoomSpeed=.65;
    this.controls.touches.ONE=THREE.TOUCH.ROTATE;this.controls.touches.TWO=THREE.TOUCH.DOLLY_PAN;
    this.controls.addEventListener('start',()=>{this.orbiting=true;});this.controls.addEventListener('end',()=>{this.orbiting=false;this.inspectUntil=this.elapsed+4;});
    this.ambient=new THREE.HemisphereLight('#fff7df','#a1aaa1',2.1);this.scene.add(this.ambient);
    this.sun=new THREE.DirectionalLight('#ffe6bd',3.5);this.sun.position.set(-7,16,9);this.sun.castShadow=true;this.sun.shadow.mapSize.set(2048,2048);Object.assign(this.sun.shadow.camera,{left:-21,right:21,top:21,bottom:-21,near:.5,far:65});this.sun.shadow.normalBias=.035;this.sun.shadow.bias=-.00018;this.sun.shadow.radius=3;this.scene.add(this.sun,this.sun.target);
    const fill=new THREE.DirectionalLight('#e0ece6',.55);fill.position.set(8,5,-7);this.scene.add(fill);
    const generator=new THREE.PMREMGenerator(this.renderer);const studio=new RoomEnvironment();this.environmentMap=generator.fromScene(studio,.045);this.scene.environment=this.environmentMap.texture;this.scene.environmentIntensity=.22;studio.dispose();generator.dispose();
    const sky=document.createElement('canvas');sky.width=2;sky.height=256;const context=sky.getContext('2d')!;const gradient=context.createLinearGradient(0,0,0,256);gradient.addColorStop(0,'#9db7bb');gradient.addColorStop(.5,'#d5dfd6');gradient.addColorStop(1,'#ede8d4');context.fillStyle=gradient;context.fillRect(0,0,2,256);this.skyTexture=new THREE.CanvasTexture(sky);this.skyTexture.colorSpace=THREE.SRGBColorSpace;
    this.scene.add(this.fish);this.fish.scale.setScalar(.84);
    this.moveMarker=new THREE.Mesh(new THREE.RingGeometry(.29,.33,48),new THREE.MeshBasicMaterial({color:'#fcf0c4',transparent:true,opacity:.85,depthWrite:false,side:THREE.DoubleSide}));this.moveMarker.rotation.x=-Math.PI/2;this.moveMarker.visible=false;this.scene.add(this.moveMarker);
    this.navigationBeacon=new THREE.Group();this.navigationBeacon.visible=false;
    const goalRing=new THREE.Mesh(new THREE.RingGeometry(.57,.66,48),new THREE.MeshBasicMaterial({color:'#eac36f',transparent:true,opacity:.85,depthWrite:false,side:THREE.DoubleSide}));goalRing.rotation.x=-Math.PI/2;this.navigationBeacon.add(goalRing);
    const goalArrow=new THREE.Mesh(new THREE.ConeGeometry(.22,.4,4),new THREE.MeshBasicMaterial({color:'#f2d189'}));goalArrow.rotation.z=Math.PI;goalArrow.position.y=2.5;this.navigationBeacon.add(goalArrow);this.scene.add(this.navigationBeacon);
    this.routeLine=new THREE.Line(new THREE.BufferGeometry(),new THREE.LineBasicMaterial({color:'#e4bb63',transparent:true,opacity:.75,depthWrite:false}));this.routeLine.visible=false;this.scene.add(this.routeLine);
    this.resizeObserver=new ResizeObserver(()=>this.resize());this.resizeObserver.observe(host);this.resize();this.applyPlace('home');
    this.host.dataset.sceneLoading='false';this.host.dataset.sceneTransition='ready';this.host.dataset.sceneRevision='0';
    this.installInput();
    this.host.dataset.ready='loading';this.host.dataset.outfit='classic';this.animate();
  }
  private installInput() {
    const canvas=this.renderer.domElement;let down={x:0,y:0,time:0};let pointerCount=0;let multiTouch=false;
    const pointerdown=(e:PointerEvent)=>{if(this.suspended||this.sceneLoading)return;pointerCount++;if(pointerCount>1)multiTouch=true;if(pointerCount===1){down={x:e.clientX,y:e.clientY,time:performance.now()};multiTouch=false;}canvas.focus({preventScroll:true});this.lastMove=this.elapsed;};
    const pointerup=(e:PointerEvent)=>{pointerCount=Math.max(0,pointerCount-1);if(this.suspended||this.sceneLoading||multiTouch||e.button>0||Math.hypot(e.clientX-down.x,e.clientY-down.y)>8||performance.now()-down.time>550)return;
      this.pick(e.clientX,e.clientY,true);
    };
    const pointercancel=()=>{pointerCount=0;multiTouch=false;};
    this.resetPointerInput=pointercancel;
    let lastHover=0;const pointermove=(e:PointerEvent)=>{if(this.suspended||this.sceneLoading||e.pointerType==='touch'||e.buttons||performance.now()-lastHover<75)return;lastHover=performance.now();this.pick(e.clientX,e.clientY,false);};
    const keydown=(e:KeyboardEvent)=>{if(this.suspended||this.sceneLoading||this.dbhConversation)return;const target=e.target as HTMLElement|null;if(target?.closest('input,textarea,select,[contenteditable="true"],[role="dialog"],dialog'))return;if(document.querySelector('[role="dialog"][aria-modal="true"],dialog[open]'))return;if(e.key.toLowerCase()==='e'){if(!e.repeat)this.interactNearest();return;}if(!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','w','a','s','d','W','A','S','D'].includes(e.key))return;e.preventDefault();this.cancelActivity();this.keys.add(e.key.toLowerCase());this.lastMove=this.elapsed;this.route=[];this.pendingInteraction=null;this.routeLine.visible=false;this.target.copy(this.fish.position);};
    const keyup=(e:KeyboardEvent)=>this.keys.delete(e.key.toLowerCase());
    const blur=()=>{this.keys.clear();this.joystick.set(0,0);pointercancel();};
    const visibility=()=>{this.active=!document.hidden;this.clock.getDelta();if(!this.active)blur();};
    canvas.addEventListener('pointerdown',pointerdown);canvas.addEventListener('pointerup',pointerup);canvas.addEventListener('pointercancel',pointercancel);canvas.addEventListener('pointermove',pointermove);window.addEventListener('keydown',keydown);window.addEventListener('keyup',keyup);window.addEventListener('blur',blur);document.addEventListener('visibilitychange',visibility);
    this.cleanup.push(()=>{canvas.removeEventListener('pointerdown',pointerdown);canvas.removeEventListener('pointerup',pointerup);canvas.removeEventListener('pointercancel',pointercancel);canvas.removeEventListener('pointermove',pointermove);window.removeEventListener('keydown',keydown);window.removeEventListener('keyup',keyup);window.removeEventListener('blur',blur);document.removeEventListener('visibilitychange',visibility);});
  }
  private pick(x:number,y:number,activate:boolean) {
    const bounds=this.renderer.domElement.getBoundingClientRect();this.ray.setFromCamera(new THREE.Vector2((x-bounds.left)/bounds.width*2-1,-(y-bounds.top)/bounds.height*2+1),this.camera);
    const fishHit=this.ray.intersectObject(this.fish,true);const hits=this.ray.intersectObjects(this.hotspots,false);const markers=this.ray.intersectObjects(this.hotspotMarkers,false);let action='',label='';
    if(markers.length&&(!fishHit.length||markers[0].distance<fishHit[0].distance)){action=markers[0].object.userData.action;label=markers[0].object.userData.label;}
    else if(fishHit.length&&(!hits.length||fishHit[0].distance<hits[0].distance)){action='pet';label='摸摸难鱼';}
    else if(hits.length){action=hits[0].object.userData.action;label=hits[0].object.userData.label;}
    this.host.dataset.hover=label;this.renderer.domElement.style.cursor=action?'pointer':'grab';
    if(!activate||this.dbhConversation)return;
    if(action){if(action==='pet'){this.beginActivity('talk',{duration:2.5});this.onInteract(action);}else{const hit=markers.length&&markers[0].object.userData.action===action?markers[0]:hits.find(h=>h.object.userData.action===action);this.walkToHotspot(action,{interactOnArrival:true,anchorId:hit?.object.userData.activityAnchorId});}return;}
    const ground=this.ray.intersectObjects(this.walkable,false);if(ground.length)this.walkTo(ground[0].point.x,ground[0].point.z);
  }
  private faceCamera(){const a=Math.atan2(this.camera.position.x-this.fish.position.x,this.camera.position.z-this.fish.position.z);this.fish.rotation.y=a;}
  get transitioning() { return this.sceneLoading; }
  /** Scene changes yield first, and report ready only after the new frame paints. */
  async changePlace(place:Place,options:{from?:Place;entry?:string}={}):Promise<boolean> {
    if(this.disposed)return false;
    this.sceneTransition?.abort();
    const transition=new AbortController();this.sceneTransition=transition;
    const from=options.from??this.place;
    this.sceneLoading=true;this.host.dataset.sceneLoading='true';this.host.dataset.sceneTransition='loading';delete this.host.dataset.sceneError;
    this.controls.enabled=false;this.keys.clear();this.joystick.set(0,0);this.resetPointerInput();this.cancelActivity();this.clearNavigation();this.walking=false;this.orbiting=false;
    this.host.dataset.walking='false';this.host.dataset.hover='';
    try {
      do {
        if(!await this.waitUntilResumed(transition.signal)||!await waitForScenePaint(transition.signal))return false;
      } while(this.suspended);
      this.host.dataset.sceneTransition='building';
      if(!this.environment||this.place!==place||options.entry)this.applyPlace(place,{...options,from});
      this.updateDbh(0);this.character.update(this.elapsed,0,this.motion,false);this.atmosphere?.update(this.elapsed,this.reduced,this.quality==='low');
      this.updateSceneView();
      this.renderer.render(this.scene,this.camera);this.lastRender=performance.now();
      this.host.dataset.sceneRevision=String(++this.sceneRevision);
      if(!await waitForScenePaint(transition.signal))return false;
      return true;
    } catch {
      if(this.sceneTransition===transition&&!this.disposed){this.host.dataset.sceneError='场景暂时没能准备好，请重新选择区域。';this.host.dataset.sceneTransition='error';}
      return false;
    } finally {
      if(this.sceneTransition===transition&&!this.disposed){
        this.sceneTransition=undefined;this.sceneLoading=false;this.host.dataset.sceneLoading='false';
        if(!this.host.dataset.sceneError)this.host.dataset.sceneTransition='ready';
        this.controls.enabled=!this.suspended;this.clock.getDelta();
      }
    }
  }
  private waitUntilResumed(signal:AbortSignal):Promise<boolean> {
    if(signal.aborted||!this.suspended)return Promise.resolve(!signal.aborted);
    return new Promise(resolve=>{
      const finish=(ready:boolean)=>{signal.removeEventListener('abort',abort);if(this.resumeSceneTransition===resume)this.resumeSceneTransition=undefined;resolve(ready);};
      const resume=()=>finish(true),abort=()=>finish(false);
      this.resumeSceneTransition=resume;signal.addEventListener('abort',abort,{once:true});
    });
  }
  private applyPlace(place:Place,options:{from?:Place;entry?:string}={}) {
    // Build each owning resource before replacing the current map. If preparation
    // fails, its partial resources are freed and the current scene remains usable.
    const environment=buildEnvironment(place);
    let dbh:ReturnType<typeof createDbhCharacter>|null=null,atmosphere:WorldAtmosphere|undefined,nav:WorldNavigation;
    try {
      if(place==='village'){dbh=createDbhCharacter();dbh.root.scale.setScalar(.84);dbh.root.position.set(-3.8,environment.heightAt(-3.8,1.7),1.7);}
      atmosphere=new WorldAtmosphere(place);nav=new WorldNavigation(environment.bounds,environment.obstacles,environment.navigationStep);
    } catch(error){environment.dispose();dbh?.dispose();atmosphere?.dispose();throw error;}
    this.setDbhConversation(false);this.dbh?.root.removeFromParent();this.dbh?.dispose();this.dbh=null;this.host.dataset.dbhDetails='null';this.host.dataset.dbhAction='';
    this.cancelActivity();const from=options.from??this.place;
    this.place=place;this.cameraCutaway?.dispose();this.atmosphere?.dispose();this.environment?.root.removeFromParent();this.environment?.dispose();
    this.environment=environment;this.nav=nav;this.room=this.environment.root;this.cutawayWalls=this.room.children.filter(o=>o.userData.wallAxis);this.cameraTrees=this.room.children.filter(o=>o.userData.tree);this.scene.add(this.room);this.walkable=this.environment.walkable;this.hotspots=this.environment.hotspots;this.obstacles=this.environment.obstacles;
    this.hotspotMarkers=this.hotspots.flatMap(object=>object.userData.marker?[object.userData.marker]:[]);
    this.dbhLabel=this.hotspotMarkers.find(object=>object.userData.action==='npc:dbh');
    this.dbh=dbh;if(dbh){this.scene.add(dbh.root);this.dbhAction='idle';this.dbhGreeted=false;}
    this.atmosphere=atmosphere;this.scene.add(this.atmosphere.root);
    this.room.updateMatrixWorld(true);this.activityAnchors=resolveActivityAnchors(this.environment,place);this.seats=resolveSeats(this.environment);this.hotspotInfo=this.hotspots.map(object=>{const box=new THREE.Box3().setFromObject(object),center=box.getCenter(v()),size=box.getSize(v());return{anchorId:object.userData.activityAnchorId,id:String(object.userData.action),label:String(object.userData.label),x:center.x,z:center.z,w:size.x,d:size.z,approach:this.activityAnchors.find(a=>a.object===object)?.approach??object.userData.approach,kind:object.userData.kind??'interaction',radius:object.userData.radius??2.5};});
    this.cameraCutaway=new WorldCameraCutaway(this.room,this.fish);
    const lighting=this.environment.lighting;this.scene.background=lighting.sky?new THREE.Color(lighting.sky):this.skyTexture;this.scene.fog=new THREE.Fog(lighting.fog,lighting.fogNear,lighting.fogFar);
    this.sun.intensity=lighting.sunIntensity;this.ambient.intensity=lighting.ambientIntensity;this.sun.color.set(lighting.sun);this.shadowCenter.set(Infinity,0,Infinity);
    // Fast map/task travel uses entry:'spawn'; physical doors supply their source place.
    const entry=options.entry==='spawn'?undefined:this.environment.entries[(options.entry??from) as Place];this.fish.position.copy(this.environment.spawn);if(entry)this.fish.position.set(entry.x,this.environment.heightAt(entry.x,entry.z),entry.z);
    this.clearNavigation();this.target.copy(this.fish.position);this.lastCharacterPosition.copy(this.fish.position);this.route=[];this.motion='idle';this.keys.clear();this.joystick.set(0,0);this.moveMarker.visible=false;this.lastMove=this.elapsed;
    this.controls.minAzimuthAngle=-Infinity;this.controls.maxAzimuthAngle=Infinity;if(this.blocked(this.fish.position.x,this.fish.position.z)){const nearest=this.nav!.nearest(this.fish.position.x,this.fish.position.z);if(nearest>=0)this.fish.position.copy(this.nav!.points[nearest]);this.target.copy(this.fish.position);}this.resetCamera();if(entry)this.fish.rotation.y=entry.facing;else this.faceCamera();this.setWorldFlags([...this.worldFlags]);
    this.host.dataset.place=place;this.host.dataset.walking='false';this.host.dataset.position=`${this.fish.position.x.toFixed(2)},${this.fish.position.z.toFixed(2)}`;
  }
  private blocked(x:number,z:number,margin=.6) { return this.nav?this.nav.blocked(x,z,margin):true; }
  walkTo(x:number,z:number) {
    if(this.suspended||this.sceneLoading||!this.nav||!Number.isFinite(x)||!Number.isFinite(z))return;
    this.cancelActivity();this.pendingInteraction=null;this.route=this.nav.findPath(this.fish.position,x,z);
    this.target.copy(this.route.shift()??this.fish.position);this.lastMove=this.elapsed;this.motion='idle';this.host.dataset.walking='true';
    const endPoint=this.route[this.route.length-1]??this.target;
    this.moveMarker.position.set(endPoint.x,this.environment!.heightAt(endPoint.x,endPoint.z)+.08,endPoint.z);this.moveMarker.visible=true;this.markerUntil=this.elapsed+2.2;
    this.drawRoute();
  }
  private drawRoute() {
    const path=[this.fish.position,this.target,...this.route],points:THREE.Vector3[]=[];
    for(let i=1;i<path.length;i++){const a=path[i-1],b=path[i],steps=Math.max(1,Math.ceil(Math.hypot(b.x-a.x,b.z-a.z)/1.2));for(let n=0;n<steps;n++){const x=THREE.MathUtils.lerp(a.x,b.x,n/steps),z=THREE.MathUtils.lerp(a.z,b.z,n/steps);points.push(v(x,this.environment!.heightAt(x,z)+.11,z));}}
    const end=path[path.length-1];points.push(v(end.x,this.environment!.heightAt(end.x,end.z)+.11,end.z));
    this.routeLine.geometry.dispose();this.routeLine.geometry=new THREE.BufferGeometry().setFromPoints(points);this.routeLine.visible=Boolean(this.navigationTarget)&&points.length>1;
  }
  focusHotspot(id:string) {
    if(this.suspended||this.sceneLoading)return false;
    const hotspot=this.hotspotInfo.find(h=>h.id===id);if(!hotspot)return false;
    const [x,z]=hotspot.approach??[hotspot.x,hotspot.z];this.navigationTarget={id,label:hotspot.label,x,z};this.focusPoint.set(hotspot.x,1.2,hotspot.z);this.focusUntil=this.elapsed+3.5;
    this.navigationBeacon.position.set(x,this.environment!.heightAt(x,z)+.10,z);this.navigationBeacon.visible=true;return true;
  }
  walkToHotspot(id:string,options:{interactOnArrival?:boolean;anchorId?:string}={}) {
    if(this.suspended||this.sceneLoading)return false;
    const anchor=this.activityAnchor(id,options.anchorId);if(!anchor||!this.nav)return false;
    this.cancelActivity();const approach=this.safeActivityPoint(...anchor.approach);if(!approach)return false;
    const x=approach.x,z=approach.z;
    const wasOverview=this.cameraMode==='overview';this.cameraMode='follow';this.host.dataset.cameraMode='follow';if(wasOverview)this.resetCamera();
    this.walkTo(x,z);this.navigationTarget={id,label:anchor.label,x,z};this.pendingInteraction=options.interactOnArrival?id:null;this.pendingAnchorId=anchor.id;this.focusUntil=0;
    this.navigationBeacon.position.set(x,this.environment!.heightAt(x,z)+.10,z);this.navigationBeacon.visible=true;this.drawRoute();return true;
  }
  clearNavigation() {this.pendingActivity=null;this.pendingAnchorId=undefined;this.navigationTarget=null;this.pendingInteraction=null;this.focusUntil=0;this.route=[];this.target.copy(this.fish.position);if(this.navigationBeacon)this.navigationBeacon.visible=false;if(this.routeLine)this.routeLine.visible=false;}
  setWorldFlags(flags:Iterable<string>) {this.worldFlags=new Set(flags);this.room.traverse(object=>{if(object.userData.worldFlag)object.visible=this.worldFlags.has(String(object.userData.worldFlag));});}
  setJoystick(x:number,z:number){if(this.suspended||this.sceneLoading||this.dbhConversation)return;this.joystick.set(THREE.MathUtils.clamp(x,-1,1),THREE.MathUtils.clamp(z,-1,1));if(this.joystick.lengthSq()>0){this.cancelActivity();this.route=[];this.pendingInteraction=null;this.routeLine.visible=false;this.target.copy(this.fish.position);this.lastMove=this.elapsed;}}
  setMovement(x:number,z:number){this.setJoystick(Number.isFinite(x)?x:0,Number.isFinite(z)?z:0);}
  getHotspots():WorldHotspot[]{if(this.sceneLoading)return [];return this.hotspotInfo.map(({id,anchorId,label,x,z,w,d,approach,kind,radius})=>({id,anchorId,label,x,z,kind,radius,distance:approach?Math.hypot(this.fish.position.x-approach[0],this.fish.position.z-approach[1]):Math.hypot(Math.max(0,Math.abs(this.fish.position.x-x)-w/2),Math.max(0,Math.abs(this.fish.position.z-z)-d/2))})).sort((a,b)=>a.distance-b.distance);}
  interactNearest(){const hotspot=this.getHotspots()[0];if(!hotspot||hotspot.distance>(hotspot.radius??2.5))return false;return this.walkToHotspot(hotspot.id,{interactOnArrival:true,anchorId:hotspot.anchorId});}
  getSnapshot(){const target=this.navigationTarget;const distance=target?Math.hypot(target.x-this.fish.position.x,target.z-this.fish.position.z):0;return{npc:this.dbhSnapshot(),activity:this.activitySnapshot(),cameraOcclusion:this.cameraCutaway?.getSnapshot()??null,place:this.place,position:{x:this.fish.position.x,z:this.fish.position.z},heading:this.fish.rotation.y,cameraHeading:Math.atan2(this.camera.position.x-this.controls.target.x,this.camera.position.z-this.controls.target.z),cameraMode:this.cameraMode,walking:this.walking,nearestHotspot:this.getHotspots()[0]??null,navigation:target?{...target,distance,arrived:distance<.75} as NavigationTarget:null};}
  private activityAnchor(id:string,anchorId?:string) {
    return this.activityAnchors.filter(a=>a.hotspotId===id&&(!anchorId||a.id===anchorId))
      .sort((a,b)=>Math.hypot(a.approach[0]-this.fish.position.x,a.approach[1]-this.fish.position.z)-Math.hypot(b.approach[0]-this.fish.position.x,b.approach[1]-this.fish.position.z))[0];
  }
  private safeActivityPoint(x:number,z:number) {
    if(!this.nav)return null;
    const candidates=[v(x,0,z)];
    for(const radius of [.45,.85,1.25,1.8,2.5])for(let i=0;i<12;i++)candidates.push(v(x+Math.sin(i*Math.PI/6)*radius,0,z+Math.cos(i*Math.PI/6)*radius));
    for(const point of candidates){if(this.blocked(point.x,point.z))continue;const path=this.nav.findPath(this.fish.position,point.x,point.z),end=path[path.length-1];if(end&&end.distanceTo(v(point.x,0,point.z))<.25){point.y=this.environment!.heightAt(point.x,point.z);return point;}}
    return null;
  }
  /** Scene actions only expose a prop after reaching a safe physical interaction point. */
  beginActivity(kind:CharacterActivityKind,options:BeginActivityOptions={}) {
    if(this.suspended||this.sceneLoading||!(kind in ACTIVITY_PRESETS)||!this.environment||!this.nav)return false;
    const existing=this.activity;
    const inheritedStory=!options.hotspotId&&existing?.options.hotspotId&&isStoryActivityRequest(existing.options.hotspotId)?existing.options.hotspotId:undefined;
    const requestedId=options.hotspotId??inheritedStory;
    const storyRequest=requestedId&&isStoryActivityRequest(requestedId);
    let anchor=existing?.anchor;
    if(requestedId){
      const logical=()=>resolveLogicalActivityAnchor(this.place,requestedId,kind,this.activityAnchors,this.seats,[this.fish.position.x,this.fish.position.z],options.seated,storyRequest?existing?.anchor:undefined);
      anchor=storyRequest?logical():this.activityAnchor(requestedId)??logical();
    }
    if(requestedId&&!anchor)return false;
    if(!anchor&&['cook','water','shop','write','read','play'].includes(kind))anchor=this.activityAnchors.filter(a=>a.activity?.kind===kind).sort((a,b)=>Math.hypot(a.approach[0]-this.fish.position.x,a.approach[1]-this.fish.position.z)-Math.hypot(b.approach[0]-this.fish.position.x,b.approach[1]-this.fish.position.z))[0];
    const preset=anchor?.activity;
    const wantsSeat=options.seated??(kind==='sit'||(preset?.kind===kind&&preset.seated===true)||Boolean(existing?.seat&&!options.hotspotId&&['eat','read','talk','write'].includes(kind)));
    let seat=wantsSeat?(anchor?.seat?.kinds.includes(kind)?anchor.seat:undefined)??(existing?.anchor?.id===anchor?.id&&existing?.seat?.kinds.includes(kind)?existing.seat:undefined):undefined;
    if(wantsSeat&&!seat){const origin=anchor?.target??[this.fish.position.x,0,this.fish.position.z];seat=[...this.seats].filter(s=>s.kinds.includes(kind)&&(!anchor||Math.hypot(s.position[0]-origin[0],s.position[2]-origin[2])<7)).sort((a,b)=>Math.hypot(a.position[0]-origin[0],a.position[2]-origin[2])-Math.hypot(b.position[0]-origin[0],b.position[2]-origin[2]))[0];}
    const resolvedKind=kind==='sit'&&!seat?'talk':kind;
    const normalized:BeginActivityOptions={...options,hotspotId:requestedId,seated:Boolean(seat),prop:options.prop??ACTIVITY_PRESETS[resolvedKind].prop};
    if(existing&&existing.seat?.id===seat?.id&&existing.anchor?.id===anchor?.id){this.startActivity(resolvedKind,normalized,anchor,seat,existing.returnPoint.clone(),true);return true;}
    this.cancelActivity();
    const at=seat?.approach??anchor?.approach??[this.fish.position.x,this.fish.position.z];
    const approach=this.safeActivityPoint(at[0],at[1]);if(!approach)return false;
    const pending={kind:resolvedKind,options:normalized,anchor,seat,approach};
    if(Math.hypot(approach.x-this.fish.position.x,approach.z-this.fish.position.z)<.28){this.startActivity(resolvedKind,normalized,anchor,seat,approach);return true;}
    this.walkTo(approach.x,approach.z);this.pendingActivity=pending;
    this.navigationTarget={id:anchor?.hotspotId??`activity:${resolvedKind}`,label:anchor?.label??'走到合适的位置',x:approach.x,z:approach.z};
    this.navigationBeacon.position.set(approach.x,approach.y+.1,approach.z);this.navigationBeacon.visible=true;this.drawRoute();this.updateActivityView();return true;
  }
  private startActivity(kind:CharacterActivityKind,options:BeginActivityOptions,anchor:WorldActivityAnchor|undefined,seat:ActivitySeat|undefined,returnPoint:THREE.Vector3,reuse=false) {
    if(!this.environment)return;
    const previous=this.activity;const from=this.fish.position.clone();
    if(previous?.anchor?.object.userData.propSource)previous.anchor.object.userData.propSource.visible=true;
    const arrivedNavigation=this.navigationTarget&&anchor?.hotspotId===this.navigationTarget.id&&Math.hypot(returnPoint.x-this.navigationTarget.x,returnPoint.z-this.navigationTarget.z)<.3?this.navigationTarget:null;
    this.clearNavigation();
    if(arrivedNavigation){this.navigationTarget=arrivedNavigation;this.navigationBeacon.visible=true;}
    this.pendingActivity=null;this.walking=false;this.keys.clear();this.joystick.set(0,0);
    const facing=seat?.facing??anchor?.facing??this.fish.rotation.y;
    const goal=seat?v(seat.position[0],0,seat.position[2]):this.fish.position.clone();
    if(seat){const local=this.fish.getObjectByName('seat-contact')?.position??v();const offset=v(local.x,0,local.z).multiply(this.fish.scale).applyAxisAngle(THREE.Object3D.DEFAULT_UP,facing);goal.sub(offset);}
    const groundY=this.environment.heightAt(goal.x,goal.z);goal.y=groundY;
    const scale=this.fish.getWorldScale(v(1,1,1)).y;
    const seatHeight=seat?(seat.position[1]-groundY)/scale:undefined;
    const surfaceHeight=anchor?(anchor.surfaceHeight-groundY)/scale:seat?.surfaceHeight===undefined?undefined:(seat.surfaceHeight-groundY)/scale;
    this.fish.position.copy(goal);this.fish.rotation.y=facing;this.fish.updateMatrixWorld(true);
    const target=seat?.target??anchor?.target;
    const localTarget=target?this.fish.worldToLocal(v(...target)).toArray() as [number,number,number]:undefined;
    this.fish.position.copy(from);this.fish.updateMatrixWorld(true);
    const context:CharacterActivityContext={kind,prop:options.prop??ACTIVITY_PRESETS[kind].prop,food:options.food,seated:Boolean(seat),seatHeight,surfaceHeight,target:localTarget};
    this.character.setActivity(context);
    this.activity={kind,options,anchor,seat,returnPoint,from,goal,facing,groundY,context,started:this.elapsed-(reuse ? .7 : 0),expires:options.duration&&Number.isFinite(options.duration)?this.elapsed+Math.max(.2,options.duration):null,cameraFramed:reuse?previous?.cameraFramed??false:false};
    if(anchor?.object.userData.propSource)anchor.object.userData.propSource.visible=false;
    this.target.copy(this.fish.position);this.lastMove=this.elapsed;this.motion='idle';this.motionUntil=0;
    this.host.dataset.activity=kind;this.frameActivityCamera();this.updateActivityView();
  }
  cancelActivity(options:{retainTimed?:boolean}={}) {
    if(options.retainTimed&&(this.activity?.expires!==null&&this.activity?.expires!==undefined||this.pendingActivity?.options.duration))return;
    const active=this.activity,pending=this.pendingActivity;
    if(!active&&!pending)return;
    // A canceled approach owns its route; a completed unrelated navigation stays available.
    if(pending)this.clearNavigation();
    if(active?.anchor?.object.userData.propSource)active.anchor.object.userData.propSource.visible=true;
    if(active?.seat&&this.environment){this.fish.position.copy(active.returnPoint);this.fish.position.y=this.environment.heightAt(this.fish.position.x,this.fish.position.z);}
    this.activity=null;this.pendingActivity=null;
    this.character.setActivity(null);this.target.copy(this.fish.position);this.lastMove=this.elapsed;
    this.host.dataset.activity='';this.host.dataset.activityDetails='null';this.updateActivityView();
  }
  setActivityView(open:boolean){this.activityViewOpen=open;this.updateActivityView();}
  /** A separate game owns input and rendering without replacing the village map. */
  setSuspended(suspended:boolean) {
    this.host.dataset.suspended=String(suspended);
    if(this.suspended===suspended)return;
    this.suspended=suspended;
    this.clock.getDelta();
    this.keys.clear();this.joystick.set(0,0);this.resetPointerInput();this.controls.enabled=!suspended&&!this.sceneLoading;
    if(!suspended)this.resumeSceneTransition?.();
    if(suspended){
      this.cancelActivity();this.clearNavigation();this.walking=false;this.orbiting=false;
      this.motion='idle';this.motionUntil=0;this.moveMarker.visible=false;
      this.host.dataset.walking='false';this.host.dataset.hover='';
      this.host.dataset.position=`${this.fish.position.x.toFixed(2)},${this.fish.position.z.toFixed(2)}`;
    }
    this.lastMove=this.elapsed;this.lastRender=0;
  }
  /** One framing decision per interaction; orbiting remains the player's choice. */
  private frameActivityCamera(){
    const activity=this.activity;
    if(!activity||activity.cameraFramed||!['read','write','cook','sit','eat'].includes(activity.kind))return;
    activity.cameraFramed=true;
    if(this.cameraMode!=='follow'||this.orbiting||this.elapsed<this.inspectUntil)return;
    const facing=activity.facing,dx=this.camera.position.x-activity.goal.x,dz=this.camera.position.z-activity.goal.z;
    if(Math.sin(facing)*dx+Math.cos(facing)*dz>=0)return;
    const target=this.controls.target,offset=this.camera.position.clone().sub(target),radius=Math.hypot(offset.x,offset.z);
    if(radius<.1)return;
    const azimuth=Math.atan2(offset.x,offset.z);let best:THREE.Vector3|undefined,bestScore=Infinity;
    for(const degrees of [70,82])for(const side of [-1,1]){
      const angle=facing+side*THREE.MathUtils.degToRad(degrees);
      const point=v(target.x+Math.sin(angle)*radius,this.camera.position.y,target.z+Math.cos(angle)*radius);
      let score=Math.abs(Math.atan2(Math.sin(angle-azimuth),Math.cos(angle-azimuth)))+(degrees-70)*.035;
      // Favor the room's open side; a nearly side-on option avoids the wall
      // behind a kitchen counter without changing zoom, camera height or target.
      for(const wall of this.cutawayWalls??[]){const axis=wall.userData.wallAxis as 'x'|'z';score+=Math.max(0,wall.position[axis]+.9-point[axis])*1000;}
      for(const obstacle of this.obstacles)if(obstacle.w>5&&obstacle.d>5&&Math.abs(point.x-obstacle.x)<obstacle.w/2+.8&&Math.abs(point.z-obstacle.z)<obstacle.d/2+.8)score+=10;
      if(score<bestScore){best=point;bestScore=score;}
    }
    if(best){this.camera.position.copy(best);this.camera.lookAt(target);this.controls.update?.();}
  }
  private updateActivityView(){
    if(!this.camera)return;
    const enabled=this.dbhConversation||this.activityViewOpen&&Boolean(this.activity||this.pendingActivity);
    if(enabled)this.frameActivityCamera();
    const w=this.host.clientWidth,h=this.host.clientHeight;
    const panelBelow=this.dbhConversation?w<=700:this.mobile;
    this.camera.fov=this.mobile?(enabled?49:43):44;
    if(enabled&&w&&h){const x=panelBelow?0:Math.min(this.dbhConversation?386:460,w*.46)/2,y=panelBelow?h*.245:0;this.camera.setViewOffset(w,h,x,y,w,h);}
    else this.camera.clearViewOffset();
    this.camera.updateProjectionMatrix();
  }
  private activitySnapshot(){
    const active=this.activity,pending=this.pendingActivity;if(!active&&!pending)return null;
    const kind=active?.kind??pending!.kind,options=active?.options??pending!.options,anchor=active?.anchor??pending?.anchor,seat=active?.seat??pending?.seat;
    const pose=this.character.getActivitySnapshot();
    const xyz=(a:readonly number[]|null|undefined)=>a?{x:a[0],y:a[1],z:a[2]}:null;
    const seatContact=active?.seat?xyz(pose.seatContact):null;
    const seatAnchor=seat?{id:seat.id,...xyz(seat.position)!,width:seat.width,depth:seat.depth}:null;
    const box=new THREE.Box3(),part=new THREE.Box3();this.fish.updateMatrixWorld(true);
    this.fish.traverseVisible(object=>{if(!(object instanceof THREE.Mesh)||object.userData.qaRole==='outline')return;const material=Array.isArray(object.material)?object.material:[object.material];if(material.every(m=>!m.visible||m.opacity===0))return;if(!object.geometry.boundingBox)object.geometry.computeBoundingBox();if(object.geometry.boundingBox)box.union(part.copy(object.geometry.boundingBox).applyMatrix4(object.matrixWorld));});
    const w=this.host.clientWidth,h=this.host.clientHeight;let left=Infinity,top=Infinity,right=-Infinity,bottom=-Infinity;
    for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z]){const p=v(x,y,z).project(this.camera);const sx=(p.x*.5+.5)*w,sy=(-p.y*.5+.5)*h;left=Math.min(left,sx);right=Math.max(right,sx);top=Math.min(top,sy);bottom=Math.max(bottom,sy);}
    const root=this.fish.getWorldPosition(v()).project(this.camera);
    return {kind,prop:options.prop??ACTIVITY_PRESETS[kind].prop,food:options.food??null,phase:pending?'approaching':this.elapsed-active!.started<.7?'settling':'active',requestedHotspotId:options.hotspotId??null,hotspotId:anchor?.hotspotId??null,anchorId:anchor?.id??null,position:{x:this.fish.position.x,y:this.fish.position.y,z:this.fish.position.z},heading:this.fish.rotation.y,groundY:active?.groundY??this.environment!.heightAt(this.fish.position.x,this.fish.position.z),seatHeight:active?.context.seatHeight??null,seatAnchor,seatContact,seatContactError:seatAnchor&&seatContact?Math.hypot(seatAnchor.x-seatContact.x,seatAnchor.y-seatContact.y,seatAnchor.z-seatContact.z):null,seated:pose.seated,visibleProps:pose.visibleProps.map(p=>({name:p.name,prop:p.prop,position:xyz(p.position)})),foodGrip:xyz(pose.foodGrip),mouthContact:xyz(pose.mouth),foodMouthDistance:pose.gripToMouth,propPosition:xyz(pose.propPosition),propOriginToMouth:pose.propOriginToMouth,remaining:active?.expires===null||active?.expires===undefined?null:Math.max(0,active.expires-this.elapsed),screen:Number.isFinite(left)?{root:{x:(root.x*.5+.5)*w,y:(-root.y*.5+.5)*h},bounds:{left,top,right,bottom,width:right-left,height:bottom-top}}:null};
  }
  setCameraMode(mode:CameraMode){if(this.sceneLoading)return;this.cameraMode=mode;this.host.dataset.cameraMode=mode;this.resetCamera();}
  outfit(outfit:Outfit){this.character.setOutfit(outfit);this.host.dataset.outfit=outfit;}
  act(motion:Motion,duration=2.5,interruptPath=false){
    if(this.suspended||this.sceneLoading)return;
    if(this.activity||this.pendingActivity){this.lastMove=this.elapsed;return;}
    this.motion=motion;this.motionUntil=this.elapsed+duration;this.character.startMotion(motion);
    this.host.dataset.motion=motion;this.lastMove=this.elapsed;this.faceCamera();
    // A gesture takes place where she is standing; fresh movement input can interrupt it.
    if(interruptPath||motion==='sleep'){this.clearNavigation();this.walking=false;}
    if(motion==='sleep'){this.keys.clear();this.joystick.set(0,0);}
  }
  resize(){const w=this.host.clientWidth,h=this.host.clientHeight;if(!w||!h)return;const previous=this.mobile;this.mobile=w/h<.85;this.renderer.setSize(w,h);this.camera.aspect=w/h;this.camera.fov=this.mobile?43:44;this.updateActivityView();if(previous!==this.mobile&&this.environment)this.resetCamera();}
  resetCamera(){
    if(this.dbhConversation){this.frameDbhCamera();return;}
    if(this.cameraMode==='overview'&&this.environment){const b=this.environment.bounds,span=Math.max(b.maxX-b.minX,b.maxZ-b.minZ)*(this.mobile?1.22:1);this.controls.maxDistance=Math.max(64,span*1.65);this.controls.target.set((b.minX+b.maxX)/2,.7,(b.minZ+b.maxZ)/2);this.camera.position.copy(this.controls.target).add(v(span*.55,span*.81,span*.73));}
    else{this.controls.maxDistance=26;const p=this.fish.position;this.controls.target.set(p.x,1.8+p.y,p.z-.2);const offset=this.mobile?this.environment?.camera?.mobile:this.environment?.camera?.desktop;this.camera.position.copy(this.controls.target).add(offset?v(...offset):this.mobile?v(6.4,6.7,10.9):v(7.2,6.3,10.4));}
    this.controls.update();
  }
  focusCharacter(){const p=this.fish.position;this.controls.target.set(p.x,1.8+p.y,p.z);const direction=this.camera.position.clone().sub(this.controls.target).normalize();this.camera.position.copy(this.controls.target).addScaledVector(direction,this.mobile?9:11);this.controls.update();}
  setQuality(low:boolean){
    const quality=low?'low':'high',changed=this.quality!==quality;this.quality=quality;
    this.character.setQuality(low);
    this.host.dataset.quality=quality;
    this.renderer.setPixelRatio(low?1:Math.min(devicePixelRatio,this.mobile?1.5:1.65));this.renderer.shadowMap.enabled=!low;
    // Shadow defines belong to compiled shaders; changing the renderer flag alone leaves stale shadow sampling.
    if(changed){const materials=new Set<THREE.Material>();this.scene.traverse(object=>{if(object instanceof THREE.Mesh)(Array.isArray(object.material)?object.material:[object.material]).forEach(material=>materials.add(material));});materials.forEach(material=>{material.needsUpdate=true;});}
    this.resize();
  }
  private tickMovement(dt:number) {
    if(this.dbhConversation){this.walking=false;this.host.dataset.walking='false';return;}
    let inputX=this.joystick.x+(this.keys.has('arrowright')||this.keys.has('d')?1:0)-(this.keys.has('arrowleft')||this.keys.has('a')?1:0);
    let inputZ=this.joystick.y+(this.keys.has('arrowdown')||this.keys.has('s')?1:0)-(this.keys.has('arrowup')||this.keys.has('w')?1:0);
    const manual=Math.abs(inputX)+Math.abs(inputZ)>.04;this.walking=false;
    if(manual&&this.activity)this.cancelActivity();
    if(this.activity){const a=this.activity,t=THREE.MathUtils.clamp((this.elapsed-a.started)/.55,0,1),ease=t*t*(3-2*t);this.fish.position.lerpVectors(a.from,a.goal,ease);this.fish.rotation.y=a.facing;this.target.copy(this.fish.position);}
    else if(manual){const length=Math.max(1,Math.hypot(inputX,inputZ));inputX/=length;inputZ/=length;this.camera.getWorldDirection(this.tmpForward);this.tmpForward.y=0;this.tmpForward.normalize();this.tmpRight.crossVectors(this.tmpForward,THREE.Object3D.DEFAULT_UP).normalize();this.tmpDirection.copy(this.tmpRight).multiplyScalar(inputX).addScaledVector(this.tmpForward,-inputZ);
      const dx=this.tmpDirection.x*3.1*dt,dz=this.tmpDirection.z*3.1*dt;
      if(!this.blocked(this.fish.position.x+dx,this.fish.position.z+dz)){this.fish.position.x+=dx;this.fish.position.z+=dz;this.walking=true;}
      else{if(!this.blocked(this.fish.position.x+dx,this.fish.position.z)){this.fish.position.x+=dx;this.walking=true;}if(!this.blocked(this.fish.position.x,this.fish.position.z+dz)){this.fish.position.z+=dz;this.walking=true;}}
      this.target.copy(this.fish.position);this.lastMove=this.elapsed;this.motion='idle';
    }else {
      if(Math.hypot(this.fish.position.x-this.target.x,this.fish.position.z-this.target.z)<.012&&this.route.length){this.target.copy(this.route.shift()!);this.drawRoute();}
      this.tmpDirection.copy(this.target).sub(this.fish.position);this.tmpDirection.y=0;const distance=this.tmpDirection.length();
      if(distance>.006){this.tmpDirection.normalize();const amount=Math.min(2.7*dt,distance);this.fish.position.addScaledVector(this.tmpDirection,amount);this.walking=true;}
    }
    if(this.walking){const angle=Math.atan2(this.tmpDirection.x,this.tmpDirection.z),delta=Math.atan2(Math.sin(angle-this.fish.rotation.y),Math.cos(angle-this.fish.rotation.y));this.fish.rotation.y+=delta*Math.min(1,dt*10);}
    else if(!this.activity&&this.motion==='idle'&&!this.orbiting&&this.elapsed>this.inspectUntil){const desired=Math.atan2(this.camera.position.x-this.fish.position.x,this.camera.position.z-this.fish.position.z);const delta=Math.atan2(Math.sin(desired-this.fish.rotation.y),Math.cos(desired-this.fish.rotation.y));this.fish.rotation.y+=delta*Math.min(1,dt*1.4);}
    if(!this.activity)this.fish.position.y=THREE.MathUtils.damp(this.fish.position.y,this.environment!.heightAt(this.fish.position.x,this.fish.position.z),18,dt);
    this.host.dataset.walking=String(this.walking);this.host.dataset.position=`${this.fish.position.x.toFixed(2)},${this.fish.position.z.toFixed(2)}`;
    // Keep the companion in frame while the room continues beyond the edges of the view.
    if(this.cameraMode==='follow'){if(this.elapsed<this.focusUntil)this.desiredLook.copy(this.focusPoint);else this.desiredLook.set(this.fish.position.x,1.8+this.fish.position.y,this.fish.position.z-.2);const change=this.desiredLook.sub(this.controls.target).multiplyScalar(1-Math.exp(-dt*2.4));this.controls.target.add(change);this.camera.position.add(change);}this.lastCharacterPosition.copy(this.fish.position);
    if(!this.walking&&!this.route.length&&this.navigationTarget&&Math.hypot(this.fish.position.x-this.navigationTarget.x,this.fish.position.z-this.navigationTarget.z)<.3){this.routeLine.visible=false;if(this.pendingActivity){const a=this.pendingActivity;this.pendingActivity=null;this.startActivity(a.kind,a.options,a.anchor,a.seat,a.approach);}else if(this.pendingInteraction){const id=this.pendingInteraction,anchor=this.activityAnchor(id,this.pendingAnchorId);this.pendingInteraction=null;this.pendingAnchorId=undefined;this.lastMove=this.elapsed;if(anchor?.activity){const preset=anchor.activity;const seat=preset.seated?anchor.seat:undefined;const kind=preset.kind==='sit'&&!seat?'talk':preset.kind;this.startActivity(kind,{prop:preset.prop,seated:Boolean(seat)},anchor,seat,this.fish.position.clone());}this.onInteract(id);}}
  }
  private updateSceneView() {
    this.controls.update();for(const wall of this.cutawayWalls)wall.visible=(wall.userData.wallAxis==='x'?this.camera.position.x:this.camera.position.z)>-10.8;
    if(this.shadowCenter.distanceToSquared(this.fish.position)>9){this.shadowCenter.copy(this.fish.position);this.sun.target.position.set(this.fish.position.x,0,this.fish.position.z);this.sun.position.set(this.fish.position.x-7,16,this.fish.position.z+9);this.sun.target.updateMatrixWorld();}
    this.cameraCutaway?.update(this.camera.position,this.elapsed,this.cameraMode==='follow');
    this.cameraSight.set(this.camera.position,this.controls.target);
    for(const tree of this.cameraTrees){this.treeCenter.set(tree.position.x,tree.userData.canopyHeight,tree.position.z);this.cameraSight.closestPointToPoint(this.treeCenter,true,this.sightPoint);tree.visible=this.cameraMode==='overview'||this.sightPoint.distanceTo(this.treeCenter)>tree.userData.canopyRadius+.6;}
  }
  private animate=()=>{if(this.disposed)return;this.raf=requestAnimationFrame(this.animate);const elapsedDelta=Math.min(this.clock.getDelta(),.25),loading=this.host.dataset.loading==='true';if(!this.active||document.hidden||this.suspended||this.sceneLoading||loading&&this.ready)return;const dt=loading?0:elapsedDelta;this.elapsed+=dt;if(this.activity?.expires!==null&&this.activity?.expires!==undefined&&this.elapsed>=this.activity.expires)this.cancelActivity();if(this.elapsed>this.motionUntil&&this.motion!=='idle')this.motion='idle';this.host.dataset.motion=this.activity?.kind??this.motion;
    // Simulation follows wall time on slow devices; small movement steps preserve collision safety.
    const steps=Math.max(1,Math.ceil(dt/.04));for(let i=0;i<steps;i++)this.tickMovement(dt/steps);
    if(!this.activity&&!this.pendingActivity&&!this.reduced&&!this.walking&&!this.orbiting&&this.motion==='idle'&&this.elapsed-this.lastMove>35&&!document.querySelector('[role="dialog"],dialog[open]')){this.lastMove=this.elapsed;for(let i=0;i<8;i++){const x=this.fish.position.x+(Math.random()-.5)*5.5,z=this.fish.position.z+(Math.random()-.5)*5.5;if(!this.blocked(x,z)){this.walkTo(x,z);break;}}}
    this.updateDbh(dt);this.character.update(this.elapsed,dt,this.motion,this.walking);this.atmosphere?.update(this.elapsed,this.reduced,this.quality==='low');
    this.updateSceneView();
    if(this.moveMarker.visible){this.moveMarker.visible=this.elapsed<this.markerUntil;(this.moveMarker.material as THREE.MeshBasicMaterial).opacity=Math.min(.85,Math.max(0,this.markerUntil-this.elapsed));this.moveMarker.scale.setScalar(1+Math.sin(this.elapsed*5)*.06);}
    if(this.navigationBeacon.visible){this.navigationBeacon.children[1].position.y=2.5+(this.reduced?0:Math.sin(this.elapsed*3)*.12);this.navigationBeacon.children[1].rotation.y=this.reduced?0:this.elapsed*.65;}
    const dialogOpen=loading||Boolean(document.querySelector('dialog[open],[role="dialog"][aria-modal="true"]'));
    const backgroundFps=loading?1:this.activityViewOpen&&this.activity?(this.mobile?24:30):this.quality==='low'?8:18;
    this.host.dataset.backgroundFps=dialogOpen?String(backgroundFps):'auto';
    if(this.lastRender===0||!dialogOpen||performance.now()-this.lastRender>=1000/backgroundFps){this.renderer.render(this.scene,this.camera);this.lastRender=performance.now();if(!this.ready&&this.fish.userData.ready){this.ready=true;this.host.dataset.ready='true';}}
    if(performance.now()-this.lastStats>1000){this.lastStats=performance.now();this.host.dataset.drawCalls=String(this.renderer.info.render.calls);this.host.dataset.triangles=String(this.renderer.info.render.triangles);this.host.dataset.geometries=String(this.renderer.info.memory.geometries);this.host.dataset.textures=String(this.renderer.info.memory.textures);this.host.dataset.activity=this.activity?.kind??this.pendingActivity?.kind??'';this.host.dataset.activityDetails=JSON.stringify(this.activitySnapshot());this.host.dataset.cameraOcclusion=JSON.stringify(this.cameraCutaway?.getSnapshot()??null);}
  };
  setDbhConversation(open:boolean) {
    if(open&&this.sceneLoading)return false;
    if(open&&(!this.dbh||this.place!=='village'||this.fish.position.distanceTo(this.dbh.root.position)>4.6))return false;
    if(this.dbhConversation===open)return true;
    this.dbhConversation=open;this.keys.clear();this.joystick.set(0,0);
    if(open){
      this.cancelActivity();this.clearNavigation();this.walking=false;this.motion='idle';this.motionUntil=0;
      this.cameraMode='follow';this.host.dataset.cameraMode='follow';
      this.fish.rotation.y=Math.atan2(-3.8-this.fish.position.x,1.7-this.fish.position.z);
      this.playDbhAction('wave');this.frameDbhCamera();
    }else{this.controls.minDistance=7;this.lastMove=this.elapsed;this.playDbhAction('bye');this.resetCamera();}
    this.updateActivityView();return true;
  }
  playDbhAction(action:DbhAction) {
    if(!this.dbh)return false;
    this.dbhAction=action;this.dbhActionUntil=this.elapsed+(action==='dance'?8:action==='photo'?7:action==='stretch'?6:4.5);
    this.dbh.setAction(action);this.host.dataset.dbhAction=action;
    if(action==='photo'){this.motion='idle';this.motionUntil=0;this.faceCamera();this.frameDbhCamera();}
    return true;
  }
  private frameDbhCamera(){
    if(!this.dbh)return;
    this.controls.minDistance=5;this.controls.maxDistance=16;
    this.controls.target.set(-2.85,1.8,2.1);
    this.camera.position.copy(this.controls.target).add(this.mobile?v(.7,1.2,12.3):v(.7,1.0,8.7));
    this.controls.update();this.updateActivityView();
  }
  private dbhSnapshot(){
    if(!this.dbh)return null;
    const root=this.dbh.root,p=root.position.clone().add(v(0,1.8,0)).project(this.camera);
    return {id:'dbh',qq:'80117801',action:this.dbhAction,conversation:this.dbhConversation,position:{x:root.position.x,y:root.position.y,z:root.position.z},screen:{x:(p.x*.5+.5)*this.host.clientWidth,y:(-p.y*.5+.5)*this.host.clientHeight}};
  }
  private updateDbh(dt:number){
    if(!this.dbh)return;
    if(this.dbhLabel){this.dbhLabel.quaternion.copy(this.camera.quaternion);this.dbhLabel.visible=!this.dbhConversation;}
    const distance=this.fish.position.distanceTo(this.dbh.root.position);
    if(distance>8)this.dbhGreeted=false;
    if(!this.dbhConversation&&distance<5&&!this.dbhGreeted){this.dbhGreeted=true;this.playDbhAction('wave');}
    if(this.elapsed>this.dbhActionUntil)this.dbhAction='idle';
    const looking=distance<8;
    this.dbhLook.copy(this.dbhAction==='photo'?this.camera.position:this.fish.position).y=2.6;
    this.dbh.update(this.elapsed,dt,this.dbhAction,looking?this.dbhLook:undefined);
    this.host.dataset.dbhAction=this.dbhAction;
    if(performance.now()-this.lastStats>1000)this.host.dataset.dbhDetails=JSON.stringify(this.dbhSnapshot());
  }
  photograph(){this.renderer.render(this.scene,this.camera);return this.renderer.domElement.toDataURL('image/png');}
  photographDbh(){
    if(!this.dbh||!this.dbhConversation)return null;
    // A saved image uses the entire canvas, independent of the space reserved for the panel.
    const target=this.controls.target.clone(),position=this.camera.position.clone(),heading=this.fish.rotation.y;
    try {
      this.camera.clearViewOffset();this.controls.target.set(-2.7,1.85,2.15);
      this.camera.position.set(-2.0,2.95,this.mobile?13.5:10.5);this.camera.lookAt(this.controls.target);this.camera.updateProjectionMatrix();
      this.fish.rotation.y=Math.atan2(this.camera.position.x-this.fish.position.x,this.camera.position.z-this.fish.position.z);
      return this.photograph();
    } finally {
      this.fish.rotation.y=heading;this.controls.target.copy(target);this.camera.position.copy(position);this.controls.update();this.updateActivityView();
    }
  }
  dispose(){if(this.disposed)return;this.cancelActivity();this.disposed=true;this.sceneTransition?.abort();this.sceneTransition=undefined;cancelAnimationFrame(this.raf);this.cleanup.forEach(f=>f());this.resizeObserver.disconnect();this.controls.dispose();this.cameraCutaway?.dispose();this.atmosphere?.dispose();this.environment?.dispose();this.dbh?.dispose();this.character.dispose();this.moveMarker.geometry.dispose();(this.moveMarker.material as THREE.Material).dispose();this.navigationBeacon.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose();(o.material as THREE.Material).dispose();}});this.routeLine.geometry.dispose();(this.routeLine.material as THREE.Material).dispose();this.skyTexture.dispose();this.environmentMap.dispose();this.sun.shadow.map?.dispose();this.renderer.dispose();this.renderer.domElement.remove();}
}
