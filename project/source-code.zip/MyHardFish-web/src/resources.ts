/** Files in public are copied by Vite as-is. Keep Object.keys directly around
 * import.meta.glob: Vite's keys-only transform emits paths, not asset imports. */
const publicPaths = Object.keys(import.meta.glob([
  '/public/assets/**/*.{png,jpg,jpeg,webp,gif,svg,avif}',
  '/public/audio/**/*.{mp3,ogg,wav,m4a}',
]));

export const RESOURCE_URLS: readonly string[] = Object.freeze(publicPaths
  .filter(path => !path.startsWith('/public/audio/cycling-'))
  .sort()
  .map(path => `${import.meta.env.BASE_URL}${path.slice('/public/'.length)}`));

export interface ResourceProgress {
  /** Completed work, including a visibly reported failed request. */
  percent: number;
  completed: number;
  total: number;
  label: string;
  loadedBytes: number;
}

export interface ResourcePreloadResult {
  failed: string[];
  completed: number;
  total: number;
  aborted: boolean;
}

export const INITIAL_PROGRESS: ResourceProgress = {
  percent: 0,
  completed: 0,
  total: RESOURCE_URLS.length,
  label: '正在唤醒难鱼的小世界',
  loadedBytes: 0,
};

const CONCURRENCY = 6;
const REQUEST_IDLE_TIMEOUT_MS = 30_000;
const REQUEST_MAX_TIMEOUT_MS = 90_000;
const OVERALL_TIMEOUT_MS = 180_000;

/** Warm the browser HTTP cache without retaining a second copy of every file.
 * Each resource has equal weight. Known Content-Length contributes actual
 * downloaded fractions; unknown lengths contribute on completion. Failed work
 * completes its slot and is returned explicitly, so 100% is not a success claim.
 * A transient transport/stream failure gets one fresh request in the same slot.
 * Both attempts share the resource's hard deadline. HTTP errors and explicit
 * cancellation remain visible failures, without an automatic retry loop.
 * Browser/server caching rules still govern subsequent media cache reuse.
 */
export async function preloadResources(
  onProgress: (progress: ResourceProgress) => void,
  signal?: AbortSignal,
  options?: { retry?: boolean; urls?: readonly string[]; label?: string },
): Promise<ResourcePreloadResult> {
  const urls = options?.urls ?? RESOURCE_URLS;
  const total = urls.length;
  const fractions = new Float64Array(total);
  const finished = new Uint8Array(total);
  const failures = new Set<string>();
  const controller = new AbortController();
  let cursor = 0;
  let completed = 0;
  let loadedBytes = 0;
  let externallyAborted = signal?.aborted ?? false;
  let timedOut = false;
  let lastPercent = -1;
  let lastCompleted = -1;

  const notify = (label: string, force = false) => {
    if (externallyAborted) return;
    const percent = total === 0 ? 100 : Math.min(100,
      Math.floor(fractions.reduce((sum, fraction) => sum + fraction, 0) / total * 100));
    if (!force && percent === lastPercent && completed === lastCompleted) return;
    lastPercent = percent;
    lastCompleted = completed;
    onProgress({ percent, completed, total, label, loadedBytes });
  };
  const externalAbort = () => {
    externallyAborted = true;
    controller.abort();
  };
  if (externallyAborted) controller.abort();
  else signal?.addEventListener('abort', externalAbort, { once: true });

  const deadline = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, OVERALL_TIMEOUT_MS);

  const loadOne = async (index: number) => {
    const url = urls[index];
    let activeRequest: AbortController | null = null;
    let hardExpired = false;
    const cancelRequest = () => activeRequest?.abort();
    controller.signal.addEventListener('abort', cancelRequest, { once: true });
    const hardTimeout = setTimeout(() => {
      hardExpired = true;
      cancelRequest();
    }, REQUEST_MAX_TIMEOUT_MS);
    const label = options?.label ?? (url.includes('/audio/music-') ? '正在准备各场景的纯音乐'
      : url.includes('/audio/') ? '正在准备难鱼的群聊语音' : '正在准备房间和人物素材');
    try {
      let succeeded = false;
      for (let attempt = 0; attempt < 2 && !controller.signal.aborted && !hardExpired; attempt++) {
        const request = new AbortController();
        activeRequest = request;
        let httpFailure = false;
        let idleTimeout = setTimeout(() => request.abort(), REQUEST_IDLE_TIMEOUT_MS);
        const noteProgress = () => {
          if (request.signal.aborted) return;
          clearTimeout(idleTimeout);
          idleTimeout = setTimeout(() => request.abort(), REQUEST_IDLE_TIMEOUT_MS);
        };
        try {
          // Manual retries and the single automatic retry bypass cached errors.
          const response = await fetch(url, {
            cache: options?.retry || attempt > 0 ? 'reload' : 'force-cache',
            signal: request.signal,
          });
          noteProgress();
          if (!response.ok) {
            httpFailure = true;
            throw new Error(`HTTP ${response.status}`);
          }
          const headerLength = Number(response.headers.get('content-length'));
          // A compressed Content-Length does not describe decoded stream bytes.
          const length = !response.headers.get('content-encoding') && headerLength > 0
            ? headerLength : 0;
          let received = 0;
          if (response.body) {
            const reader = response.body.getReader();
            try {
              for (;;) {
                const { done, value } = await reader.read();
                if (done) break;
                if (value.byteLength > 0) noteProgress();
                received += value.byteLength;
                loadedBytes += value.byteLength;
                if (length > 0) fractions[index] = Math.min(0.99, received / length);
                notify(label);
              }
            } finally {
              reader.releaseLock();
            }
          } else {
            const bytes = await response.arrayBuffer();
            loadedBytes += bytes.byteLength;
          }
          succeeded = true;
          break;
        } catch {
          if (attempt > 0 || httpFailure || controller.signal.aborted || hardExpired) break;
          // Discard fractional progress from the abandoned transfer. The byte
          // counter still records bytes actually received, including retransfers.
          fractions[index] = 0;
          notify('素材传输中断，正在重试一次', true);
        } finally {
          clearTimeout(idleTimeout);
          // Non-2xx responses may still stream a large error body. Stop any
          // abandoned transfer before this worker starts its next request.
          if (!succeeded) request.abort();
          activeRequest = null;
        }
      }
      if (!succeeded) failures.add(url);
    } finally {
      clearTimeout(hardTimeout);
      controller.signal.removeEventListener('abort', cancelRequest);
      fractions[index] = 1;
      finished[index] = 1;
      completed++;
      notify(label);
    }
  };

  notify(options?.label ?? INITIAL_PROGRESS.label, true);
  try {
    await Promise.all(Array.from({ length: Math.min(CONCURRENCY, total) }, async () => {
      while (!controller.signal.aborted && cursor < total) {
        const index = cursor++;
        await loadOne(index);
      }
    }));
    if (controller.signal.aborted && !externallyAborted) {
      // The global deadline also settles queued files, with explicit failures.
      for (let index = 0; index < total; index++) {
        if (finished[index]) continue;
        failures.add(urls[index]);
        fractions[index] = 1;
        completed++;
      }
    }
    notify(failures.size > 0
      ? timedOut ? '网络等待超时，可重试或先进入小镇' : '部分素材暂时没来，可重试或先进入小镇'
      : '素材已经到齐，难鱼马上就来', true);
    return { failed: [...failures], completed, total, aborted: externallyAborted };
  } finally {
    clearTimeout(deadline);
    signal?.removeEventListener('abort', externalAbort);
  }
}
