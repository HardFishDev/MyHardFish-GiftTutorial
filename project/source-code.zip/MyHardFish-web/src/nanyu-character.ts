import { NanyuCharacter } from './character';
import type { NanyuOutfit } from './character';

/** Keep the world-facing API stable without changing the independently authored model. */
export function createCharacter() {
  const model = new NanyuCharacter();
  return {
    root: model.root,
    setOutfit: (outfit: NanyuOutfit) => model.setOutfit(outfit),
    setQuality: (low: boolean) => model.setQuality(low),
    startMotion: (motion: string) => model.startMotion(motion),
    update: (elapsed: number, delta: number, motion: string, walking: boolean, _reduced?: boolean) => model.update(elapsed, delta, motion, walking),
    dispose: () => model.dispose(),
  };
}
