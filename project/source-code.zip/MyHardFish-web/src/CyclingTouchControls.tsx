import { useEffect, useId, useLayoutEffect, useRef, useState } from 'react';
import type { CSSProperties, KeyboardEvent as ReactKeyboardEvent, MouseEvent as ReactMouseEvent, PointerEvent as ReactPointerEvent } from 'react';
import { ArrowLeft, ArrowRight, HandPalm, Pause, SlidersHorizontal } from '@phosphor-icons/react';
import { getCyclingTouchPositions, normalizeCyclingTouchPreferences } from './cycling-controls';
import type { CyclingTouchGroup, CyclingTouchOrientation, CyclingTouchPosition, CyclingTouchPreferences } from './cycling-controls';
import './cycling-touch-controls.css';

export interface CyclingTouchControlsProps {
  preferences: CyclingTouchPreferences;
  editing?: boolean;
  disabled?: boolean;
  paused: boolean;
  lane: number;
  braking: boolean;
  onSteer: (direction: -1 | 1) => void;
  onBrakeSource: (source: string, active: boolean) => void;
  onPause: () => void;
  onSettings: () => void;
  onChange?: (next: CyclingTouchPreferences) => void;
  onLayoutValidChange?: (valid: boolean) => void;
}

interface BandGeometry {
  orientation: CyclingTouchOrientation;
  height: number;
  lift: number;
  topClearance: number;
}
interface ControlDrag {
  pointerId: number;
  group: CyclingTouchGroup;
  startX: number;
  startY: number;
  position: CyclingTouchPosition;
  travelX: number;
  travelY: number;
  orientation: CyclingTouchOrientation;
}
const groups: CyclingTouchGroup[] = ['steering', 'brake', 'tools'];
const groupLabels: Record<CyclingTouchGroup, string> = {
  steering: '移动方向键位置', brake: '移动减速键位置', tools: '移动工具键位置',
};
const clamp = (value: number) => Math.max(0, Math.min(1, value));

function isVirtualActivation(event: ReactMouseEvent<HTMLButtonElement>): boolean {
  const native = event.nativeEvent as MouseEvent & {
    pointerType?: string;
    sourceCapabilities?: { firesTouchEvents?: boolean } | null;
  };
  // Touch-generated clicks can also have detail 0; their pointer-down already acted.
  return event.detail === 0 && !native.pointerType && !native.sourceCapabilities?.firesTouchEvents;
}

export default function CyclingTouchControls({
  preferences, editing = false, disabled = false, paused, lane, braking,
  onSteer, onBrakeSource, onPause, onSettings, onChange, onLayoutValidChange,
}: CyclingTouchControlsProps) {
  const root = useRef<HTMLDivElement>(null);
  const band = useRef<HTMLDivElement>(null);
  const groupElements = useRef<Partial<Record<CyclingTouchGroup, HTMLDivElement>>>({});
  const drag = useRef<ControlDrag | null>(null);
  const sources = useRef(new Set<string>());
  const brakeCallback = useRef(onBrakeSource); brakeCallback.current = onBrakeSource;
  const preferencesRef = useRef(preferences); preferencesRef.current = preferences;
  const validCallback = useRef(onLayoutValidChange); validCallback.current = onLayoutValidChange;
  const lastValid = useRef<boolean | null>(null);
  const remeasure = useRef<() => void>(() => {});
  const revalidate = useRef<() => void>(() => {});
  const helpId = useId();
  const [geometry, setGeometry] = useState<BandGeometry>({ orientation: 'portrait', height: 210, lift: 0, topClearance: 150 });
  const [invalidGroups, setInvalidGroups] = useState<string>('');
  const positions = getCyclingTouchPositions(preferences, geometry.orientation);
  const blocked = disabled || paused || editing;

  function releaseSource(source: string) {
    if (sources.current.delete(source)) brakeCallback.current(source, false);
  }
  function releaseBrakes() {
    for (const source of [...sources.current]) releaseSource(source);
  }
  function pressBrake(source: string) {
    if (blocked || sources.current.has(source)) return;
    sources.current.add(source); brakeCallback.current(source, true);
  }

  useEffect(() => {
    const releasePointer = (event: PointerEvent) => releaseSource(`pointer:${event.pointerId}`);
    const releaseKey = (event: KeyboardEvent) => releaseSource(`button:${event.code || event.key}`);
    const interrupt = () => { drag.current = null; releaseBrakes(); };
    const visibility = () => { if (document.hidden) interrupt(); };
    window.addEventListener('pointerup', releasePointer);
    window.addEventListener('pointercancel', releasePointer);
    window.addEventListener('keyup', releaseKey);
    window.addEventListener('blur', interrupt);
    document.addEventListener('visibilitychange', visibility);
    return () => {
      window.removeEventListener('pointerup', releasePointer);
      window.removeEventListener('pointercancel', releasePointer);
      window.removeEventListener('keyup', releaseKey);
      window.removeEventListener('blur', interrupt);
      document.removeEventListener('visibilitychange', visibility);
      interrupt();
    };
  }, []);

  useEffect(() => {
    if (blocked) releaseBrakes();
    if (!editing) drag.current = null;
  }, [blocked, editing]);

  useLayoutEffect(() => {
    const element = root.current;
    if (!element) return;
    let frame = 0;
    const measure = () => {
      const rect = element.getBoundingClientRect();
      const orientation = rect.width >= 560 && rect.width > rect.height ? 'landscape' : 'portrait';
      const bottomInset = Number.parseFloat(getComputedStyle(element).paddingBottom) || 16;
      let topClearance = orientation === 'landscape' ? 120 : 150;
      // Existing route/HUD placement can vary with language, orientation and screen width.
      element.parentElement?.querySelectorAll<HTMLElement>('.cycling-top, .cycling-dashboard, .cycling-layout-editor-head').forEach(hud => {
        if (hud.getClientRects().length) topClearance = Math.max(topClearance, hud.getBoundingClientRect().bottom - rect.top + 12);
      });
      const available = Math.max(0, rect.height - bottomInset - topClearance);
      const height = Math.min(orientation === 'landscape' ? 115 : 210, available);
      const lift = Math.min(preferencesRef.current.verticalOffset, Math.max(0, available - height));
      setGeometry(current => current.orientation === orientation && current.height === height
        && current.lift === lift && current.topClearance === topClearance
        ? current : { orientation, height, lift, topClearance });
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => revalidate.current());
    };
    remeasure.current = measure;
    const observer = new ResizeObserver(measure);
    observer.observe(element);
    for (const group of groups) if (groupElements.current[group]) observer.observe(groupElements.current[group]!);
    element.parentElement?.querySelectorAll('.cycling-top, .cycling-dashboard, .cycling-layout-editor-head').forEach(header => observer.observe(header));
    window.addEventListener('resize', measure);
    window.visualViewport?.addEventListener('resize', measure);
    window.visualViewport?.addEventListener('scroll', measure);
    measure();
    return () => {
      cancelAnimationFrame(frame); observer.disconnect();
      window.removeEventListener('resize', measure);
      window.visualViewport?.removeEventListener('resize', measure);
      window.visualViewport?.removeEventListener('scroll', measure);
    };
  }, []);

  revalidate.current = () => {
    const rootRect = root.current?.getBoundingClientRect();
    if (!rootRect || rootRect.width === 0 || rootRect.height === 0) return;
    const viewport = window.visualViewport;
    const bounds = {
      left: Math.max(rootRect.left, viewport?.offsetLeft ?? 0),
      right: Math.min(rootRect.right, (viewport?.offsetLeft ?? 0) + (viewport?.width ?? window.innerWidth)),
      top: Math.max(rootRect.top + geometry.topClearance, viewport?.offsetTop ?? 0),
      bottom: Math.min(rootRect.bottom, (viewport?.offsetTop ?? 0) + (viewport?.height ?? window.innerHeight)),
    };
    const invalid = new Set<CyclingTouchGroup>();
    const rectangles = groups.map(group => ({ group, rect: groupElements.current[group]?.getBoundingClientRect() }));
    for (const { group, rect } of rectangles) {
      if (!rect || rect.width === 0 || rect.height === 0 || rect.left < bounds.left - .5
        || rect.right > bounds.right + .5 || rect.top < bounds.top - .5 || rect.bottom > bounds.bottom + .5)
        invalid.add(group);
    }
    for (let first = 0; first < rectangles.length; first++) {
      for (let second = first + 1; second < rectangles.length; second++) {
        const a = rectangles[first], b = rectangles[second];
        if (a.rect && b.rect && a.rect.left < b.rect.right - 1 && a.rect.right > b.rect.left + 1
          && a.rect.top < b.rect.bottom - 1 && a.rect.bottom > b.rect.top + 1) {
          invalid.add(a.group); invalid.add(b.group);
        }
      }
    }
    const next = groups.filter(group => invalid.has(group)).join(' ');
    setInvalidGroups(current => current === next ? current : next);
    const valid = invalid.size === 0;
    if (lastValid.current !== valid) { lastValid.current = valid; validCallback.current?.(valid); }
  };

  useLayoutEffect(() => {
    remeasure.current(); revalidate.current();
  }, [preferences, geometry, editing]);

  function updatePosition(group: CyclingTouchGroup, position: CyclingTouchPosition, orientation = geometry.orientation) {
    const current = preferencesRef.current;
    const next = normalizeCyclingTouchPreferences(current);
    next.positions[orientation][group] = {
      x: current.handedness === 'left' ? 1 - clamp(position.x) : clamp(position.x),
      y: clamp(position.y),
    };
    onChange?.(next);
  }

  function startDrag(group: CyclingTouchGroup, event: ReactPointerEvent<HTMLDivElement>) {
    event.stopPropagation();
    if (!editing || event.button !== 0 || !band.current) return;
    event.preventDefault();
    const area = band.current.getBoundingClientRect();
    const control = event.currentTarget.getBoundingClientRect();
    drag.current = {
      pointerId: event.pointerId, group, startX: event.clientX, startY: event.clientY,
      position: positions[group], travelX: Math.max(0, area.width - control.width),
      travelY: Math.max(0, area.height - control.height), orientation: geometry.orientation,
    };
    event.currentTarget.focus({ preventScroll: true });
    try { event.currentTarget.setPointerCapture(event.pointerId); } catch { /* The pointer may already be cancelled. */ }
  }

  function moveDrag(event: ReactPointerEvent<HTMLDivElement>) {
    const current = drag.current;
    if (!current || current.pointerId !== event.pointerId || !editing) return;
    event.preventDefault(); event.stopPropagation();
    updatePosition(current.group, {
      x: current.position.x + (current.travelX ? (event.clientX - current.startX) / current.travelX : 0),
      y: current.position.y + (current.travelY ? (event.clientY - current.startY) / current.travelY : 0),
    }, current.orientation);
  }

  function stopDrag(event: ReactPointerEvent<HTMLDivElement>) {
    if (drag.current?.pointerId !== event.pointerId) return;
    drag.current = null;
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
  }

  function moveByKey(group: CyclingTouchGroup, event: ReactKeyboardEvent<HTMLDivElement>) {
    if (!editing || event.ctrlKey || event.metaKey || event.altKey
      || !['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) return;
    event.preventDefault(); event.stopPropagation();
    const step = event.shiftKey ? .1 : .03;
    const position = positions[group];
    updatePosition(group, {
      x: position.x + (event.key === 'ArrowLeft' ? -step : event.key === 'ArrowRight' ? step : 0),
      y: position.y + (event.key === 'ArrowUp' ? -step : event.key === 'ArrowDown' ? step : 0),
    });
  }

  function groupProps(group: CyclingTouchGroup) {
    const position = positions[group];
    return {
      ref: (element: HTMLDivElement | null) => { if (element) groupElements.current[group] = element; else delete groupElements.current[group]; },
      className: `cycling-touch-group cycling-touch-${group}`,
      'data-testid': `cycling-${group}`,
      'data-group': group,
      'data-collision': invalidGroups.split(' ').includes(group),
      role: 'group',
      tabIndex: editing ? 0 : undefined,
      'aria-label': editing ? groupLabels[group] : group === 'steering' ? '骑行方向' : group === 'brake' ? '骑行减速' : '骑行工具',
      'aria-describedby': editing ? helpId : undefined,
      style: { left: `${position.x * 100}%`, top: `${position.y * 100}%`, transform: `translate(${-position.x * 100}%, ${-position.y * 100}%)` } satisfies CSSProperties,
      onPointerDown: (event: ReactPointerEvent<HTMLDivElement>) => startDrag(group, event),
      onPointerMove: moveDrag, onPointerUp: stopDrag, onPointerCancel: stopDrag, onLostPointerCapture: stopDrag,
      onKeyDown: (event: ReactKeyboardEvent<HTMLDivElement>) => moveByKey(group, event),
    };
  }

  function steerOnPointer(direction: -1 | 1, event: ReactPointerEvent<HTMLButtonElement>) {
    if (event.button !== 0 || blocked) return;
    event.preventDefault(); event.stopPropagation(); onSteer(direction);
  }
  function brakeOnPointer(event: ReactPointerEvent<HTMLButtonElement>) {
    if (event.button !== 0 || blocked) return;
    event.preventDefault(); event.stopPropagation();
    event.currentTarget.focus({ preventScroll: true });
    try { event.currentTarget.setPointerCapture(event.pointerId); } catch { /* Window pointer-up still releases the source. */ }
    pressBrake(`pointer:${event.pointerId}`);
  }
  function brakeOnKey(event: ReactKeyboardEvent<HTMLButtonElement>, active: boolean) {
    if (event.key !== ' ' && event.key !== 'Enter') return;
    if (active && (event.ctrlKey || event.metaKey || event.altKey)) return;
    event.preventDefault(); event.stopPropagation();
    const source = `button:${event.code || event.key}`;
    if (active) pressBrake(source); else releaseSource(source);
  }

  return <div ref={root} className="cycling-touch-dock" data-orientation={geometry.orientation}
    data-size={preferences.size} data-editing={editing} data-layout-valid={!invalidGroups}
    style={{ '--cycling-touch-lift': `${geometry.lift}px`, '--cycling-touch-band-height': `${geometry.height}px` } as CSSProperties}>
    {editing && <span id={helpId} className="cycling-touch-sr-only">拖动调整位置，也可使用方向键移动，按住 Shift 大步移动。红色表示重叠或超出范围。</span>}
    <div className="cycling-touch-band" ref={band}>
      <div {...groupProps('steering')}>
        <button aria-label="向左变道" disabled={blocked || lane <= -1} tabIndex={editing ? -1 : undefined}
          onPointerDown={event => steerOnPointer(-1, event)} onClick={event => { if (isVirtualActivation(event) && !blocked) onSteer(-1); }}>
          <ArrowLeft size={28} weight="bold" /><span>左移</span>
        </button>
        <button aria-label="向右变道" disabled={blocked || lane >= 1} tabIndex={editing ? -1 : undefined}
          onPointerDown={event => steerOnPointer(1, event)} onClick={event => { if (isVirtualActivation(event) && !blocked) onSteer(1); }}>
          <ArrowRight size={28} weight="bold" /><span>右移</span>
        </button>
      </div>
      <div {...groupProps('brake')}>
        <button aria-label="减速" aria-pressed={braking} disabled={blocked} tabIndex={editing ? -1 : undefined}
          onPointerDown={brakeOnPointer}
          onPointerUp={event => releaseSource(`pointer:${event.pointerId}`)}
          onPointerCancel={event => releaseSource(`pointer:${event.pointerId}`)}
          onLostPointerCapture={event => releaseSource(`pointer:${event.pointerId}`)}
          onKeyDown={event => brakeOnKey(event, true)} onKeyUp={event => brakeOnKey(event, false)}
          onBlur={releaseBrakes}
          onClick={event => {
            if (!isVirtualActivation(event) || blocked) return;
            if (sources.current.has('a11y')) releaseSource('a11y'); else pressBrake('a11y');
          }}>
          <HandPalm size={27} /><strong>减速</strong><span>按住</span>
        </button>
      </div>
      <div {...groupProps('tools')}>
        <button aria-label="暂停骑行" disabled={blocked} tabIndex={editing ? -1 : undefined}
          onClick={() => { releaseBrakes(); onPause(); }}><Pause size={21} /><span>暂停</span></button>
        <button aria-label="操作设置" disabled={editing} tabIndex={editing ? -1 : undefined}
          onClick={() => { releaseBrakes(); onSettings(); }}><SlidersHorizontal size={21} /><span>设置</span></button>
      </div>
    </div>
  </div>;
}
