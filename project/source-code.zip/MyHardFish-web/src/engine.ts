import rawQuotes from "./quotes.json" with { type: "json" };
import {
  achievementInfo,
  dailyTasks,
  foods,
  friends,
  friendProgress,
  outfits,
  places,
  stories,
} from "./content";
import type { FoodId } from "./content";
import type { Motion, Outfit, Place } from "./scene";
import { applyAdventureAction, createAdventure, getAdventureView, latestFriendQuest, recordAdventureEvent, syncAdventures } from "./adventure";
import type { ActiveGame, AdventureAction, AdventureState, GameKind } from "./adventure-types";
import { createDbhState, normalizeDbhState } from './dbh-state';
import type { DbhState } from './dbh-state';
import { CYCLING_MAX_SCORE, cyclingReward, getCyclingDifficulty } from './cycling';
import type { CyclingDifficulty } from './cycling';
export type { GameKind } from "./adventure-types";
export { getAdventureView, getQuestView } from "./adventure";

export const quotes = rawQuotes;
export const quoteMap = Object.fromEntries(quotes.map((q) => [q.id, q]));
export const GAME_MAX_SCORE: Record<GameKind, number> = { bottle: 6, cook: 3, math: 5, words: 5, harvest: 5, cycling: CYCLING_MAX_SCORE };
const gameName: Record<GameKind, string> = { bottle: "漂流瓶记忆", cook: "火候挑战", math: "五题就下课", words: "物品词卡", harvest: "浆果订单", cycling: "难鱼骑自行车" };
export type Counters = {
  chat: number;
  feed: number;
  play: number;
  pet: number;
  cook: number;
  tease: number;
};
export type Message = {
  who: "you" | "fish";
  text: string;
  quoteId?: string;
  at: number;
};
export type GameState = {
  version: 1;
  createdAt: number;
  updatedAt: number;
  name: string;
  hunger: number;
  mood: number;
  energy: number;
  bond: number;
  shells: number;
  place: Place;
  outfit: Outfit;
  inventory: Record<FoodId, number>;
  owned: Outfit[];
  visited: Place[];
  collected: string[];
  achievements: string[];
  endings: string[];
  counts: Counters;
  daily: { date: string; counts: Counters; claimed: string[] };
  records: Record<GameKind, number>;
  story: { id: string; node: string } | null;
  messages: Message[];
  journal: { at: number; text: string }[];
  topic: string;
  settings: {
    voice: boolean;
    volume: number;
    lowQuality: boolean;
    gentle: boolean;
  };
  lastReward: number;
  reaction: { id: number; text: string; quoteId?: string; motion: Motion };
  notice: string;
  revision: number;
  adventure: AdventureState;
  dbh: DbhState;
  /** Runtime-only claim credential; loading a save cancels unfinished rounds. */
  activeGame: (ActiveGame & { difficulty?: CyclingDifficulty }) | null;
};
export type Action =
  | AdventureAction
  | { type: "tick" }
  | { type: "dbh"; value: DbhState }
  | { type: "place"; value: Place }
  | { type: "chat"; text: string }
  | { type: "interact"; value: "pet" | "tease" | "praise" | "rest" | "dance" | "wave" }
  | { type: "feed" | "buyFood"; value: FoodId }
  | { type: "outfit"; value: Outfit }
  | { type: "startStory"; value: string }
  | { type: "choice"; value: string }
  | { type: "startGame"; value: GameKind; difficulty?: CyclingDifficulty }
  | { type: "cancelGame"; sessionId: string }
  | { type: "finishGame"; value: GameKind; score: number; sessionId: string }
  | { type: "claim"; value: string }
  | { type: "settings"; value: Partial<GameState["settings"]> }
  | { type: "name"; value: string }
  | { type: "recall" };

const blankCounts = (): Counters => ({
  chat: 0,
  feed: 0,
  play: 0,
  pet: 0,
  cook: 0,
  tease: 0,
});
export const localDate = (now: number) => {
  const d = new Date(now);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
export const clamp = (v: number, max = 100) => Math.min(max, Math.max(0, v));
export function newGame(now = Date.now()): GameState {
  return {
    version: 1,
    createdAt: now,
    updatedAt: now,
    name: "群友",
    hunger: 72,
    mood: 80,
    energy: 78,
    bond: 12,
    shells: 120,
    place: "home",
    outfit: "classic",
    inventory: { bun: 3, milk: 2, peach: 1, rice: 0, coffee: 0 },
    owned: ["classic"],
    visited: ["home"],
    collected: ["greeting"],
    achievements: [],
    endings: [],
    counts: blankCounts(),
    daily: { date: localDate(now), counts: blankCounts(), claimed: [] },
    records: { bottle: 0, cook: 0, math: 0, words: 0, harvest: 0, cycling: 0 },
    story: null,
    messages: [
      {
        who: "fish",
        text: quoteMap.greeting.text,
        quoteId: "greeting",
        at: now,
      },
    ],
    journal: [{ at: now, text: "难鱼住进了小窝。欢迎加入她的日常。" }],
    topic: "",
    settings: { voice: true, volume: 0.75, lowQuality: false, gentle: false },
    lastReward: 0,
    reaction: {
      id: now,
      text: quoteMap.greeting.text,
      quoteId: "greeting",
      motion: "idle",
    },
    notice: "",
    revision: 0,
    adventure: createAdventure(now),
    dbh: createDbhState(),
    activeGame: null,
  };
}
function count(s: GameState, key: keyof Counters) {
  s.counts[key]++;
  s.daily.counts[key]++;
}
function journal(s: GameState, text: string, now: number) {
  s.journal = [...s.journal.slice(-99), { at: now, text }];
}
function say(
  s: GameState,
  id: string,
  now: number,
  motion: Motion = "idle",
  extra = "",
) {
  if (
    s.settings.gentle &&
    ["dog", "rude", "goaway", "shut", "rename"].includes(id)
  )
    id = "hardjudge";
  const q = quoteMap[id];
  const text = q ? q.text + (extra ? `。${extra}` : "") : id;
  s.reaction = { id: s.revision, text, quoteId: q?.id, motion };
  s.messages = [
    ...s.messages.slice(-79),
    { who: "fish", text, quoteId: q?.id, at: now },
  ];
  if (q && !s.collected.includes(q.id)) s.collected.push(q.id);
}
function awards(s: GameState, now: number) {
  const tests: Record<string, boolean> = {
    hello: s.counts.chat + s.counts.feed + s.counts.pet + s.counts.tease >= 10,
    explore: places.every(place => s.visited.includes(place.id)),
    chef: s.counts.cook >= 3,
    math: s.records.math >= 5,
    collector: s.collected.length >= 20,
    fashion: s.owned.length >= 3,
    story: s.endings.length >= 5,
    friend: s.bond >= 60,
  };
  for (const a of achievementInfo)
    if (tests[a.id] && !s.achievements.includes(a.id)) {
      s.achievements.push(a.id);
      s.shells += a.reward;
      s.notice += `${s.notice ? " · " : ""}成就「${a.title}」+${a.reward} 贝壳`;
      journal(s, `解锁成就「${a.title}」，获得 ${a.reward} 贝壳。`, now);
    }
}
function age(s: GameState, now: number) {
  // Absence never kills the companion or destroys relationship/progress.
  const hours = clamp((now - s.updatedAt) / 3_600_000, 8);
  s.hunger = Math.max(10, s.hunger - hours * 3);
  s.energy = Math.max(15, s.energy - hours * 2);
  s.mood = Math.max(20, s.mood - hours);
  if (s.daily.date !== localDate(now))
    s.daily = { date: localDate(now), counts: blankCounts(), claimed: [] };
  s.updatedAt = now;
}
function adventureGuidance(s: GameState): string {
  const overview = getAdventureView(s);
  const tracked = overview.tracked;
  if (!tracked) return "开村日的委托都完成啦。翻翻手帐里的发现册，补上还没找到的小事，或者去回忆里重温一起闹过的故事。";
  const stage = tracked.stage || tracked.quest.stages[0];
  const place = places.find(item => item.id === stage.place)?.name || stage.place;
  if (tracked.status === "available") return `先在手帐接下「${tracked.quest.title}」，再去${place}：${stage.title}。我陪你走。`;
  const missing = tracked.requirements.filter(item => !item.met)
    .map(item => `${item.requirement.label}${item.target > 1 ? `（${item.current}/${item.target}）` : ""}`);
  const material = tracked.choices.find(item => item.reason.startsWith("还需要"))?.reason;
  const next = missing.length ? `还要${missing.join("、")}。`
    : material ? `${material}。` : "条件已经齐了，到现场选个做法就能继续。";
  return `下一步去${place}，做「${stage.title}」。${next}打开手帐可以追踪和带路，别在村口绕圈啦。`;
}
function chat(s: GameState, text: string, now: number) {
  const previous = s.topic;
  const t = text.toLowerCase();
  const pick = (ids: string[]) => ids[s.counts.chat % ids.length];
  let id = "what",
    topic = "",
    extra = "",
    motion: Motion = "idle";
  const namedFriend = friends.find((friend) =>
    [friend.name, ...friend.aliases].some((alias) =>
      /^[a-z]+$/i.test(alias)
        ? new RegExp(`\\b${alias}\\b`, "i").test(t)
        : t.includes(alias.toLowerCase()),
    ),
  );
  const previousFriend = friends.find((friend) => previous === `friend:${friend.id}`);
  const seekingComfort = /难过|伤心|累了|压力|不开心|焦虑|烦恼/.test(t);
  const seekingGoal = /下一步|接下来(?:做|干|去)|现在(?:做|干)什么|任务|委托|去哪里|去哪儿?|迷路|开村日/.test(t);
  if (seekingGoal && !seekingComfort) {
    topic = "adventure";
    id = "idea";
    extra = adventureGuidance(s);
    motion = "happy";
  } else if (namedFriend && !seekingComfort) {
    topic = `friend:${namedFriend.id}`;
    id = namedFriend.quoteId;
    extra = namedFriend.topic;
    motion = namedFriend.id === "monkey" ? "angry" : "happy";
    const adventureMemory = latestFriendQuest(s, namedFriend.id);
    const progress = friendProgress(namedFriend.id, s.endings);
    if (adventureMemory) {
      extra += ` 还记得一起完成的「${adventureMemory.title}」吗？${adventureMemory.ending.slice(0, 200)}`;
    } else if (progress.completed) {
      const recent = [...s.endings].reverse().find((ending) =>
        namedFriend.storyIds.includes(ending.split(":")[0]),
      );
      if (recent) {
        const [storyId, nodeId] = recent.split(":");
        const memory = stories.find((story) => story.id === storyId)?.nodes[nodeId]?.ending;
        if (memory) extra += ` 还记得「${memory}」吗？那次也挺有意思的。`;
      }
    }
  } else if (previousFriend && !seekingComfort && /^(好|行|可以|走|来吧|嗯|那走吧|试试|为啥|为什么|真的|然后|后来|继续|说说|还有)/.test(t)) {
    topic = previous;
    id = "okay";
    extra = previousFriend.followup;
    motion = "happy";
  } else if (
    /^(好|行|可以|走|来吧|嗯|那走吧|试试)[吧的呀啊呢！!。\s]*$/.test(t) &&
    previous
  ) {
    topic = previous;
    id = "idea";
    extra =
      (
        {
          food: "去厨房看看，包子还热着。",
          game: "去公园捡漂流瓶，输了别赖我。",
          school: "去教室，五道题就下课。",
          tech: "把那个菜单再翻一遍，说不定就在眼前。",
          movie: "选喜剧。那个黑漆漆的封面先放一边。",
          rain: "伞拿上，这次别忘。",
          sad: "那就坐会儿，我在。",
        } as Record<string, string>
      )[previous] || "那就陪我待一会儿。";
  } else if (/应援|会长|粉丝|名字|昵称/.test(t)) {
    topic = "fanclub";
    id = pick(["whatname", "rename", "police"]);
    motion = "angry";
  } else if (/鬼片|恐怖|吓你|吓人/.test(t)) {
    topic = "movie";
    id = pick(["horror", "horroraway"]);
    motion = "angry";
  } else if (/电影|喜剧|追剧/.test(t)) {
    topic = "movie";
    id = "idea";
    extra = "喜剧可以，鬼片你自己看。";
  } else if (/难过|伤心|累了|压力|不开心|焦虑|烦恼/.test(t)) {
    topic = "sad";
    id = "fine";
    extra = "今天先歇一下。想说的话，我听着。";
    motion = "happy";
  } else if (/骂|狗叫|笨|傻|丑|坏鱼|没素质/.test(t)) {
    topic = "banter";
    id = pick(["dog", "manners", "blackheart", "attack", "cold"]);
    motion = "angry";
  } else if (/谢|对不起|抱歉/.test(t)) {
    id = pick(["fine", "mercy"]);
    motion = "happy";
  } else if (/好看|可爱|喜欢你|抱抱|爱你|夸/.test(t)) {
    id = pick(["greeting", "notbelieve", "meow"]);
    extra = s.bond > 40 ? "行吧，允许你再说一遍。" : "";
    motion = "happy";
  } else if (/吃|饿|饭|包子|桃|牛奶|咖啡/.test(t)) {
    topic = "food";
    id = t.includes("咖啡") ? "no" : "idea";
    extra = s.hunger < 40 ? "有点饿了，翻翻零食袋。" : "去厨房？这次你掌勺。";
    motion = "eat";
  } else if (/数学|作业|考试|学校|学习/.test(t)) {
    topic = "school";
    id = pick(["math", "nextlife", "graduation"]);
    extra = "要不先做五道小题，做完就撤。";
  } else if (/miui|手机|电池|续航/.test(t)) {
    topic = "tech";
    id = /续航|电池/.test(t) ? "battery" : pick(["miuiokay", "battery"]);
  } else if (/电脑|下载|按钮|设置/.test(t)) {
    topic = "tech";
    id = "download";
    extra = "你帮我看看，它又藏哪了。";
  } else if (/插件|服务器|我的世界|minecraft|mc\b/.test(t)) {
    topic = "game";
    id = pick(["plugins", "chickens", "game"]);
  } else if (/玩|游戏|漂流瓶|机器人/.test(t)) {
    topic = "game";
    id = pick(["bottle", "fun", "bot", "letme"]);
    extra = "公园那个漂流瓶，要不要一起试试？";
  } else if (/下雨|伞|天气|出门/.test(t)) {
    topic = "rain";
    id = "rain";
    extra = "这回出门前，你提醒我一下。";
  } else if (/睡|晚安|休息/.test(t)) {
    topic = "sleep";
    id = "meow";
    extra = "晚安，今天先不和你计较了。";
    motion = "sleep";
  } else if (/无聊|空虚|放假/.test(t)) {
    topic = "game";
    id = pick(["holiday", "empty", "roast"]);
    extra = "要不出去走走？";
  } else if (/钱|贝壳|贵|买/.test(t)) {
    topic = "shop";
    id = pick(["money", "nomoney", "merchant"]);
    extra = "玩一局或者做做今日小事，还能攒点。";
  } else if (/喵/.test(t)) {
    id = "meow";
    motion = "happy";
  } else if (/你好|早|在吗|哈喽|hi|hello|难鱼/.test(t)) {
    id = pick(["greeting", "who", "mercy"]);
    motion = "happy";
  } else if (/为啥|为什么|真的|然后|后来|继续/.test(t) && previous) {
    topic = previous;
    id = "ask";
    extra =
      (
        {
          school: "嫌数学难，还是得一点点写。你陪我做五道就行。",
          tech: "上次吐槽续航，这次也不一定。同一台手机还得看怎么用。",
          movie: "我说了，把鬼片拿远点。喜剧不香吗。",
          sad: "不用急着把事情都解决。先把今天过完。",
          game: "嘴上说不玩了，点开还是想再来一把。",
          food: "你先做，我负责认真点评。",
          rain: "有伞就走，没伞先看天气。",
        } as Record<string, string>
      )[previous] || "刚刚那件事，你再讲具体一点。";
  } else {
    id = pick(["hardjudge", "what", "read", "dontknow"]);
    extra = "这句我还没接上。说说吃饭、游戏，或者今天怎么了？";
  }
  s.topic = topic;
  say(s, id, now, motion, extra);
}
export function step(
  input: GameState,
  action: Action,
  now = Date.now(),
): GameState {
  const s = structuredClone(input);
  // Loading normally migrates in storage.ts; this also supports an in-memory v1 upgrade.
  if (!s.adventure) s.adventure = createAdventure(now, s.revision);
  s.dbh ??= createDbhState();
  s.activeGame ??= null;
  s.revision++;
  s.notice = "";
  age(s, now);
  const rewardable = now - s.lastReward > 5000;
  switch (action.type) {
    case 'dbh':
      s.dbh = normalizeDbhState(action.value);
      break;
    case "tick":
      break;
    case "place": {
      if (
        !places.some((p) => p.id === action.value) ||
        s.place === action.value
      )
        break;
      s.place = action.value;
      if (!s.visited.includes(s.place)) {
        s.visited.push(s.place);
        s.shells += 8;
        s.notice = "发现新地点 +8 贝壳";
        journal(
          s,
          `第一次来到${places.find((p) => p.id === s.place)!.name}。`,
          now,
        );
      }
      say(
        s,
        (
          {
            home: "greeting",
            kitchen: "idea",
            park: "bottle",
            shop: "money",
            school: "math",
            village: "greeting",
            workshop: "plugins",
            river: "bottle",
            market: "money",
          } as const
        )[s.place],
        now,
        "happy",
      );
      break;
    }
    case "chat": {
      const text = action.text.trim().slice(0, 200);
      if (!text) break;
      s.messages.push({ who: "you", text, at: now });
      count(s, "chat");
      if (rewardable) {
        s.bond += 1;
        s.mood += 2;
        s.lastReward = now;
      }
      chat(s, text, now);
      break;
    }
    case "interact": {
      const v = action.value;
      if (v === "wave") {
        say(s, "greeting", now, "happy");
      }
      if (v === "pet") {
        count(s, "pet");
        if (rewardable) {
          s.bond += 2;
          s.mood += 4;
        }
        say(
          s,
          s.counts.pet % 4 === 0
            ? "police"
            : s.bond > 35
              ? "meow"
              : ["greeting", "six", "who"][s.counts.pet % 3],
          now,
          "happy",
        );
      }
      if (v === "tease") {
        count(s, "tease");
        if (rewardable) {
          s.mood -= 3;
          s.bond += 1;
        }
        say(
          s,
          ["dog", "rude", "cold", "manners", "blackheart", "police"][
            s.counts.tease % 6
          ],
          now,
          "angry",
        );
      }
      if (v === "praise") {
        if (rewardable) {
          s.mood += 7;
          s.bond += 2;
        }
        say(s, s.bond > 40 ? "greeting" : "notbelieve", now, "happy");
      }
      if (v === "rest") {
        s.energy += 30;
        s.mood += 4;
        s.notice = "歇一会儿 · 精力 +30";
        say(s, "meow", now, "sleep", "今天的互损先暂停一下。");
      }
      if (v === "dance") {
        if (s.energy < 8) {
          say(s, "no", now, "idle", "先歇会儿。");
          break;
        }
        s.energy -= 4;
        s.mood += 8;
        say(s, "fun", now, "dance");
      }
      if (rewardable && v !== "wave") s.lastReward = now;
      break;
    }
    case "feed": {
      const f = foods.find((f) => f.id === action.value);
      if (!f) break;
      if (!s.inventory[f.id]) {
        s.notice = "零食袋里没有了，去便利店补货吧";
        break;
      }
      if (s.hunger >= 98) {
        say(s, "no", now, "idle", "已经吃饱了，给我留着。");
        break;
      }
      s.inventory[f.id]--;
      s.hunger += f.hunger;
      s.mood += f.mood;
      s.energy += f.energy;
      s.bond += 2;
      count(s, "feed");
      s.notice = `${f.name} · 饱腹 +${f.hunger} · 精力 +${f.energy}`;
      say(
        s,
        f.id === "coffee"
          ? "nonsense"
          : ["thanks", "nice", "happy", "greeting"][s.counts.feed % 4],
        now,
        "eat",
      );
      break;
    }
    case "buyFood": {
      const f = foods.find((f) => f.id === action.value);
      if (!f) break;
      if (s.shells < f.price) {
        s.notice = "贝壳不够，完成今日小事或小游戏赚一点";
        break;
      }
      if (s.inventory[f.id] >= 99) {
        s.notice = "这一样已经囤了 99 份，先吃一点";
        break;
      }
      s.shells -= f.price;
      s.inventory[f.id]++;
      s.notice = `${f.name}已装进零食袋`;
      say(s, "rich", now, "happy");
      break;
    }
    case "outfit": {
      const o = outfits.find((o) => o.id === action.value);
      if (!o) break;
      if (!s.owned.includes(o.id)) {
        if (s.shells < o.price) {
          s.notice = "贝壳不够，攒够了再来试这件";
          break;
        }
        s.shells -= o.price;
        s.owned.push(o.id);
        journal(s, `把「${o.name}」放进了衣柜。`, now);
      }
      s.outfit = o.id;
      s.notice = `已穿上「${o.name}」`;
      say(s, "nice", now, "happy");
      break;
    }
    case "startStory": {
      const story = stories.find((e) => e.id === action.value);
      if (!story) break;
      if (s.story) {
        s.notice = s.story.id === story.id ? "继续上次的故事就好，进度还在" : "先完成正在进行的故事，再开新的一篇";
        break;
      }
      if (s.bond < story.minBond || s.place !== story.place) {
        s.notice = "先到对应地点，和难鱼再熟悉一点";
        break;
      }
      s.story = { id: story.id, node: "start" };
      const node = story.nodes.start;
      say(s, node.quote || "这件事，说来话长。", now);
      break;
    }
    case "choice": {
      if (!s.story) break;
      const story = stories.find((e) => e.id === s.story!.id)!;
      const current = story.nodes[s.story.node];
      if (!current.choices?.some((c) => c.next === action.value)) break;
      const node = story.nodes[action.value];
      s.story.node = action.value;
      if (node.quote) say(s, node.quote, now, node.ending ? "happy" : "idle");
      if (node.ending) {
        const key = `${story.id}:${action.value}`;
        if (!s.endings.includes(key)) {
          s.endings.push(key);
          s.bond += node.bond || 0;
          s.shells += node.shells || 0;
          s.notice = `新结局「${node.ending}」· +${node.shells} 贝壳`;
          journal(s, `《${story.title}》：${node.ending}。${node.text}`, now);
        } else s.notice = "又一起走过了这个结局，试试其他选择吧";
        recordAdventureEvent(s, { kind: "story", storyId: story.id, place: s.place });
        s.story = null;
      }
      break;
    }
    case "startGame":
      if (!Object.hasOwn(GAME_MAX_SCORE, action.value)) { s.notice = "没有找到这个小游戏"; break; }
      if (s.energy < 8) {
        s.notice = "精力不足，先休息一下再玩";
        break;
      }
      s.energy -= 8;
      s.activeGame = { id: `${now.toString(36)}:${s.revision.toString(36)}:${action.value}`, kind: action.value, place: s.place, startedAt: now, startedRevision: s.revision,
        ...(action.value === 'cycling' ? { difficulty: getCyclingDifficulty(action.difficulty).id } : {}),
      };
      s.notice = "开局消耗 8 精力";
      break;
    case "cancelGame":
      if (s.activeGame?.id === action.sessionId) {
        s.activeGame = null;
        s.notice = "已退出本局，未结算奖励";
      }
      break;
    case "finishGame": {
      const session = s.activeGame;
      if (!session || session.kind !== action.value || session.id !== action.sessionId || !Object.hasOwn(GAME_MAX_SCORE, action.value)) {
        s.notice = "这局尚未开始、已经结算或已重新开局";
        break;
      }
      if (!Number.isFinite(action.score)) { s.notice = "本局成绩无效，请重新完成这一局"; break; }
      const max = GAME_MAX_SCORE[action.value];
      const score = Math.round(clamp(action.score, max));
      // Clear before applying any payouts or task events; duplicate callbacks are harmless.
      s.activeGame = null;
      const reward = action.value === "cycling" ? cyclingReward(score, session.difficulty) : { shells: 8 + score * 5, bond: 3 + score };
      const earned = reward.shells;
      count(s, "play");
      if (action.value === "cook") {
        count(s, "cook");
        s.inventory.rice = Math.min(
          99,
          s.inventory.rice + (score >= 2 ? 2 : 1),
        );
      }
      s.records[action.value] = Math.max(s.records[action.value], score);
      s.shells += earned;
      s.bond += reward.bond;
      s.mood += 6 + (action.value === "cycling" ? Math.floor(score / 200) : score);
      s.notice = `本局 +${earned} 贝壳${action.value === "cook" ? ` · 蛋炒饭 +${score >= 2 ? 2 : 1}` : ""}`;
      recordAdventureEvent(s, { kind: "game", game: action.value, score, place: session.place, startedRevision: session.startedRevision });
      say(s, score === max ? "win" : score > 0 ? "fun" : "bot", now, "happy");
      journal(
        s,
        `${gameName[action.value]}${action.value === 'cycling' ? `（${getCyclingDifficulty(session.difficulty).label}）` : ''}：${score}/${max}，获得 ${earned} 贝壳。`,
        now,
      );
      break;
    }
    case "claim": {
      const t = dailyTasks.find((t) => t.id === action.value);
      if (
        !t ||
        s.daily.claimed.includes(t.id) ||
        s.daily.counts[t.id] < t.target
      )
        break;
      s.daily.claimed.push(t.id);
      s.shells += t.reward;
      s.notice = `今日小事完成 +${t.reward} 贝壳`;
      break;
    }
    case "settings":
      s.settings = { ...s.settings, ...action.value };
      break;
    case "name":
      s.name = action.value.trim().slice(0, 16) || "群友";
      s.notice = "称呼已更新";
      break;
    case "recall": {
      const unseen = quotes.filter((q) => !s.collected.includes(q.id));
      const q = unseen.length
        ? unseen[s.counts.chat % unseen.length]
        : quotes[s.revision % quotes.length];
      say(s, q.id, now);
      s.notice = `翻到 ${q.date} 的一句原话，语境已放进收藏册`;
      break;
    }
    case "startQuest":
    case "trackQuest":
    case "questAction":
    case "discover":
      applyAdventureAction(s, action, now, (quoteId, text) => say(s, quoteId || text, now, "happy", quoteId ? text : ""));
      break;
  }
  syncAdventures(s, now);
  s.hunger = clamp(s.hunger);
  s.mood = clamp(s.mood);
  s.energy = clamp(s.energy);
  s.bond = clamp(s.bond);
  s.shells = clamp(s.shells, 999999);
  s.messages = s.messages.slice(-80);
  awards(s, now);
  return s;
}
export const relationship = (bond: number) =>
  bond >= 80
    ? "嘴硬的自己人"
    : bond >= 50
      ? "固定饭搭子"
      : bond >= 25
        ? "可以互损了"
        : "刚认识的群友";
