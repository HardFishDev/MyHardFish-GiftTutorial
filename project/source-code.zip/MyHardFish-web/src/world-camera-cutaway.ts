import * as THREE from 'three';

type CutawayPart = {
  object: THREE.Object3D;
  bounds: THREE.Box3;
  pieces: THREE.Box3[];
  originalVisible: boolean;
  hiddenUntil: number;
};

/** Static architectural pieces only: furniture, seats and collision remain intact. */
export class WorldCameraCutaway {
  private readonly parts: CutawayPart[] = [];
  private readonly points = Array.from({ length: 9 }, () => new THREE.Vector3());
  private readonly rays = Array.from({ length: 9 }, () => new THREE.Ray());
  private readonly distances = new Float64Array(9);
  private readonly intersection = new THREE.Vector3();
  private readonly body: THREE.Object3D;
  private readonly mouth: THREE.Object3D | undefined;
  private readonly eyes: (THREE.Object3D | undefined)[];
  private hiddenCount = 0;

  constructor(root: THREE.Object3D, private readonly character: THREE.Object3D) {
    root.updateMatrixWorld(true);
    this.body = character.getObjectByName('eat-contact')?.parent ?? character;
    this.mouth = character.getObjectByName('eat-contact');
    this.eyes = [character.getObjectByName('right-eye'), character.getObjectByName('left-eye')];
    root.traverse(object => {
      if (!object.userData.cameraOccluder) return;
      const pieces: THREE.Box3[] = [], bounds = new THREE.Box3();
      object.traverse(child => {
        if (!(child instanceof THREE.Mesh)) return;
        const materials = Array.isArray(child.material) ? child.material : [child.material];
        if (materials.every(material => !material.visible || material.opacity === 0)) return;
        child.geometry.computeBoundingBox();
        const piece = child.geometry.boundingBox!.clone().applyMatrix4(child.matrixWorld).expandByScalar(.07);
        pieces.push(piece); bounds.union(piece);
      });
      if (pieces.length) this.parts.push({ object, bounds, pieces, originalVisible: object.visible, hiddenUntil: -Infinity });
    });
  }

  /** Runs without creating geometries, materials, rays, boxes or temporary arrays. */
  update(cameraPosition: THREE.Vector3, elapsed: number, enabled = true) {
    if (!enabled) { this.restore(); return; }
    this.character.updateMatrixWorld(true);
    const points = this.points;
    if (this.mouth) this.mouth.getWorldPosition(points[0]);
    else points[0].set(0, 2.2, .25).applyMatrix4(this.body.matrixWorld);
    for (let i = 0; i < 2; i++) {
      const eye = this.eyes[i];
      if (eye) eye.getWorldPosition(points[i + 1]);
      else points[i + 1].set(i ? .48 : -.48, 2.94, .2).applyMatrix4(this.body.matrixWorld);
    }
    // Head crown, shoulders and the front of the torso use the animated body's matrix.
    points[3].set(0, 3.43, 0).applyMatrix4(this.body.matrixWorld);
    points[4].set(0, 2.76, .35).applyMatrix4(this.body.matrixWorld);
    points[5].set(-.56, 1.83, .20).applyMatrix4(this.body.matrixWorld);
    points[6].set(.56, 1.83, .20).applyMatrix4(this.body.matrixWorld);
    points[7].set(0, 1.52, .27).applyMatrix4(this.body.matrixWorld);
    points[8].set(0, 2.3, -.12).applyMatrix4(this.body.matrixWorld);
    for (let i = 0; i < points.length; i++) {
      const ray = this.rays[i]; ray.origin.copy(cameraPosition); ray.direction.copy(points[i]).sub(cameraPosition);
      this.distances[i] = ray.direction.length(); ray.direction.normalize();
    }
    this.hiddenCount = 0;
    for (const part of this.parts) {
      let obstructing = false;
      for (let i = 0; i < this.rays.length && !obstructing; i++) {
        const ray = this.rays[i], distance = this.distances[i];
        if (!this.crosses(ray, distance, part.bounds)) continue;
        for (const piece of part.pieces) {
          if (this.crosses(ray, distance, piece)) { obstructing = true; break; }
        }
      }
      // Delay restoration a little so thin posts do not flicker at a silhouette edge.
      if (obstructing) part.hiddenUntil = elapsed + .22;
      const hidden = elapsed < part.hiddenUntil;
      part.object.visible = part.originalVisible && !hidden;
      if (hidden) this.hiddenCount++;
    }
  }

  private crosses(ray: THREE.Ray, distance: number, box: THREE.Box3) {
    if (box.containsPoint(ray.origin)) return true;
    const hit = ray.intersectBox(box, this.intersection);
    return hit !== null && hit.distanceToSquared(ray.origin) < (distance + .04) ** 2;
  }

  getSnapshot() {
    return { total: this.parts.length, hiddenCount: this.hiddenCount,
      hidden: this.parts.filter(part => !part.object.visible && part.originalVisible).map(part => part.object.name) };
  }

  restore() {
    for (const part of this.parts) { part.object.visible = part.originalVisible; part.hiddenUntil = -Infinity; }
    this.hiddenCount = 0;
  }
  dispose() { this.restore(); this.parts.length = 0; }
}
