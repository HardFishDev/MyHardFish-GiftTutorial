import type { CSSProperties } from 'react';
import { INITIAL_PROGRESS } from './resources';
import type { ResourceProgress } from './resources';
import './loading.css';

export interface LoadingScreenProps {
  variant?: 'world' | 'cycling';
  progress?: ResourceProgress;
  worldReady?: boolean;
  failed?: readonly string[];
  error?: string;
  onRetry?: () => void;
  onContinue?: () => void;
}

const debris = Array.from({ length: 16 }, (_, index) => {
  const angle = (index / 16) * Math.PI * 2;
  const distance = 68 + (index % 4) * 17;
  return {
    '--debris-x': `${Math.cos(angle) * distance}px`,
    '--debris-y': `${Math.sin(angle) * distance}px`,
    '--debris-turn': `${(index % 2 ? 1 : -1) * (90 + index * 21)}deg`,
    '--debris-color': ['#7ea984', '#d0ad78', '#426c55', '#dfba9e'][index % 4],
    '--debris-size': `${5 + index % 4 * 2}px`,
  } as CSSProperties;
});

export default function LoadingScreen({
  variant = 'world',
  progress = INITIAL_PROGRESS,
  worldReady = false,
  failed = [],
  error,
  onRetry,
  onContinue,
}: LoadingScreenProps) {
  const cycling = variant === 'cycling';
  const percent = Math.max(0, Math.min(100, Math.floor(progress.percent)));
  const hasError = !!error || failed.length > 0;
  const resourcesDone = progress.total > 0 && progress.completed >= progress.total;
  const message = hasError
    ? error || `${failed.length} 个素材暂未加载，重试一下，也可以先进入小镇。`
    : resourcesDone && !worldReady ? cycling ? '素材到齐了，正在准备自行车和赛道。' : '素材到齐了，正在布置难鱼的小世界。'
      : resourcesDone ? '好啦，难鱼在等你。' : progress.label;

  return <section className="resource-loading" aria-label="我的群友难鱼，游戏加载中" aria-busy={!hasError}>
    <div className="resource-loading__paper" aria-hidden="true" />
    <div className="resource-loading__content">
      <p className="resource-loading__eyebrow">我的群友难鱼 <span>·</span> {cycling ? '骑行即将出发' : '小镇正在开门'}</p>
      <div className="resource-loading__performance" role="img" aria-label="难鱼的马，蓄力、爆开，然后消失">
        <span className="resource-loading__words" aria-hidden="true">难鱼的</span>
        <div className="resource-loading__burst" aria-hidden="true">
          <span className="resource-loading__horse">🐴</span>
          <span className="resource-loading__ring" />
          <span className="resource-loading__flash" />
          {debris.map((style, index) => <i className="resource-loading__debris" style={style} key={index} />)}
          <span className="resource-loading__poof">嘭！</span>
        </div>
      </div>
      <p className="resource-loading__aside" aria-hidden="true">先别急，正在把世界装进口袋。</p>
      <div className="resource-loading__progress">
        <div className="resource-loading__progress-heading">
          <span>{cycling ? '骑行准备中' : '小世界准备中'}</span><strong>{percent}<small>%</small></strong>
        </div>
        <div className="resource-loading__track" role="progressbar"
          aria-label="游戏素材加载进度" aria-valuemin={0} aria-valuemax={100} aria-valuenow={percent}
          aria-valuetext={`${percent}%，已处理 ${progress.completed} / ${progress.total} 个素材${failed.length ? `，${failed.length} 个未能加载` : ''}`}>
          <div className="resource-loading__fill" style={{ width: `${percent}%` }} />
        </div>
        <div className="resource-loading__count">
          <span>已处理 {progress.completed} / {progress.total} 个素材</span>
          <span>{hasError ? `${failed.length || '部分'} 项待重试` : resourcesDone ? '打包完成' : cycling ? '自行车 · 赛道 · 语音音效' : '图片 · 语音 · 背景音乐'}</span>
        </div>
      </div>
      <p className={`resource-loading__status${hasError ? ' resource-loading__status--error' : ''}`}
        role="status" aria-live="polite" aria-atomic="true">{message}</p>
      {hasError && (onRetry || onContinue) && <div className="resource-loading__actions">
        {onRetry && <button type="button" className="resource-loading__retry" onClick={onRetry}>再试一次</button>}
        {onContinue && <button type="button" className="resource-loading__continue" onClick={onContinue}>先进入小镇</button>}
      </div>}
      <span className="resource-loading__footer">今天也来和群友待一会儿。</span>
    </div>
  </section>;
}
