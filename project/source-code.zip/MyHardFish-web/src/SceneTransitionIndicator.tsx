import './scene-transition.css';

export default function SceneTransitionIndicator({ label = '正在准备场景…', className = '' }: { label?: string; className?: string }) {
  return <div className={`scene-transition-indicator ${className}`} data-testid="scene-transition-indicator" role="status" aria-live="polite" aria-atomic="true">
    <span className="scene-transition-indicator__spinner" aria-hidden="true" />
    <span>{label}</span>
  </div>;
}
