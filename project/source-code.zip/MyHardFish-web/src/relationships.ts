import type { Place } from "./scene";
import type { Story } from "./content";

/** Public, deliberately compact adaptations. Private message IDs stay in research/. */
export type GroupFriend = {
  id: string;
  name: string;
  aliases: string[];
  role: string;
  color: string;
  initial: string;
  summary: string;
  habit: string;
  relationship: string;
  evidenceNote: string;
  storyIds: string[];
};

export const groupFriends: GroupFriend[] = [
  {
    id: "monkey", name: "猴", aliases: ["逗比猴", "逗逼猴", "dbh", "猴老师"], role: "应援会热心策划",
    color: "#c99369", initial: "猴",
    summary: "招牌一做就很大，难鱼一看就想让他改名。两个人的聊天很容易从正事拐进互损。",
    habit: "起哄、接梗，顺便把全村人拉进活动。",
    relationship: "高频互相接话的老群友；游戏里是经常被难鱼叫停的活动策划。",
    evidenceNote: "“猴 / 逗比猴”是正文中的反复称呼；应援会与游戏服务器的互动有连续对话。策划职务为游戏改编。",
    storyIds: ["fanclub", "village_notice", "berry_coop", "group_picnic"],
  },
  {
    id: "fox", name: "狐狸", aliases: ["狐"], role: "爱出主意的损友",
    color: "#b98765", initial: "狐",
    summary: "一句建议能换来一句“谢谢大师”。也会认真回答学习问题，只是难鱼未必每次都买账。",
    habit: "隔空接梗、抛问题，给漂流瓶加一点不安分。",
    relationship: "互损和请教会在同一段对话里来回切换。",
    evidenceNote: "“狐狸”在难鱼与群友正文中反复出现；英语请教、漂流瓶与互怼有独立语境。",
    storyIds: ["fox_bottles", "fox_dictionary", "group_picnic"],
  },
  {
    id: "jiuwo", name: "酒窝", aliases: ["小酒窝", "小鸡窝", "窝神"], role: "联机搭子",
    color: "#8d9d68", initial: "窝",
    summary: "喊开服、一起联机、讨论插件。难鱼嘴上说懒，下一句又可能在问怎么进。",
    habit: "把一件小事折腾成全村联机，把难鱼的休息时间也算进日程。",
    relationship: "游戏、数码和日常互损里的熟面孔。叫“小鸡窝”有时指游戏内命名，不能全当真人。",
    evidenceNote: "按账号合并跨年份昵称；“酒窝”是稳定称呼，“小鸡窝”的人物与游戏实体语境分开使用。",
    storyIds: ["server_chickens", "plugin_parade", "group_picnic"],
  },
  {
    id: "soup", name: "胡辣汤", aliases: ["胡辣汤老师", "老孙"], role: "偶尔收获善意的群友",
    color: "#aa926e", initial: "汤",
    summary: "平时互损得很响，也能让难鱼直接说想念。认真夸一句，反而可能把她说得不知怎么回。",
    habit: "从日常小事开聊，偶尔遇到一条收起攻击性的鱼。",
    relationship: "有互怼，也有“想念”“天天开心”等明确的友好表达。老师是群内称呼。",
    evidenceNote: "2026 年多次直接称“胡辣汤老师”；不把“老师”“叔叔”等玩笑称呼认定为现实职业或亲属。",
    storyIds: ["soup_photo", "soup_museum", "group_picnic"],
  },
  {
    id: "rainnight", name: "雨夜", aliases: ["RainNight"], role: "会记得小事的搭子",
    color: "#7798a5", initial: "雨",
    summary: "一起聊游戏、装置和英语。有时候会提议补个生日蛋糕。她会感谢，也会明确说不用；关心不等于必须收下。",
    habit: "研究游戏里的小装置，也会递来一句很具体的关心。",
    relationship: "难鱼既会认真补充他的建议，也会回一句“谢谢喵”。",
    evidenceNote: "“雨夜”是全群正文的常用简称；补生日蛋糕与英文游戏环境的讨论有直接引用链。",
    storyIds: ["belated_cake", "english_kitchen", "group_picnic"],
  },
  {
    id: "jin", name: "jin佬", aliases: ["jin", "jin老师", "金佬"], role: "课间讨论搭子",
    color: "#9a90b1", initial: "J",
    summary: "聊天能从手机跳到一道英语题。难鱼会主动请教背文章的方法，也会回过头认真夸他一句。",
    habit: "发个问题，全群一起补充；谁说对了都算过关。",
    relationship: "学习、工具与数码话题里的双向交流，不固定谁教谁。",
    evidenceNote: "难鱼正文 20 次提到 jin，其中 18 次写作“jin佬”；2024 年有请教、道谢和鼓励的连续对话。",
    storyIds: ["grammar_club", "quiet_revision", "group_picnic"],
  },
];

export type ContextEvent = {
  id: string;
  place: Place;
  title: string;
  text: string;
  friendIds: string[];
  storyId: string;
  quoteId: string;
};

/** Scene hooks are fiction inspired by documented conversation contexts. */
export const contextEvents: ContextEvent[] = [
  { id: "notice", place: "home", title: "猴的新招牌到了", text: "门口靠着一块写得过分认真的应援会招牌。难鱼还没开口，你已经猜到她要说什么。", friendIds: ["monkey"], storyId: "village_notice", quoteId: "whatname" },
  { id: "bottles", place: "park", title: "一瓶看起来很可疑的建议", text: "狐狸说今天的漂流瓶很有营养。难鱼决定先看署名，再决定信几个字。", friendIds: ["fox"], storyId: "fox_bottles", quoteId: "thanksmaster" },
  { id: "chickens", place: "home", title: "酒窝喊你上线", text: "村里的小鸡又挤满了院子。难鱼盯着通知：鸡可以管，锅不能乱甩。", friendIds: ["jiuwo"], storyId: "server_chickens", quoteId: "chickens" },
  { id: "photo", place: "park", title: "胡辣汤的合影邀请", text: "一张合影，三秒倒计时。难鱼提前宣布：表情由她自己决定。", friendIds: ["soup"], storyId: "soup_photo", quoteId: "meow" },
  { id: "cake", place: "kitchen", title: "雨夜的蛋糕提议", text: "一份迟到的祝福来到厨房。难鱼有权选要不要蛋糕，也愿意认真说一声谢谢。", friendIds: ["rainnight"], storyId: "belated_cake", quoteId: "thankyou" },
  { id: "grammar", place: "school", title: "jin佬的背文俱乐部", text: "长文章才翻开一页，狐狸先贡献了“不背最快”。难鱼直接把凳子搬到了jin佬旁边。", friendIds: ["jin", "fox"], storyId: "grammar_club", quoteId: "manythanks" },
  { id: "picnic", place: "shop", title: "全村野餐采购单", text: "六个人贡献了七种意见。你和难鱼负责让这张采购单真正变成一顿饭。", friendIds: ["monkey", "jiuwo", "fox", "soup", "rainnight", "jin"], storyId: "group_picnic", quoteId: "hardjudge" },
];

export const relationshipPrinciples = [
  "群友叫法取自反复出现的正文称呼，昵称后面的赛季与应援会头衔会变化。",
  "互损是互动的一部分；她也会问问题、分享经验、接受帮助和明确道谢。",
  "场景、职业、面对面活动与群友台词为游戏改编；难鱼的语音原话另有语料出处。",
];

const friendDialogues: Record<string, { quote: string; quoteId: string; topic: string; followup: string }> = {
  monkey: { quote: "你这什么鬼名字", quoteId: "whatname", topic: "猴又想做应援会招牌？正经事先排队，浆果回收的牌子还欠着呢。你陪我去催一下。", followup: "让他把承诺写进公告栏。这回不准只回一句咕咕；做完了再一起吃点东西。" },
  fox: { quote: "谢谢大师", quoteId: "thanksmaster", topic: "狐狸的建议先听半句。他会认真讲单词，也会让我多写数学题。这个谢谢大师，你得听语气。", followup: "有用的建议就留着，互损的话就接回去。到公园翻翻漂流瓶，先看内容，别先猜他在憋什么坏。" },
  jiuwo: { quote: "插件真好玩", quoteId: "plugins", topic: "酒窝，联机搭子啊。我找他问插件，嘴上说算了，转头又想上线看看。小鸡窝这个叫法，也有游戏里的来历。", followup: "村里的鸡不是现实养鸡场。让它们排个队，或者研究一下集体坐下的按钮；别什么故障都赖我的鸡。" },
  soup: { quote: "今天心情好不和你计较了", quoteId: "mercy", topic: "胡辣汤老师，也叫老孙。平常可以互损，他认真说句照顾好自己，我也会认真祝他天天开心。", followup: "善意我听得出来，不用天天硬接梗。去公园拍张合影吧，照片选哪张，让我自己定。" },
  rainnight: { quote: "谢谢", quoteId: "thankyou", topic: "雨夜提过补个生日蛋糕。我说谢谢，也说不用了。心意能收到，东西不一定非得收。", followup: "后来还聊过不带奶油的版本。今天可以一起做，也可以只留张卡片；选什么都不影响这一声谢谢。" },
  jin: { quote: "多谢多谢", quoteId: "manythanks", topic: "jin佬给我讲过背英文长文章的方法。我会嫌难，也会问；他心情低落的时候，我也会夸他已经很优秀。", followup: "先拆成几段，再试着自己接一句。谁先会就谁来讲，不用一直固定谁教谁。去教室把最后一段过了吧。" },
};

/** Compact public data; all private account joins and message IDs remain in research. */
export const friends = groupFriends.map((friend) => ({
  ...friend,
  ...friendDialogues[friend.id],
  source: `${friend.evidenceNote} 以下相处场景为群聊改编。`,
}));

export function friendProgress(friendId: string, endings: readonly string[]) {
  const friend = groupFriends.find((f) => f.id === friendId);
  const completed = friend?.storyIds.filter((id) => endings.some((e) => e.startsWith(`${id}:`))).length ?? 0;
  const total = friend?.storyIds.length ?? 0;
  return {
    completed,
    total,
    label: completed >= total && total > 0 ? "全村都有我们的故事" : completed >= 2 ? "有故事的老群友" : completed ? "一起经历过一件事" : "先认识一下",
    nextStoryId: friend?.storyIds.find((id) => !endings.some((e) => e.startsWith(`${id}:`))),
  };
}

/** Every location and direct groupmate line below is a fictional adaptation. */
export const relationshipStories: Story[] = [
  {
    id: "village_notice", title: "公告栏不许再叫应援会", place: "home", tag: "猴 · 起名拉扯", minBond: 0,
    intro: "猴把新招牌送到门口。字很大，大到难鱼隔着窗户就看见了。", friendIds: ["monkey"],
    source: "群聊改编｜2023-06-20 对猴的应援会昵称连续吐槽。公告栏、当面送招牌与以下群友对白为创作。",
    nodes: {
      start: { text: "招牌写着「难鱼国际应援会永久会址」。猴留了一支笔，说只要签字就算同意。难鱼直接把笔递给了你。", quote: "whatname", choices: [{ label: "先把永久会址划掉", next: "edit" }, { label: "建议开个民主命名大会", next: "meeting" }] },
      edit: { text: "你改成「今天有什么好玩的」。难鱼看了半天：这下才像一个能看的东西。猴发来一串问号。", choices: [{ label: "让全村写下想一起做的事", next: "notice" }, { label: "给猴留一个小小的署名角", next: "corner" }] },
      meeting: { text: "猴提议投票，狐狸提议继续用原名。难鱼把选票翻了个面，写上：先问当事人。", quote: "ask", choices: [{ label: "请难鱼自己定名字", next: "notice" }, { label: "保留作品，改成小号署名", next: "corner" }] },
      notice: { text: "新牌子叫「老母猪村今日有空」。第一张便签是难鱼写的：吃饭可以，挂我名字不行。猴的邀请被保留了，难鱼的意见也被听见了。", quote: "idea", ending: "当事人拥有命名权", bond: 10, shells: 30 },
      corner: { text: "招牌角落多了一行「猴做的，鱼改的」。难鱼嫌字丑，还是把它挂到了门边。以后大家来串门，先在这里留句话。", quote: "hardjudge", ending: "联合署名的小牌子", bond: 9, shells: 30 },
    },
  },
  {
    id: "berry_coop", title: "浆果回收还在咕咕", place: "shop", tag: "猴 · 催更小队", minBond: 10,
    intro: "一筐浆果已经到了，回收价目表却还没写。难鱼决定亲自催更。", friendIds: ["monkey", "jiuwo"],
    source: "群聊改编｜2023-08-16 难鱼直接叫「猴」并追问浆果回收，对方回答「也在咕咕」。原语境为游戏服务器。",
    nodes: {
      start: { text: "便利店临时设了个游戏道具交换角。猴把浆果筐放下，价目表上只有两个字：待定。难鱼敲了敲空白处。", quote: "ask", choices: [{ label: "列一张最小可用的价目表", next: "list" }, { label: "先办一次不收钱的交换", next: "trade" }] },
      list: { text: "酒窝提醒：回收规则得先写清楚。难鱼让你别整一百行，先写浆果、南瓜和兑换上限就行。", choices: [{ label: "把三条规则贴在篮子前", next: "open" }, { label: "拉猴一起试算一单", next: "receipt" }] },
      trade: { text: "你拿一袋浆果换回一只纸做的南瓜。大家开始认真讨论，这样究竟算赚了还是亏了。难鱼举起那只南瓜笑了一声。", quote: "six", choices: [{ label: "给双方写一张交换小票", next: "receipt" }, { label: "下次照着这次经验开张", next: "open" }] },
      open: { text: "小小的交换角终于有了规则。猴问能不能明天再开始，难鱼把第一筐浆果推到他面前：现在。", quote: "done", ending: "咕咕项目今天开张", bond: 11, shells: 34 },
      receipt: { text: "小票上写着「第一次成交，谁也不许反悔」。难鱼把它折好收进抽屉；下次猴再说没做过，你们就拿它出来。", quote: "read", ending: "留下小票为证", bond: 10, shells: 34 },
    },
  },
  {
    id: "fox_bottles", title: "狐狸的瓶中建议", place: "park", tag: "狐狸 · 接梗有分寸", minBond: 0,
    intro: "三个瓶子，一句建议。署名狐狸的那个尤其可疑。", friendIds: ["fox"],
    source: "群聊改编｜2024-03-03 双方围绕扔漂流瓶继续接话；2023-06-21「谢谢大师」来自数学调侃，不能视为无条件真诚道谢。",
    nodes: {
      start: { text: "池边漂来一个纸瓶，里面写着：无聊就多做两道数学题。难鱼看完署名，表情没有发生任何令人意外的变化。", quote: "thanksmaster", choices: [{ label: "先分清这是建议还是接梗", next: "read" }, { label: "回一张更有攻击力的纸条", next: "reply" }] },
      read: { text: "第二张纸条真的解释了一道题。难鱼把第一张压在石头下，把第二张摊平：这张还能看。", choices: [{ label: "认真解完，再说谢谢", next: "useful" }, { label: "把两种语气分开收好", next: "archive" }] },
      reply: { text: "你写了「出题的人先做」。她添上一个巨大的问号，又把纸条折回了瓶子。狐狸回了个同样大的问号。", quote: "dog", choices: [{ label: "互损暂停，一人讲一步", next: "useful" }, { label: "把这一来一回画成小漫画", next: "archive" }] },
      useful: { text: "题算出来了，纸条也没再飞回来。难鱼很短地说了声谢谢。这一回不用猜语气，桌上有写完的过程作证。", quote: "thankyou", ending: "这次是真心的谢谢", bond: 12, shells: 32 },
      archive: { text: "收藏夹多了一页：一句话，要看前后。难鱼给第一页画了个狐狸头，给第二页盖了个「有用」的章。", quote: "read", ending: "大师发言分类收藏", bond: 10, shells: 32 },
    },
  },
  {
    id: "fox_dictionary", title: "今天只背五个词", place: "school", tag: "狐狸 · 认真请教", minBond: 8,
    intro: "难鱼主动翻开单词本。狐狸难得没有马上接梗。", friendIds: ["fox", "jin"],
    source: "群聊改编｜2023-07-04 与 08-11 向狐狸询问词汇量及学习难度。纸卡游戏与五词目标为创作，不把夸张建议当教学结论。",
    nodes: {
      start: { text: "桌上有一整本生词。狐狸说先看词，难鱼看着厚度，决定先和书谈谈条件：今天只要五个。", quote: "ask", choices: [{ label: "拿窗边的东西做提示", next: "objects" }, { label: "和难鱼轮流抽卡", next: "cards" }] },
      objects: { text: "窗户、书、椅子、雨伞、瓶子。她发现不用一次面对整本书，连吐槽都能抽空用刚背的词了。", quote: "surprise", choices: [{ label: "让她反过来考你", next: "teacher" }, { label: "把五张卡装进小口袋", next: "pocket" }] },
      cards: { text: "你第一张就卡住了。难鱼拍了拍桌子：别急，我也刚会。jin佬把答案折起来，留出再想一下的时间。", choices: [{ label: "请难鱼给一点提示", next: "teacher" }, { label: "带着卡片走一圈再记", next: "pocket" }] },
      teacher: { text: "她讲完最后一个词，才发现这次自己讲得比抱怨还多。狐狸问明天继续吗，她说先看今天的成绩。", quote: "win", ending: "今天轮到鱼来讲", bond: 12, shells: 32 },
      pocket: { text: "五张纸卡跟着你们下了楼。那本厚书还在，但今天有五个词从里面走了出来。", quote: "okay", ending: "五个词装进口袋", bond: 11, shells: 32 },
    },
  },
  {
    id: "server_chickens", title: "几百只鸡的清白", place: "home", tag: "酒窝 · 联机日常", minBond: 5,
    intro: "酒窝喊人上线。难鱼的第一件事，是替自己的鸡说句话。", friendIds: ["jiuwo", "monkey"],
    source: "群聊改编｜「我养了几百只鸡也没见卡」为游戏服务器讨论；与酒窝多次聊插件、开服。卡顿排查与鸡舍方案均为剧情创作。",
    nodes: {
      start: { text: "电脑里传来熟悉的咯咯声。有人一说卡顿，视线就落到了鸡舍上。难鱼把椅子往前挪了一寸。", quote: "chickens", choices: [{ label: "先观察哪里真的变慢了", next: "observe" }, { label: "帮她把鸡舍整理得好看些", next: "coop" }] },
      observe: { text: "你们关掉多余的画面效果，再比较空地和鸡舍。酒窝一边记录，一边提醒猴别在测试时乱开装置。", choices: [{ label: "把过程写成小小的记录", next: "log" }, { label: "顺手给鸡舍留条走道", next: "village" }] },
      coop: { text: "栅栏修好了，门也有了。难鱼坚持不能少一只，猴提议把入口命名为难鱼养鸡协会，立刻被否决。", quote: "no", choices: [{ label: "挂上普通的「鸡舍」牌子", next: "village" }, { label: "记录改动，让大家自己看", next: "log" }] },
      log: { text: "记录本里留下了观察步骤，没有随便给谁定罪。难鱼把「鸡不是万能背锅侠」写得最大，酒窝在下面补了一句：下回照着查。", quote: "read", ending: "鸡舍无罪记录", bond: 12, shells: 34 },
      village: { text: "晚上的小村亮起灯，鸡舍外终于可以顺畅地走过去。她说自己只是顺手修一下，却又多摆了一盏灯。", quote: "nice", ending: "会亮灯的小鸡舍", bond: 11, shells: 34 },
    },
  },
  {
    id: "plugin_parade", title: "全体坐下的那个按钮", place: "park", tag: "酒窝 · 小装置脑洞", minBond: 18,
    intro: "难鱼想把联机里的愿望，做成公园里一排听指挥的玩具。", friendIds: ["jiuwo", "monkey"],
    source: "群聊改编｜2024-05-05 询问酒窝能否让游戏里的狗一起站起坐下，随后提议让猴写插件。公园玩具队列是创作。",
    nodes: {
      start: { text: "长椅前摆了一排木头小狗。酒窝搬来两个按钮，猴说红色那个很有气势。难鱼只关心：到底能不能一起坐下？", quote: "plugins", choices: [{ label: "先给按钮写上清楚的字", next: "labels" }, { label: "用手势排练一次", next: "rehearsal" }] },
      labels: { text: "「站起来」「坐下」贴好之后，猴提议再加个全村跳舞。难鱼盯着第三个空白按钮，把笔推给你。", choices: [{ label: "只保留两个靠谱的动作", next: "simple" }, { label: "把第三个按钮留作谢幕", next: "encore" }] },
      rehearsal: { text: "你举手，难鱼点头，酒窝按下按钮。只有最后一只慢了半拍，像极了还没睡醒的群友。", quote: "fun", choices: [{ label: "等最后一只，一起再来", next: "simple" }, { label: "让慢半拍成为压轴节目", next: "encore" }] },
      simple: { text: "最后一次，木头小狗整齐坐下。难鱼郑重宣布：需求完成，谁也别临时加功能。猴把第三张标签偷偷塞回了口袋。", quote: "done", ending: "按钮够用就很好", bond: 13, shells: 36 },
      encore: { text: "慢半拍的小狗最后才点头，全场莫名笑了起来。难鱼也没绷住，这个不太整齐的谢幕被大家一致保留。", quote: "fun", ending: "慢半拍的压轴明星", bond: 12, shells: 36 },
    },
  },
  {
    id: "soup_photo", title: "胡辣汤老师，拍好了没", place: "park", tag: "胡辣汤 · 收起攻击性", minBond: 12,
    intro: "夕阳正好。难鱼的表情却不打算听倒计时指挥。", friendIds: ["soup"],
    source: "群聊改编｜常叫「胡辣汤老师」「老孙」；2026-08-30 对提醒照顾自己回以「天天开心」。合影活动与摄影分工属于游戏设定。",
    nodes: {
      start: { text: "胡辣汤在长椅旁支好相机。难鱼先声明，不许把闭眼那张做成群头像。你手里握着倒计时遥控。", quote: "police", choices: [{ label: "让她自己选喜欢的姿势", next: "pose" }, { label: "大家都做最离谱的表情", next: "funny" }] },
      pose: { text: "她把手揣好，站得很认真。胡辣汤没起哄，只说光线不错。难鱼似乎不太习惯这样普通的夸奖。", choices: [{ label: "拍完先给她看", next: "approve" }, { label: "请她也给大家拍一张", next: "behind" }] },
      funny: { text: "你负责歪头，胡辣汤负责憋笑。难鱼坚持自己没做表情，屏幕上却留下了全场最有攻击力的一眼。", quote: "attack", choices: [{ label: "让她决定要不要留下", next: "approve" }, { label: "交换相机，轮到她按快门", next: "behind" }] },
      approve: { text: "她挑中了一张大家都没准备好的合影。照片背后，你们写上今天的日期；没有人把它擅自改成群头像。", quote: "mercy", ending: "她亲自选的那张", bond: 13, shells: 32 },
      behind: { text: "难鱼数了三声，第三声时自己先笑了。照片稍微有些歪，胡辣汤还是收了下来，说这张很像今天。", quote: "happy", ending: "镜头这边也是朋友", bond: 12, shells: 32 },
    },
  },
  {
    id: "soup_museum", title: "客厅里的小小展览", place: "home", tag: "胡辣汤 · 联机手作", minBond: 24,
    intro: "难鱼把一排纸模型摆上架子，邀请函的语气相当欠揍。", friendIds: ["soup", "fox", "monkey"],
    source: "群聊改编｜2024-03-31 在游戏里做「老孙纪念馆」，邀请狐狸上线看。这里改编为友好作品展，不是现实纪念馆或生死信息。",
    nodes: {
      start: { text: "模型里有小长椅、小路灯，还有一张歪歪的小桌子。难鱼给胡辣汤留了第一张参观票，又问狐狸要不要也做一份。", quote: "nice", choices: [{ label: "先写清楚这是游戏作品展", next: "caption" }, { label: "邀请大家自己摆一件作品", next: "together" }] },
      caption: { text: "你写下作品名字和制作日期。猴想给展览加一个长得离谱的头衔，难鱼直接把标题栏框小了一半。", quote: "whatname", choices: [{ label: "把最初那张草图也留下", next: "sketch" }, { label: "留一格给下次一起做", next: "space" }] },
      together: { text: "狐狸放了纸瓶，猴放了半成品招牌。胡辣汤把合影靠在路灯后面，难鱼悄悄把它移到更亮的地方。", choices: [{ label: "记录这间展览是怎么做的", next: "sketch" }, { label: "空一格，谁有空就来添", next: "space" }] },
      sketch: { text: "最歪的草图被放在最前面。难鱼说这样大家就知道做得有多不容易，说完又给你补了一张参观票。", quote: "collect", ending: "从草图开始的展览", bond: 14, shells: 38 },
      space: { text: "架子故意没有摆满。那格空白贴着一张小纸条：下次上线再做。难鱼抬头看了一眼，觉得今天可以收工了。", quote: "okay", ending: "给下次留一格", bond: 14, shells: 38 },
    },
  },
  {
    id: "belated_cake", title: "谢谢，但蛋糕先不用", place: "kitchen", tag: "雨夜 · 心意与边界", minBond: 0,
    intro: "一份补来的生日祝福。接受心意，不必只有收下蛋糕一种方式。", friendIds: ["rainnight"],
    source: "群聊改编｜2024-03-20 对雨夜补蛋糕的提议先说「谢谢喵」，紧接着说「但是不用了」；04-18 又谈到不带奶油的版本。没有把拒绝删掉。",
    nodes: {
      start: { text: "雨夜说要补个小蛋糕。难鱼先说谢谢，接着摇了摇头。厨房安静了一秒，她看向你，等你有没有听完这两句话。", quote: "thankyou", choices: [{ label: "那就只留一张祝福卡", next: "card" }, { label: "问她要不要自己选个版本", next: "choose" }] },
      card: { text: "你把纸卡放在桌边，没再劝。雨夜在上面画了小蜡烛，难鱼伸手给火苗描了一笔。", choices: [{ label: "一起写一句普通的祝福", next: "wish" }, { label: "把选择留到她想吃的时候", next: "later" }] },
      choose: { text: "难鱼指了指没有奶油的小点心，又补了一句：今天也可以不吃。你把两个选项都保留了。", choices: [{ label: "她想试的话，一起做一小份", next: "small" }, { label: "今天先不做，陪她坐一会儿", next: "later" }] },
      wish: { text: "没有蛋糕，蜡烛也只画在纸上。祝福却一点都没少。难鱼把卡片靠到杯子旁边，说这样就挺好。", quote: "fine", ending: "一张被认真收好的卡片", bond: 14, shells: 32 },
      small: { text: "小点心烤好后，难鱼自己决定先尝一口。雨夜的祝福，你的陪伴，还有她自己的选择，都留在了这张桌子上。", quote: "thanks", ending: "自己选的小小一份", bond: 14, shells: 32 },
      later: { text: "盒子还是空的，心意已经收到了。你们约好，哪天想做再一起做；今天不需要为了礼貌勉强吃掉什么。", quote: "okay", ending: "不用也能说谢谢", bond: 14, shells: 32 },
    },
  },
  {
    id: "english_kitchen", title: "把厨房切成英文模式", place: "kitchen", tag: "雨夜 · 反过来教你", minBond: 12,
    intro: "难鱼拿来一叠标签。今天边做饭边认几个词，她来当向导。", friendIds: ["rainnight", "jin"],
    source: "群聊改编｜2024-03-20 难鱼向雨夜分享用英文游戏环境熟悉词汇的经验，雨夜认可并补充。厨房贴标签为创作。",
    nodes: {
      start: { text: "杯子叫 cup，盘子叫 plate。难鱼把标签贴得七扭八歪，却坚称这样比盯着书发呆有趣。雨夜负责检查有没有贴错。", quote: "idea", choices: [{ label: "把 bowl 标签贴到碗上", next: "correct" }, { label: "把 bowl 标签贴到雨伞上", next: "wrong" }] },
      correct: { text: "她点了点头，把下一张标签推给你。桌上的牛奶还没凉，这一回连催你的人都没有。", choices: [{ label: "用刚会的词，帮她摆桌", next: "table" }, { label: "请她也认一张新标签", next: "mutual" }] },
      wrong: { text: "难鱼举起雨伞看了两秒：你这碗防水面积还挺大。雨夜把正确的碗推过来，标签重贴就行。", quote: "six", choices: [{ label: "笑一下，重贴到碗上", next: "table" }, { label: "轮流出题，谁都可以错", next: "mutual" }] },
      table: { text: "最后一只盘子放好，桌面刚好够两个人吃饭。难鱼收起标签，说今天会几个就算几个，先吃。", quote: "done", ending: "会用的词才记得住", bond: 12, shells: 34 },
      mutual: { text: "新标签有一张她也不认识。你们查明白后一起贴好；这张最陌生的，反而成了今天记得最牢的一张。", quote: "surprise", ending: "今天谁都会一点", bond: 13, shells: 34 },
    },
  },
  {
    id: "grammar_club", title: "不背最快，但还得背", place: "school", tag: "jin佬 · 背文俱乐部", minBond: 8,
    intro: "长文章摆在桌上，狐狸贡献了最快的办法：不背。难鱼没采纳。", friendIds: ["jin", "fox"],
    source: "群聊改编｜2024-04-08 主动向jin佬请教快速背英文长文；狐狸插话「不背」「最快」，难鱼继续请教，之后明确道谢。",
    nodes: {
      start: { text: "狐狸的建议刚说完，难鱼把书往jin佬那边挪了挪。这次她不是来征集放弃理由的。你坐在另一边，等她决定怎么开始。", quote: "hardjudge", choices: [{ label: "先把一大段拆成三小段", next: "split" }, { label: "先听一遍，再接一句", next: "listen" }] },
      split: { text: "第一小段比想象中短。她捂住后半页，试着复述，卡住的地方只留一个小记号。jin佬等她把话接上。", choices: [{ label: "只补那个卡住的地方", next: "finish" }, { label: "把这一段讲给你听", next: "relay" }] },
      listen: { text: "你慢慢读，她一开始嫌慢，后来却能接上末尾。窗外有人喊下课，她说等这一句过了再走。", choices: [{ label: "再来一遍就收工", next: "finish" }, { label: "轮流接力，最后一起读", next: "relay" }] },
      finish: { text: "她把小记号一个个擦掉，合上书，转向jin佬认真说了声谢谢。狐狸问「不背最快」算不算也有功劳，被一致跳过。", quote: "manythanks", ending: "谢谢这次有明确对象", bond: 13, shells: 34 },
      relay: { text: "最后一段被你们一人一句接完。难鱼发现，讲给别人听的时候，自己也又记住了一次。她把椅子推回原处，约好下次再来。", quote: "win", ending: "全村接力一小段", bond: 12, shells: 34 },
    },
  },
  {
    id: "quiet_revision", title: "jin佬已经很优秀了", place: "school", tag: "jin佬 · 互相鼓励", minBond: 25,
    intro: "这次先放下笔的不是难鱼。她把惯常的吐槽也放轻了一点。", friendIds: ["jin"],
    source: "群聊改编｜2024-06-01 jin谈到自己没有机会时，难鱼回应「jin佬已经很优秀了喵」。不推断现实成绩、心理或长期状态。",
    nodes: {
      start: { text: "jin佬看着草稿纸，说今天好像什么都没做完。难鱼没立刻接梗，先把桌上写满的那几页翻到他面前。", quote: "fine", choices: [{ label: "具体说说今天完成了什么", next: "count" }, { label: "先到窗边站一会儿", next: "window" }] },
      count: { text: "一页整理好的笔记，几道算过的题，还有给别人的解答。难鱼说这些难道都不算，然后把纸排得整整齐齐。", choices: [{ label: "今天做到这里就很好", next: "enough" }, { label: "只约明天一起做一小件事", next: "tomorrow" }] },
      window: { text: "操场慢慢安静下来。难鱼没有催他说话，只把水杯放在够得到的地方。过了一会儿，他自己把窗户推开了些。", choices: [{ label: "陪着，不急着给答案", next: "enough" }, { label: "约好明天还是这张桌子", next: "tomorrow" }] },
      enough: { text: "书包合上了，今天也确实做过不少事。难鱼最后还是补了一声喵，像把一句认真话装进熟悉的语气里。", quote: "meow", ending: "今天已经够好了", bond: 15, shells: 38 },
      tomorrow: { text: "明天的计划只有一行。难鱼把自己的椅子留在旁边，没有写一定要赢，只写一起。", quote: "okay", ending: "明天还有这个座位", bond: 15, shells: 38 },
    },
  },
  {
    id: "group_picnic", title: "全村意见大于购物预算", place: "shop", tag: "全村 · 一起出门", minBond: 20,
    intro: "六个人写了七种安排。难鱼负责把这次野餐从群聊里捞出来。", friendIds: ["monkey", "fox", "jiuwo", "soup", "rainnight", "jin"],
    source: "群聊群像改编｜由已核查的应援会、联机、漂流瓶、祝福、学习互助等互动设计聚会。采购、分工与全部群友对白均为虚构，不是历史聚会记录。",
    nodes: {
      start: { text: "猴要做招牌，狐狸要带纸瓶，酒窝惦记联机，胡辣汤想拍照，雨夜留了点心选项，jin佬写了一张清单。难鱼问：有人记得带伞吗？", quote: "rain", choices: [{ label: "先核对天气、人数和必需品", next: "plan" }, { label: "先把每个人最想做的一件事圈出来", next: "wishes" }] },
      plan: { text: "清单被压成了水、坐垫、雨伞和够分的点心。剩下的预算，刚好能选一个小活动。难鱼看着终于变短的纸，松了口气。", choices: [{ label: "选拍一张全村合影", next: "photo" }, { label: "选纸瓶留言，慢慢坐着聊", next: "letters" }] },
      wishes: { text: "大家发现这些愿望并不冲突：小招牌能当合影背景，纸瓶里可以装留言，点心不必人人都吃。难鱼把「必须参加」四个字划掉了。", choices: [{ label: "有人拍照，有人站在镜头后", next: "photo" }, { label: "谁有话就写，没话就发呆", next: "letters" }] },
      photo: { text: "合影里每个人都有自己的位置。难鱼把伞靠在长椅边，最后一个走进画面。招牌上只写了四个字：今天有空。", quote: "happy", ending: "今天全村都有空", bond: 17, shells: 45 },
      letters: { text: "傍晚收拾东西时，瓶子里装了几句吐槽，也装了一句下次还来。难鱼没有猜是谁写的，把瓶子稳稳放进了包里。", quote: "collect", ending: "群聊以外的一天", bond: 17, shells: 45 },
    },
  },
];
