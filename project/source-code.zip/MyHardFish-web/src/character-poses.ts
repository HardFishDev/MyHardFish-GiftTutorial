import type { CharacterActivityKind } from './character-activity';

/** Reused scratch pose. Coordinates belong to the torso group, before world placement. */
export class ActivityArmPose {
  hx=0;hy=0;hz=0;ex=0;ey=0;ez=0;ux=0;uy=0;uz=0;
  set(kind:CharacterActivityKind,time:number,side:number,workY:number,workZ:number,reachX:number,intensity:number) {
    const right=side<0,beat=Math.sin(time*2.3)*intensity,slow=Math.sin(time*1.35)*intensity;
    this.hx=side*.873;this.hy=1.075;this.hz=.04;
    this.ex=side*.82;this.ey=1.56;this.ez=-.015;
    this.ux=side*.74;this.uy=1.98;this.uz=.05;
    switch(kind) {
      case 'sit': this.hx=side*.40;this.hy=1.32;this.hz=.63;this.ex=side*.79;this.ey=1.59;this.ez=.39;break;
      case 'read': this.hx=side*.36;this.hy=1.58+slow*.014;this.hz=.77;this.ex=side*.80;this.ey=1.67;this.ez=.43;this.uz=.13;break;
      case 'cook':
        this.hx=right?-.19+Math.cos(time*3)*.09*intensity:.41;this.hy=right?workY+.38+beat*.035:workY-.055;this.hz=workZ+(right?Math.sin(time*3)*.075*intensity:0);this.ex=side*.87;this.ey=right?1.89:1.66;this.ez=.47;this.uz=.17;break;
      case 'water': this.hx=right?-.30:side*.60;this.hy=right?workY+.36:1.37;this.hz=right?workZ+.08:.38;this.ex=side*.87;this.ey=right?1.86:1.56;this.ez=right?.42:.23;this.uz=.13;break;
      case 'shop': this.hx=right?-.85:.32+slow*.06;this.hy=right?1.23:1.66;this.hz=right?.20:.68;this.ex=side*.85;this.ey=right?1.54:1.80;this.ez=right?.09:.39;break;
      case 'play': this.hx=side*(.28+Math.max(0,beat)*.045);this.hy=1.41+Math.max(0,beat)*.33;this.hz=.81;this.ex=side*.91;this.ey=1.62+Math.max(0,beat)*.1;this.ez=.40;this.uz=.15;break;
      case 'write': this.hx=(right?-.13+Math.sin(time*7)*.035*intensity:.32)+reachX;this.hy=right?workY+.26:workY;this.hz=workZ+(right?-.035+Math.cos(time*5)*.035*intensity:0);this.ex=side*.81;this.ey=1.68;this.ez=.45;this.uz=.15;break;
      case 'inspect': this.hx=right?-.25+slow*.10:.48;this.hy=right?2.21:1.48;this.hz=right?.72:.48;this.ex=side*.87;this.ey=right?1.98:1.65;this.ez=.39;this.uz=.14;break;
      case 'talk': this.hx=side*(.60+slow*.11);this.hy=1.57+(right?beat:-beat)*.15;this.hz=.56;this.ex=side*.88;this.ey=1.75;this.ez=.30;this.uz=.12;break;
      case 'celebrate': this.hx=side*(.98+slow*.08);this.hy=2.79+beat*.14;this.hz=.13;this.ex=side*1.00;this.ey=2.49;this.ez=.03;this.ux=side*.85;this.uy=2.32;break;
      case 'eat': break;
    }
  }
}
