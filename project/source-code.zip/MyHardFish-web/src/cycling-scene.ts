import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { CYCLING_RIG, NanyuCharacter } from './character';
import type { NanyuOutfit } from './character';
import { CYCLING_LANE_WIDTH, CYCLING_LENGTH, getCyclingDifficulty } from './cycling';
import type { CyclingCamera, CyclingState, CyclingDifficulty, CyclingEvent } from './cycling';
import { CyclingCameraControls } from './cycling-camera';
import { CyclingEnvironment } from './cycling-environment';
import { waitForScenePaint } from './scene-transition';

const TAU=Math.PI*2,RIDER_SCALE=.67,WHEEL_RADIUS=.7;
let rendererSequence=0;
const point=(x:number,y:number,z:number)=>new THREE.Vector3(x,y,z);
type RoadItem=CyclingState['items'][number];
type PickupEffect={group:THREE.Group;sparkles:THREE.Group;start:THREE.Vector3;at:number;side:number;kind:RoadItem['kind']};

/** A separate little village road; no world renderer, map, or clock is shared. */
export class CyclingScene {
  readonly renderer!:THREE.WebGLRenderer;
  private readonly host:HTMLDivElement;
  private readonly scene=new THREE.Scene();
  private readonly camera=new THREE.PerspectiveCamera(48,1,.1,230);
  private readonly character!:NanyuCharacter;
  private readonly rider=new THREE.Group();
  private readonly wheelGroups:THREE.Group[]=[];
  private readonly pedalGroups:THREE.Group[]=[];
  private readonly crankGroups:THREE.Group[]=[];
  private readonly handlebar=new THREE.Group();
  private readonly finish=new THREE.Group();
  private environment?:CyclingEnvironment;
  private readonly nearRoadTrees:THREE.Group[]=[];
  private readonly cameraBlockers:{object:THREE.Object3D;center:THREE.Vector3;radius:number}[]=[];
  private readonly itemObjects=new Map<string,THREE.Group>();
  private readonly geometries=new Map<string,THREE.BufferGeometry>();
  private readonly materials=new Map<string,THREE.MeshStandardMaterial>();
  private readonly textures=new Set<THREE.Texture>();
  private readonly resizeObserver?:ResizeObserver;
  private readonly cameraPosition=new THREE.Vector3();
  private readonly cameraTarget=new THREE.Vector3();
  private readonly lookTarget=new THREE.Vector3();
  private readonly orbit=new THREE.Spherical();
  private readonly orbitOffset=new THREE.Vector3();
  private readonly sightLine=new THREE.Line3();
  private readonly blockerCenter=new THREE.Vector3();
  private readonly nearestSightPoint=new THREE.Vector3();
  private controls?:CyclingCameraControls;
  private orbitActive=false;
  private readonly ambient=new THREE.HemisphereLight();
  private readonly sunlight=new THREE.DirectionalLight('#fff5d6',3.0);
  private readonly pickupEffects:PickupEffect[]=[];
  private readonly impactDust=new THREE.Group();
  private lastEvent=0;
  private lastDistance=0;
  private hitAt=-100;
  private hitSide=1;
  private hitKind:RoadItem['kind']='hole';
  private headlight?:THREE.SpotLight;
  private difficulty:CyclingDifficulty;
  private transition?:AbortController;
  private transitionRevision=0;
  private readonly onTransition?: (busy:boolean)=>void;
  private phase=0;
  private time=0;
  private lastX=0;
  private steering=0;
  private width=1;
  private height=1;
  private activeCamera:CyclingCamera|null=null;
  private disposed=false;
  private readonly low:boolean;

  constructor(host:HTMLDivElement,options:{lowQuality:boolean;outfit:NanyuOutfit;difficulty?:CyclingDifficulty;onTransition?:(busy:boolean)=>void}) {
    this.host=host;this.low=options.lowQuality;this.difficulty=getCyclingDifficulty(options.difficulty).id;this.onTransition=options.onTransition;
    try {
    this.scene.name=`难鱼骑自行车 · ${getCyclingDifficulty(this.difficulty).mapName}`;
    this.renderer=new THREE.WebGLRenderer({antialias:!this.low,alpha:false,powerPreference:'high-performance'});
    this.character=new NanyuCharacter();
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,this.low?1:2));
    this.renderer.outputColorSpace=THREE.SRGBColorSpace;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;
    this.renderer.shadowMap.enabled=!this.low;this.renderer.shadowMap.type=THREE.PCFSoftShadowMap;
    const canvas=this.renderer.domElement;canvas.dataset.testid='cycling-canvas';canvas.dataset.scene='cycling';canvas.setAttribute('role','img');canvas.setAttribute('aria-label','难鱼在独立村外绿道骑自行车的 3D 场景');
    canvas.style.cssText='display:block;width:100%;height:100%;touch-action:none';host.appendChild(canvas);host.dataset.testid||='cycling-scene';
    this.controls=new CyclingCameraControls(canvas,(azimuth,polar)=>this.rotateCamera(azimuth,polar),factor=>this.zoomCamera(factor));
    this.environment=new CyclingEnvironment(this.low,this.difficulty);
    this.scene.add(this.ambient);this.applyEnvironmentLighting();
    this.sunlight.position.set(-12,24,7);this.sunlight.target.position.set(0,0,-16);this.sunlight.castShadow=!this.low;
    Object.assign(this.sunlight.shadow.camera,{left:-20,right:20,top:30,bottom:-30,near:1,far:80});this.sunlight.shadow.camera.updateProjectionMatrix();this.sunlight.shadow.mapSize.set(this.low?512:2048,this.low?512:2048);this.sunlight.shadow.bias=-.0004;this.sunlight.shadow.normalBias=.035;
    this.scene.add(this.sunlight,this.sunlight.target,this.rider,this.finish,this.environment.root,this.impactDust);
    this.cameraBlockers.push(...this.environment.blockers);this.nearRoadTrees.push(...this.environment.roadTrees);
    this.makeBicycle();this.makeFinish();
    for(let i=0;i<9;i++){const dust=this.mesh(this.impactDust,this.geometry('impact-dust',()=>new THREE.IcosahedronGeometry(.07,0)),this.material('#ddba7f'),point(0,0,0));dust.castShadow=false;}this.impactDust.visible=false;
    this.character.setQuality(this.low);this.character.setOutfit(options.outfit);this.rider.add(this.character.root);
    this.rider.rotation.y=Math.PI;this.rider.scale.setScalar(RIDER_SCALE);
    host.dataset.difficulty=this.difficulty;host.dataset.map=this.environment.theme;host.dataset.riderInstance=this.rider.uuid;host.dataset.rendererInstance=String(++rendererSequence);host.dataset.sceneRevision='0';host.dataset.sceneLoading='false';host.dataset.sceneTransition='ready';
    this.resizeObserver=new ResizeObserver(()=>this.resize());this.resizeObserver.observe(host);this.resize();
    } catch(error) {
      this.dispose();throw error;
    }
  }

  get transitioning() { return Boolean(this.transition); }

  private applyEnvironmentLighting() {
    const palette=this.environment!.palette;
    this.scene.name=`难鱼骑自行车 · ${getCyclingDifficulty(this.difficulty).mapName}`;
    this.scene.background=new THREE.Color(palette.sky);this.scene.fog=new THREE.Fog(palette.fog,80,this.difficulty==='hard'?190:175);this.renderer.toneMappingExposure=palette.exposure;
    this.ambient.color.set(palette.hemi);this.ambient.groundColor.set(palette.bounce);this.ambient.intensity=palette.ambient;
    this.sunlight.color.set(palette.sun);this.sunlight.intensity=palette.sunPower;
    if(this.difficulty==='hard'&&!this.low&&!this.headlight){this.headlight=new THREE.SpotLight('#f3e7bf',14,32,.48,.8,1.4);this.headlight.position.set(0,1.75,1.25);this.headlight.target.position.set(0,.15,14);this.rider.add(this.headlight,this.headlight.target);}
    if(this.headlight)this.headlight.visible=this.difficulty==='hard';
  }

  /** Keep the expensive renderer, rider and bicycle alive when selecting a map. */
  async setDifficulty(difficulty:CyclingDifficulty,state:CyclingState,camera:CyclingCamera):Promise<boolean> {
    if(this.disposed)return false;
    this.transition?.abort();
    const transition=new AbortController();this.transition=transition;
    this.controls?.cancelGesture();this.host.dataset.sceneLoading='true';this.host.dataset.sceneTransition='loading';this.onTransition?.(true);
    try {
      if(!await waitForScenePaint(transition.signal))return false;
      this.host.dataset.sceneTransition='building';
      if(this.difficulty!==difficulty){
        // Build before disposing the old map so a construction failure retains it.
        const environment=new CyclingEnvironment(this.low,difficulty);
        this.environment?.dispose();this.environment=environment;this.difficulty=difficulty;
        this.scene.add(environment.root);this.cameraBlockers.length=0;this.nearRoadTrees.length=0;
        this.cameraBlockers.push(...environment.blockers);this.nearRoadTrees.push(...environment.roadTrees);this.applyEnvironmentLighting();
      }
      this.clearFeedback();for(const group of this.itemObjects.values())group.removeFromParent();this.itemObjects.clear();
      this.time=0;this.lastDistance=0;this.lastX=state.x;this.steering=0;this.activeCamera=null;this.orbitActive=false;
      delete this.host.dataset.course;
      this.host.dataset.difficulty=this.difficulty;this.host.dataset.map=this.environment!.theme;
      this.renderFrame(state,camera,0);
      this.host.dataset.sceneRevision=String(++this.transitionRevision);
      if(!await waitForScenePaint(transition.signal))return false;
      return true;
    } catch(error) {
      if(this.transition===transition&&!this.disposed)this.host.dataset.sceneTransition='error';
      throw error;
    } finally {
      if(this.transition===transition&&!this.disposed){this.transition=undefined;this.host.dataset.sceneLoading='false';if(this.host.dataset.sceneTransition!=='error')this.host.dataset.sceneTransition='ready';this.onTransition?.(false);}
    }
  }

  private geometry(key:string,make:()=>THREE.BufferGeometry) {
    let geometry=this.geometries.get(key);if(!geometry){geometry=make();this.geometries.set(key,geometry);}return geometry;
  }
  private material(color:string,metalness=0,emissive?:string) {
    const key=`${color}:${metalness}:${emissive??''}`;let material=this.materials.get(key);
    if(!material){material=new THREE.MeshStandardMaterial({color,roughness:metalness?.36:.88,metalness,emissive:emissive??'#000000',emissiveIntensity:emissive?.22:0});this.materials.set(key,material);}return material;
  }
  private mesh(parent:THREE.Object3D,geometry:THREE.BufferGeometry,material:THREE.Material,position:THREE.Vector3,scale?:THREE.Vector3) {
    const mesh=new THREE.Mesh(geometry,material);mesh.position.copy(position);if(scale)mesh.scale.copy(scale);mesh.castShadow=!this.low;mesh.receiveShadow=true;parent.add(mesh);return mesh;
  }
  private box(parent:THREE.Object3D,size:readonly number[],position:readonly number[],color:string,metalness=0) {
    return this.mesh(parent,this.geometry('box',()=>new THREE.BoxGeometry(1,1,1)),this.material(color,metalness),point(position[0],position[1],position[2]),point(size[0],size[1],size[2]));
  }
  private cylinder(parent:THREE.Object3D,radius:number,height:number,position:readonly number[],color:string,metalness=0,segments=16) {
    return this.mesh(parent,this.geometry(`cylinder:${segments}`,()=>new THREE.CylinderGeometry(1,1,1,segments)),this.material(color,metalness),point(position[0],position[1],position[2]),point(radius,height,radius));
  }
  private rod(parent:THREE.Object3D,a:THREE.Vector3,b:THREE.Vector3,radius:number,color:string,metalness=0) {
    const mesh=this.cylinder(parent,radius,a.distanceTo(b),[0,0,0],color,metalness,8);mesh.position.copy(a).add(b).multiplyScalar(.5);mesh.quaternion.setFromUnitVectors(point(0,1,0),b.clone().sub(a).normalize());return mesh;
  }
  private ring(parent:THREE.Object3D,radius:number,tube:number,position:readonly number[],color:string,metalness=0) {
    return this.mesh(parent,this.geometry(`torus:${radius}:${tube}`,()=>new THREE.TorusGeometry(radius,tube,this.low?6:10,this.low?24:48)),this.material(color,metalness),point(position[0],position[1],position[2]));
  }
  private label(parent:THREE.Object3D,text:string,width:number,height:number,bg:string,fg:string) {
    const canvas=document.createElement('canvas');canvas.width=768;canvas.height=192;const ctx=canvas.getContext('2d')!;
    ctx.fillStyle=bg;ctx.fillRect(0,0,768,192);ctx.strokeStyle=fg;ctx.lineWidth=4;ctx.strokeRect(12,12,744,168);ctx.fillStyle=fg;ctx.font='bold 64px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(text,384,99,710);
    const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;this.textures.add(texture);
    const material=new THREE.MeshStandardMaterial({map:texture,roughness:.8,side:THREE.DoubleSide});this.materials.set(`label:${text}`,material);
    return this.mesh(parent,this.geometry('plane',()=>new THREE.PlaneGeometry(1,1)),material,point(0,0,0),point(width,height,1));
  }

  private makeBicycle() {
    const frame='#c8794d',trim='#ead9af',ink='#293c3b',chrome='#b9cfcc',rig=CYCLING_RIG;
    const rear=point(0,WHEEL_RADIUS,-1.25),front=point(0,WHEEL_RADIUS,1.25),crank=point(0,rig.crankY,rig.crankZ),seat=point(0,1.53,-.42),stem=point(0,1.66,1.05);
    for(const z of [-1.25,1.25]) {
      const wheel=new THREE.Group();wheel.name=z<0?'cycling-rear-wheel':'cycling-front-wheel';wheel.position.set(0,WHEEL_RADIUS,z);this.rider.add(wheel);this.wheelGroups.push(wheel);
      this.ring(wheel,WHEEL_RADIUS-.055,.063,[0,0,0],ink).rotation.y=Math.PI/2;
      this.ring(wheel,WHEEL_RADIUS-.11,.017,[0,0,0],chrome,.7).rotation.y=Math.PI/2;
      this.ring(wheel,WHEEL_RADIUS-.073,.013,[.041,0,0],'#c8c7ad',.2).rotation.y=Math.PI/2;
      const spokes=this.low?10:16;for(let i=0;i<spokes;i++){const a=i/spokes*TAU;this.rod(wheel,point(i%2?.04:-.04,0,0),point(0,Math.cos(a)*.59,Math.sin(a)*.59),.007,chrome,.7);}
      this.box(wheel,[.06,.11,.22],[.014,.46,0],'#e9ba66',.4);
      const hub=this.cylinder(wheel,.075,.26,[0,0,0],chrome,.7);hub.rotation.z=Math.PI/2;
      const fender=this.mesh(this.rider,this.geometry('bike-fender',()=>new THREE.TorusGeometry(WHEEL_RADIUS+.028,.036,8,32,Math.PI)),this.material('#78877d',.65),point(0,WHEEL_RADIUS,z));fender.rotation.y=Math.PI/2;
    }
    for(const [a,b] of [[rear,seat],[seat,crank],[crank,rear],[seat,stem],[crank,stem],[stem,front]])this.rod(this.rider,a,b,.046,frame,.45);
    for(const side of [-1,1]){
      this.rod(this.rider,point(side*.1,1.5,-.42),point(side*.12,WHEEL_RADIUS,-1.25),.026,trim,.45);
      this.rod(this.rider,point(side*.105,1.6,1.05),point(side*.12,WHEEL_RADIUS,1.25),.029,chrome,.65);
    }
    this.rod(this.rider,point(0,1.35,-.42),point(0,rig.saddle[1],-.42),.035,chrome,.7);
    this.mesh(this.rider,this.geometry('saddle',()=>new RoundedBoxGeometry(.78,.16,.46,3,.06)),this.material('#394545'),point(0,rig.saddle[1]-.04,rig.saddle[2]));
    this.rod(this.rider,stem,point(0,rig.gripY-.08,rig.gripZ),.035,chrome,.8);
    this.handlebar.position.set(0,rig.gripY,rig.gripZ);this.rider.add(this.handlebar);
    this.rod(this.handlebar,point(-rig.gripX,0,0),point(rig.gripX,0,0),.034,chrome,.75);
    for(const side of [-1,1])this.rod(this.handlebar,point(side*.42,0,0),point(side*.7,0,0),.051,ink);
    this.cylinder(this.handlebar,.068,.055,[.31,.062,.01],'#c5ac76',.8);
    for(const side of [-1,1]){this.rod(this.handlebar,point(side*.43,-.025,.01),point(side*.60,-.09,.09),.013,chrome,.7);this.rod(this.rider,point(side*.43,rig.gripY-.07,rig.gripZ+.08),point(side*.08,1.31,1.2),.008,ink);}
    const lamp=this.cylinder(this.rider,.1,.1,[0,1.77,1.13],'#fff1b8',.3);lamp.rotation.x=Math.PI/2;
    const chainring=this.cylinder(this.rider,.20,.065,[.10,rig.crankY,rig.crankZ],chrome,.7);chainring.rotation.z=Math.PI/2;
    this.rod(this.rider,point(.11,.97,.02),point(.11,.79,-1.25),.014,ink,.5);this.rod(this.rider,point(.11,.59,.02),point(.11,.64,-1.25),.014,ink,.5);
    for(const side of [-1,1]) {
      const crankGroup=new THREE.Group();crankGroup.position.set(side*.16,rig.crankY,rig.crankZ);this.rider.add(crankGroup);this.crankGroups.push(crankGroup);
      this.rod(crankGroup,point(0,0,0),point(0,rig.crankRadius,0),.032,chrome,.75);this.rod(crankGroup,point(0,rig.crankRadius,0),point(side*(rig.pedalX-.16),rig.crankRadius,0),.026,chrome,.7);
      const pedal=new THREE.Group();pedal.name=side<0?'cycling-right-pedal':'cycling-left-pedal';this.rider.add(pedal);this.pedalGroups.push(pedal);
      this.box(pedal,[.26,.10,.28],[0,0,0],ink);this.box(pedal,[.27,.045,.065],[0,0,.142],'#efd589');
    }
    this.box(this.rider,[.45,.05,.58],[0,1.22,-1.15],chrome,.6);
    this.box(this.rider,[.31,.09,.13],[0,1.30,-1.4],'#e37352');
    const basket=new THREE.Group();basket.name='cycling-collection-basket';basket.position.set(0,1.30,-1.28);this.rider.add(basket);
    this.box(basket,[.76,.065,.58],[0,0,0],'#af8f63');
    for(const side of [-1,1])for(let i=0;i<3;i++){this.box(basket,[.77,.06,.045],[0,.09+i*.10,side*.30],'#c3a477');this.box(basket,[.045,.06,.59],[side*.385,.09+i*.10,0],'#c3a477');}
    for(const x of [-.37,.37])for(const z of [-.29,.29])this.box(basket,[.045,.35,.045],[x,.16,z],'#997c55');
  }

  private makeFinish() {
    for(const side of [-1,1])this.box(this.finish,[.24,5,.3],[side*4.25,2.5,0],'#277970');
    const banner=this.label(this.finish,'终 点  /  FINISH',8.8,1.35,'#217c70','#fff4d4');banner.position.set(0,4.6,0);
    for(let row=0;row<2;row++)for(let col=0;col<12;col++)this.box(this.finish,[.72,.02,.4],[(col-5.5)*.72,.025,row*.4],(row+col)%2?'#f7edce':'#3d6866');
    for(const side of [-1,1])for(let i=0;i<3;i++){const balloon=this.mesh(this.finish,this.geometry('balloon',()=>new THREE.SphereGeometry(1,12,8)),this.material(i%2?'#e5bd68':'#639d81'),point(side*(4.6+i*.35),3.1+i*.4,.15),point(.24,.3,.24));balloon.castShadow=false;}
  }

  private makeItem(item:RoadItem) {
    const group=new THREE.Group();group.name=`cycling-${item.kind}-${item.id}`;group.userData.kind=item.kind;
    if(item.kind==='hole') {
      this.cylinder(group,.85,.04,[0,.022,0],'#ba7957',0,32);
      this.cylinder(group,.72,.045,[0,.049,0],'#101e25',0,32);
      this.cylinder(group,.48,.047,[0,.051,0],'#060f18',0,28);
      const rim=this.ring(group,.76,.06,[0,.08,0],'#f29a61');rim.rotation.x=-Math.PI/2;
      for(let i=0;i<6;i++){const a=i/6*TAU;const warning=this.box(group,[.20,.022,.12],[Math.cos(a)*.81,.08,Math.sin(a)*.81],'#ffdf95');warning.rotation.y=-a;}
      // A second inset edge makes the opening read as depth, even in the night map.
      this.ring(group,.58,.016,[0,.058,0],'#3d4b54').rotation.x=-Math.PI/2;
    } else if(item.kind==='barrier') {
      for(const side of [-1,1]){this.box(group,[.11,1.05,.12],[side*.59,.53,0],'#885f4d');this.box(group,[.34,.09,.5],[side*.59,.045,0],'#6b6456');}
      this.box(group,[1.75,.44,.16],[0,.72,0],'#e7a45c');
      for(let i=-2;i<=2;i++){const stripe=this.box(group,[.15,.46,.18],[i*.33,.72,.01],'#4c4e40');stripe.rotation.z=-.4;}
      for(const side of [-1,1])this.cylinder(group,.065,.12,[side*.64,1.12,0],'#ee7254');
    } else {
      const halo=this.ring(group,.59,.035,[0,.065,0],'#f4cc65',.35);halo.rotation.x=-Math.PI/2;
      const collectible=new THREE.Group();collectible.name='floating-pickup';group.add(collectible);
      if(item.kind==='cover') {
        this.cylinder(collectible,.48,.1,[0,0,0],'#448d82',.7,28);
        this.ring(collectible,.43,.036,[0,.06,0],'#f1ce73',.55).rotation.x=-Math.PI/2;
        for(let i=-1;i<=1;i++){this.box(collectible,[.54,.023,.035],[0,.068,i*.13],'#b4d3b3',.4);this.box(collectible,[.034,.023,.54],[i*.13,.07,0],'#b4d3b3',.4);}
        collectible.rotation.z=.18;
      } else if(item.kind==='bottle') {
        this.cylinder(collectible,.19,.52,[0,.10,0],'#73c9bc',.3);this.cylinder(collectible,.10,.16,[0,.42,0],'#73c9bc',.3);this.cylinder(collectible,.115,.07,[0,.53,0],'#f0c46a');this.cylinder(collectible,.20,.16,[0,.11,0],'#f5e6bd');
      } else {
        this.box(collectible,[.66,.49,.49],[0,.05,0],'#cf9f65');this.box(collectible,[.12,.51,.5],[0,.05,0],'#f2dfb2');this.box(collectible,[.68,.06,.51],[0,.05,0],'#ecce93');
      }
    }
    this.scene.add(group);this.itemObjects.set(item.id,group);return group;
  }

  private clearFeedback() {
    for(const effect of this.pickupEffects){effect.group.removeFromParent();effect.sparkles.removeFromParent();}this.pickupEffects.length=0;
    this.lastEvent=0;this.hitAt=-100;this.impactDust.visible=false;
  }
  private pickupEvent(event:CyclingEvent,state:CyclingState,at:number) {
    const item=state.items.find(value=>value.id===event.itemId);if(!item)return;
    const source=this.itemObjects.get(item.id)??this.makeItem(item),pickup=source.getObjectByName('floating-pickup');if(!pickup)return;
    const group=new THREE.Group(),copy=pickup.clone(true);copy.position.set(0,0,0);group.add(copy);group.name=`collected-${event.kind}-${event.id}`;
    const start=point(event.lane*CYCLING_LANE_WIDTH,.70,state.distance-event.distance),sparkles=new THREE.Group();sparkles.name='pickup-sparkles';
    for(let i=0;i<(this.low?5:9);i++){const sparkle=this.mesh(sparkles,this.geometry('pickup-sparkle',()=>new THREE.OctahedronGeometry(.075)),this.material('#f8d274',.25,'#eab44b'),point(0,0,0));sparkle.castShadow=false;}
    this.scene.add(group,sparkles);this.pickupEffects.push({group,sparkles,start,at,side:event.lane*CYCLING_LANE_WIDTH>state.x? -1:1,kind:event.kind});
  }
  private animateFeedback(state:CyclingState) {
    if(state.distance<this.lastDistance-.1||state.eventId<this.lastEvent)this.clearFeedback();this.lastDistance=state.distance;
    for(const event of state.events){
      if(event.id<=this.lastEvent)continue;
      this.lastEvent=event.id;const age=Math.max(0,state.elapsed-event.at),at=this.time-age;
      if(event.type==='hit'&&age<.95){this.hitAt=at;this.hitSide=event.lane===0?(event.id%2?1:-1):Math.sign(event.lane);this.hitKind=event.kind;}
      else if(event.type==='pickup'&&age<1.05)this.pickupEvent(event,state,at);
    }
    let reach=0,reachSide=-1,pickupProgress=0;
    for(let i=this.pickupEffects.length-1;i>=0;i--){
      const effect=this.pickupEffects[i],age=this.time-effect.at,p=THREE.MathUtils.clamp(age/.72,0,1),ease=1-(1-p)**3;
      if(age>=1.05){effect.group.removeFromParent();effect.sparkles.removeFromParent();this.pickupEffects.splice(i,1);continue;}
      const target=point(state.x,1.14,.86);effect.group.position.copy(effect.start).lerp(target,ease);effect.group.position.y+=Math.sin(Math.PI*p)*1.15;
      // The rider faces -Z, so its local reaching arm has the opposite world-X sign.
      // Keep the lid outside the torso until it has reached the basket behind it.
      const sideArc=1.12*THREE.MathUtils.smoothstep(p,0,.2)*(1-THREE.MathUtils.smoothstep(p,.66,1));
      effect.group.position.x-=effect.side*sideArc;
      effect.group.scale.setScalar(1-p*.55);effect.group.rotation.y=p*TAU*(effect.kind==='cover'?1.5:.75);effect.group.rotation.z=Math.sin(Math.PI*p)*.25;effect.group.visible=p<1;
      effect.sparkles.position.copy(p<1?effect.group.position:target);
      const burst=THREE.MathUtils.clamp((age-.20)/.75,0,1),fade=1-THREE.MathUtils.clamp((age-.62)/.43,0,1);
      effect.sparkles.children.forEach((sparkle,j)=>{const a=j/effect.sparkles.children.length*TAU+age*1.3,radius=.10+burst*.55;sparkle.position.set(Math.cos(a)*radius,Math.sin(a*2)*radius*.7+burst*.12,Math.sin(a)*radius);sparkle.scale.setScalar(fade*(.6+Math.sin(Math.PI*burst)*.6));sparkle.rotation.set(age*4+j,age*3,0);});
      const amount=Math.sin(Math.PI*THREE.MathUtils.clamp(age/.60,0,1));if(amount>reach){reach=amount;reachSide=effect.side;}pickupProgress=Math.max(pickupProgress,age/1.05);
    }
    const hitAge=this.time-this.hitAt,hitActive=hitAge>=0&&hitAge<.95,p=THREE.MathUtils.clamp(hitAge/.95,0,1),decay=(1-p)**2;
    const impact=hitActive?decay*Math.min(1,hitAge/.045):0;
    this.impactDust.visible=hitActive;this.impactDust.position.set(state.x,.11,.12);
    if(hitActive)this.impactDust.children.forEach((dust,i)=>{const a=i/9*TAU,r=.15+p*1.1;dust.position.set(Math.cos(a)*r,Math.sin(Math.PI*p)*(.15+i%3*.09),Math.sin(a)*r);dust.scale.setScalar((1-p)*(i%2?.9:1.4));});
    this.host.dataset.pickupAnimation=this.pickupEffects.length?'active':'idle';this.host.dataset.hitAnimation=hitActive?'active':'idle';
    this.host.dataset.pickupProgress=pickupProgress.toFixed(3);this.host.dataset.hitProgress=hitActive?p.toFixed(3):'0';this.host.dataset.activePickups=String(this.pickupEffects.length);this.host.dataset.lastEvent=String(this.lastEvent);
    return {impact,reach,reachSide,hitAge,hitActive};
  }

  private resize() {
    if(this.disposed)return;const rect=this.host.getBoundingClientRect();this.width=Math.max(1,rect.width);this.height=Math.max(1,rect.height);
    this.renderer.setSize(this.width,this.height,false);this.camera.aspect=this.width/this.height;this.camera.updateProjectionMatrix();
  }

  private beginOrbit() {
    if(this.orbitActive)return;
    if(this.activeCamera===null)this.updateCamera('follow',0);
    this.lookTarget.set(this.rider.position.x,1.35,0);
    this.orbit.setFromVector3(this.orbitOffset.copy(this.camera.position).sub(this.lookTarget));
    this.orbitActive=true;
  }

  /** Public controls also support the keyboard while riding is paused. */
  rotateCamera(azimuthDelta:number,polarDelta:number) {
    if(this.disposed||this.transitioning||!Number.isFinite(azimuthDelta)||!Number.isFinite(polarDelta)||(azimuthDelta===0&&polarDelta===0))return;
    this.beginOrbit();this.orbit.theta+=azimuthDelta;this.orbit.phi+=polarDelta;
    this.updateCamera(this.activeCamera??'follow',0);this.renderer.render(this.scene,this.camera);
  }

  zoomCamera(factor:number) {
    if(this.disposed||this.transitioning||!Number.isFinite(factor)||factor<=0||factor===1)return;
    this.beginOrbit();this.orbit.radius*=factor;
    this.updateCamera(this.activeCamera??'follow',0);this.renderer.render(this.scene,this.camera);
  }

  resetCamera() {
    if(this.disposed||this.transitioning)return;
    this.controls?.cancelGesture();this.orbitActive=false;
    this.updateCamera(this.activeCamera??'follow',0);this.renderer.render(this.scene,this.camera);
  }

  private updateCamera(camera:CyclingCamera,dt:number) {
    const narrow=this.width/this.height<.8,change=this.activeCamera!==camera,x=this.rider.position.x;
    if(change){this.orbitActive=false;this.controls?.cancelGesture();this.activeCamera=camera;}
    if(this.orbitActive){
      this.orbit.theta=THREE.MathUtils.euclideanModulo(this.orbit.theta+Math.PI,TAU)-Math.PI;
      this.orbit.phi=THREE.MathUtils.clamp(this.orbit.phi,.18,1.42);
      this.orbit.radius=THREE.MathUtils.clamp(this.orbit.radius,5,28);
      this.lookTarget.set(x,1.35,0);
      this.camera.position.copy(this.lookTarget).add(this.orbitOffset.setFromSpherical(this.orbit));
    }else{
      if(camera==='overhead'){
        this.cameraPosition.set(x*.18,narrow?25:21,10);this.cameraTarget.set(0,0,narrow?-9:-10);this.camera.fov=50;
      }else if(camera==='side'){
        this.cameraPosition.set(narrow?6.5:16,narrow?11:13,narrow?11:-3);this.cameraTarget.set(0,1,narrow?-4:-6);this.camera.fov=narrow?61:57;
      }else{
        this.cameraPosition.set(x*.38+2.6,narrow?8.5:6.6,narrow?13.5:10.5);this.cameraTarget.set(x*.12,1,narrow?-9:-10);this.camera.fov=narrow?61:50;
      }
      const ease=change||dt===0?1:1-Math.exp(-dt*5);
      this.camera.position.lerp(this.cameraPosition,ease);this.lookTarget.lerp(this.cameraTarget,ease);
      this.orbit.setFromVector3(this.orbitOffset.copy(this.camera.position).sub(this.lookTarget));
    }
    this.camera.lookAt(this.lookTarget);this.camera.updateProjectionMatrix();
    this.updateCameraBlockers(camera);
    this.host.dataset.camera=camera;this.host.dataset.cameraMode=this.orbitActive?'orbit':'preset';
    this.host.dataset.cameraPosition=JSON.stringify(this.camera.position.toArray());
    this.host.dataset.cameraTarget=JSON.stringify(this.lookTarget.toArray());
    this.host.dataset.cameraOrbit=JSON.stringify({azimuth:this.orbit.theta,polar:this.orbit.phi,distance:this.orbit.radius});
  }

  private updateCameraBlockers(camera:CyclingCamera) {
    this.sightLine.set(this.camera.position,this.lookTarget);
    for(const {object,center,radius} of this.cameraBlockers){
      object.visible=true;
      if(this.orbitActive){
        object.updateWorldMatrix(true,false);this.blockerCenter.copy(center).applyMatrix4(object.matrixWorld);
        this.sightLine.closestPointToPoint(this.blockerCenter,true,this.nearestSightPoint);
        object.visible=this.nearestSightPoint.distanceToSquared(this.blockerCenter)>(radius+.3)**2;
      }
    }
    if(!this.orbitActive&&camera==='side')for(const tree of this.nearRoadTrees){
      const z=tree.position.z+(tree.parent?.position.z??0);tree.visible=z<-25||z>18;
    }
  }

  update(state:CyclingState,camera:CyclingCamera,delta:number) {
    if(this.disposed||this.transitioning)return;
    this.renderFrame(state,camera,delta);
  }

  private renderFrame(state:CyclingState,camera:CyclingCamera,delta:number) {
    const dt=THREE.MathUtils.clamp(Number.isFinite(delta)?delta:0,0,.1);this.time+=dt;
    const moving=state.phase==='riding';this.phase=state.distance/(RIDER_SCALE*WHEEL_RADIUS)*.42;
    const desiredSteering=moving&&dt>0?THREE.MathUtils.clamp((state.x-this.lastX)/(dt*9),-1,1):0;this.lastX=state.x;this.steering+=(desiredSteering-this.steering)*(1-Math.exp(-dt*10));
    const reaction=this.animateFeedback(state),jolt=reaction.impact,hitTime=reaction.hitAge;
    const pitch=jolt*(this.hitKind==='hole'?.18:-.13)*Math.cos(hitTime*17);
    this.rider.position.set(state.x,Math.max(0,jolt*(.06+Math.sin(hitTime*23)*.08)),0);
    this.rider.rotation.set(pitch,Math.PI,this.steering*-.13+jolt*this.hitSide*.16*Math.sin(hitTime*19));
    this.character.updateCycling(this.time,this.phase,this.steering,reaction);this.handlebar.rotation.y=this.steering*.10+jolt*Math.sin(hitTime*25)*.08;
    this.wheelGroups.forEach(wheel=>{wheel.rotation.x=state.distance/(RIDER_SCALE*WHEEL_RADIUS);});
    for(let i=0;i<2;i++){const side=i===0?-1:1,angle=this.phase+(i===0?Math.PI:0);this.crankGroups[i].rotation.x=angle;this.pedalGroups[i].position.set(side*CYCLING_RIG.pedalX,CYCLING_RIG.crankY+Math.cos(angle)*CYCLING_RIG.crankRadius,CYCLING_RIG.crankZ+Math.sin(angle)*CYCLING_RIG.crankRadius);}
    this.environment?.update(state.distance,this.time);
    this.finish.position.z=state.distance-CYCLING_LENGTH;this.finish.visible=this.finish.position.z>-155&&this.finish.position.z<20;
    let visibleItems=0;
    const currentIds=new Set(state.items.map(item=>item.id));
    for(const [id,group] of this.itemObjects)if(!currentIds.has(id)){group.removeFromParent();this.itemObjects.delete(id);}
    for(const item of state.items){
      const z=state.distance-item.distance,visible=!item.collected&&z>-112&&z<14;
      let group=this.itemObjects.get(item.id);if(!visible){if(group)group.visible=false;continue;}group??=this.makeItem(item);group.visible=true;group.position.set(item.lane*CYCLING_LANE_WIDTH,0,z);visibleItems++;
      const pickup=group.getObjectByName('floating-pickup');if(pickup){pickup.position.y=.62+Math.sin(this.time*2.7+item.distance)*.11;pickup.rotation.y=this.time*.65;}
    }
    this.updateCamera(camera,dt);
    this.host.dataset.pedalPhase=this.phase.toFixed(4);this.host.dataset.distance=state.distance.toFixed(2);this.host.dataset.visibleItems=String(visibleItems);
    if(!this.host.dataset.course)this.host.dataset.course=JSON.stringify(state.items.map(({id,kind,lane,distance})=>({id,kind,lane,distance})));
    this.renderer.render(this.scene,this.camera);
  }

  dispose() {
    if(this.disposed)return;this.disposed=true;this.transition?.abort();this.transition=undefined;this.controls?.dispose();this.resizeObserver?.disconnect();this.character?.dispose();this.clearFeedback();this.environment?.dispose();
    for(const geometry of this.geometries.values())geometry.dispose();for(const material of this.materials.values())material.dispose();for(const texture of this.textures)texture.dispose();
    this.sunlight.shadow.map?.dispose();this.scene.clear();this.itemObjects.clear();this.geometries.clear();this.materials.clear();this.textures.clear();
    if(this.renderer){this.renderer.renderLists.dispose();this.renderer.dispose();this.renderer.forceContextLoss();this.renderer.domElement.remove();}
  }
}
