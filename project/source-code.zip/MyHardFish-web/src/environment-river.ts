import * as THREE from 'three';
import type { EnvironmentBuilder } from './environment';
import { path, boundaryForest, lamp, flowerBed, fence } from './world-town-props';

export function buildRiver(b:EnvironmentBuilder) {
  b.bounds={minX:-28,maxX:28,minZ:-28,maxZ:28};b.chunkSize=14;b.navigationStep=.5;b.floor('#93a584','plaster',118);boundaryForest(b,30,64);b.spawn.set(-4,0,11);b.camera={desktop:[-7.2,6.3,10.4],mobile:[-6.4,6.7,10.9]};
  b.lighting={outdoor:true,fog:'#c5d7c8',fogNear:48,fogFar:140,sun:'#f4e4b8',sunIntensity:2.7,ambientIntensity:1.9};
  path(b,-17,0,5.4,52);path(b,-13,12,28,5);path(b,-8,0,19,4.5);path(b,22,0,4.5,52);path(b,-7,-11,23,4.8);
  const water=new THREE.Mesh(new THREE.PlaneGeometry(15.2,100),new THREE.MeshPhysicalMaterial({color:'#7daaa0',roughness:.23,metalness:.16,transparent:true,opacity:.92,clearcoat:.5}));water.rotation.x=-Math.PI/2;water.position.set(11,.01,0);water.receiveShadow=true;b.root.add(water);
  // Water blockers explicitly leave both the arched bridge and the dock open.
  b.obstacle(11,-21.1,14.8,13.8);b.obstacle(11,-5.9,14.8,6.2);b.obstacle(11,16.25,14.8,26.5);b.obstacle(16.8,0,3.2,5.7);
  for(let i=0;i<20;i++)b.surface([1.4+(i%3)*.7,.009,.035],[6.7+(i%4)*2.8,.033,-31+i*3.1],'#afd1bf','metal',0).castShadow=false;
  for(const side of [-1,1])for(let i=0;i<28;i++){
    const z=-32+i*2.4,x=11+side*(7.6+Math.sin(i*.7)*.2);if(Math.abs(z+11)<3||Math.abs(z)<3)continue;
    b.sphere([.65,.27,.55],[x,.20,z],i%2?'#b9c0a5':'#a2b195').castShadow=false;
    if(i%3===0)for(let n=0;n<5;n++){const reed=b.cylinder(.018,.027,.8+n*.11,[x+Math.sin(n)*.3,.52+n*.05,z+Math.cos(n)*.3],'#7d986c');reed.rotation.z=Math.sin(n)*.15;reed.castShadow=false;}
  }
  // Bridge walk height matches the slope of each individual plank.
  const bridgeY=(x:number)=>.12+Math.sin(THREE.MathUtils.clamp((x-1.7)/18.6,0,1)*Math.PI)*.95;
  for(let i=0;i<48;i++){const x=1.7+i*18.6/47,plank=b.surface([.405,.1,4.7],[x,bridgeY(x)-.05,-11],i%3?'#ab9470':'#bca17a','wood',.015);plank.rotation.z=Math.atan((bridgeY(x+.04)-bridgeY(x-.04))/.08);}
  for(const side of [-1,1])for(let i=0;i<13;i++){const x=1.7+i*1.55,y=bridgeY(x),z=-11+side*2.48;b.surface([.15,1.1,.15],[x,y+.5,z],'#91805c','wood',.025);if(i<12){const next=bridgeY(x+1.55),rail=b.surface([1.6,.1,.13],[x+.775,(y+next)/2+1.01,z],'#b09a73','wood',.02);rail.rotation.z=Math.atan2(next-y,1.55);}}
  b.obstacle(11,-13.55,19,.18);b.obstacle(11,-8.45,19,.18);b.heightZone(11,-11,18.6,4.76,x=>bridgeY(x));
  // Broad working dock, mooring posts, coiled rope and a rowboat beyond the bank.
  for(let i=0;i<40;i++)b.surface([.41,.12,4.8],[-2.5+i*.4,.13,0],i%4?'#b69d77':'#c4ad87','wood',.018);b.elevation(5.3,0,16,4.8,.19);
  for(const x of [-2.5,1.4,5.3,9.2,13.1])for(const side of [-1,1]){b.cylinder(.14,.19,1.6,[x,.24,side*2.45],'#857b5a');b.cylinder(.19,.19,.08,[x,1.07,side*2.45],'#bcaa80');}
  for(const side of [-1,1]){b.surface([15.8,.075,.075],[5.3,.88,side*2.45],'#c5b78b','wood',.015);b.obstacle(5.3,side*2.5,16,.12);}b.obstacle(13.3,0,.17,5);
  for(let i=0;i<4;i++){const rope=b.torus(.28+i*.045,.018,[9.2,.245,1.4],'#c1b188');rope.rotation.x=-Math.PI/2;}
  b.sphere([1.08,.5,2.4],[20,.21,6.8],'#ae9470').rotation.y=-.25;b.sphere([.85,.35,2.08],[20,.48,6.8],'#6f816b').rotation.y=-.25;
  for(const z of [5.8,7.55])b.surface([1.6,.11,.26],[20,.64,z],'#c5ad82','wood',.03);b.surface([.11,.1,3.5],[20.15,.74,6.65],'#c3ac81','wood').rotation.y=-.5;
  b.table(-7,9,3.8,1.6,1.05);b.surface([3.5,1.25,.12],[-7,1.95,8.5],'#bca57d','wood');b.label('狐狸的纸瓶信箱',[-7,2,8.58],3.2);
  for(let i=0;i<6;i++){b.cylinder(.12,.16,.48,[-8.2+i*.48,1.39,9.1],i%2?'#a4c3ab':'#83ada0');b.cylinder(.065,.075,.16,[-8.2+i*.48,1.7,9.1],'#b8cbb1');b.cylinder(.08,.08,.065,[-8.2+i*.48,1.81,9.1],'#b79d70');}
  // Raised quiet lookout with a matching continuous ramp and guardrails.
  b.surface([8,.62,7],[-13,.325,-15],'#b8b79a','stone',.12);b.elevation(-13,-15,8,7,.64);
  const ramp=b.surface([3.7,.10,4.55],[-13,.32,-9.25],'#c7c0a1','stone',.02);ramp.rotation.x=Math.atan(.64/4.5);b.heightZone(-13,-9.25,3.7,4.5,(_x,z)=>Math.max(0,Math.min(.64,(-7-z)/4.5*.64)));
  fence(b,-13,-18.3,8).position.y=.64;fence(b,-16.9,-15,6.5,Math.PI/2).position.y=.64;fence(b,-9.1,-15,6.5,Math.PI/2).position.y=.64;
  fence(b,-15.7,-11.5,2.45).position.y=.64;fence(b,-10.3,-11.5,2.45).position.y=.64;
  b.bench(-13,-16.25).position.y=.64;b.cylinder(.04,.07,1.45,[-10.5,1.46,-13.5],'#7f8970');const telescope=b.cylinder(.14,.18,1.1,[-10.5,2.23,-13.5],'#bbaa7e');telescope.rotation.z=-1.16;b.obstacle(-10.5,-13.5,.65,.65);
  for(const [x,z,s]of [[-23,-19,1.6],[-24,-7,1.4],[-6,-22,1.55],[-4,19,1.4],[25,17,1.6],[25,-20,1.5],[-22,22,1.2]])b.tree(x,z,s);
  for(const [x,z]of [[-20,6],[-20,-8],[-19,19],[0,11],[23,-6],[23,12]])lamp(b,x,z);
  b.bench(23.5,3,-Math.PI/2);b.bench(-10,19);flowerBed(b,-22,3,2,4.5);flowerBed(b,-3,18,2,5);
  const bottles=b.flagGroup('river_ready');for(let i=0;i<12;i++){const x=-9.7+(i%6)*1.2,z=7+Math.floor(i/6)*.55;b.cylinder(.09,.12,.32,[x,.8,z],'#bfd3a9',bottles);const light=b.sphere([.08,.10,.08],[x,.85,z],'#f9dea0',bottles),m=b.material('#f9dea0');m.emissive.set('#e3b477');m.emissiveIntensity=.7;light.material=m;}
  const quiet=b.flagGroup('quiet_ready');b.surface([.76,.11,.57],[-13.1,1.52,-16],'#b59c7a','fabric',.035,quiet);b.label('不用急着说话',[-13,2.2,-17.1],2.9,'#536d5b','#e8dcc0',quiet);
}
